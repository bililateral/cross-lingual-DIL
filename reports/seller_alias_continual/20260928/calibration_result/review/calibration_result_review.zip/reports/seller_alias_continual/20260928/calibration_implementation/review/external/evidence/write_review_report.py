from pathlib import Path
import json
E=Path(__file__).resolve().parent; TOP=E.parent
r=json.loads((E/'independent_outputs/independent_results.json').read_text())
source=json.loads((E/'submission_verification.json').read_text())
report=r'''# 冻结C排序后的概率校准：独立合同与实现外审

日期：2026-09-28。对象：本次明确授权上传的 calibration_review.zip。阶段：新阶段正式拟合／valid评价前的合同与实现外审，不是上一轮结果复审或本轮效果验收。

## 0. 总判定

**本次合同与实现外审通过。未发现经本轮检查确证、必须先修复的新增 SCIENTIFIC_BLOCKER 或 REPRODUCIBILITY_DEFECT；必须代码整改为0项。**

该计算能够检验用户已确认的问题：冻结A/C E6分数，保留C相对D/A的已有排序优势，只在既有训练内校准群拟合概率映射，检验相对校准A及原始A的概率损失保护。它不继续提高C自身排名，不是新编码器训练，也没有在本次审查中形成新方法创新或正式效能结果。

**此“通过”不表示六个正式映射已收敛、不表示正式顺序检查已通过，更不表示17项性能条件已经通过。** 原九模型结果仍为9过4败，18份Linux推理权重继续保留；不改写历史结果。本回复没有运行正式入口、消费本阶段正式标签、载入权重或开启test／持续学习。

| 审查类别 | 已确认新增缺陷 | 处置 |
|---|---:|---|
| SCIENTIFIC_BLOCKER | 0 | 方法能回答已确认问题；保留条件性及外部有效性边界 |
| REPRODUCIBILITY_DEFECT | 0 | 当前代码／来源／手工核验未显示必须修复的问题；不把未运行的正式行为写成实证 |
| OUT_OF_SCOPE_OVERDESIGN | 不据此另造整改 | 不要求重跑BGE、加seed、换校准族、扩大场景、额外模型下载或无关加固 |

下文的类别标注是审查维度；标为“未确认缺陷”的条目不是阻断清单。外审为建议，主执行者仍负责逐项核对和处置。用户已经确认具体新阶段方法、预算和train／valid各一次范围；依既定顺序完成主审及正式就绪汇报后执行，不重复询问同一范围，不绕过这些未完成的前置步骤。test仍须之后独立合同与授权。

## 1. 附件身份、阅读及审查边界

实际ZIP：1,286,211字节；SHA-256：

`77ab3765d0928a231fadae7cbb9d92049e0343c4a7518ea5478a0b2909bcf51d`

103成员＝102份来源＋source_inventory.json；来源解压字节合计2,399,944。ZIP完整性、全部来源大小及SHA逐项一致。当前26份执行依赖／合同来源、其中18份旧冻结来源与来源记录对应；没有修改提交文件。

已完整阅读本包 request.zh.md、SELLER_ALIAS_CALIBRATION.zh.md、decision.json、当前校准方法／运行器／审计器／16项测试和启动脚本，阅读实现说明、政策、两次CPU记录及当前主审记录；回读直接调用的分类／检索／bootstrap／二值计数／身份对齐代码。相关旧结果报告F1—F10及处置用于限定继承范围，没有把它当成本次方法有效性的证明。长篇交接和项目纪律仅回读本阶段相关段落，没有宣称重审其全部历史。

历史六模型E6的12份原分数及12份原指标文件，只核对文件字节大小／SHA和JSON身份对应，**没有把正式分数或矩阵解码成NumPy数组**。这应区别于“附件文件字节从未读取”。同样没有正式CSV、商品文本、owners、模型或凭据读取；没有网络访问项目服务器。

证据：`submission_verification.json`、`provenance_metadata_results.json`、最终`final_integrity.json`。本包无需真实模型载荷即可审查冻结分数后的标量计算，不能把权重未随包上传当作远端缺失。

## 2. 本次网页实际执行与独立性

网页现有环境：Linux，Python3.13.5、NumPy2.3.5、SciPy1.17.0，CPU亲和性[0]，OMP/MKL/OpenBLAS三环境变量均1；独立进程记录Threads:1。没有安装、升级或创建新环境。

项目CPU证据：既有py310，Python3.10.19／NumPy2.2.6／SciPy1.15.3，CPU0；当前记录为cpu/20260928_121900，GNU time 1.54秒，退出0，16项通过、0失败／错误／跳过。首次cpu/20260928_121500同样16项通过，GNU time 1.74秒。两次16份小型证据合计90,495字节，与cpu_sync逐文件对应。初次与当前仅运行器和测试两份来源变化；原始快照的大小／SHA与旧CPU记录匹配，其余24份来源不变。这是包内实测证据核对，不是网页访问远端进程。

| 网页执行 | 结果／范围 |
|---|---|
| 附件及来源核验 | 退出0；102份来源、两次CPU证据及18份旧冻结来源一致 |
| 提交的16项手工套件 | 实际16通过，0失败／错误／跳过；退出0。含6次完整规模手工映射和3个解析例子的真实SciPy求解 |
| 新增独立检查最终版 | 10项通过，退出0；包含6次另一手工夹具的完整规模拟合和4个独立解析／边界求解 |
| 两份早期新增检查 | 各9通过、1失败、退出1；失败均位于同一极端概率参考语义问题，原日志及源码完整保留，见§3 |
| 元数据身份、环境差异及最终完整性 | 实际核查，正式数组解析0；详细命令和退出码见execution记录 |

“16＋10”是最终不同测试用例数，不是26次科研实验。两次参考修订均为审查者手工测试，不是正式数据重试。若累计计数：提交套件9次真实手工求解；新增脚本三版各10次，累计30次；本次共39次手工标量求解，不含被mock的分支返回，不是39个模型训练或正式校准。

新增参考没有调用项目的NLL、梯度、指标或bootstrap函数来生成对应期望值。目标使用逐项Bernoulli标量式与解析Hessian／有限差分；AP／PR面积／AUC及查询排名采用单独循环，AUC另用正负两两比较；区间采用逐重复、逐域抽样后频数权重和手写线性分位数。概率指标的极端舍入单独对照90位Decimal，随后按冻结概率接口独立聚合；这一数值接口的复用被明确披露，而非冒称和冻结浮点算法无关的实数oracle。

最终版记录17,316个数值对照；其中720个手工valid群×22＝15,840个指标由独立定义核对。另在15个极端／并列手工群上比较330个指标。数值对照数量并非样本量或研究重复次数。

关键结果：

| 独立检查 | 最大误差或实际结果 |
|---|---:|
| NLL标量对照 | 2.220446049250313e−16 |
| 解析一阶梯度 | 1.1102230246251565e−16 |
| 独立有限差分一阶梯度 | 5.667133429199112e−12 |
| Hessian有限差分 | 7.220068987123796e−11 |
| 已知内部最优(a,b) | 1.712785469010214e−11 |
| 斜率上界例的(a,b) | 1.122731008162958e−8；在该解析求解测试预定2e−6容限内 |
| 固定浮点概率接口下，极端手工22指标 | 1.776356839400251e−15 |
| 完整手工流程valid指标 | 3.330669073875470e−16 |
| 非恒定四比较bootstrap区间 | 5.204170427930421e−18 |
| 完整手工流程四比较bootstrap区间 | 8.326672684688674e−17 |
| 六参数JSON＋12变换分数逐文件损坏 | 18/18拒绝，未解析valid |
| 4处采集后统计故障 | 12矩阵保全，保存结果恢复成功，无重拟合／标签解析 |
| 17项判据 | 各项单独触发失败；坏校准A不能绕过四个原A保护 |

上界参数误差、有限差分误差、概率浮点误差和指标误差使用各自有意义的判据；没有用参数2e−6或梯度1e−8容限放宽指标1e−12。

## 3. 审查者自己的两次失败与修订

新增脚本v1在极端手工a=100、b=−100映射上失败：参考概率写成直接`1/(1+exp(−z))`，与旧评价的`exp(−logaddexp(0,−z))`相差最多1个float64量级的末位，群log_loss差3.448325486488102e−6。90位Decimal核查最有影响的六个点，项目概率均等于理想概率正确舍入到float64，v1参考有±1 ULP差异。例如z=29.420297778384736、手工y=0，项目p=0.9999999999998329，v1为0.999999999999833。

v2改用高精度实数sigmoid再一次舍入，仍在同一测试有2.259525899717119e−12的群log_loss差：这说明“实数概率一次舍入”与“多步float64计算后取概率再clip”的数值接口也不必完全相等。这个差异并不是正式数据的发现。

v3将两个问题分开：一是独立计算冻结接口给出的概率、截断和逐群聚合，仍按1e−12比较；二是将该概率与独立高精度oracle比较，并用均值定理验证概率舍入传递到log_loss的误差界。所有检查通过。三组手工映射中最大概率差1.1102230246251565e−16；高精度参考与冻结接口的最大群log_loss差仍如实保留，没有改成0，也没有隐藏先前失败。

**未改项目源码、概率截断定义、正式指标阈值或验收标准。** 这是审查者参考对象的数值语义修订，不是经证实的项目缺陷。最小结论是：不得把实现规定的截断概率log_loss、其理想实数版本以及拟合用未截断NLL当成一个逐位相同的量；本次也未测正式分数中是否出现这种极端情况。

完整历史：`independent_calibration_checks_v1.py`、`independent_calibration_checks_v2.py`、最终脚本、两个diff、三版stdout/stderr/exit、`probability_rounding_diagnosis.json`、`error_and_revision_history.json`。所有v1／v2输出也保留。

## 4. F1—F10逐项判断

下列缩写：M=`scripts/step28_alias_calibration.py`；R=`scripts/step28_alias_calibration_run.py`；Q=`scripts/step28_alias_ranking.py`；E=`scripts/step28_continual_population_evaluate.py`；D=`scripts/step28_chinese_base.py`。行号对应本包未修改的文件。

### F1. 用户目标和新阶段的科学问题

**审查维度：SCIENTIFIC_BLOCKER；已确认缺陷：否。**

受影响主张：这不是“校准可以继续提高C排序”，而是“冻结C排序收益后，是否能满足相对D/A的概率保护”。

依据：decision.json的用户原话与question_scope；合同§1、3、5；M:15–29、150–179；R:381–428。实际固定s0/s1/s2、A/C、E6，六个映射各a/b两参数，无B、E3或最优seed选择。主比较为C_cal−A_cal，原始A仍作为概率参照；原C自身排序不变。

判断：这与最新已确认用途相符。若顺序／并列及原矩阵重放完全一致，原先9个排名及区分判据只是继承原结果；新阶段实质待检验的是对A_cal及A_raw的8个概率观察值条件。不能把旧排名区间的再次输出当成新增独立排名证据。这里是数学条件关系，不是预先宣布正式9项或17项已经运行通过。

最小处置：无需改方法。正式结果继续分别报告历史结果、新校准开发验收和未来test，不把任一替代其他。继续保留18权重，不加载或删除。

### F2. 拟合目标、归约、梯度与数学可解性

**审查维度：SCIENTIFIC_BLOCKER；已确认缺陷：否。**

受影响主张：实际训练的是原比例下的概率映射，不是通过类别重加权改变概率含义，也不是优化排名。

依据：M:32–49、97–147；R:141–184、209–253；E:58–64。

令t_i=a z_i+b，实际目标为

L(a,b)=mean[softplus(t_i)−y_i t_i]。

梯度为mean[(σ(t_i)−y_i)z_i]与mean[σ(t_i)−y_i]，与独立标量／有限差分一致。Hessian为

H=mean[σ(t_i)(1−σ(t_i)) [z_i,1]^T[z_i,1]]，为半正定。

因此这是有界凸优化问题，没有神经网络层面的非凸搜索；但常数分数等情况下不保证a/b分别唯一。独立常数分数例中只核对可识别的a z+b，而不错误要求特定a/b。

拟合共36×378=13,608对，720正对，正比例20/378。各群同样378对、各域同样12群，所以展平的未加权均值同时等于群均值／域等权均值。没有按查询、正负类别或域另加权。账号对相关不妨碍定义经验损失，却不能据此把13,608对当成独立推断样本；本轮有效重采样单位仍是群。

恒等映射a=1,b=0在约束域内，精确优化的校准集NLL不高于恒等值；实际另以1e−12数值容限检查。**这不能保证Brier下降，也不能保证任何valid概率损失下降。** 稳定NLL用于拟合；正式log_loss仍用旧评价的概率clip(1e−15,1−1e−15)。独立±1000错误预测例的未截断NLL=1000，旧截断log_loss=34.53917619362578，二者不同是预定定义，不是缺陷。

最小处置：无必须修改。不能将同一校准集NLL降低写成新valid效能；不得把Brier/log_loss直接解释成纯校准误差。[R3]

### F3. L-BFGS-B边界、停止与真实收敛记录

**审查维度：REPRODUCIBILITY_DEFECT／数值正确性；已确认缺陷：否。**

依据：M:23–25、52–67、97–147；policy.fit；CPU实际fit.json；独立解析求解记录。

初值(1,0)，a∈[0.001,100]、b∈[−100,100]；maxiter=200、maxfun=2000、maxls=40、maxcor=10、ftol=1e−12、gtol=1e−8、解析Jacobian。代码除检查success与预算，还检查最终有限NLL、不劣于恒等和投影梯度≤1e−6。失败结果先写fit.json再停；异常／预算中止记录failure.json，不自动换初值、求解器或重新解析。异常发生在求解器返回之前时没有完整OptimizeResult／最后迭代轨迹文件，不能把一般失败记录夸成每类中止都保有完整迭代状态。

**gtol=1e−8不是所有PASS都达到的梯度保证。** SciPy可能由ftol相对下降条件停止。[R1,R2] 包内手工s0_d实际由相对下降停止，投影梯度2.353525219600266e−8，高于1e−8但低于明确的1e−6接收限制。记录和代码一致，不是伪造收敛；正式报告应按保存的停止原因和实际梯度解释，不把它改写为“全部达到gtol”。

独立内部最优：两组x=−2、0.5，对应正比例0.2、0.8，解析a=2log(4)/2.5、b=−log(4)+2a；实际误差约1.71e−11。负相关对称例到a=0.001、b=0，原梯度指向约束外而投影梯度符合KKT；需要更大斜率的例到a=100、b≈−0.5，同样符合边界KKT。边界解本身不是数值失败，也不保证拟合族足以恢复目标概率。

最小处置：无需改优化器、范围或容限。网页SciPy1.17.0与项目1.15.3区分记录；相同手工夹具最大a/b差约7.77e−16／1.78e−15，最终NLL相同，但不作未来任意版本逐位保证。不要求安装／升级项目依赖。

### F4. 顺序、并列、概率饱和与阈值含义

**审查维度：SCIENTIFIC_BLOCKER；已确认缺陷：否。**

依据：M:61–94；R:225–238、269–280、300–311、333–343；E:28–100；D:269–276。

a>0在实数上保持顺序和并列。实现进一步对每群378个logit比较稳定排序索引及相邻并列块，拒绝新并列／翻转；一个群的全对顺序与并列保持，就保持该群所有27候选查询子列表的顺序和公开账号tie-break。评价阶段再要求14个曲线／检索列精确一致，且原始22列与旧矩阵一致。

必须说“logit顺序保持”，而不是“浮点概率严格递增”。概率可饱和为0或1；代码不按饱和或打印概率排名。独立极端、全并列、部分并列和一／二正例夹具均核对；float32相邻极小数被a=0.001,b=100映射成同一float64数时确实拒绝，没有以原分数代填。

固定概率0.5的实现使用变换logit≥0；实数上对应原logit≥−b/a。它不维持原logit0决策集合，也不以显示四舍五入后的概率回判。原极低误报诊断则始终在原logit空间比较旧阈值，映射后阈值仅作对应记录，不重搜。独立例z=1，旧阈值nextafter(1,+∞)，a=0.001,b=100，原决策为否，但映射阈值和映射分数都舍入成100.001、若直接比较会错误纳入；现实现选择原空间比较避免了这一问题。

最小处置：无代码整改。结果报告应继续披露固定0.5不等于固定原始决策边界；需要展示原始等价阈值时从实际保存a/b计算−b/a，不作阈值搜索。概率损失保护不保证固定阈值F1／recall或每种子每域均不降。

### F5. A/C公平比较及17项保护

**审查维度：SCIENTIFIC_BLOCKER；已确认缺陷：否。**

依据：M:15–29、150–179；Q:208–222；合同§5；独立17项单独失败和坏对照测试。

六模型使用完全相同36群和拟合过程，A也得到校准机会。主比较C_cal−A_cal保留13项：MAP幅度／区间／各种子方向3项；R5均值及s0严格增加2项；AP、AUC、Brier、log_loss的均值及s0保护8项。额外4项检查C_cal对原始A的Brier／log_loss在均值及s0均不增加。

对每个相应概率损失及统计层面，合取相当于

L(C_cal)≤min{L(A_cal),L(A_raw)}。

所以不能仅因A校准变差制造完整通过。由于A自身排名精确不变，主比较AP／AUC等保护也不会因校准A破坏顺序而被放松；顺序破坏会先作为实现错误拒绝。

这仍是观察值保护，均值与s0不下降不等于总体非劣效，不保证s1/s2每项或每域不降。C_cal−C_raw和A_cal−A_raw只是预定描述比较；合同没有要求每个模型都从校准获益，因此不能把某seed校准恶化自动另加成第18项。不得按valid在raw/calibrated、A/B/C、seed或轮次间事后挑选。

独立将17项分别单独破坏，均仅触发相应失败；构造“C比坏A_cal好但比A_raw差”时四个原A保护全部失败。最小处置：无，保持原标准；不得预宣称正式17项通过。

### F6. 六模型分数身份与新的一次监督边界

**审查维度：REPRODUCIBILITY_DEFECT；已确认缺陷：否。**

依据：R:57–138、141–206、381–428；历史job的manifest／partition／collected、六模型calibration.json；本次provenance_metadata_results.json。

实际只取s0/s1/s2的d/hard E6，每模型calibration36×378与development60×378；对模型点、源分数、原校准群序、旧阈值绑定和原指标引用逐项核验。原分区fit144／cal36／valid60无公开群ID交叉，三域各48／12／20，旧collected群序和域序对应。12份分数、12份旧矩阵的实际文件字节与旧记录匹配。本次没有解码这些正式数组，因此shape／dtype实际重检属于未来historical()正式预检，不冒称本次已经动态通过。

read_labels整CSV仅一次解析，核对完整378无向对、28个排序账号ID、重复／缺失及标签形式；只有选择的36群转换为拟合数组，其余144群不进入拟合。新解析顺序与旧公开输入的sorted seller顺序和组合对齐相同，原始cal／valid指标重放作为进一步对齐检查。文件哈希会另读字节，因此“一次”应理解为一次监督CSV解析，不是只有一次底层文件读取。

parse_once在解析前独占创建本阶段访问记录；失败后不可同目录重入。train解析一次供六映射共用；六映射完整保存重放和来源核验后才解析development一次。heldout入口不开放，不调用商品文本加载函数或任何权重加载函数。新许可由新阶段decision、来源绑定和就绪材料约束，不复用旧已消费许可。

最小处置：无。正式CSV的实际身份／真值尚未验证；不能以本次公开群ID及哈希检查宣称控制者级隔离或真值正确。完整正式execute没有执行，手工套件仅测试了错误授权的前置拒绝分支。

### F7. 六映射完整保存、恢复及valid前阻断

**审查维度：REPRODUCIBILITY_DEFECT；已确认缺陷：否。**

依据：R:209–281、409–417；独立手工流程、损坏测试、旧校准矩阵错配测试。

每次真实求解先保存包含a/b、求解状态、轨迹、来源和拟合群ID的fit.json。JSON恢复后，对calibration与development两角色重新变换完整原分数，要求与内存原结果完全一致；保存float64数组，再重载核对大小／SHA／shape／dtype、数值和顺序。六模型全部完成才写fitted，再核对六份原校准指标与历史矩阵；全部恢复后写prevalid，才允许valid解析。

独立使用另外手工数据完成六次13,608对SciPy拟合；12个角色数组完整重放。六JSON和12数组逐个字节损坏均拒绝；没有valid解析。旧cal原矩阵人为错配时，六个已有手工拟合记录全部保留，然后拒绝；该分支复用已测手工求解结果，不冒称进行了额外六次真实求解。注入求解失败状态，首个fit.json保留、无fitted完备标记、不重试。

最小处置：无。与历史模型权重不同，本阶段必须恢复的是小型映射与分数，不需要重复BGE前向或Adam恢复。本次未验证正式六映射；本次手工保存恢复不能替代正式分数上的实际保序检查。

### F8. 12矩阵保全、原始矩阵对应及仅保存结果恢复

**审查维度：REPRODUCIBILITY_DEFECT；已确认缺陷：否。**

依据：R:284–366；独立四处统计故障与恢复记录。

collect先计算并保存A_raw/A_cal/C_raw/C_cal×3的12份60×22矩阵及固定0计数，再保存六份历史raw参考矩阵和原阈值诊断，写collected；之后finalize检查完整角色集合、来源、政策、文件与矩阵、原始22列对旧矩阵和变换14个排名列不变，再比较和验收。

与旧阶段不同，此新collect并没有在单矩阵保存期间作跨模型比较／bootstrap；但每群指标计算本来必须在保存矩阵之前，不能将“先保存后统计”理解成没有逐群指标运算。采集阶段失败不保证全部12矩阵已齐，也不自动授权再次读取标签。

独立在summarize、paired_summary、逐seed metric_comparison和automatic_report四处注入采集后故障，12矩阵和SHA完备；禁止重新拟合／读标签／读取正式来源数组后finalize恢复。新输出的12个手工矩阵全部用独立22指标定义核对。公开evaluation.json不能覆盖；源码与政策错配会拒绝旧collected。

最小处置：无。若未来真的修改了统计源码，不能假称与旧collected的冻结来源相同；需如实保留新处理器的来源与重算关系，但不因此需要重读标签。既有R1／R2／R3不重新开门，本阶段也不存在新GPU资源判据。

### F9. 指标、四比较、条件bootstrap与结论范围

**审查维度：SCIENTIFIC_BLOCKER；已确认缺陷：否。**

依据：E:21–100、225–228；D:269–276、680–726、775–785；Q:185–222；M:166–179；R:344–365。

完整22列保留：AP、梯形PR-AUC、AUC、Recall@FPR≤1%、Brier、截断log_loss、固定0的precision/recall/F1/specificity/balanced_accuracy/MCC、MAP/MRR、Recall@1/3/5/10和NDCG@1/3/5/10。AP不是梯形面积；Recall@1/5是相关候选找回比例，不是首位命中／至少一个命中概率。群宏分类与先合并TP/FP/FN/TN再算比率分开。当前AP/AUC本身也为群内计算后的宏汇总，不是跨群全局曲线。

四比较是C_cal−A_cal、C_cal−A_raw、C_cal−C_raw、A_cal−A_raw。主条件区间先对同一群三个固定seed差取平均，再三域各20群整群有放回抽样，5000次、种子20260927、域等权、线性分位数。独立以交错域行和非恒定差验证，并在真实手工全流程输出上再验证；没有把3×60、查询或账号对视为独立样本。

区间条件于固定编码器、当前映射、种子、群数据和阈值，不包含映射重估、模型重训、重新生成及重复开发valid的偏差。完整17条件仅是开发观察值门槛，不是总体非劣效；辅助比较和众多区间没有自动多重校正。排名区间是原收益保留，不形成第二份独立证据。

最小处置：无。不要求加入ECE、不同校准族或新候选场景来通过本轮审查。可报告概率损失改善，但仅凭两种proper score不能证实退化根因被唯一定位为校准。[R3]

### F10. CPU证据、资源与尚未执行范围

**审查维度：REPRODUCIBILITY_DEFECT／OUT_OF_SCOPE_OVERDESIGN；已确认缺陷：否。**

依据：CPU两次audit、handmade、原始stderr、resource_usage、exit；primary_check及cpu_sync；R:369–434和新shell:14–40。

包内当前16项手工核验为真实SciPy调用，没有模拟优化器来冒充求解。网页复跑相同手工夹具并逐项用独立标量核对包内六个NLL和梯度记录，差异处于相应数值精度内。首次之后的三处对齐修补（数据清单、原cal指标、collected来源）有精确源快照和复测证据，不是正式数据重试。实际手工CPU没有BGE执行，本阶段也不需要BGE。

正式资源上限为单CPU、1小时／256MiB新增产物；shell timeout包含整个入口，内部预算检查覆盖job产物和流程，时间与输出是不同于RSS／旧权重体积的口径。当前手工规模证据支持小型实现可运行，但不是正式峰值或完成时间保证。已有18份大权重不属于本次新增产物；本次未检查远端现存性。

未执行：正式六映射拟合、正式train／valid解析、正式数组变换与排序检查、正式原矩阵重放、17项性能验收、实际正式预算、test及任何持续学习。数据仍为中文合成同群27候选且保证同控候选；20/378先验及三域生成条件下的概率不能直接视为真实市场同控概率。训练内校准群曾用于旧阈值，不称为从未使用的全新数据；多次valid开发偏差仍存在。当前联合三域模型及映射也不能被直接当成未来持续学习的纯首域初态。

最小处置：按既定核验／主审／就绪顺序推进已确认范围。不得要求重跑未变编码器、增加seed、校准族搜索、重读旧标签、自动test或额外真实市场实验作为本次外审通过条件。

## 5. 当前最小处置与可归档结论

本轮没有必须修改的源码、方法、边界、判据或预算。以下是结果表达应保留的精度，不是新增门槛：

1. “数值接收”按实际停止原因和≤1e−6投影梯度记录，不等同于所有求解达到gtol1e−8。
2. “保序”指经逐群顺序／并列核验的logit；显示或饱和概率不是排名依据。固定0.5允许原始决策边界改变；旧极低误报集合则固定。
3. 拟合未截断NLL、冻结概率clip后的log_loss以及理想实数NLL是不同量；概率舍入误差与指标定义分开解释。
4. A_cal和A_raw两条参照同时约束概率损失；即使17项通过，也只获得请求另行test合同的依据，不能回写旧9过4败或提前启动持续学习。

建议归档：

> 本次冻结C排序后的概率校准合同与实现外审通过，未确证必须先修复的新增科研／复现缺陷。实现与手工实证支持在不改动编码器和排序的条件下，公平校准A/C并检验17项开发要求；不承诺正式概率效果。历史排序结果和18权重保留决定不变。正式六映射、一次train／valid及17项结果尚未执行；按已确认范围完成主审和就绪汇报后推进，test与持续学习保持另行阶段边界。

## 6. 证据和外部技术核查

关键文件：

- `evidence/submission_verification.json`、`provenance_metadata_results.json`、`final_integrity.json`。
- `evidence/guarded_supplied_audit.py`、`supplied_audit_run/`、`supplied_audit_artifacts/`。
- `evidence/independent_calibration_checks.py`、v1／v2、两个diff、三次`independent_run_v*/`和三次`independent_outputs*`。
- `evidence/diagnose_probability_rounding.py`、`probability_rounding_diagnosis.json`、`error_and_revision_history.json`。
- `evidence/run_capture.py`及各次command.json、execution.json、stdout.log、stderr.log、exit_status.txt、resource_usage.log。空stderr也保留。
- 包内SHA256SUMS.json逐一列出文件大小和SHA。测试代码仅构造手工输入，完整结果中的`handmade_acceptance_only`不能当正式验收。

本次外部核查只用于确认数值接口和概率解释，不用于承诺实验收益。没有宣称重审合同引用论文的全部实验、运行其代码或访问任何项目远端。

[R1] SciPy 1.15.3官方minimize(method='L-BFGS-B')文档：ftol相对目标下降、gtol投影梯度及maxiter/maxfun/maxls语义。
https://docs.scipy.org/doc/scipy-1.15.3/reference/optimize.minimize-lbfgsb.html

[R2] SciPy 1.17.0同一官方接口文档：核对网页实际安装版本的相关选项；未使用数值Jacobian或workers并行。
https://docs.scipy.org/doc/scipy-1.17.0/reference/optimize.minimize-lbfgsb.html

[R3] scikit-learn官方Probability calibration说明：Brier/log_loss同时涉及可靠性和区分能力等，校准数据应与底层模型拟合数据区分；sigmoid校准并非一般效能保证。
https://scikit-learn.org/stable/modules/calibration.html
'''
(TOP/'calibration_review_report.zh.md').write_text(report)
Path('/mnt/data/calibration_review_report.zh.md').write_text(report)
findings=[]
for i,(title,category) in enumerate([
('用户问题与新阶段目标','SCIENTIFIC_BLOCKER'),('NLL归约梯度与凸性','SCIENTIFIC_BLOCKER'),('优化器边界及收敛','REPRODUCIBILITY_DEFECT'),('顺序并列和阈值','SCIENTIFIC_BLOCKER'),('公平对照与17条件','SCIENTIFIC_BLOCKER'),('来源和一次监督','REPRODUCIBILITY_DEFECT'),('六映射保存恢复','REPRODUCIBILITY_DEFECT'),('12矩阵保全和恢复','REPRODUCIBILITY_DEFECT'),('指标与条件区间','SCIENTIFIC_BLOCKER'),('证据资源和未执行范围','OUT_OF_SCOPE_OVERDESIGN')],1):
 findings.append({'id':f'F{i}','review_dimension':category,'confirmed_defect':False,'title':title,'mandatory_fix':None,'details':'See corresponding F section in calibration_review_report.zh.md'})
(E/'review_findings.json').write_text(json.dumps({'decision':'PASS_IMPLEMENTATION_REVIEW_WITHOUT_FORMAL_PERFORMANCE_CLAIM','mandatory_fixes':0,'formal_17_guards_verified':False,'formal_stage_executed':False,'findings':findings},ensure_ascii=False,indent=2))
(E/'external_source_register.json').write_text(json.dumps({'sources':[{'id':'R1','url':'https://docs.scipy.org/doc/scipy-1.15.3/reference/optimize.minimize-lbfgsb.html','scope':'Official parameter and stopping semantics; full relevant HTML obtained.'},{'id':'R2','url':'https://docs.scipy.org/doc/scipy-1.17.0/reference/optimize.minimize-lbfgsb.html','scope':'Actual web SciPy version interface verified; full relevant HTML obtained.'},{'id':'R3','url':'https://scikit-learn.org/stable/modules/calibration.html','scope':'Official proper-score and calibration explanation, not an efficacy guarantee.'}]},ensure_ascii=False,indent=2))
print('Report characters',len(report),'bytes',len(report.encode()))
