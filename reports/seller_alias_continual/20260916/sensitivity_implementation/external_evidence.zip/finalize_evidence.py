"""Final archive/copy integrity and audit scope, without any project execution."""
from pathlib import Path
import json,hashlib,re,zipfile,datetime
ROOT=Path('/mnt/data/sensitivity_review');COPY=Path('/mnt/data/sensitivity_test_copy');OUT=Path('/mnt/data/sensitivity_audit')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(n,o):(OUT/n).write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n')
m=json.loads((ROOT/'manifest.json').read_text());rows=m['files'];expected={x['path'] for x in rows}|{'manifest.json'}
result={'archive_bytes':Path('/mnt/data/review(1).zip').stat().st_size,'archive_sha256':sha('/mnt/data/review(1).zip'),'roots':{}}
for label,root in [('review_original',ROOT),('test_copy',COPY)]:
 actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()};checks=[]
 for r in rows:
  p=root/r['path'];ok=p.stat().st_size==r['bytes'] and sha(p)==r['sha256'];assert ok;checks.append({'path':r['path'],'match':ok})
 assert actual==expected,(label,actual-expected,expected-actual)
 assert (root/'manifest.json').read_bytes()==(ROOT/'manifest.json').read_bytes()
 result['roots'][label]={'files':len(actual),'listed_files_checked':len(rows),'all_match':True,'extra':[],'missing':[]}
save('final_integrity.json',result)
read_scope={'whole_new_files':['scripts/step28_continual_sensitivity.py','schema/step28_continual_sensitivity_policy.json','tests/test_step28_continual_sensitivity_contracts.py','scripts/run_step28_sensitivity_linux_20260916.sh','docs/SELLER_ALIAS_WEIGHT_SENSITIVITY.zh.md'],
 'direct_dependency_paths_reviewed':{'step28_continual_distillation.py':['contract/sources/origin/reference_baseline','ReplayState','populate_targets/save_memory','historical_loss/observed_update/train_replay/check_shared','expected_history/validated_scores'],
 'step28_continual_replay.py':['origin','ReplayState','expected_history','validated_scores','compare'],
 'step28_continual_expression_run.py':['contract/sources/public_inputs/attach_labels','segment/segment_schedule/train_segment','validated_scores/paired_summary'],
 'step28_continual_population.py':['model/optimizer','tokenization/account-pooling/pair-logits','backward/update/score','state_digest/save_state/restore_state'],
 'step28_continual_population_run.py':['Budget/checkpoint_reserve/remove_work_file','point/retain_inference'],
 'step28_continual_population_data.py':['serialization/hash/verify','Group/align_labels','Memory/seed_for/schedule'],
 'step28_continual_population_evaluate.py':['COLUMNS','curve_metrics/confusion_metrics/classification/retrieval']},
 'historical_full_replies':[{'id':'d6c46b25-358a-4880-adec-1af2e262de55','source':'reports/seller_alias_continual/20260915/distillation_implementation/review_reply.json','text_selector':'last[0].text','characters':7798},
 {'id':'b2af6353-cadb-4e07-a855-997d0ac1e136','source':'reports/seller_alias_continual/20260915/distillation_evaluation/20260915_181330/review_reply.json','text_selector':'message.text','characters':8897}],
 'historical_resolution_records_read':['reports/seller_alias_continual/20260915/distillation_implementation/review_verification.json','reports/seller_alias_continual/20260915/distillation_evaluation/20260915_181330/review_verification.json','reports/seller_alias_continual/20260915/distillation_evaluation/20260915_181330/resource_wording_correction.json'],
 'not_claimed':'Not all 210 background files read word-for-word; no original paper or external literature newly reviewed; no old audit script/suite executed'}
save('reading_scope.json',read_scope)
test=json.loads((OUT/'new_contracts_run.json').read_text());hand=json.loads((OUT/'independent_hand_checks.json').read_text());history=json.loads((OUT/'source_history_checks.json').read_text())
log=(OUT/'new_contracts.log').read_text(); assert re.search(r'Ran 8 tests in 7\.383s\n\nOK',log)
assert 'FAILED' not in log and 'skipped ' not in log
test.update({'tests':8,'passed':8,'skipped':0,'failures':0,'errors':0,'unittest_seconds':7.383,'real_cpu_torch_tests':2,'other_hand_fixture_or_mock_tests':6,'old_tests_discovered':0,'formal_label_parses':0})
save('new_contracts_run.json',test)
scope={'review_type':'Approved two-configuration plan/implementation review only','reviewer_self_identification':'GPT-6 Astra Pro','current_webpage_model_slug_independently_read':False,'historical_model_attributes_preserved':True,
 'scientific_blockers':[],'reproducibility_defects':[],
 'out_of_scope_overdesign':['additional weight grid/capacity/data/seeds/selection algorithms','new success criteria/utility','GPU smoke','signatures/hardening/new monitoring','full old test-suite or repeated review gate'],
 'verdict':'No confirmed implementation blocker within examined scope; no source fix required. Principal checks and already-required Linux report/pause remain. No launch approval.',
 'production_sources_changed':False,'new_scientific_results':False,'new_formal_permissions_consumed':{'train':0,'valid':0,'test':0,'owners':0},'project_linux_connection_or_resource_probe':False,
 'actual_tests':test,'independent_hand_check_families':3,'hand_comparison_scalars':hand['comparison_scalar_values_checked'],'hand_comparison_max_error':hand['comparison_max_abs_error'],
 'hand_checks_are_scientific_observations':False,'saved_matrix_files_read':29,'saved_blind_score_files_read':18,'saved_shared_metric_elements_exactly_compared':7920,
 'official_AP_recomputed_from_truth':False,'production_entrypoints_executed':False,'formal_model_or_LaBSE_loaded':False,
 'handcrafted_evaluate_executed_with_mocked_Windows':True,'handcrafted_CSV_parser_executed_only_inside_requested_contracts':True,'toy_torch_models_adam_and_disk_reload_executed':True,
 'real_CUDA_LaBSE_activation_checkpointing':False,'new_end_to_end_parent_run_executed':False,
 'historical_updates_or_results_reexecuted':False,'historical_audit_counts_not_merged':[17986,5764],
 'audit_script_correction':{'file':'audit_sources_history.py','initial_error':'Assumed original SEQ evaluation contains config; it does not','fix':'Always verify fixed score manifest link; compare config only for ER/distillation where field exists','failed_log_preserved':'source_history_checks_attempt1.log','project_defect':False,'labels_read':False},
 'future_existing_requirements':['Linux py310 2 CPU contracts passed with zero skips before formal train parse','parent train parse once and children zero','6 shared full model/Adam/original valid exact reconstructions','3240 actual updates with 12 weighted first-update branch records','18 full double-score/reload points','12 restored caches and 50 own-branch target forwards','6 retained inference models verified','parent total runtime/output receipts and late file accounting','both branches and all references complete before one Windows valid parse']}
save('review_scope_and_verdict.json',scope)
print(json.dumps({'final_integrity':result,'tests':test['tests'],'torch':hand['environment']['torch'],'verdict':scope['verdict']},ensure_ascii=False,indent=2))
