"""Only artificial tensors/metric matrices: never call run, evaluate or a label parser.
The six comparison invocations below are software examples, not new study results.
"""
from pathlib import Path
import sys,json,math,time,platform
import numpy as np
import torch
sys.path.insert(0,'/mnt/data/sensitivity_test_copy/scripts')
import step28_continual_sensitivity as sens
OUT=Path('/mnt/data/sensitivity_audit'); torch.set_num_threads(1)
t0=time.monotonic()
# 1. Fully independent 378-edge analytical logit gradient, with stable BCE.
z=np.linspace(-3.0,2.0,378); target=np.linspace(.7,-1.1,378)
y=np.zeros(378); y[np.arange(20)*17]=1
bce=float(np.mean(np.logaddexp(0,z)-y*z));mse=float(np.mean((z-target)**2))
gradients={};loss_checks=[]
for alpha,beta in ((1.,.5),(.5,.5),(1.,.25)):
 x=torch.tensor(z,dtype=torch.float64,requires_grad=True)
 loss,raw_bce,raw_mse=sens.historical_loss(x,torch.tensor(y),torch.tensor(target),alpha,beta)
 loss.backward()
 expected=alpha*(1/(1+np.exp(-z))-y)/378+2*beta*(z-target)/378
 err=float(np.max(np.abs(x.grad.numpy()-expected)))
 assert math.isclose(float(loss.detach()),alpha*bce+beta*mse,rel_tol=1e-12,abs_tol=1e-12)
 assert err<1e-14
 gradients[alpha,beta]=x.grad.numpy().copy()
 loss_checks.append({'alpha':alpha,'beta':beta,'max_gradient_error':err,'loss_formula_matched':True})
np.testing.assert_allclose(gradients[1.,.5]-gradients[.5,.5],.5*(1/(1+np.exp(-z))-y)/378,rtol=1e-12,atol=1e-15)
np.testing.assert_allclose(gradients[1.,.5]-gradients[1.,.25],.5*(z-target)/378,rtol=1e-12,atol=1e-15)
# 2. Hand-built trajectories, independent counts-weighted bootstrap on shared domains.
D='ABC';ORDERS=('ABC','BCA','CAB');cols=sens.metrics.COLUMNS
c=sens.contract();draws=np.random.default_rng(20260910).integers(0,20,size=(5000,3,20))
draw_copy=draws.copy();counts=np.zeros((5000,3,20),dtype=np.int64)
for d in range(3):
 for j in range(20):counts[:,d,j]=(draws[:,d,:]==j).sum(1)
def trajectories(k,candidate):
 d=np.repeat(np.arange(3),20)[:,None];g=np.tile(np.arange(20),3)[:,None];m=np.arange(22)[None,:]
 base=.15+.03*d+.004*g+.0007*m
 a={'initial':base.copy()}
 for oi,o in enumerate(ORDERS):
  i,j,l=map(D.index,o)
  shared=base+.14*(d==i)+.002*oi
  second=shared+(.085-.01*k)*(d==j)-(.06-.008*k)*(d==i)+.01*(d==l)+(g-9.5)*.00015*k*((m%3)+1)
  final=second+(.09-.007*k)*(d==l)-(.022-.005*k)*(d==i)-(.01-.002*k)*(d==j)+.00003*k*(g-9.5)*(d-1)
  a[o+'_shared']=shared
  for s,x in ((2,second),(3,final)):a[o+('_distill_stage' if candidate else '_stage')+str(s)]=x
 if candidate:del a['initial']
 return a
def independent(candidate,reference,role):
 metrics={}
 for col,name in enumerate(cols):
  def at(a,key,d):return a[key].reshape(3,20,22)[D.index(d),:,col]
  contrast_names=('H','N','G_candidate','G_reference','F_candidate','F_reference','second_candidate_change','second_reference_change','final_candidate_minus_reference')
  pools={k:{d:[] for d in D} for k in contrast_names};by_order={}
  for o in ORDERS:
   u,v,w=o
   start=at(reference,o+'_shared',u);ce=at(candidate,o+'_distill_stage3',u);re=at(reference,o+'_stage3',u)
   local={'H':ce-re,'F_candidate':start-ce,'F_reference':start-re}
   for k,x in local.items():pools[k][u].append(x)
   nt=[];gc=[];gr=[]
   for s,d in ((2,v),(3,w)):
    ca=at(candidate,o+f'_distill_stage{s}',d);ra=at(reference,o+f'_stage{s}',d)
    cb=at(candidate,o+('_shared' if s==2 else '_distill_stage2'),d)
    rb=at(reference,o+('_shared' if s==2 else '_stage2'),d)
    n=ca-ra;cg=ca-cb;rg=ra-rb
    for k,x in (('N',n),('G_candidate',cg),('G_reference',rg)):pools[k][d].append(x)
    nt.append(n);gc.append(cg);gr.append(rg)
   for k,a,pre in (('second_candidate_change',candidate,'_distill_stage'),('second_reference_change',reference,'_stage')):
    x=at(a,o+pre+'3',v)-at(a,o+pre+'2',v);pools[k][v].append(x);local[k]=x
   for d in D:pools['final_candidate_minus_reference'][d].append(at(candidate,o+'_distill_stage3',d)-at(reference,o+'_stage3',d))
   by_order[o]={**{k:float(np.mean(v)) for k,v in local.items()},'N':float(np.mean(nt)),'G_candidate':float(np.mean(gc)),'G_reference':float(np.mean(gr)),
     'N_transitions':[float(np.mean(v)) for v in nt],'G_candidate_transitions':[float(np.mean(v)) for v in gc],'G_reference_transitions':[float(np.mean(v)) for v in gr]}
  summaries={}
  for k,pool in pools.items():
   delta=np.stack([np.mean(pool[d],axis=0) for d in D])
   sample=np.einsum('ndg,dg->n',counts,delta)/60
   summaries[k]={'mean':float(np.mean(delta)),'by_domain_or_first_domain':np.mean(delta,axis=1).tolist(),'conditional_95pct_interval':np.quantile(sample,[.025,.975]).tolist()}
  absolute={'initial':{d:float(np.mean(at(reference,'initial',d))) for d in D},
   'shared':{o:{d:float(np.mean(at(reference,o+'_shared',d))) for d in D} for o in ORDERS},'final':{}}
  for label,a,suffix in (('candidate',candidate,'_distill_stage3'),('reference',reference,'_stage3')):
   v={o:{d:float(np.mean(at(a,o+suffix,d))) for d in D} for o in ORDERS}
   absolute['final'][label]={'by_order_and_domain':v,'domain_order_group_equal_mean':float(np.mean([x for r in v.values() for x in r.values()]))}
  metrics[name]={'contrasts':summaries,'by_order':by_order,'absolute':absolute}
 result={'metrics':metrics,'reference_role':role}
 if role=='sequential':
  ap=metrics['average_precision'];same=[o for o,v in ap['by_order'].items() if v['H']>0 and v['G_candidate']>=.02]
  h=ap['contrasts']['H'];n=ap['contrasts']['N']
  checks={'retention':h['mean']>=.01 and h['conditional_95pct_interval'][0]>0,'new_capability':n['conditional_95pct_interval'][0]>=-.01,'same_order_learning_and_retention':len(same)>=2}
  result['gate']={'checks':checks,'same_orders':same,'passed':all(checks.values())}
 return result
numeric_count=0;max_error=0.;comparisons=[]
def match(a,b):
 global numeric_count,max_error
 if isinstance(a,dict):
  assert set(a)==set(b),(set(a)-set(b),set(b)-set(a))
  for k in a:match(a[k],b[k])
 elif isinstance(a,list):
  assert len(a)==len(b)
  for x,y in zip(a,b):match(x,y)
 elif isinstance(a,bool) or isinstance(a,str):assert a==b
 elif isinstance(a,(float,int)):
  numeric_count+=1;err=abs(a-b);max_error=max(max_error,err);assert err<1e-12,(a,b)
 else:assert a==b
for arm,k in zip(sens.ARMS,(3,4)):
 candidate=trajectories(k,True)
 for role,rk in (('sequential',0),('random_er',1),('original_distillation',2)):
  ref=trajectories(rk,False);actual=sens.compare(candidate,ref,draws,c,role);expected=independent(candidate,ref,role);match(actual,expected)
  comparisons.append({'artificial_candidate':arm,'role':role,'correct_gate_presence':('gate' in actual)==(role=='sequential')})
assert np.array_equal(draws,draw_copy)
# 3. Minimal same-order intersection and N-vs-G counterexamples.
def constant(x):return np.full((60,22),x)
ref={'initial':constant(.4)};candidate={}
for o,h,g in zip(ORDERS,(.02,.02,-.01),(0.,.03,.03)):
 ref[o+'_shared']=constant(.5);ref[o+'_stage2']=constant(.5);ref[o+'_stage3']=constant(.5)
 candidate[o+'_shared']=constant(.5);candidate[o+'_distill_stage2']=constant(.5);candidate[o+'_distill_stage3']=constant(.5)
 first,second,third=map(D.index,o)
 candidate[o+'_distill_stage2'][second*20:(second+1)*20]+=g
 candidate[o+'_distill_stage3'][third*20:(third+1)*20]+=g
 candidate[o+'_distill_stage3'][first*20:(first+1)*20]+=h
r=sens.compare(candidate,ref,draws,c,'sequential')
assert r['gate']['same_orders']==['BCA'] and not r['gate']['checks']['same_order_learning_and_retention']
# ABC's stage-3 domain C: candidate .1->.3, reference .5->.6.
candidate['ABC_distill_stage2'][40:60]=.1;candidate['ABC_distill_stage3'][40:60]=.3;ref['ABC_stage2'][40:60]=.5;ref['ABC_stage3'][40:60]=.6
v=sens.compare(candidate,ref,draws,c,'sequential')['metrics']['average_precision']['by_order']['ABC']
assert math.isclose(v['N_transitions'][1],-.3,abs_tol=1e-14)
assert math.isclose(v['G_candidate_transitions'][1],.2,abs_tol=1e-14)
assert math.isclose(v['G_reference_transitions'][1],.1,abs_tol=1e-14)
result={'status':'PASS_ARTIFICIAL_SOFTWARE_CHECKS_NOT_SCIENTIFIC_RESULTS','independent_hand_cases':3,
 'environment':{'python':sys.version,'platform':platform.platform(),'numpy':np.__version__,'torch':torch.__version__,'cuda_available':torch.cuda.is_available(),'torch_threads':torch.get_num_threads()},
 'full_group_logit_gradient':loss_checks,'analytic_loss':{'bce':bce,'mse':mse},'six_synthetic_comparisons':comparisons,
 'comparison_scalar_values_checked':numeric_count,'comparison_max_abs_error':max_error,'shared_draws_shape':list(draws.shape),'shared_draws_unchanged':True,
 'same_order_hand_counterexample':{'H_positive_orders':['ABC','BCA'],'G_pass_orders':['BCA','CAB'],'intersection':['BCA']},
 'absolute_N_not_gain_difference_hand_case':{'N':v['N_transitions'][1],'G_candidate':v['G_candidate_transitions'][1],'G_reference':v['G_reference_transitions'][1]},
 'elapsed_seconds':time.monotonic()-t0,'not_executed':['formal data or labels','model load/train','run/evaluate','old tests','new statistical tests on study data']}
(OUT/'independent_hand_checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2))
