"""Verify the user-supplied archive, without importing any project code."""
import argparse,hashlib,json,zipfile
from pathlib import Path,PurePosixPath
from collections import Counter
p=argparse.ArgumentParser();p.add_argument('--zip',default='/mnt/data/review(1).zip');p.add_argument('--root',default='/mnt/data/sensitivity_review');p.add_argument('--out',default='/mnt/data/sensitivity_audit/manifest_verification.json');a=p.parse_args()
zp=Path(a.zip);raw=zp.read_bytes();root=Path(a.root)
r={'archive':str(zp),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'expected_bytes':3716891,'expected_sha256':'2429f01910bf6751039babd6d89d281a985cfe981dd30802a8f412eb21dad5c6'}
assert r['bytes']==r['expected_bytes'] and r['sha256']==r['expected_sha256']
with zipfile.ZipFile(zp) as z:
 names=z.namelist();r.update(members=len(names),crc_failure=z.testzip(),duplicates=[n for n,c in Counter(names).items() if c>1])
 assert not r['duplicates'] and r['crc_failure'] is None
 m=json.loads(z.read('manifest.json')); files=m['files'];r['manifest_entries']=len(files)
 assert len({x['path'] for x in files})==len(files)
 r['extra']=sorted(set(names)-{x['path'] for x in files}-{'manifest.json'});r['missing']=sorted({x['path'] for x in files}-set(names))
 assert not r['extra'] and not r['missing']
 checked=[]
 for x in files:
  n=x['path'];assert not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts
  b=z.read(n);h=hashlib.sha256(b).hexdigest();assert len(b)==x['bytes'] and h==x['sha256'],n
  dest=root/n;dest.parent.mkdir(parents=True,exist_ok=True)
  if dest.exists(): assert dest.read_bytes()==b
  else:dest.write_bytes(b)
  checked.append({'path':n,'bytes':len(b),'sha256':h,'match':True})
 (root/'manifest.json').write_bytes(z.read('manifest.json'))
 r['files']=checked;r['file_bytes_sum']=sum(x['bytes'] for x in checked);r['manifest_bytes']=len(z.read('manifest.json'));r['extracted_bytes_sum']=r['file_bytes_sum']+r['manifest_bytes']
Path(a.out).write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in r.items() if k!='files'},ensure_ascii=False,indent=2))
