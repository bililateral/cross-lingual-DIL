# 本次审查证据包

本包只包含外审核验脚本、报告和日志，不包含新科研结果、正式监督、缓存正文或模型权重。生产来源未修改。

主报告为`REVIEW.zh.md`；执行/未执行范围见`review_scope_and_verdict.json`，阅读范围见`reading_scope.json`。

`verify_archive.py`按本次精确ZIP摘要检查并解压，支持`--zip`、`--root`、`--out`。其他审查脚本的archive/copy/output根路径在文件开头，当前对应`/mnt/data/sensitivity_review`、`/mnt/data/sensitivity_test_copy`、`/mnt/data/sensitivity_audit`。移到别的环境时只调整这些审查路径，不修改被审来源。执行日志保留实际完整命令。

- `run_contracts.py`只在完整临时副本执行用户指定的新8项合同，不发现旧测试。两个真实Torch用例是这8项的子集。
- `independent_hand_checks.py`只有三个手工软件核验族，不读研究真值或模型，不调用run/evaluate。16896个标量来自人为轨迹，不是科学观察或新增实验结果。
- `audit_sources_history.py`仅读取冻结来源、指定旧记录、保存数组及公开UID。最初对旧SEQ评价格式的错误假设和修正记录均保留。不得将初次审查脚本KeyError归为项目缺陷。
- `finalize_evidence.py`核对全部被审文件和测试副本保持原字节，并汇总范围。没有新训练或监督访问。

使用本证据不构成Linux启动许可；原本地6通过2跳过、旧生产Torch结果、旧审查17986与本地5764各保持原统计范围。
