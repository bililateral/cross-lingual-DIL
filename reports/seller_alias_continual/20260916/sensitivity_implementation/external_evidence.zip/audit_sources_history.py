"""Read-only source/archived public metadata check. No labels, cache bodies or weights."""
from pathlib import Path
import ast,hashlib,json,random,sys,subprocess,re,difflib
import numpy as np
ROOT=Path('/mnt/data/sensitivity_review');OUT=Path('/mnt/data/sensitivity_audit')
def load(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def canonical(x):return (json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode()
def seed(*parts):return int.from_bytes(hashlib.sha256(canonical(list(parts))).digest()[:8],'big')%(2**63-1)
def verify(p,row):
 assert p.stat().st_size==row['bytes'] and digest(p)==row['sha256'],str(p)
 return {'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':digest(p),'match':True}
c=load(ROOT/'schema/step28_continual_sensitivity_policy.json')
locations={'seq':(c['origin_run'],c['origin_manifest_sha256'],c['origin_evaluation'],c['origin_evaluation_sha256']),
 'random_er':(c['baseline_run'],c['baseline_run_sha256'],c['baseline_evaluation'],c['baseline_evaluation_sha256']),
 'original_distillation':(c['distillation_reference']['run'],c['distillation_reference']['manifest_sha256'],c['distillation_reference']['evaluation'],c['distillation_reference']['evaluation_sha256'])}
runs={};evaluations={};sources={};matrices={};pins=[];score_files=[]
for role,(run,hs,ev,he) in locations.items():
 rp=ROOT/run/'manifest.json';ep=ROOT/ev
 assert digest(rp)==hs and digest(ep)==he
 pins += [{'role':role,'type':'run','sha256':hs},{'role':role,'type':'evaluation','sha256':he}]
 m=load(rp);e=load(ep);runs[role]=m;evaluations[role]=e
 sources[role]=[verify(ROOT/x['path'],x) for x in m['source_files']]
 assert e['score_manifest_sha256']==hs
 if role != 'seq': assert e['config']==m['config']
 matrices[role]={}
 for n,p in e['points'].items():
  f=p['file'];path=ep.parent/f['path'];verify(path,f);a=np.load(path,allow_pickle=False)
  assert a.shape==(60,22) and a.dtype==np.float64 and np.isfinite(a).all()
  matrices[role][n]=a
 for n,p in m['points'].items():
  f=p['scores']['development'];path=rp.parent/f['path']
  if path.exists():
   verify(path,f);a=np.load(path,allow_pickle=False);assert a.shape==(60,378) and a.dtype==np.float32 and np.isfinite(a).all()
   score_files.append({'role':role,'point':n,**verify(path,f)})
shared=[]
for role in ('random_er','original_distillation'):
 for o in ('ABC','BCA','CAB'):
  n=o+'_shared';assert np.array_equal(matrices[role][n],matrices['seq'][n]);shared.append({'role':role,'point':n,'elements':1320,'exact':True})
meta=runs['seq']['inputs']['metadata'];assert len(meta)==240
assert all(runs[k]['inputs']==runs['seq']['inputs'] for k in runs)
by_domain={d:sorted(x['group_uid'] for x in meta if x['split']=='train' and x['domain']==d) for d in 'ABC'}
assert all(len(x)==60 for x in by_domain.values())
history=[];schedule=[];targets=[]
for order in ('ABC','BCA','CAB'):
 mem=[];seen=0;rng=random.Random(seed(20260909,order,'memory'))
 for stage in (1,2,3):
  rows=[];stream=seed(20260909,order,stage,'current');sr=random.Random(stream)
  for _ in range(3):
   g=by_domain[order[stage-1]].copy();sr.shuffle(g);rows+=g
  name=order+('_shared' if stage==1 else f'_stage{stage}')
  assert runs['seq']['training'][name]['group_ids']==rows
  for role,suffix in [('random_er','er'),('original_distillation','distill')]:
   n=order+('_shared' if stage==1 else f'_{suffix}_stage{stage}')
   assert runs[role]['training'][n]['group_ids']==rows and runs[role]['training'][n]['dropout_stream']==stream
  schedule.append({'order':order,'stage':stage,'rows':len(rows),'seed':stream,'ids_sha256':hashlib.sha256(canonical(rows)).hexdigest()})
  if stage>1:
   rr=random.Random(seed(20260909,order,stage,'replay_draw'));draws=[rr.choice(mem) for _ in range(180)]
   for role,suffix in [('random_er','er'),('original_distillation','distill')]:
    assert runs[role]['training'][f'{order}_{suffix}_stage{stage}']['replay_group_ids']==draws
   history.append({'order':order,'stage':stage,'draws':180,'ids_sha256':hashlib.sha256(canonical(draws)).hexdigest()})
  if stage<3:
   current=by_domain[order[stage-1]]
   for uid in current:
    seen+=1;pos=len(mem) if len(mem)<6 else rng.randrange(seen)
    if pos<6:
     if pos==len(mem):mem.append(uid)
     else:mem[pos]=uid
   for role,suffix in [('random_er','er'),('original_distillation','distill')]:
    n=order+('_shared' if stage==1 else f'_{suffix}_stage{stage}')
    receipt=runs[role]['memory'][n];assert receipt['retained_groups']==mem and receipt['seen']==seen
   n=order+('_shared' if stage==1 else '_distill_stage2')
   new=[uid for uid in mem if uid in current]
   assert runs['original_distillation']['memory'][n]['teacher']['new_groups']==new
   targets.append({'order':order,'stage_end':stage,'seen':seen,'members':mem.copy(),'new_targets':new,'target_forwards':len(new)})
assert sum(t['target_forwards'] for t in targets)==25
# New-file syntax and call boundary check, no run/evaluate execution.
new=ROOT/'scripts/step28_continual_sensitivity.py';tree=ast.parse(new.read_text())
funs={n.name:n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
calls={name:[ast.unparse(n.func) for n in ast.walk(f) if isinstance(n,ast.Call)] for name,f in funs.items()}
assert calls['run'].count('persistence.Budget')==1 and calls['run'].count('pilot.attach_labels')==1
assert calls['evaluate'].count('pilot.attach_labels')==1
assert 'persistence.Budget' not in calls['run_arm'] and 'pilot.attach_labels' not in calls['run_arm']
assert not any('patch' in n for v in calls.values() for n in v)
new_paths=['scripts/step28_continual_sensitivity.py','schema/step28_continual_sensitivity_policy.json','tests/test_step28_continual_sensitivity_contracts.py','scripts/run_step28_sensitivity_linux_20260916.sh']
current_sources=sources['original_distillation']+[{'path':p,'bytes':(ROOT/p).stat().st_size,'sha256':digest(ROOT/p)} for p in new_paths]
assert len(current_sources)==21
syntax=[]
for p in [new,ROOT/'tests/test_step28_continual_sensitivity_contracts.py']:
 ast.parse(p.read_text());syntax.append(str(p.relative_to(ROOT)))
sh=ROOT/new_paths[-1]
subprocess.run(['bash','-n',str(sh)],check=True)
links=re.findall(r'\]\(([^)#]+)',(ROOT/'docs/SELLER_ALIAS_WEIGHT_SENSITIVITY.zh.md').read_text())
link_checks=[]
for u in links:
 if '://' in u:continue
 p=(ROOT/'docs'/u).resolve();assert p.exists();link_checks.append({'link':u,'exists':True})
# Save differences of the parameterized functions for human traceability.
old_tree=ast.parse((ROOT/'scripts/step28_continual_distillation.py').read_text())
old_funs={n.name:n for n in old_tree.body if isinstance(n,ast.FunctionDef)}
diffs=[]
for fn in ('historical_loss','observed_update','train_replay'):
 a=ast.unparse(old_funs[fn]).splitlines();b=ast.unparse(funs[fn]).splitlines()
 diffs+=list(difflib.unified_diff(a,b,fromfile='frozen_distill:'+fn,tofile='sensitivity:'+fn,lineterm=''))
(OUT/'parameterized_functions.diff').write_text('\n'.join(diffs)+'\n')
model_sizes=[x['bytes'] for x in runs['original_distillation']['models'].values()]
max_checkpoint=max(p['checkpoint']['bytes'] for p in runs['original_distillation']['points'].values())
result={'pinned_evidence':pins,'frozen_sources':sources,'new_production_source_files':current_sources,'new_source_count':len(current_sources),
 'saved_metric_matrices':{k:len(v) for k,v in matrices.items()},'saved_blind_score_files_present':score_files,
 'saved_shared_matrix_checks':shared,'public_metadata_count':len(meta),'historical_current_schedules':schedule,'historical_replay_schedules':history,
 'target_counts_per_configuration':targets,'unique_historical_current_rows_checked':1620,'unique_historical_replay_draws_checked':1080,
 'projected_new_counts':{'updates':3240,'shared_updates':1080,'weighted_updates':2160,'points':18,'double_pass_valid_group_forwards':2160,'memory_snapshots':12,'inference_models':6,'target_group_forwards':50,'current_pair_presentations':1224720,'historical_pair_presentations':816480},
 'static_call_boundary':{'parent_Budget_constructions':1,'parent_train_attach_calls':1,'child_attach_calls':0,'child_Budget_constructions':0,'windows_attach_calls':1,'runtime_monkeypatch_calls':0},
 'syntax_checked':syntax,'bash_n':True,'doc_links':link_checks,
 'storage_estimate_only':{'reference_three_models_bytes':sum(model_sizes),'estimated_six_models_bytes':2*sum(model_sizes),'reference_max_checkpoint_bytes':max_checkpoint,'estimated_large_file_coexistence_bytes':2*sum(model_sizes)+max_checkpoint,'stage_output_cap_bytes':c['runtime']['maximum_output_bytes'],'not_an_actual_new_run_peak':True},
 'not_executed':['production context','public corpus loading','formal labels','cached labels','model loading','production run/evaluate','old suite','historical bootstrap recalculation']}
(OUT/'source_history_checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('new_source_count','saved_metric_matrices','public_metadata_count','unique_historical_current_rows_checked','unique_historical_replay_draws_checked','projected_new_counts','storage_estimate_only')},indent=2))
