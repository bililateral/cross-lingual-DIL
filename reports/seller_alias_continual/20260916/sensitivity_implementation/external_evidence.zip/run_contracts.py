"""Run only the eight explicitly requested contracts in an isolated archive copy."""
import sys,os,platform,json,subprocess,time
from pathlib import Path
root=Path('/mnt/data/sensitivity_test_copy');out=Path('/mnt/data/sensitivity_audit')
env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',TOKENIZERS_PARALLELISM='false')
cmd=[sys.executable,'-B','-m','unittest','discover','-s','tests','-p','test_step28_continual_sensitivity_contracts.py','-v']
t=time.monotonic()
with (out/'new_contracts.log').open('w') as f:
 f.write('cwd: '+str(root)+'\ncommand: '+' '.join(cmd)+'\n');f.flush()
 p=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=90)
r={'command':cmd,'cwd':str(root),'exit_code':p.returncode,'wall_seconds':time.monotonic()-t,'python':sys.version,'platform':platform.platform(),'machine':platform.machine(),'thread_environment':{k:env[k] for k in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS')},'scope':'Only new sensitivity contract set; prior fixture functions imported, no old test discovery'}
(out/'new_contracts_run.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2));print((out/'new_contracts.log').read_text())
sys.exit(p.returncode)
