#!/usr/bin/env python3
"""Exercise proposed minimal function changes using synthetic artifacts only.
Does not edit source_snapshots or certify a new production-source hash.
"""
from __future__ import annotations
import ast
import difflib
import json
from pathlib import Path
import tempfile
from unittest import mock
import numpy as np
import independent_review_checks as o
base=o.base
root=o.ROOT
original=(o.SOURCE/'scripts/step28_base_model.py').read_text()
changed=original.replace('    return result, part, r\n',
'''    for record in expected_models:
        data.verify(out / record["path"], record)
    return result, part, r
''',1)
changed=changed.replace('''def automatic_report(counts: np.ndarray, domains: list[str], draws: np.ndarray) -> dict:
    out = {}
''','''def automatic_report(counts: np.ndarray, domains: list[str], draws: np.ndarray) -> dict:
    out = {}
    pooled_boot = np.zeros((len(draws), 4), dtype=np.float64)
''',1)
changed=changed.replace('''        boot = values[draws[:, index]].sum(axis=1).astype(np.float64)
''','''        boot = values[draws[:, index]].sum(axis=1).astype(np.float64)
        pooled_boot += boot
''',1)
changed=changed.replace('''    return {"by_domain": out, "pooled": rates(counts),
''','''    pooled = rates(counts)
    pooled["conditional_95pct_intervals"] = {}
    for name, numerator, other in (("fpr", 1, 3), ("recall", 0, 2), ("precision", 0, 1)):
        denominator = pooled_boot[:, numerator] + pooled_boot[:, other]
        values = np.divide(pooled_boot[:, numerator], denominator,
                           out=np.zeros(len(draws)), where=denominator > 0)
        pooled["conditional_95pct_intervals"][name] = np.quantile(values, [.025, .975]).tolist()
    return {"by_domain": out, "pooled": pooled,
''',1)
assert changed!=original
patch=''.join(difflib.unified_diff(original.splitlines(True),changed.splitlines(True),
            fromfile='a/scripts/step28_base_model.py',tofile='b/scripts/step28_base_model.py'))
(root/'evidence/proposed_minimal.patch').write_text(patch)
# Compile only the two changed functions, reusing the original globals without
# changing the production file, source hash, original module, or environment.
nodes=[n for n in ast.parse(changed).body if isinstance(n,ast.FunctionDef) and n.name in ('validated_run','automatic_report')]
namespace=vars(base).copy()
exec(compile(ast.Module(body=nodes,type_ignores=[]),'<proposed_minimal_functions>','exec'),namespace)
patched_gate=namespace['validated_run'];patched_report=namespace['automatic_report']
results={}
for mode in ('intact','deleted','same_size_modified'):
    with tempfile.TemporaryDirectory() as temp:
        out=Path(temp)/'job/run';c,g,m,checked=o.supplied.fake_run(out)
        p=out/'labse/models/epoch6.pt'
        if mode=='deleted':p.unlink()
        if mode=='same_size_modified':
            b=p.read_bytes();p.write_bytes(bytes([b[0]^1])+b[1:])
        reached=[]
        class Sentinel(RuntimeError):pass
        def parse(*a,**kw):reached.append(True);raise Sentinel('handmade parser sentinel')
        try:
            with mock.patch.object(base,'validated_run',patched_gate), \
                 mock.patch.object(base.public,'public_inputs',return_value=(g,m,checked)), \
                 mock.patch.object(base.public,'attach_labels',side_effect=parse):
                base.evaluate(out,Path(temp)/'eval')
        except Sentinel:
            assert mode=='intact'
        except (ValueError,FileNotFoundError):
            assert mode!='intact'
        else:raise AssertionError('Expected sentinel or missing/corrupt model rejection')
        assert len(reached)==int(mode=='intact')
        results[mode]={'synthetic_parser_calls':len(reached),'passes_expected_behavior':True}
domains=list('A'*20+'B'*20+'C'*20)
counts=np.array([[8+(i%9),int(i%13==0)+int(i%7==0),12-(i%9),358-int(i%13==0)-int(i%7==0)] for i in range(60)])
draws=np.random.default_rng(20260918).integers(0,20,size=(5000,3,20))
before=base.automatic_report(counts,domains,draws);after=patched_report(counts,domains,draws)
assert before['by_domain']==after['by_domain']
assert before['all_domains_pass']==after['all_domains_pass']
for k,v in before['pooled'].items():assert after['pooled'][k]==v
boot=o.manual_bootstrap_totals(counts,draws).sum(1)
for name in ('fpr','recall','precision'):
    reference=[o.quantile_linear(o.ratio_totals(boot,name),q) for q in (.025,.975)]
    np.testing.assert_allclose(after['pooled']['conditional_95pct_intervals'][name],reference,atol=2e-15,rtol=0.)
results['pooled_intervals']={'independent_bounds_match':True,'existing_points_domains_and_gates_unchanged':True,
    'new_random_draws':0,'bounds':after['pooled']['conditional_95pct_intervals']}
report={'status':'PASS_SYNTHETIC_FUNCTION_PATCH_TRIAL','source_snapshots_modified':False,
        'formal_labels':0,'pretrained_models_loaded':0,'formal_training':0,
        'not_a_production_retest_or_new_source_approval':True,'results':results}
(root/'evidence/minimal_patch_results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))
