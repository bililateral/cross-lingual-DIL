#!/usr/bin/env python3
"""End-to-end synthetic evaluator comparison; no training/real model or labels.
Receipt scaffolding comes from supplied.fake_run and is NOT a model execution.
The independent metric/quantile formulas are in independent_review_checks.py.
"""
from __future__ import annotations
import json
from pathlib import Path
import tempfile
from unittest import mock
import numpy as np
import independent_review_checks as oracle

base,supplied=oracle.base,oracle.supplied
ROOT=oracle.ROOT

def run():
    y=oracle.own_truth()
    with tempfile.TemporaryDirectory() as temp:
        out=Path(temp)/'job/run'
        c,groups,metadata,checked=supplied.fake_run(out)
        for ai,arm in enumerate(base.ARMS):
            ar=out/arm;a=base.data.read_json(ar/'manifest.json')
            for epoch in (3,6):
                point=a['points'][str(epoch)]
                for role,n in base.ROLE_SIZES.items():
                    pair=np.arange(378)[None,:];row=np.arange(n)[:,None]
                    scores=(((pair*37+row*13+ai*7+epoch)%23)/7.-1.5+y[None,:]*((ai+1)*.25+.05*epoch)).astype(np.float32)
                    path=ar/point['scores'][role]['path']
                    np.save(path,scores,allow_pickle=False);point['scores'][role]=base.data.record(path,ar)
                    if role!='development':
                        metrics,_=base.metrics.group_metrics(np.tile(y,(n,1)),scores)
                        path=ar/point['train_metrics'][role]['file']['path']
                        np.save(path,metrics,allow_pickle=False);point['train_metrics'][role]['file']=base.data.record(path,ar)
            scores=np.load(ar/a['points']['6']['scores']['calibration']['path'],allow_pickle=False)
            cal=base.calibrate(np.tile(y,(36,1)),scores,list('A'*12+'B'*12+'C'*12))
            cal.update(epoch=6,model_state_sha256=a['points']['6']['model_state_sha256'],score_sha256=a['points']['6']['scores']['calibration']['sha256'])
            base.data.write_json(ar/'calibration.json',cal);a['calibration']=base.data.record(ar/'calibration.json',ar)
            base.data.write_json(ar/'manifest.json',a)
        oracle.rebind_fixture(out)
        labeled=[base.data.Group(g.uid,g.sellers,g.items,tuple(map(int,y))) for g in groups['development']]
        dest=Path(temp)/'evaluation'
        with mock.patch.object(base.public,'public_inputs',return_value=(groups,metadata,checked)), \
             mock.patch.object(base.public,'attach_labels',return_value=labeled) as parser:
            result=base.evaluate(out,dest)
        parser.assert_called_once_with(groups['development'],c,'development')
        wanted={}
        for arm in base.ARMS:
            ar=out/arm;a=base.data.read_json(ar/'manifest.json')
            for epoch in ('3','6'):
                scores=np.load(ar/a['points'][epoch]['scores']['development']['path'],allow_pickle=False)
                matrix=np.array([[ref[k] for k in base.metrics.COLUMNS] for ref in
                                (oracle.metric_oracle(y,row) for row in scores)])
                got=np.load(dest/result['arms'][arm]['points'][epoch]['file']['path'],allow_pickle=False)
                for i in range(60):
                    for j,key in enumerate(base.metrics.COLUMNS):
                        oracle.compare(f'e2e.{arm}.epoch{epoch}.group{i}.{key}',got[i,j],matrix[i,j])
                for j,key in enumerate(base.metrics.COLUMNS):
                    point=result['arms'][arm]['points'][epoch]
                    oracle.compare(f'e2e.{arm}.epoch{epoch}.mean.{key}',point['mean'][key],float(sum(matrix[:,j])/60))
                    for d,domain in enumerate('ABC'):
                        oracle.compare(f'e2e.{arm}.epoch{epoch}.{domain}.{key}',point['by_domain'][domain][key],float(sum(matrix[d*20:(d+1)*20,j])/20))
                if epoch=='6':wanted[arm]=matrix
        draws=np.random.default_rng(20260918).integers(0,20,size=(5000,3,20))
        frequencies=np.zeros((5000,60),dtype=np.int64)
        for b in range(5000):
            for d in range(3):
                for idx in draws[b,d]:frequencies[b,d*20+int(idx)]+=1
        for arm in base.ARMS[1:]:
            delta=wanted[arm]-wanted['labse']
            for j,key in enumerate(base.metrics.COLUMNS):
                point=float(sum(delta[:,j])/60)
                boot=(frequencies@delta[:,j])/60
                got=result['comparisons_to_labse'][arm][key]
                oracle.compare(f'e2e.paired.{arm}.{key}.mean',got['mean'],point)
                for idx,q in enumerate((.025,.975)):
                    oracle.compare(f'e2e.paired.{arm}.{key}.q{q}',got['conditional_95pct_interval'][idx],oracle.quantile_linear(boot,q))
        summary={'status':'PASS','synthetic_only':True,'formal_labels':0,'formal_updates':0,'pretrained_models_loaded':0,
            'mocked_synthetic_label_parser_calls':parser.call_count,'numeric_comparisons':len(oracle.NUMBERS),
            'maximum_absolute_error':max(n['absolute_error'] for n in oracle.NUMBERS),
            'six_points':6,'development_groups_per_point':60,'columns':list(base.metrics.COLUMNS),
            'per_group_metric_comparisons':6*60*22,'per_point_pooled_domain_means':6*4*22,
            'paired_22metric_difference_point_and_CI_comparisons':2*22*3,
            'bootstrap_replicates':5000,'bootstrap_oracle':'frequency weighted whole-group sums / scalar linear quantile',
            'source_of_fixture':'supplied fake_run scaffolding, hand-authored scores; NOT actual model output'}
        (ROOT/'evidence/end_to_end_results.json').write_text(json.dumps(summary,indent=2)+'\n')
        (ROOT/'evidence/end_to_end_synthetic_evaluation.json').write_text(json.dumps(result,indent=2)+'\n')
        import csv
        with (ROOT/'evidence/end_to_end_numeric_comparisons.csv').open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(oracle.NUMBERS[0]));w.writeheader();w.writerows(oracle.NUMBERS)
        print(json.dumps(summary,indent=2))

if __name__=='__main__':run()
