#!/usr/bin/env python3
"""Independent, synthetic-only external-review checks; NEVER calls train/load_model.

Only CPU Torch, hand-built groups, and a temporary receipt fixture are used.
The receipt fixture is deliberately NOT a real encoder/model-run certificate.
Production sources remain unchanged. No network, project Linux, formal labels,
model archives, or CUDA are accessed. Run from any location using Python 3.10+.
"""
from __future__ import annotations
import copy
import csv
import hashlib
import itertools
import json
import math
import os
from pathlib import Path
import random
import sys
import tempfile
import unittest
from unittest import mock

for key in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS'):
    os.environ[key] = '1'
os.environ.update(CUDA_VISIBLE_DEVICES='', HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'source_snapshots'
sys.path[:0] = [str(SOURCE / 'scripts'), str(SOURCE / 'tests')]
import numpy as np
import torch
import step28_base_model as base
import test_step28_base_model_contracts as supplied

torch.set_num_threads(1)
EVIDENCE = ROOT / 'evidence'
EVIDENCE.mkdir(exist_ok=True)
DETAILS: dict = {}
NUMBERS: list[dict] = []


def compare(name: str, actual: float, expected: float, atol: float = 2e-12) -> None:
    actual, expected = float(actual), float(expected)
    err = abs(actual - expected)
    NUMBERS.append(dict(name=name, actual=actual, independent=expected,
                        absolute_error=err, absolute_tolerance=atol, passed=err <= atol))
    if not math.isfinite(actual) or not math.isfinite(expected) or err > atol:
        raise AssertionError(f'{name}: {actual} != {expected}, error={err}, tolerance={atol}')


def own_truth() -> np.ndarray:
    # Four synthetic size-3 classes plus eight size-2 classes: 28 accounts,
    # 4*C(3,2)+8*C(2,2)=20 positive pairs, 358 negative pairs.
    sizes = [3]*4 + [2]*8
    cls = [i for i,n in enumerate(sizes) for _ in range(n)]
    return np.array([int(cls[i] == cls[j]) for i in range(28)
                     for j in range(i+1,28)], dtype=np.uint8)


def own_rates(rows: np.ndarray) -> dict:
    t = [sum(int(row[k]) for row in rows) for k in range(4)]
    tp, fp, fn, tn = t
    return dict(tp=tp, fp=fp, fn=fn, tn=tn,
                fpr=fp/(fp+tn), recall=tp/(tp+fn),
                precision=tp/(tp+fp) if tp+fp else 0.)


def quantile_linear(values, q: float) -> float:
    ordered = sorted(float(v) for v in values)
    loc = (len(ordered)-1)*q
    lo, hi = math.floor(loc), math.ceil(loc)
    return ordered[lo] + (ordered[hi]-ordered[lo])*(loc-lo)


def manual_bootstrap_totals(counts, draws):
    # Independent frequency-weight method (not production fancy indexing).
    totals = np.zeros((len(draws),3,4), dtype=np.int64)
    for b in range(len(draws)):
        for d in range(3):
            freq = [0]*20
            for idx in draws[b,d]: freq[int(idx)] += 1
            for k in range(4):
                totals[b,d,k] = sum(freq[g]*int(counts[20*d+g,k]) for g in range(20))
    return totals


def ratio_totals(totals, name):
    n, o = {'fpr': (1,3), 'recall': (0,2), 'precision': (0,1)}[name]
    return [float(t[n])/(float(t[n])+float(t[o])) if t[n]+t[o] else 0.
            for t in totals]


def metric_oracle(y, score):
    """Scalar definitions, independent of production/sklearn curve algorithms."""
    y, score = list(map(int,y)), list(map(float,score))
    positive, negative = sum(y), len(y)-sum(y)
    ap=area=0.; previous_recall=0.; previous_precision=1.; r1=0.
    for boundary in sorted(set(score), reverse=True):
        chosen = [i for i,s in enumerate(score) if s >= boundary]
        tp = sum(y[i] for i in chosen); fp = len(chosen)-tp
        recall, precision = tp/positive, tp/len(chosen)
        ap += (recall-previous_recall)*precision
        area += (recall-previous_recall)*(precision+previous_precision)/2
        if fp/negative <= .01: r1 = max(r1,recall)
        previous_recall,previous_precision=recall,precision
    # Pairwise concordance (Mann-Whitney definition), including half credit ties.
    auc = sum((score[i]>score[j]) + .5*(score[i]==score[j])
              for i in range(len(y)) if y[i]
              for j in range(len(y)) if not y[j])/(positive*negative)
    prob = [1/(1+math.exp(-s)) for s in score]
    clip = [min(max(p,1e-15),1-1e-15) for p in prob]
    tp=sum(yi==1 and s>=0 for yi,s in zip(y,score))
    fp=sum(yi==0 and s>=0 for yi,s in zip(y,score))
    fn=positive-tp;tn=negative-fp
    precision=tp/(tp+fp) if tp+fp else 0.
    recall=tp/positive;spec=tn/negative
    denom=math.sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn))
    result = dict(average_precision=ap,trapezoidal_pr_auc=area,roc_auc=auc,
                  recall_at_fpr_1pct=r1,
                  brier=sum((p-v)**2 for p,v in zip(prob,y))/len(y),
                  log_loss=-sum(v*math.log(p)+(1-v)*math.log1p(-p) for v,p in zip(y,clip))/len(y),
                  precision=precision,recall=recall,f1=2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0.,
                  specificity=spec,balanced_accuracy=(recall+spec)/2,
                  mcc=(tp*tn-fp*fn)/denom if denom else 0.)
    edge = {(i,j): (y[k],score[k]) for k,(i,j) in enumerate(itertools.combinations(range(28),2))}
    query = []
    for i in range(28):
        candidates = [(j,*edge[min(i,j),max(i,j)]) for j in range(28) if j!=i]
        # (-score, ascending public account index), exclude self explicitly.
        ranked = sorted(candidates,key=lambda x: (-x[2],x[0]))
        labels = [row[1] for row in ranked]; total=sum(labels)
        ranks=[r for r,z in enumerate(labels,1) if z]
        a=sum(sum(labels[:r])/r for r in ranks)/total
        row=dict(map=a,mrr=1/ranks[0])
        for k in (1,3,5,10):
            row[f'recall_at_{k}']=sum(labels[:k])/total
            dcg=sum(z/math.log2(r+1) for r,z in enumerate(labels[:k],1))
            ideal=sum(1/math.log2(r+1) for r in range(1,min(total,k)+1))
            row[f'ndcg_at_{k}']=dcg/ideal
        query.append(row)
    for key in query[0]: result[key]=sum(row[key] for row in query)/28
    return result


class IndependentReview(unittest.TestCase):
    def test_01_partition_schedule_independent_digest(self):
        c=base.contract();groups,meta=supplied.public_fixture()
        got,record=base.partition(groups,meta,c)
        fit=set();cal=set()
        for d in 'ABC':
            ids=[m['group_uid'] for m in meta if m['domain']==d and m['split']=='train']
            def digest(uid):
                raw=json.dumps([20260918,d,uid],ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n'
                return hashlib.sha256(raw.encode()).hexdigest()
            ids=sorted(ids,key=digest);fit.update(ids[:48]);cal.update(ids[48:])
        self.assertEqual(fit,{g.uid for g in got['fit']});self.assertEqual(cal,{g.uid for g in got['calibration']})
        seq,seed=base.schedule(got['fit'],c)
        # Reconstruct the seed instead of calling data.seed_for.
        raw=json.dumps([20260918,'BASE_JOINT','current'],ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n'
        expected_seed=int.from_bytes(hashlib.sha256(raw.encode()).digest()[:8],'big')%(2**63-1)
        # Production uses first 16 hex digits modulo (2**63-1); equality checked below.
        self.assertEqual(seed,expected_seed)
        rng=random.Random(seed); wanted=[]
        for _ in range(6):
            epoch=sorted(fit);rng.shuffle(epoch);wanted+=epoch
        self.assertEqual([g.uid for g in seq],wanted)
        self.assertTrue(set(wanted).isdisjoint(cal));self.assertEqual(len(wanted),864)
        DETAILS['partition_schedule']={'fit':len(fit),'calibration':len(cal),'updates_per_arm':len(wanted),
            'total_updates':len(wanted)*3,'seed':seed,'calibration_seen_in_schedule':False,
            'fixture_only':True,'reference_reconstruction':'standard json/hashlib/random, independent recipe'}

    def test_02_threshold_full_size_ties_and_rounding(self):
        t=own_truth(); y=np.tile(t,(36,1)); domains=list('A'*12+'B'*12+'C'*12)
        scores=np.full((36,378),-5,dtype=np.float32)
        for d,offset in enumerate((0.,1.,2.)):
            block=scores[d*12:(d+1)*12]; mask=y[d*12:(d+1)*12]==0
            n=np.full(4296,-5.+offset,np.float32)
            n[:9]=np.array([10,9,8,7,6,6,6,6,6],np.float32)+offset
            block[mask]=n;block[~mask]=9.+offset
        result=base.calibrate(y,scores,domains)
        bounds=[]
        for d in range(3):
            neg=[float(s) for row,ys in zip(scores[d*12:(d+1)*12],y[d*12:(d+1)*12]) for s,z in zip(row,ys) if z==0]
            bounds.append(math.nextafter(sorted(neg,reverse=True)[4],math.inf))
        threshold=max(bounds)
        compare('threshold.fullsize.global',result['threshold'],threshold,0.)
        expected=[]
        for row,ys in zip(scores,y):
            flags=[float(s)>=threshold for s in row]
            expected.append([sum(z==1 and f for z,f in zip(ys,flags)),sum(z==0 and f for z,f in zip(ys,flags)),
                             sum(z==1 and not f for z,f in zip(ys,flags)),sum(z==0 and not f for z,f in zip(ys,flags))])
        np.testing.assert_array_equal(base.binary_counts(y,scores,threshold),expected)
        per_domain=[np.asarray(expected)[12*d:12*(d+1)].sum(0).tolist() for d in range(3)]
        self.assertEqual([row[1] for row in per_domain],[2,3,4])
        # Demonstrate specifically why a float32 threshold cast is not equivalent.
        wrong=(scores>=np.float32(threshold)) & (y==0)
        wrong_fp=[int(wrong[12*d:12*(d+1)].sum()) for d in range(3)]
        self.assertEqual(wrong_fp,[3,4,9])
        changed=scores.copy();changed[y==1]=-100
        self.assertEqual(base.calibrate(y,changed,domains)['threshold'],threshold)
        self.assertEqual(int(base.binary_counts(y,changed,threshold)[:,0].sum()),0)
        all_tied=np.zeros_like(scores)
        all_reject=base.calibrate(y,all_tied,domains)
        self.assertEqual(all_reject['threshold'],math.nextafter(0.,math.inf))
        self.assertEqual(int(base.binary_counts(y,all_tied,all_reject['threshold'])[:,:2].sum()),0)
        DETAILS['calibration']={'threshold':threshold,'threshold_hex':threshold.hex(),'independent_bounds':bounds,
            'correct_domain_counts':per_domain,'incorrect_float32_threshold_FP':wrong_fp,
            'negative_count_per_domain':4296,'allowed_FP':4,
            'all_tied_threshold':all_reject['threshold'],'positive_scores_do_not_change_threshold':True}

    def test_03_gate_boundaries_and_pooled_cancellation(self):
        rows=np.tile([10,0,10,358],(60,1));dom=list('A'*20+'B'*20+'C'*20)
        draws=np.tile(np.arange(20),(3,3,1))
        rows[0]=[10,7,10,351]
        self.assertTrue(base.automatic_report(rows,dom,draws)['all_domains_pass'])
        rows[0]=[10,8,10,350]
        bad=base.automatic_report(rows,dom,draws)
        pooled=own_rates(rows)
        self.assertFalse(bad['all_domains_pass']);self.assertLess(pooled['fpr'],.001)
        rows[0]=[10,0,10,358];rows[40,0]=9;rows[40,2]=11
        bad_recall=base.automatic_report(rows,dom,draws)
        self.assertEqual(bad_recall['by_domain']['C']['tp'],199)
        self.assertFalse(bad_recall['all_domains_pass'])
        DETAILS['gates']={'FP7_TP200':'PASS','FP8_TP200':'FAIL','FP0_TP199':'FAIL',
             'one_domain_FP8_but_pooled_FPR':pooled['fpr'],'pooled_recall':pooled['recall'],
             'false_pooled_pass_prevented':True}

    def test_04_all_22_metrics_independent_scalar_oracle(self):
        y=own_truth(); scoreset={
            'nontied':np.array([math.sin((i+1)*1.123)+(int(y[i])*.15) for i in range(378)],np.float32),
            'ties':np.array([((i*37)%17-8)/3 for i in range(378)],np.float32),
            'all_tied':np.zeros(378,np.float32)}
        for label,scores in scoreset.items():
            actual,_=base.metrics.group_metrics(y[None,:],scores[None,:])
            wanted=metric_oracle(y,scores)
            for index,key in enumerate(base.metrics.COLUMNS):
                compare(f'metric.{label}.{key}',actual[0,index],wanted[key])
        hand=base.metrics.curve_metrics(np.array([1,0,1,0]),np.array([4.,3.,2.,1.]))
        compare('hand.AP',hand['average_precision'],5/6)
        compare('hand.PR_trapezoid',hand['trapezoidal_pr_auc'],19/24)
        self.assertNotEqual(hand['average_precision'],hand['trapezoidal_pr_auc'])
        DETAILS['metrics']={'full_groups':3,'columns_per_group':22,'scalar_comparisons':66,
                            'hand_AP':hand['average_precision'],'hand_PR_trapezoid':hand['trapezoidal_pr_auc'],
                            'ties':'curve threshold blocks; retrieval ascending public seller order'}

    def test_05_bootstrap_frequency_oracle_and_pooled_ci_gap(self):
        domains=list('A'*20+'B'*20+'C'*20)
        reference=np.array([[7+(i%9),int(i%13==0),13-(i%9),358-int(i%13==0)] for i in range(60)])
        candidate=reference.copy();candidate[:,0]+=1;candidate[:,2]-=1
        candidate[::7,1]+=1;candidate[::7,3]-=1
        draws=np.random.default_rng(20260918).integers(0,20,size=(5000,3,20))
        rb=manual_bootstrap_totals(reference,draws);cb=manual_bootstrap_totals(candidate,draws)
        report=base.automatic_report(candidate,domains,draws)
        comparison=base.automatic_comparison(candidate,reference,domains,draws)
        for d in range(3):
            for name in ('fpr','recall','precision'):
                v=ratio_totals(cb[:,d],name)
                point=own_rates(candidate[d*20:(d+1)*20])[name]
                compare(f'boot.domain.{d}.{name}.point',report['by_domain']['ABC'[d]][name],point)
                for j,q in enumerate((.025,.975)):
                    compare(f'boot.domain.{d}.{name}.q{q}',
                            report['by_domain']['ABC'[d]]['conditional_95pct_intervals'][name][j],quantile_linear(v,q))
        for d,scope in enumerate((*'ABC','pooled')):
            a=cb[:,d] if d<3 else cb.sum(1);b=rb[:,d] if d<3 else rb.sum(1)
            cr=candidate[d*20:(d+1)*20] if d<3 else candidate
            rr=reference[d*20:(d+1)*20] if d<3 else reference
            for name in ('fpr','recall','precision'):
                values=[v-w for v,w in zip(ratio_totals(a,name),ratio_totals(b,name))]
                compare(f'boot.diff.{scope}.{name}.point',comparison[name][scope]['difference'],
                        own_rates(cr)[name]-own_rates(rr)[name])
                for j,q in enumerate((.025,.975)):
                    compare(f'boot.diff.{scope}.{name}.q{q}',comparison[name][scope]['conditional_95pct_interval'][j],quantile_linear(values,q))
        self.assertNotIn('conditional_95pct_intervals',report['pooled'])
        suggested={name:[quantile_linear(ratio_totals(cb.sum(1),name),q) for q in (.025,.975)]
                   for name in ('fpr','recall','precision')}
        DETAILS['bootstrap']={'replicates':5000,'seed':20260918,'paired_unit':'complete groups within each domain',
             'independent_numeric_comparisons':63,'reported_pooled_keys':list(report['pooled']),
             'missing_pooled_CIs_recomputed_without_new_resampling':suggested,
             'synthetic_pooled_points':own_rates(candidate)}

    def test_06_six_scores_identity_and_preparse_mutations(self):
        outcomes={}
        mutations={
            'wrong_model_arm':lambda out: mutate_arm(out,'labse',lambda a:a.update(arm='bge_m3')),
            'missing_epoch3':lambda out: mutate_arm(out,'labse',lambda a:a['points'].pop('3')),
            'calibration_wrong_epoch6_state':lambda out: mutate_cal(out,'labse',lambda a:a.update(model_state_sha256='wrong')),
            'calibration_wrong_score_hash':lambda out: mutate_cal(out,'labse',lambda a:a.update(score_sha256='0'*64)),
            'calibration_float32_boundary':lambda out: mutate_cal(out,'labse',lambda a:a.update(threshold=-2.)),
            'score_payload_changed':lambda out: (out/'labse/scores/epoch6_development.npy').write_bytes(b'corrupt'),
            'outer_timeout':lambda out:(out.parent/'exit_status.txt').write_text('124\n')}
        for name,change in mutations.items():
            with tempfile.TemporaryDirectory() as temp:
                out=Path(temp)/'job/run';c,g,m,checked=supplied.fake_run(out);change(out)
                with mock.patch.object(base.public,'public_inputs',return_value=(g,m,checked)), \
                     mock.patch.object(base.public,'attach_labels',side_effect=AssertionError('parser must not be called')) as parser:
                    with self.assertRaises((ValueError,KeyError,FileNotFoundError)):
                        base.evaluate(out,Path(temp)/'eval')
                    self.assertEqual(parser.call_count,0)
                outcomes[name]={'rejected_before_valid_parser':True,'formal_labels_read':0}
        DETAILS['mutation_gates']=outcomes

    def test_07_stale_model_receipt_counterexample(self):
        outcomes={}
        for variant in ('deleted','same_size_modified'):
            with tempfile.TemporaryDirectory() as temp:
                out=Path(temp)/'job/run';c,g,m,checked=supplied.fake_run(out)
                target=out/'labse/models/epoch6.pt'
                if variant=='deleted':target.unlink()
                else:
                    payload=target.read_bytes();target.write_bytes(bytes([payload[0]^1])+payload[1:])
                # Genuine receipt was created BEFORE mutation. No manifests, hashes,
                # source records, or completion records are forged/rewritten here.
                original_ok=True
                base.validated_run(out,c,g,m,checked)
                called=[]
                class ReachedSyntheticParser(RuntimeError):pass
                def sentinel(*args,**kwargs):
                    called.append(True);raise ReachedSyntheticParser('synthetic sentinel; no labels opened')
                with mock.patch.object(base.public,'public_inputs',return_value=(g,m,checked)), \
                     mock.patch.object(base.public,'attach_labels',side_effect=sentinel):
                    with self.assertRaises(ReachedSyntheticParser):base.evaluate(out,Path(temp)/'eval')
                # Proposed minimal existing-file check rejects the same artifact.
                ar=base.data.read_json(out/'labse/manifest.json');rec=ar['points']['6']['model']
                with self.assertRaises((ValueError,FileNotFoundError)):
                    base.data.verify(out/'labse'/rec['path'],rec)
                outcomes[variant]={'old_gate_accepts':original_ok,'synthetic_parser_reached':len(called)==1,
                   'minimal_fresh_data_verify_rejects':True,'manifest_or_receipt_modified':False,
                   'synthetic_model_payload':True,'formal_labels_read':0}
        DETAILS['stale_model_receipt']=outcomes

    def test_08_real_cpu_full378_gradient_manual_adam_and_restore(self):
        model,c,group=make_tiny_group_model();reference=copy.deepcopy(model)
        optimizer=base.core.make_optimizer(model,c);state={};step_details=[]
        y=torch.tensor(own_truth(),dtype=torch.float32)
        with tempfile.TemporaryDirectory() as temp:
            for step in (1,2,3):
                log=base.update(model,optimizer,group,c,'multilingual_e5_large',step,observe=True)
                reference.zero_grad(set_to_none=True)
                z=reference_logits(reference,group,'query: ')
                loss=torch.stack([torch.logaddexp(torch.zeros_like(v),v)-truth*v for v,truth in zip(z,y)]).sum()/378
                loss.backward()
                norm=math.sqrt(sum(float(p.grad.detach().double().square().sum()) for p in reference.parameters()))
                factor=min(1.,1/(norm+1e-6))
                with torch.no_grad():
                    for p in reference.parameters():p.grad.mul_(factor)
                compare(f'gradient.step{step}.BCE',log['bce'],float(loss.detach()),3e-7)
                for (name,p),(name2,q) in zip(model.named_parameters(),reference.named_parameters(),strict=True):
                    self.assertEqual(name,name2)
                    compare(f'gradient.step{step}.{name}.max_error',float((p.grad-q.grad).abs().max()),0.,5e-7)
                # Explicit AdamW recurrence: no reference torch optimizer is used.
                with torch.no_grad():
                    for name,p in reference.named_parameters():
                        m,v=state.setdefault(name,(torch.zeros_like(p),torch.zeros_like(p)))
                        m.mul_(.9).add_(p.grad,alpha=.1);v.mul_(.999).addcmul_(p.grad,p.grad,value=.001)
                        lr,wd=(2e-5,.01) if name.startswith('encoder.') else (.001,0.)
                        p.mul_(1-lr*wd)
                        p.addcdiv_(m/(1-.9**step),(v/(1-.999**step)).sqrt()+1e-8,value=-lr)
                for (name,p),(_,q) in zip(model.named_parameters(),reference.named_parameters(),strict=True):
                    compare(f'AdamW.step{step}.{name}.parameter_max_error',float((p-q).abs().max().detach()),0.,5e-7)
                    actual_state=optimizer.state[p];m,v=state[name]
                    self.assertEqual(int(actual_state['step']),step)
                    compare(f'AdamW.step{step}.{name}.first_moment_max_error',float((actual_state['exp_avg']-m).abs().max()),0.,5e-8)
                    compare(f'AdamW.step{step}.{name}.second_moment_max_error',float((actual_state['exp_avg_sq']-v).abs().max()),0.,5e-9)
                step_details.append({'step':step,'BCE':log['bce'],'reference_BCE':float(loss.detach()),'pair_count':len(z)})
                if step==1:
                    path=Path(temp)/'full_state.pt'
                    rec=base.core.save_state(path,model,optimizer,{'synthetic':True,'step':1})
                    fresh,_,_=make_tiny_group_model();freshopt=base.core.make_optimizer(fresh,c)
                    meta=base.core.restore_state(path,fresh,freshopt,rec['state_sha256'])
                    self.assertEqual(meta,{'synthetic':True,'step':1})
                    self.assertEqual(base.core.state_digest(fresh.state_dict()),base.core.state_digest(model.state_dict()))
                    self.assertEqual(base.core.state_digest(freshopt.state_dict()),base.core.state_digest(optimizer.state_dict()))
                    model,optimizer=fresh,freshopt
            # Execute production checkpoint_point with three independently named roles.
            out=Path(temp)/'point';(out/'scores').mkdir(parents=True);(out/'models').mkdir();(out/'work').mkdir()
            budget=base.persistence.Budget(out,c)
            point=base.checkpoint_point(model,optimizer,c,'multilingual_e5_large',3,
                    {role:[group] for role in base.ROLES},out,budget)
            self.assertTrue(point['full_model_and_adam_reloaded'])
            self.assertTrue(point['model']['actual_reload_verified'])
            self.assertFalse((out/'work/epoch3.pt').exists())
            for role in base.ROLES:
                a=np.load(out/point['scores'][role]['path'],allow_pickle=False)
                self.assertEqual(a.shape,(1,378));self.assertEqual(a.dtype,np.float32)
            DETAILS['torch_independent']={'device':'cpu','encoder':'hand-built embedding + linear, not pretrained',
                'groups':1,'accounts':28,'items':sum(map(len,group.items)),'positive_pairs':int(y.sum()),
                'steps':step_details,'optimizer_oracle':'manual AdamW recurrence; independent scalar clipping',
                'fresh_object_complete_model_Adam_restore_after_step1':True,
                'production_checkpoint_point_roles':3,'production_checkpoint_point_score_equality':'bitwise',
                'retained_inference_reload':True,'transient_full_checkpoint_removed':True}

    def test_09_text_pooling_symmetry_no_silent_truncation(self):
        model,c,g=make_tiny_group_model();model.eval()
        got=base.logits(model,g,c,'multilingual_e5_large')
        ref=reference_logits(model,g,'query: ')
        compare('input.all378_logits_max_error',float((got-ref).abs().max().detach()),0.,5e-7)
        # Group/account/item IDs are deliberately changed; actual text identical.
        changed=base.data.Group('other_group',tuple(f'x{i:02}' for i in range(28)),
                tuple(tuple((f'alt_{i}_{j}',t,d) for j,(_,t,d) in enumerate(items)) for i,items in enumerate(g.items)),g.labels)
        self.assertTrue(torch.equal(got,base.logits(model,changed,c,'multilingual_e5_large')))
        swapped=base.data.Group(g.uid,tuple(reversed(g.sellers)),tuple(reversed(g.items)),g.labels)
        actual=base.logits(model,swapped,c,'multilingual_e5_large')
        pairs=list(itertools.combinations(range(28),2));lookup={p:k for k,p in enumerate(pairs)}
        indices=[lookup[tuple(sorted((27-i,27-j)))] for i,j in pairs]
        compare('input.account_permutation_max_error',float((actual-got[indices]).abs().max().detach()),0.,5e-7)
        bad=copy.deepcopy(c);bad['input']['token_budget']=1
        with self.assertRaises(ValueError):base.logits(model,g,bad,'multilingual_e5_large')
        DETAILS['input_semantics']={'ID_renaming_no_logit_change':True,'all378_symmetric_permutation':True,
                                  'over_token_budget_rejected_not_truncated':True,'native_pretrained_pooling_executed':False}


def rebind_fixture(out):
    """Recompute outer fixture bindings so semantic mutations test beyond hashes."""
    run=base.data.read_json(out/'manifest.json')
    for arm in base.ARMS:
        run['arms'][arm]['manifest']=base.data.record(out/arm/'manifest.json',out)
    base.data.write_json(out/'manifest.json',run)
    completion=base.data.read_json(out/'completion.json');completion['manifest_sha256']=base.data.sha256(out/'manifest.json')
    base.data.write_json(out/'completion.json',completion)
    receipt=base.data.read_json(out/'model_verification.json');receipt['manifest_sha256']=base.data.sha256(out/'manifest.json')
    base.data.write_json(out/'model_verification.json',receipt)


def mutate_arm(out,arm,fn):
    path=out/arm/'manifest.json';a=base.data.read_json(path);fn(a);base.data.write_json(path,a);rebind_fixture(out)


def mutate_cal(out,arm,fn):
    path=out/arm/'calibration.json';a=base.data.read_json(path);fn(a);base.data.write_json(path,a)
    mutate_arm(out,arm,lambda a:a.update(calibration=base.data.record(path,out/arm)))


class TinyTokenizer:
    def __call__(self,texts,*,padding,truncation,return_tensors='pt'):
        if truncation is not False:raise AssertionError('Unexpected truncation')
        rows=[[1]+[2+ord(ch)%27 for ch in text]+[2] for text in texts]
        width=max(map(len,rows))
        return {'input_ids':torch.tensor([r+[0]*(width-len(r)) for r in rows]),
                'attention_mask':torch.tensor([[1]*len(r)+[0]*(width-len(r)) for r in rows])}


class TinyEncoder(torch.nn.Module):
    def __init__(self):
        super().__init__();self.embedding=torch.nn.Embedding(32,5);self.linear=torch.nn.Linear(5,5);self.tokenizer=TinyTokenizer()
    def forward(self,features):
        mask=features['attention_mask'].unsqueeze(-1)
        return {'sentence_embedding':self.linear((self.embedding(features['input_ids'])*mask).sum(1)/mask.sum(1))}


def make_tiny_group_model():
    torch.manual_seed(401) # synthetic fixture seed, NOT an additional research training seed
    model=base.core.build_model(TinyEncoder(),5,7)
    c=copy.deepcopy(base.contract());c['input'].update(encoder_bf16=False,microbatch=4)
    sellers=tuple(f's{i:02}' for i in range(28))
    items=tuple(tuple((f'i{i}_{j}',f'商品{i}x{j}',f'描述{(i*7+j)%23}') for j in range(2+i%7)) for i in range(28))
    group=base.data.Group('independent_synthetic_28',sellers,items,tuple(map(int,own_truth())))
    return model,c,group


def reference_logits(model,group,prefix):
    texts=[prefix+t+'\n'+d for items in group.items for _,t,d in items]
    features=model.encoder.tokenizer(texts,padding=True,truncation=False)
    # Direct module algebra, not production account_vectors / pool_records.
    mask=features['attention_mask'].unsqueeze(-1)
    embedding=model.encoder.embedding(features['input_ids'])
    x=model.encoder.linear((embedding*mask).sum(1)/mask.sum(1))
    normalized=x/x.norm(dim=1,keepdim=True)
    accounts=[];offset=0
    for items in group.items:
        a=sum(normalized[offset+j] for j in range(len(items)))/len(items)
        accounts.append(a/a.norm());offset+=len(items)
    pair_features=torch.stack([torch.cat([(accounts[i]-accounts[j]).abs(),accounts[i]*accounts[j]])
                              for i in range(28) for j in range(i+1,28)])
    return model.head(pair_features).flatten()


if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(IndependentReview)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    summary={'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
       'skips':len(result.skipped),'successful':result.wasSuccessful(),
       'numeric_comparisons':len(NUMBERS),'numeric_comparisons_passed':sum(r['passed'] for r in NUMBERS),
       'formal_label_reads':0,'pretrained_model_loads':0,'formal_training_updates':0,
       'project_linux_connections':0,'details':DETAILS}
    (EVIDENCE/'independent_results.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    with (EVIDENCE/'numeric_comparisons.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=['name','actual','independent','absolute_error','absolute_tolerance','passed'])
        writer.writeheader();writer.writerows(NUMBERS)
    print(json.dumps({k:v for k,v in summary.items() if k!='details'},ensure_ascii=False,indent=2))
    sys.exit(0 if result.wasSuccessful() else 1)
