import hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; p=ROOT/'input/review_package.zip'
def sha(b): return hashlib.sha256(b).hexdigest()
b=p.read_bytes(); expected='69ae0d1d712faddf6303da62f49f78a2edd05031d772036bf0e25b02c5a3f1da'
assert len(b)==247507 and sha(b)==expected
with zipfile.ZipFile(p) as z:
    manifest=json.loads(z.read('contents.json'))
    rows=[]
    for f in manifest['files']:
        name=f['path']; d=z.read(name); dest=ROOT/'source_snapshots'/name
        assert not Path(name).is_absolute() and '..' not in Path(name).parts
        row={**f,'actual_bytes':len(d),'actual_sha256':sha(d),'passed':len(d)==f['bytes'] and sha(d)==f['sha256']}
        rows.append(row); assert row['passed'],name
        dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(d)
    (ROOT/'source_snapshots'/'contents.json').write_bytes(z.read('contents.json'))
    assert len(rows)==37 and sum(r['actual_bytes'] for r in rows)==588538
    assert len(z.namelist()) == len(set(z.namelist())) == 38
    assert set(z.namelist())=={r['path'] for r in rows}|{'contents.json'}
    report={'zip_bytes':len(b),'zip_sha256':sha(b),'entries':len(z.namelist()),'manifest_files':len(rows),'manifest_payload_bytes':sum(r['actual_bytes'] for r in rows),'contents_json_bytes':len(z.read('contents.json')),'zip_crc_check':z.testzip(),'files':rows}
(ROOT/'evidence/archive_verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='files'},ensure_ascii=False,indent=2))
print('ALL 37 SIZE/SHA256 MATCH')
