#!/usr/bin/env python3
"""Re-hash submitted bytes and reconcile historical/final source receipts."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1];S=ROOT/'source_snapshots'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
c=json.loads((S/'contents.json').read_text())
files=[]
for r in c['files']:
 p=S/r['path'];row={'path':r['path'],'bytes':p.stat().st_size,'sha256':sha(p)}
 row['matches_submission']=row['bytes']==r['bytes'] and row['sha256']==r['sha256']
 assert row['matches_submission'];files.append(row)
p=S/'reports/seller_alias_continual/20260918/base_implementation'
v=json.loads((p/'20260918_111900/verification.json').read_text())
for r in v['source_files']:
 assert sha(S/r['path'])==r['sha256'] and (S/r['path']).stat().st_size==r['bytes']
returned=json.loads((p/'20260918_111900/returned.json').read_text())
for r in returned:
 f=p/'20260918_111900'/r['name'];assert f.stat().st_size==r['bytes'] and sha(f)==r['sha256']
hist=json.loads((p/'historical_sources.json').read_text())
prior=list((S/'reports/seller_alias_continual/20260910').rglob('review_reply.json'))
for r in hist:
 assert sha(S/r['path'])==r['sha256']
 r['actual_current_hash_matches']=True
 r['hash_literal_in_prior_originals']=[str(f.relative_to(S)) for f in prior if r['sha256'] in f.read_text()]
sync=json.loads((p/'20260918_111900/sync.json').read_text())
diff=[r for r in sync['files'] if sha(S/r['path'])!=r['sha256']]
assert [r['path'] for r in diff]==['scripts/step28_base_model.py']
policy=json.loads((S/'schema/step28_base_model_policy.json').read_text())
for key,filename in [('data_manifest_sha256','manifest.json'),('data_validation_sha256','validation.json')]:
 assert sha(S/policy['data_root']/filename)==policy[key]
report={'status':'PASS','submitted_payloads_unchanged':len(files),'payload_bytes':sum(r['bytes'] for r in files),
 'final_linux_source_receipt_verified':len(v['source_files']),'returned_files_verified':len(returned),
 'returned_bytes':sum(r['bytes'] for r in returned),'historical_five_dependencies':hist,
 'initial_sync_difference':diff,'difference_explanation_from_final_receipt':v['post_first_test_correction'],
 'formal_remote_state_reverified':False,'dataset_manifests_match_frozen_policy':True,'files':files}
(ROOT/'evidence/provenance_verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('files','historical_five_dependencies')},ensure_ascii=False,indent=2))
