from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parents[1];S=R/'source_snapshots'
B='reports/seller_alias_continual/20260918/base_implementation/'
H='reports/seller_alias_continual/20260910/'
paths=[B+'review_request.md','docs/SELLER_ALIAS_BASE_MODEL.zh.md','docs/SELLER_ALIAS_BASE_IMPLEMENTATION.zh.md',
 'scripts/step28_base_model.py','schema/step28_base_model_policy.json','tests/test_step28_base_model_contracts.py',
 'scripts/run_step28_base_model_linux_20260918.sh','scripts/step28_continual_population.py',
 'scripts/step28_continual_population_data.py','scripts/step28_continual_population_evaluate.py',
 'scripts/step28_continual_population_run.py','scripts/step28_continual_expression_run.py','schema/step7_semantic_model_policy.json',
 'AGENTS.md','docs/RESEARCH_DISCIPLINE.zh.md','docs/AI_RESEARCH_HANDOFF.zh.md','docs/SELLER_ALIAS_EXPRESSION_RESULT.zh.md',
 'docs/SELLER_ALIAS_JOINT_RESULT.zh.md',H+'expression_implementation/review_reply.json',H+'joint_implementation/review_reply.json',
 H+'joint_evaluation/20260910_200019/review_reply.json',H+'expression_generation/20260910_150500/data/manifest.json',
 H+'expression_generation/20260910_150500/data/validation.json',B+'20260918_111900/verification.json',B+'20260918_111900/sync.json',
 B+'20260918_111900/final_tests.log',B+'20260918_111900/final_resources.log',B+'20260918_111900/final_exit.txt',
 B+'20260918_111900/cpu_tests.log',B+'20260918_111900/cpu_resources.log',B+'20260918_111900/cpu_exit.txt',
 B+'20260918_111900/returned.json',B+'return_sync.json',B+'historical_sources.json',B+'20260918_111900/help.txt',
 B+'windows_cleanup.json',B+'windows_cleanup_completion.json']
manifest=json.loads((S/'contents.json').read_text())
assert set(paths)=={r['path'] for r in manifest['files']} and len(paths)==37
index=[];V=R/'evidence/numbered_sources';V.mkdir(exist_ok=True)
for i,path in enumerate(paths,1):
 p=S/path;data=p.read_bytes();lines=data.decode().splitlines();sid=f'S{i:02}'
 scope='全文审读；原字节大小/SHA逐项核验'
 if i in (14,15,16):scope='检索并审读本轮相关现行条款与历史边界；不宣称通读所有旧历史段落'
 if i in (22,23):scope='结构化解析原文；审读发布元数据、计数、隔离声明和适用限制；没有打开标签/owners载荷'
 if i>=24:scope='包内回执/日志审读或结构化核对；不代表本轮连接Linux验证'
 view=V/f'{sid}.txt';view.write_text('\n'.join(f'{j:04d} {s}' for j,s in enumerate(lines,1))+'\n')
 index.append(dict(id=sid,path=path,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),lines=len(lines),review_scope=scope,numbered_view=str(view.relative_to(R))))
(R/'evidence/source_index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
text=['# 来源索引与实际审读范围','',
 'Sxx 为本次证据包自定义来源号，不是平台自动 filecite。行号为原 UTF-8 文件的物理行号。',
 '原件见 source_snapshots/；可读行号副本见 evidence/numbered_sources/；全文散列见 source_index.json。',
 '所有37份清单文件均按大小和SHA核验。完整审读声明只适用于下表相应项。','',
 '| ID | 原相对路径 | 字节 | 行数 | 实际范围 |','|---|---|---:|---:|---|']
for r in index:text.append(f"| {r['id']} | `{r['path']}` | {r['bytes']} | {r['lines']} | {r['review_scope']} |")
text+=['','## 历史外审便于阅读的解码副本','',
 'S19 → evidence/historical_expression_implementation.txt（203行）；S20 → evidence/historical_joint_implementation.txt（223行）；S21 → evidence/historical_joint_evaluation.txt（253行）。',
 '三份历史外审原文已完整阅读；JSON原件保持原字节。历史回复中的下载链接并不意味着其附加证据已在本轮取得。',
 '', '## 外部第一方技术来源','', '见 evidence/web_sources.json。仅用于核对公开模型定义、AP和nextafter语义；未下载或加载任何预训练模型。',
 '', '## 本次独立执行证据','',
 '- E01：evidence/archive_verification.json；E02：evidence/provenance_verification.json。',
 '- E03：logs/provided_tests.log、logs/provided_tests_resources.log、logs/provided_tests.exit；E04：evidence/independent_results.json、numeric_comparisons.csv。',
 '- E05：evidence/end_to_end_results.json、end_to_end_numeric_comparisons.csv。',
 '- E06：evidence/minimal_patch_results.json、proposed_minimal.patch。',
 '- E07：logs/sandbox_environment.log。',
 '- 首次自编夹具的临时work目录遗漏及修复后结果均保留，详见 logs/independent_checks_attempt1.log 和 README。']
(R/'SOURCE_INDEX.md').write_text('\n'.join(text)+'\n')
web=[
 ('R1','LaBSE官方模型卡','https://huggingface.co/sentence-transformers/LaBSE','768维CLS、Dense(Tanh)、Normalize；模型卡116–123行。'),
 ('R2','E5-large作者模型卡','https://huggingface.co/intfloat/multilingual-e5-large','1024维、attention-mask mean；对称任务双方query前缀；105–122、212–225行。'),
 ('R3','BGE-M3作者模型卡','https://huggingface.co/BAAI/bge-m3','dense通道和1024维；不要求查询指令；133–164行。'),
 ('R4','BGE-M3官方Pooling配置','https://huggingface.co/BAAI/bge-m3/blob/main/1_Pooling/config.json','1024维，CLS=true、mean=false；115–122行。'),
 ('R5','scikit-learn AP官方文档','https://scikit-learn.org/stable/modules/generated/sklearn.metrics.average_precision_score.html','AP按召回增量加权，不等于梯形积分；638–643行。'),
 ('R6','NumPy nextafter官方文档','https://numpy.org/doc/stable/reference/generated/numpy.nextafter.html','指定方向的相邻可表示浮点数；165–196行。'),
 ('R7','E5-large官方Pooling配置','https://huggingface.co/intfloat/multilingual-e5-large/blob/main/1_Pooling/config.json','1024维，mean=true、CLS=false。')]
(R/'evidence/web_sources.json').write_text(json.dumps([dict(id=i,title=t,url=u,checked_facts=f,accessed='2026-09-18',scope='网页阅读；未下载模型；当前网页不证明项目冻结归档字节') for i,t,u,f in web],ensure_ascii=False,indent=2)+'\n')
print('Indexed all 37 submitted payloads; generated numbered source views and 7 primary-reference entries.')
