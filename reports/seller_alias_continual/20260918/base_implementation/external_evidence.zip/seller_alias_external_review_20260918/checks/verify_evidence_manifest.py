#!/usr/bin/env python3
"""Read-only verification of the downloaded review evidence package, not project data."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parents[1]
manifest = json.loads((root / 'EVIDENCE_MANIFEST.json').read_text(encoding='utf-8'))
expected = {row['path'] for row in manifest['files']}
actual = {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}
assert actual == expected | {'EVIDENCE_MANIFEST.json'}, 'Missing or additional evidence member'
for row in manifest['files']:
    raw = (root / row['path']).read_bytes()
    assert len(raw) == row['bytes'], row['path']
    assert hashlib.sha256(raw).hexdigest() == row['sha256'], row['path']
print(f"PASS: {len(expected)} evidence files match size and SHA256; manifest self excluded.")
