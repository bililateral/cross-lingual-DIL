# 来源索引与实际审读范围

Sxx 为本次证据包自定义来源号，不是平台自动 filecite。行号为原 UTF-8 文件的物理行号。
原件见 source_snapshots/；可读行号副本见 evidence/numbered_sources/；全文散列见 source_index.json。
所有37份清单文件均按大小和SHA核验。完整审读声明只适用于下表相应项。

| ID | 原相对路径 | 字节 | 行数 | 实际范围 |
|---|---|---:|---:|---|
| S01 | `reports/seller_alias_continual/20260918/base_implementation/review_request.md` | 4359 | 23 | 全文审读；原字节大小/SHA逐项核验 |
| S02 | `docs/SELLER_ALIAS_BASE_MODEL.zh.md` | 12357 | 83 | 全文审读；原字节大小/SHA逐项核验 |
| S03 | `docs/SELLER_ALIAS_BASE_IMPLEMENTATION.zh.md` | 10855 | 72 | 全文审读；原字节大小/SHA逐项核验 |
| S04 | `scripts/step28_base_model.py` | 40162 | 702 | 全文审读；原字节大小/SHA逐项核验 |
| S05 | `schema/step28_base_model_policy.json` | 3593 | 26 | 全文审读；原字节大小/SHA逐项核验 |
| S06 | `tests/test_step28_base_model_contracts.py` | 19510 | 343 | 全文审读；原字节大小/SHA逐项核验 |
| S07 | `scripts/run_step28_base_model_linux_20260918.sh` | 1058 | 29 | 全文审读；原字节大小/SHA逐项核验 |
| S08 | `scripts/step28_continual_population.py` | 9699 | 210 | 全文审读；原字节大小/SHA逐项核验 |
| S09 | `scripts/step28_continual_population_data.py` | 11587 | 258 | 全文审读；原字节大小/SHA逐项核验 |
| S10 | `scripts/step28_continual_population_evaluate.py` | 20911 | 349 | 全文审读；原字节大小/SHA逐项核验 |
| S11 | `scripts/step28_continual_population_run.py` | 21310 | 356 | 全文审读；原字节大小/SHA逐项核验 |
| S12 | `scripts/step28_continual_expression_run.py` | 26322 | 448 | 全文审读；原字节大小/SHA逐项核验 |
| S13 | `schema/step7_semantic_model_policy.json` | 3960 | 106 | 全文审读；原字节大小/SHA逐项核验 |
| S14 | `AGENTS.md` | 48919 | 129 | 检索并审读本轮相关现行条款与历史边界；不宣称通读所有旧历史段落 |
| S15 | `docs/RESEARCH_DISCIPLINE.zh.md` | 38543 | 105 | 检索并审读本轮相关现行条款与历史边界；不宣称通读所有旧历史段落 |
| S16 | `docs/AI_RESEARCH_HANDOFF.zh.md` | 204522 | 885 | 检索并审读本轮相关现行条款与历史边界；不宣称通读所有旧历史段落 |
| S17 | `docs/SELLER_ALIAS_EXPRESSION_RESULT.zh.md` | 13132 | 109 | 全文审读；原字节大小/SHA逐项核验 |
| S18 | `docs/SELLER_ALIAS_JOINT_RESULT.zh.md` | 10497 | 82 | 全文审读；原字节大小/SHA逐项核验 |
| S19 | `reports/seller_alias_continual/20260910/expression_implementation/review_reply.json` | 12841 | 13 | 全文审读；原字节大小/SHA逐项核验 |
| S20 | `reports/seller_alias_continual/20260910/joint_implementation/review_reply.json` | 14485 | 9 | 全文审读；原字节大小/SHA逐项核验 |
| S21 | `reports/seller_alias_continual/20260910/joint_evaluation/20260910_200019/review_reply.json` | 17260 | 7 | 全文审读；原字节大小/SHA逐项核验 |
| S22 | `reports/seller_alias_continual/20260910/expression_generation/20260910_150500/data/manifest.json` | 3790 | 93 | 结构化解析原文；审读发布元数据、计数、隔离声明和适用限制；没有打开标签/owners载荷 |
| S23 | `reports/seller_alias_continual/20260910/expression_generation/20260910_150500/data/validation.json` | 24290 | 1218 | 结构化解析原文；审读发布元数据、计数、隔离声明和适用限制；没有打开标签/owners载荷 |
| S24 | `reports/seller_alias_continual/20260918/base_implementation/20260918_111900/verification.json` | 2452 | 78 | 包内回执/日志审读或结构化核对；不代表本轮连接Linux验证 |
| S25 | `reports/seller_alias_continual/20260918/base_implementation/20260918_111900/sync.json` | 1888 | 60 | 包内回执/日志审读或结构化核对；不代表本轮连接Linux验证 |
| S26 | `reports/seller_alias_continual/20260918/base_implementation/20260918_111900/final_tests.log` | 2338 | 24 | 包内回执/日志审读或结构化核对；不代表本轮连接Linux验证 |
| S27 | `reports/seller_alias_continual/20260918/base_implementation/20260918_111900/final_resources.log` | 816 | 23 | 包内回执/日志审读或结构化核对；不代表本轮连接Linux验证 |
| S28 | `reports/seller_alias_continual/20260918/base_implementation/20260918_111900/final_exit.txt` | 2 | 1 | 包内回执/日志审读或结构化核对；不代表本轮连接Linux验证 |
| S29 | `reports/seller_alias_continual/20260918/base_implementation/20260918_111900/cpu_tests.log` | 2338 | 24 | 包内回执/日志审读或结构化核对；不代表本轮连接Linux验证 |
| S30 | `reports/seller_alias_continual/20260918/base_implementation/20260918_111900/cpu_resources.log` | 820 | 23 | 包内回执/日志审读或结构化核对；不代表本轮连接Linux验证 |
| S31 | `reports/seller_alias_continual/20260918/base_implementation/20260918_111900/cpu_exit.txt` | 2 | 1 | 包内回执/日志审读或结构化核对；不代表本轮连接Linux验证 |
| S32 | `reports/seller_alias_continual/20260918/base_implementation/20260918_111900/returned.json` | 1243 | 47 | 包内回执/日志审读或结构化核对；不代表本轮连接Linux验证 |
| S33 | `reports/seller_alias_continual/20260918/base_implementation/return_sync.json` | 240 | 7 | 包内回执/日志审读或结构化核对；不代表本轮连接Linux验证 |
| S34 | `reports/seller_alias_continual/20260918/base_implementation/historical_sources.json` | 942 | 27 | 包内回执/日志审读或结构化核对；不代表本轮连接Linux验证 |
| S35 | `reports/seller_alias_continual/20260918/base_implementation/20260918_111900/help.txt` | 520 | 14 | 包内回执/日志审读或结构化核对；不代表本轮连接Linux验证 |
| S36 | `reports/seller_alias_continual/20260918/base_implementation/windows_cleanup.json` | 505 | 12 | 包内回执/日志审读或结构化核对；不代表本轮连接Linux验证 |
| S37 | `reports/seller_alias_continual/20260918/base_implementation/windows_cleanup_completion.json` | 470 | 12 | 包内回执/日志审读或结构化核对；不代表本轮连接Linux验证 |

## 历史外审便于阅读的解码副本

S19 → evidence/historical_expression_implementation.txt（203行）；S20 → evidence/historical_joint_implementation.txt（223行）；S21 → evidence/historical_joint_evaluation.txt（253行）。
三份历史外审原文已完整阅读；JSON原件保持原字节。历史回复中的下载链接并不意味着其附加证据已在本轮取得。

## 外部第一方技术来源

见 evidence/web_sources.json。仅用于核对公开模型定义、AP和nextafter语义；未下载或加载任何预训练模型。

## 本次独立执行证据

- E01：evidence/archive_verification.json；E02：evidence/provenance_verification.json。
- E03：logs/provided_tests.log、logs/provided_tests_resources.log、logs/provided_tests.exit；E04：evidence/independent_results.json、numeric_comparisons.csv。
- E05：evidence/end_to_end_results.json、end_to_end_numeric_comparisons.csv。
- E06：evidence/minimal_patch_results.json、proposed_minimal.patch。
- E07：logs/sandbox_environment.log。
- 首次自编夹具的临时work目录遗漏及修复后结果均保留，详见 logs/independent_checks_attempt1.log 和 README。
