# 正式外审证据包 · 2026-09-18

## 结论与范围

完整中文报告见 `REPORT.zh.md`。本次实际审查模型为 **GPT-6 Astra Pro**；未核实网页 DOM／model_slug，未自行切换模型。原提交包已正式审查，原字节保持不变。

结论：0 项已证实 SCIENTIFIC_BLOCKER，2 项 REPRODUCIBILITY_DEFECT。R1 是 valid 前只接受旧的模型文件核验回执；R2 是单模型合并域条件区间缺失。最小修改见 `evidence/proposed_minimal.patch`，仅在合成函数级夹具中验证，不是已合并的生产版本。

没有连接项目 Linux，没有读取正式 train／valid／test／owners 标签，没有下载或加载任何真实预训练模型，没有执行正式训练、CUDA 或旧敏感性作业。所有出现的 Torch 参数更新、磁盘 checkpoint 与标签数组均来自临时的手工夹具。包内既有项目 Linux 日志只是原始材料，不能冒称本次远程执行。

## 文件导览

| 路径 | 内容 |
|---|---|
| `REPORT.zh.md` | 正式完整报告、分类处置、源码行号、独立证据与剩余未验证行为 |
| `SOURCE_INDEX.md` | 37 份来源的 ID、相对路径、大小、物理行数及实际审读范围 |
| `input/review_package.zip` | 用户提交原 ZIP，247507 字节，SHA256 `69ae0d1d712faddf6303da62f49f78a2edd05031d772036bf0e25b02c5a3f1da` |
| `source_snapshots/` | 37 份原件与 contents.json，未经修改 |
| `checks/verify_archive.py` | 对原 ZIP、每个清单文件的大小与 SHA 校验；从原 ZIP 还原相同快照 |
| `checks/verify_provenance.py` | 当前 37 件不变检查、最终 9 来源、9 回传文件、5 依赖与历史来源交叉核验 |
| `checks/independent_review_checks.py` | 9 个自编测试；手工阈值、22 指标、配对群重采样、显式 AdamW、真实微型 CPU 保存恢复、完整门反例 |
| `checks/end_to_end_numeric.py` | 六点评价驱动；8580 项独立数值回比，不使用真实模型输出 |
| `checks/check_minimal_patch.py` | 将建议函数编译到独立命名空间，验证 R1/R2 最小修改，不改源快照 |
| `checks/build_source_index.py` | 生成来源索引与原件行号副本 |
| `evidence/numeric_comparisons.csv` | 221 项数字回比：实际值、独立期望值、误差、容差与通过结果 |
| `evidence/end_to_end_numeric_comparisons.csv` | 8580 项数字回比，覆盖全部六点的逐群／分域／总体指标与候选配对差区间 |
| `evidence/*results.json` | 每个执行任务的结构化结果，明确标识合成范围 |
| `evidence/proposed_minimal.patch` | 建议补丁；没有更新冻结生产 SHA，也没有加入项目源码 |
| `evidence/numbered_sources/` | S01–S37 原文行号副本；这些是自定义定位号，不是平台 filecite |
| `evidence/historical_*.txt` | 三份历史外审 JSON 正文的便读解码，原 JSON 仍保留 |
| `evidence/web_sources.json` | 作者／官方模型卡、池化配置及 AP／nextafter 文档来源，含访问日期和使用范围 |
| `logs/` | 真实 stdout/stderr、退出状态与资源记录；首次夹具错误也保留 |
| `EVIDENCE_MANIFEST.json` | 本证据包其他全部文件的相对路径、字节数及 SHA256，自身明确不列入自身清单 |

## 实际环境与结果

Python 3.13.5；Torch 2.10.0+cpu；NumPy 2.3.5；Torch 单 CPU 线程；CUDA 不可用；sentence-transformers／transformers 未安装；没有安装依赖。其他预装包的实测信息见 `logs/sandbox_environment.log`。指标独立答案没有调用 scikit-learn 的同名函数来替代推导。

原 16 项 unittest：16 通过、0 跳过，其中两项真实 CPU Torch。自编 9 项：9 通过、0 跳过，221 项回比全通过。端到端合成评价：8580 项回比通过，最大绝对误差 3.3306690738754696e-16。两组 CSV 合计 **8801** 行数字回比，不重复计数原测试断言或补丁验证。

首次自编测试有 1 ERROR：夹具直接调用生产 checkpoint 函数前忘记创建临时 work 目录；生产 train_arm 会正常创建。此错误不归为项目缺陷。第一次的日志、JSON、CSV 和退出状态保存为 `*_attempt1.*`；修正审查夹具后生成无 attempt1 的最终记录。原测试还产生一条从 requires_grad 张量转换 Python 标量的 Warning，日志原样保留，没有当作跳过或静默吞掉。

## 可复核命令（仅合成沙箱）

以下记录在独立沙箱复核的入口，不要求用户电脑或项目 Linux 安装、运行。为避免覆盖下载包内的既有日志及数字证据，应先复制／另行解压到独立临时目录，**只在副本运行**。除 unittest 名称外，检查脚本用自身路径定位源快照，不依赖原 `/mnt/data` 位置。运行环境需已有 Python、NumPy、CPU Torch；此证据包不带模型、依赖安装器或字体。

```bash
cd <独立证据包副本>
export PYTHONDONTWRITEBYTECODE=1
export CUDA_VISIBLE_DEVICES=''
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
python -B checks/verify_archive.py
python -B checks/verify_provenance.py
bash -n source_snapshots/scripts/run_step28_base_model_linux_20260918.sh
python -B source_snapshots/scripts/step28_base_model.py --help
PYTHONPATH=source_snapshots/scripts:source_snapshots/tests \
  python -B -m unittest -v test_step28_base_model_contracts
python -B checks/independent_review_checks.py
python -B checks/end_to_end_numeric.py
python -B checks/check_minimal_patch.py
```

**不要执行原生产入口的 train／evaluate，也不要执行原 Linux 启动器。** 上述 `bash -n` 只检查其语法；生产评价路径只由自编检查在合成 public_inputs／解析哨兵替换下调用。`fake_run`、假模型回执与手工分数始终是控制流夹具，不是实际模型运行证书。

`verify_archive.py` 会将原 ZIP 内相同字节重新写入副本快照；其 SHA／大小必须完全一致。`verify_provenance.py` 是只读交叉验证源文件、输出核验结果。结果脚本会更新副本中的 evidence，因此重跑后的副本文件不再全部匹配原证据包的 EVIDENCE_MANIFEST；这是复核输出变化，不是提交原件变化。旧日志中的原沙箱绝对路径是当时实测记录，不影响脚本的相对路径复核。

## 阅读边界

本轮完整阅读审查请求、两份核心方案／实现文档、新入口／政策／测试／启动器、五份直接依赖、旧模型政策、两份结果文档和三份历史外审原文。AGENTS／科研纪律／长交接仅审读本轮相关条款与历史边界，不声称全文全部历史段落均审读。数据 manifest／validation 为发布元数据及现有核验声明；没有取回其列出的正式载荷。历史回复内链接的额外证据不在本次已取得范围。

证据包没有原始预训练权重、正式标签或可供恢复正式项目的模型。当前保留的是研究方案与原始负／正历史证据，不是对未来训练效果或 8 小时／32GiB 资源可达性的承诺。正式执行仍须遵循原授权边界。
