# 基础识别模型实现与核验

2026-09-18。[用户确认方案](SELLER_ALIAS_BASE_MODEL.zh.md)已落实为三模型匹配的离线训练、训练内校准及完整门后评价。主要目标仍是三个域各自FPR≤0.1%、Recall≥50%，没有改成只看AP或相对LaBSE增量。本记录不是达标结果，也不是新的持续学习方法结果。

用户最新明确脚本在既有Linux py310运行，不在Windows下载依赖或运行科研脚本。本次已据此连接、复制必要源码，并完成单CPU线程手工夹具检查；GPU不可用不妨碍此类检查。后续正式三模型训练仍待另行汇报恢复，既有权重敏感性等待不变。

## 需求到实际计算的核对

| 已确认要求 | 实际实现与证据 | 结论边界 |
|---|---|---|
| 自动判断同控，逐域低误报下召回 | `calibrate`只使用36群校准标签；三个域各允许4/4296误报，取统一阈值；`automatic_report`逐域以整数混淆计数判断，不能平均抵消失败 | valid每域须FP≤7、TP≥200；仅开发集点值筛选 |
| 三编码器匹配比较 | 三模型共用144群、六轮日程、未加权378边mean BCE、AdamW与账号聚合；原通用权重重新初始化训练 | 原LaBSE见过校准群，不能充当匹配参照；不声称等参数或等FLOPs |
| 参数学习与阈值校准隔离 | `partition`只按公开群ID、域和固定SHA规则划分48/12；`schedule`只接收拟合群；`train_arm`的优化器循环只取该日程 | 本次只对手工群划分，正式数据尚未处理 |
| 完整文本、无身份特征 | 仅title＋换行＋description；E5两端均加`query: `，BGE与LaBSE不加；每商品归一化、全部商品均值、账号归一化；absdiff＋product对称头 | 身份和域字段仅装配／对齐／评价，不传入模型；不静默截断 |
| 正确原生模型定义 | LaBSE 768维CLS＋Dense，E5 1024维mean，BGE-M3 1024维CLS dense通道；实际模块、维度、归档哈希及256 token限制在监督前检查 | 本次未加载真实预训练权重，原生模块和CUDA行为仍未实测 |
| 编码器与头共同训练 | 每次显式train、完整BCE反传、统一clip、AdamW；窗口首步分别检查两个模块梯度有限非零且参数改变；Adam步数1…864连续 | 两项小型真实CPU用例验证计算／梯度／两步状态恢复，不冒称已验证2592次GPU训练 |
| 固定训练量，不事后选轮数 | 144群×6轮×3模型＝2592更新；三轮与六轮固定保存，六轮主要比较；第二窗口不重置Adam或打乱流 | 不自动早停、重训、改阈值或挑赢家 |
| 保存和实际恢复 | 每个模型两个评分点，拟合144／校准36／valid60群均在完整model＋Adam保存恢复前后评分并要求逐值相等；六个推理模型另行保存、实际加载与哈希核验 | 正式两遍评分共2880次群前向，另加3次监督前盲前向；本次未执行这些前向 |
| valid完整门后一次读取 | 来源、政策、公开输入、划分、2592更新、六点全部分数、全局阈值绑定、六模型回执、外层exit0／耗时／预算均通过后，才调用一次valid parser | 测试使用手工真值与mock的正式读取接口；缺一个模型时接口未调用；正式监督0次 |
| 正确评价与不确定性 | 22指标完整保留，AP与梯形PR-AUC分列，含MRR/MAP及Recall/NDCG@1/3/5/10；校准阈值下计数、FPR/Recall/Precision逐域报告；对LaBSE做同群配对差及5000次域内群bootstrap | 固定logit0指标为辅助；条件区间不含训练随机性／校准重抽，不构成部署误报率保证 |
| 8小时／32GiB | 启动器timeout8h；Budget覆盖job目录；保存前预留，完整checkpoint与推理模型共存时强制采样 | 仍是离散观测，不称精确磁盘峰值；外层时间、日志与晚到回执另保留 |

## 亲自审读与修正

主执行者从用户目标出发审读[新入口](../scripts/step28_base_model.py)、[政策](../schema/step28_base_model_policy.json)、[启动器](../scripts/run_step28_base_model_linux_20260918.sh)、[测试](../tests/test_step28_base_model_contracts.py)，追踪五份直接旧依赖中的公开输入、二值监督对齐、群日程、模型头与聚合、AdamW、实际恢复、预算及全部指标。未沿用旧入口的LaBSE专用评分，因为它不处理E5前缀和新模型配置；复用底层纯函数，新评分路径覆盖训练与保存恢复两端。

开发中明确处理了float32分数与float64阈值比较：若直接在float32数组上比较相邻float64阈值，边界可能被舍入而纳入并列误报。现在先把logit提升为float64，并用人工并列反例核验。又将校准分数读取写成显式角色，不依赖前一循环变量；补齐阈值／模型／分数对应、校准混淆计数及外层时间核对。最后给原生编码器构造前也设置初始化种子，避免加载器初始化未用参数时的偶然随机状态造成前置检查与正式初始化不一致；头初始化仍独立设置。该最后修正在Linux复核后16项仍全部通过。

已完整阅读三份相关历史外审原文：

- [表达变化实现原文](../reports/seller_alias_continual/20260910/expression_implementation/review_reply.json)：历史身份按原记录，不追认为本轮GPT6 Pro。确认其阈值／bootstrap常量绑定缺口已由旧入口修复；新政策进一步绑定完整文件SHA。
- [联合延长实现原文](../reports/seller_alias_continual/20260910/joint_implementation/review_reply.json)：实际记录GPT6 Pro；承接完整Adam、静态风险、公开输入与完整门的审读范围适用于复用函数，不能替代本轮新增三模型／校准实现审查。
- [联合延长结果原文](../reports/seller_alias_continual/20260910/joint_evaluation/20260910_200019/review_reply.json)：原非阻断摘要笔误已闭合；离散磁盘采样限制保留，本轮共存时强制检查但不冒称连续高水位；低绝对召回与重复valid开发边界继续成立。

本轮未重跑上述历史实验、未重读旧标签；旧有效负结果保持。没有使用子agent。

## Linux实际检查

位置：`/home/yongpeng/cross-lingual/reports/seller_alias_continual/20260918/base_implementation/20260918_111900`。

环境为原`/home/yongpeng/miniconda3/envs/py310/bin/python`，Python3.10.19、Torch2.9.1+cu130、NumPy2.2.6、sentence-transformers5.6.0、transformers4.46.3。未安装或改动服务器环境。`CUDA_VISIBLE_DEVICES=''`且OMP/MKL/OpenBLAS均为1线程。11:15只读资源检查可用内存226723MiB、磁盘约952GiB；GPU仍被其他用户占用，仅余3999MiB，未使用GPU或干预他人进程。

执行命令为以下CPU检查；全部数据由测试手工构造，未运行`train`、`evaluate`正式动作：

```bash
cd /home/yongpeng/cross-lingual
source /home/yongpeng/miniconda3/etc/profile.d/conda.sh
conda activate py310
export CUDA_VISIBLE_DEVICES=''
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export PYTHONDONTWRITEBYTECODE=1
bash -n scripts/run_step28_base_model_linux_20260918.sh
python -B scripts/step28_base_model.py --help
python -B -m unittest discover \
  -s tests \
  -p test_step28_base_model_contracts.py \
  -v
```

最终16通过、0失败、0跳过，unittest计时2.350秒；两项为真实CPU Torch。外层用时2.88秒、最大RSS780588KiB（约762.3MiB），不能称正式训练耗时。第一次检查亦16通过0跳过，1.833秒；随后仅初始化种子前置修正触发复验，不重复扩大历史全套。测试中一次把仅供断言的requires_grad损失转为标量产生UserWarning，不影响反传、比较或结果；该提示不是科研失败。测试名称中的“完整运行”指手工回执夹具，不是三模型真实训练。

目前正式train／valid／test／owners读取均0，预训练模型加载0，正式更新0。Linux本次只复制4份新来源、复用5份原来源，初始9文件154104字节均两端大小/SHA一致；最后单文件种子修正后9份最终来源再按实际回执核对，五份原依赖另与9月16日前审SHA一致。原CPU输入ZIP留作首次检查的来源证据，不冒充最终源代码快照。检查日志及回执已原样回传；6026字节ZIP的SHA-256为`f23bdd52f46873c138fecce4c3d4f1a66f2b109798114e45a25b6b17e29b788f`，各成员逐项大小/SHA通过。SSH已退出，没有本轮后台检查进程。

直接证据：[Linux核验](../reports/seller_alias_continual/20260918/base_implementation/20260918_111900/verification.json)、[最终测试日志](../reports/seller_alias_continual/20260918/base_implementation/20260918_111900/final_tests.log)、[资源日志](../reports/seller_alias_continual/20260918/base_implementation/20260918_111900/final_resources.log)、[回传核对](../reports/seller_alias_continual/20260918/base_implementation/return_sync.json)、[历史来源核对](../reports/seller_alias_continual/20260918/base_implementation/historical_sources.json)。政策SHA为`3344572d6f48b4b10aabfe0db536a8052c75cac0c5cde4e1ac5c2a62c68ec5ab`，最终入口SHA为`31f549b527d61b93e1bc667a1b8d8c3b76954336c2c3ba63d699e03f47f1a294`。

## 外审准备与剩余范围

本轮按“实现与外审准备”整理[审查请求](../reports/seller_alias_continual/20260918/base_implementation/review_request.md)、[外审包](../reports/seller_alias_continual/20260918/base_implementation/review_package.zip)与逐文件清单。尚未向网页提交，不声称GPT6 Pro已审查或模型已达标。审查应独立判断该匹配比较是否能回答自动识别能力问题，重点检查训练内隔离、原生编码器处理、阈值边界、完整门和统计解释。通过审查也不等于真实CUDA训练已通过。

正式运行前仍须在已汇报并恢复的阶段确认资源、真实三模型来源／模块／分词／盲前向；真实模型的首个梯度更新、Adam连续性、各点评分与恢复由正式入口实际验证。没有必要现在追加未批准的模型试训或读取正式真值。任何失败保留证据，不自动换模型、重训或开放test。

Windows临时CPU环境清理已完成。最初误在Windows安装了CPU Torch，用户纠正后停止使用，确认本地相关运行进程为0。原生PowerShell删除被自动审批以`blocked by policy`拒绝，当时目录有20965文件、598953051字节。用户随后手动删除；11:28执行者独立核对`C:/Users/35734/AppData/Local/Temp/seller_alias_base_cpu_20260918`已不存在，见[完成回执](../reports/seller_alias_continual/20260918/base_implementation/windows_cleanup_completion.json)。原拒绝保留在[清理历史](../reports/seller_alias_continual/20260918/base_implementation/windows_cleanup.json)，不将用户删除记为执行者命令成功，也不虚构实测磁盘空间增量。
