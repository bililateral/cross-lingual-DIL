# 补充外审来源索引

N编号是本报告的证据索引，不是平台文件引用。逐行副本仅为阅读方便，原件保留在source目录，字节以contents.json为准。

|编号|来源|字节|SHA-256|
|---|---|---:|---|
|N01|`scripts/step28_base_model.py`|41435|`0a6bf3d4eda5695967d17d5f381f7a354ebaaeb4a38d6bd11931496e33ff6a38`|
|N02|`schema/step28_base_model_policy.json`|3593|`3344572d6f48b4b10aabfe0db536a8052c75cac0c5cde4e1ac5c2a62c68ec5ab`|
|N03|`scripts/step28_continual_population.py`|9699|`f8f158fff648990ae575228d1b8dc112ac8c515ec5d6acc23a598120d770db20`|
|N04|`scripts/step28_continual_population_data.py`|11587|`49cca1268b57422a46deefa8bc360423ccaeb8b5062750a39b540f0fb400e08d`|
|N05|`scripts/step28_continual_population_evaluate.py`|20911|`398825da73b25b3d06420d7a75428451f38ff97f1239af02120d4921c70bca4a`|
|N06|`scripts/step28_continual_population_run.py`|21310|`f0da5d51bb1291abe3417e5d695d8fc9134522d9fc7ced536417f4e484ab25e4`|
|N07|`scripts/step28_continual_expression_run.py`|26322|`3df878e3d78c07444cc0400b574adaf3a495b74fe193a14853706c7e9f67a760`|
|N08|`tests/test_step28_base_model_contracts.py`|22820|`68843a377fe02b52a011e2fca91c74bbbc0cd26ac5022f456ebe6ebafd07770e`|
|N09|`scripts/run_step28_base_model_linux_20260918.sh`|1058|`4473cb45f48ef1fca10b445e1f7de3615619e681cf257c391ef792329c1c74bb`|
|N10|`scripts/step28_base_model_audit.py`|8227|`b1403963b90f97289241d48cb3413a798b354480202a4fb88c2684abd5b21588`|
|N11|`docs/SELLER_ALIAS_BASE_MODEL.zh.md`|13366|`16435c12dec8d11e58935b6e5652adc963d7f721acf255e4a950b08f21a31de6`|
|N12|`reports/seller_alias_continual/20260918/base_implementation/native_review_request.md`|2952|`f2f4f7d55be6c864b97a08a3aea0c05bc33cd7e4d96c801032b076c8ba30e682`|
|N13|`reports/seller_alias_continual/20260918/base_implementation/native_audit/initial_failure.json`|1001|`64ed8a626908e634b07b4106b10fc42a5b541add4c3126ff4b04dc3a9c70c714`|
|N14|`reports/seller_alias_continual/20260918/base_implementation/native_audit/runtime.log`|513|`83828a5be814147dbd3fcc22cb6c0da34bb6c4eedd7222d2c24b283acfc7f598`|
|N15|`reports/seller_alias_continual/20260918/base_implementation/native_audit/resources.log`|1058|`8ff2d7b50e5be051a5f06296fdecfafe6ea5edf68bec498eb441c995429696b0`|
|N16|`reports/seller_alias_continual/20260918/base_implementation/native_audit/exit.txt`|2|`4355a46b19d348dc2f57c046f8ef63d4538ebb936000f3c9ee954a27460dd865`|
|N17|`reports/seller_alias_continual/20260918/base_implementation/native_audit/pooling_runtime.py`|16078|`7d5d180d88298342071148edf6989edddc298143af2469e981dd035885610f08`|

## 本轮外部原始资料

以下是公开模型/库定义核对，不是项目Linux模型实物核验；没有读取模型权重。

W01 — SentenceTransformers Modules：字符串/序列pooling_mode：`https://sbert.net/docs/package_reference/sentence_transformer/modules.html`

W02 — LaBSE作者模型定义：CLS、Dense(Tanh)、Normalize：`https://huggingface.co/sentence-transformers/LaBSE`

W03 — E5作者模型卡：1024维、mask mean及对称query前缀：`https://huggingface.co/intfloat/multilingual-e5-large`

W04 — BGE-M3作者模型卡：dense配置及无需额外查询指令：`https://huggingface.co/BAAI/bge-m3`

W05 — BGE-M3作者模块表：Transformer、Pooling、Normalize：`https://huggingface.co/BAAI/bge-m3/blob/main/modules.json`

W06 — E5作者模块表：Transformer、Pooling、Normalize：`https://huggingface.co/intfloat/multilingual-e5-large/blob/main/modules.json`

W07 — LaBSE作者模块表：Transformer、Pooling、Dense、Normalize：`https://huggingface.co/sentence-transformers/LaBSE/blob/main/modules.json`

W08 — 官网链接的当前Pooling源码，只作API佐证，不冒充服务器固定版本：`https://github.com/huggingface/sentence-transformers/blob/main/sentence_transformers/sentence_transformer/modules/pooling.py`

## 本轮执行证据

`evidence/integrity.json`：17份清单载荷逐文件实物核验。

`evidence/step28_base_model.py.diff`、`evidence/test_step28_base_model_contracts.py.diff`：相对于原review_package.zip的完整差异。

`evidence/current_contracts.log`及exit：20项合同测试真实输出。

`evidence/independent_checks.log`、exit与`independent_results.json`：7项独立检查、数字、12种模型实物变异和明确未执行范围。

`evidence/pre_native_entry_reconstructed.py`：从当前入口仅撤回native修复得到的派生核验文件，SHA吻合首次失败记录；不是伪称附件原文件。

`independent_native_checks.py`：独立检查代码，选定Pooling源码方法而非冒充安装包；本轮未执行真实load_model。

W09 — BGE-M3作者池化配置：`https://huggingface.co/BAAI/bge-m3/blob/main/1_Pooling/config.json`
