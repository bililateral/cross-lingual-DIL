"""Independent supplementary review. No pretrained weights or project labels.

The runtime Pooling arithmetic is executed from selected attached AST methods,
using torch.nn.Module only as the lightweight superclass. This is NOT a complete
SentenceTransformers installation, NOT a load_model test and NOT a native-model
training result. No packages are installed or injected into sys.modules.
"""
from __future__ import annotations
import ast, copy, csv, hashlib, json, os, platform, sys, tempfile, unittest, zipfile
from pathlib import Path
from types import SimpleNamespace
from unittest import mock
import numpy as np
import torch
ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'source'
EVIDENCE = ROOT / 'evidence'
sys.path.insert(0,str(SOURCE/'scripts'))
sys.path.insert(0,str(SOURCE/'tests'))
import step28_base_model as base
import test_step28_base_model_contracts as fixtures

torch.set_num_threads(1)
torch.use_deterministic_algorithms(True)
RESULTS = {'scope': 'CPU synthetic fixtures and extracted runtime methods only; zero pretrained loads, formal labels, formal training or Linux connections', 'environment': {'python':sys.version,'torch':torch.__version__,'numpy':np.__version__,'cuda':torch.cuda.is_available()},'checks':{}}
RUNTIME=SOURCE/'reports/seller_alias_continual/20260918/base_implementation/native_audit/pooling_runtime.py'


def sha(b): return hashlib.sha256(b).hexdigest()

def runtime_subset():
    tree=ast.parse(RUNTIME.read_text())
    original=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='Pooling')
    klass=copy.deepcopy(original)
    klass.bases=[ast.Name(id='TorchModule',ctx=ast.Load())]
    keep={'__init__','forward','_exclude_prompt_from_mask','_forward_padded'}
    klass.body=[n for n in klass.body if isinstance(n,(ast.Assign,ast.AnnAssign)) or isinstance(n,ast.FunctionDef) and n.name in keep]
    for n in klass.body:
        if isinstance(n,ast.FunctionDef) and n.name=='__init__': n.decorator_list=[]
    converter=copy.deepcopy(next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_convert_legacy_pooling_kwargs'))
    modes=copy.deepcopy(next(n for n in tree.body if isinstance(n,ast.AnnAssign) and isinstance(n.target,ast.Name) and n.target.id=='_LEGACY_POOLING_MODE_KWARGS'))
    assembled=ast.parse('from __future__ import annotations\n')
    assembled.body += [modes,converter,klass]
    ns={'torch':torch,'TorchModule':torch.nn.Module}
    exec(compile(ast.fix_missing_locations(assembled),str(RUNTIME),'exec'),ns)
    return ns['Pooling'],ns['_convert_legacy_pooling_kwargs']


class Supplement(unittest.TestCase):
    def test_01_attachment_and_failure_source_identity(self):
        rows=json.loads((SOURCE/'contents.json').read_text())
        for r in rows:
            b=(SOURCE/r['path']).read_bytes()
            self.assertEqual(len(b),r['bytes']);self.assertEqual(sha(b),r['sha256'])
        text=(SOURCE/'scripts/step28_base_model.py').read_text()
        fn=next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name=='pooling_modes')
        chunk=''.join(text.splitlines(True)[fn.lineno-1:fn.end_lineno])+'\n\n'
        before=text.replace(chunk,'',1)
        before=before.replace('    if pooling_modes(pool) != [m["pooling"]] or encoder.get_sentence_embedding_dimension() != m["embedding_dim"]:\n',
        '    active = [key for key, value in vars(pool).items()\n              if key.startswith("pooling_mode_") and value is True]\n    expected_pool = "pooling_mode_cls_token" if m["pooling"] == "cls" else "pooling_mode_mean_tokens"\n    if active != [expected_pool] or encoder.get_sentence_embedding_dimension() != m["embedding_dim"]:\n',1)
        failure=json.loads((RUNTIME.parent/'initial_failure.json').read_text())
        self.assertEqual(sha(before.encode()),failure['entry_sha256'])
        self.assertEqual(sha(RUNTIME.read_bytes()),failure['runtime_source_sha256'])
        RESULTS['checks']['source_identity']={'manifest_files':len(rows),'payload_bytes':sum(r['bytes'] for r in rows),'reconstructed_pre_native_sha256':sha(before.encode()),'current_entry_sha256':sha(text.encode()),'failure_source_match':True}

    def test_02_runtime_metadata_not_legacy_flags(self):
        Pooling,convert=runtime_subset()
        observations=[]
        for mode in ('cls','mean'):
            for representation in (mode,[mode],(mode,)):
                p=Pooling(3,representation)
                snapshot=copy.deepcopy(vars(p))
                old=[k for k,v in vars(p).items() if k.startswith('pooling_mode_') and v is True]
                current=base.pooling_modes(p)
                self.assertEqual(old,[]);self.assertEqual(current,[mode]);self.assertEqual(vars(p),snapshot)
                observations.append({'input':repr(representation),'native_stored':repr(p.pooling_mode),'old_flags':old,'current':current,'allowed':True})
            kw={'pooling_mode_cls_token':mode=='cls','pooling_mode_mean_tokens':mode=='mean'}
            convert(kw)
            self.assertEqual(kw,{'pooling_mode':mode})
            self.assertEqual(base.pooling_modes(Pooling(3,**kw)),[mode])
        for representation in (('cls','mean'),['cls','mean'],'max',()):
            p=Pooling(3,representation)
            self.assertNotIn(base.pooling_modes(p),[['cls'],['mean']])
            observations.append({'input':repr(representation),'native_stored':repr(p.pooling_mode),'current':base.pooling_modes(p),'allowed':False})
        for mode in ('cls','mean'):
            old=SimpleNamespace(pooling_mode_cls_token=mode=='cls',pooling_mode_mean_tokens=mode=='mean')
            self.assertEqual(base.pooling_modes(old),[mode])
        for bad in (42,{},np.array(['cls'])):
            with self.assertRaises(ValueError):base.pooling_modes(SimpleNamespace(pooling_mode=bad))
        # Active new API must prevail over stale legacy metadata.
        p=Pooling(3,'mean');p.pooling_mode_cls_token=True
        self.assertEqual(base.pooling_modes(p),['mean'])
        RESULTS['checks']['native_api']=observations

    def test_03_runtime_pooling_against_hand_arithmetic(self):
        Pooling,_=runtime_subset()
        tokens=torch.tensor([[[2.,4.,8.],[6.,8.,10.],[100.,200.,300.]],
                             [[100.,200.,300.],[3.,6.,9.],[7.,10.,13.]]],requires_grad=True)
        mask=torch.tensor([[1,1,0],[0,1,1]])
        expected={'cls':torch.tensor([[2.,4.,8.],[3.,6.,9.]]),
                  'mean':torch.tensor([[4.,6.,9.],[5.,8.,11.]])}
        results={}
        for mode in expected:
            p=Pooling(3,mode)
            features={'token_embeddings':tokens,'attention_mask':mask}
            out=p(features.copy())['sentence_embedding']
            torch.testing.assert_close(out,expected[mode],rtol=0,atol=0)
            before=out.detach().clone();base.pooling_modes(p)
            after=p(features.copy())['sentence_embedding']
            torch.testing.assert_close(before,after,rtol=0,atol=0)
            grad=torch.autograd.grad(out.sum(),tokens)[0]
            exp_grad=torch.zeros_like(tokens)
            if mode=='cls':exp_grad[0,0]=1;exp_grad[1,1]=1
            else:exp_grad[0,:2]=.5;exp_grad[1,1:]=.5
            torch.testing.assert_close(grad,exp_grad,rtol=0,atol=0)
            results[mode]={'output':out.detach().tolist(),'maximum_absolute_error':float((out-expected[mode]).detach().abs().max()),'gradient_exact':True,'selector_changes_output':False}
        RESULTS['checks']['pooling_arithmetic']=results

    def test_04_no_replay_objective_call_and_joint_schedule(self):
        tree=ast.parse((SOURCE/'scripts/step28_base_model.py').read_text())
        byname={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
        calls={k:sorted({ast.unparse(n.func) for n in ast.walk(byname[k]) if isinstance(n,ast.Call)}) for k in ('load_model','account_vectors','update','train_arm','run','evaluate')}
        allcalls={x for v in calls.values() for x in v}
        for prohibited in ('core.update','core.load_model','public.train_segment','public.run','persistence.run','data.Archive','data.Memory'):
            self.assertNotIn(prohibited,allcalls)
        self.assertIn('torch.nn.functional.binary_cross_entropy_with_logits',calls['update'])
        self.assertIn('optimizer.step',calls['update']);self.assertIn('model.encoder',calls['account_vectors'])
        self.assertNotIn('torch.inference_mode',calls['account_vectors'])
        c=base.contract();groups,metadata=fixtures.public_fixture()
        selected,part=base.partition(groups,metadata,c)
        sched,_=base.schedule(selected['fit'],c)
        calibration={g.uid for g in selected['calibration']}
        self.assertEqual(len(sched),864)
        self.assertFalse(calibration&{g.uid for g in sched})
        RESULTS['checks']['call_path_and_schedule']={'direct_calls':calls,'updates':864,'calibration_occurrences':sum(g.uid in calibration for g in sched)}

    def test_05_low_fpr_ties_and_joint_domain_gates(self):
        y=np.zeros((36,378),dtype=np.uint8);y[:,:20]=1
        s=np.full(y.shape,-1,dtype=np.float32);s[:,:20]=2
        for d in range(3):
            s[d*12,20:24]=np.float32(1.5);s[d*12,24:29]=np.float32(1.0)
        result=base.calibrate(y,s,list('A'*12+'B'*12+'C'*12))
        expected=float(np.nextafter(np.float64(1.),np.float64(np.inf)))
        self.assertEqual(result['threshold'],expected)
        self.assertEqual([result['counts_by_domain'][d][1] for d in 'ABC'],[4,4,4])
        wrongly_rounded=base.binary_counts(y,s,float(np.float32(expected)))
        rounded_fp=[int(wrongly_rounded[i*12:(i+1)*12,1].sum()) for i in range(3)]
        self.assertEqual(rounded_fp,[9,9,9])
        c=np.tile([10,0,10,358],(60,1));c[0]=[10,8,10,350]
        draws=np.random.default_rng(20260918).integers(0,20,(5000,3,20))
        a=base.automatic_report(c,list('A'*20+'B'*20+'C'*20),draws)
        self.assertLess(a['pooled']['fpr'],.001);self.assertFalse(a['all_domains_pass'])
        self.assertFalse(a['by_domain']['A']['passes_point_gates'])
        RESULTS['checks']['low_fpr']={'threshold':expected,'float64_fp':[4,4,4],'rounded_float32_fp':rounded_fp,'pooled_fpr_in_single_bad_domain_case':a['pooled']['fpr'],'all_domains_pass':a['all_domains_pass']}

    def test_06_r1_all_six_models_delete_or_change(self):
        rows=[]
        for arm in base.ARMS:
            for epoch in (3,6):
                for action in ('delete','same_size_change'):
                    with tempfile.TemporaryDirectory() as tmp:
                        out=Path(tmp)/'job/run';_,groups,meta,checked=fixtures.fake_run(out)
                        p=out/arm/'models'/f'epoch{epoch}.pt'
                        if action=='delete':p.unlink()
                        else:
                            b=p.read_bytes();p.write_bytes(bytes([b[0]^1])+b[1:])
                        with mock.patch.object(base.public,'public_inputs',return_value=(groups,meta,checked)),mock.patch.object(base.public,'attach_labels',side_effect=AssertionError('No formal labels')) as parse:
                            with self.assertRaises((ValueError,FileNotFoundError)):base.evaluate(out,Path(tmp)/'evaluation')
                            self.assertEqual(parse.call_count,0)
                        rows.append({'arm':arm,'epoch':epoch,'action':action,'blocked_before_parse':True,'parse_calls':parse.call_count})
        RESULTS['checks']['r1_six_model_mutations']=rows

    def test_07_pooled_bootstrap_and_ap_pr_auc(self):
        c=np.array([[5+i%13,i%5,15-i%13,358-i%5] for i in range(60)],dtype=np.int64)
        draws=np.random.default_rng(20260918).integers(0,20,(5000,3,20));unchanged=draws.copy()
        report=base.automatic_report(c,list('A'*20+'B'*20+'C'*20),draws)
        b=[]
        for sample in draws:
            total=sum((np.bincount(sample[d],minlength=20)@c[20*d:20*(d+1)] for d in range(3)),start=np.zeros(4,dtype=np.int64))
            tp,fp,fn,tn=total;b.append([fp/(fp+tn),tp/(tp+fn),tp/(tp+fp)])
        reference=np.quantile(np.asarray(b),[.025,.975],axis=0)
        for i,k in enumerate(('fpr','recall','precision')):
            np.testing.assert_allclose(report['pooled']['conditional_95pct_intervals'][k],reference[:,i],rtol=0,atol=1e-15)
        np.testing.assert_array_equal(draws,unchanged)
        curves=base.metrics.curve_metrics(np.array([1,0,1,0]),np.array([4.,3.,2.,1.]))
        self.assertAlmostEqual(curves['average_precision'],5/6,places=15)
        self.assertAlmostEqual(curves['trapezoidal_pr_auc'],19/24,places=15)
        self.assertEqual(len(base.metrics.COLUMNS),22)
        RESULTS['checks']['r2_and_curves']={'pooled':report['pooled'],'reference_intervals':reference.tolist(),'replicates':5000,'draws_unchanged':True,'curves':curves,'columns':list(base.metrics.COLUMNS)}

if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Supplement))
    RESULTS.update(passed=result.testsRun-len(result.failures)-len(result.errors)-len(result.skipped),tests_run=result.testsRun,failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped))
    (EVIDENCE/'independent_results.json').write_text(json.dumps(RESULTS,ensure_ascii=False,indent=2)+'\n')
    sys.exit(not result.wasSuccessful())
