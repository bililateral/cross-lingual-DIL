"""Verify and extract an audit archive; never reads formal supervision or model payloads."""
from pathlib import Path, PurePosixPath
import argparse, hashlib, json, zipfile

def digest(b): return hashlib.sha256(b).hexdigest()
def main():
    p=argparse.ArgumentParser(); p.add_argument('archive',type=Path);p.add_argument('destination',type=Path);p.add_argument('report',type=Path);a=p.parse_args()
    raw=a.archive.read_bytes()
    with zipfile.ZipFile(a.archive) as z:
        names=z.namelist(); m=json.loads(z.read('manifest.json')); records=m['files']; listed=[r['path'] for r in records]
        safe=all(not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts for n in names)
        checks=[]
        for r in records:
            b=z.read(r['path']); checks.append({**r,'actual_bytes':len(b),'actual_sha256':digest(b),'matched':len(b)==r['bytes'] and digest(b)==r['sha256']})
        report={'archive_name':a.archive.name,'archive_bytes':len(raw),'archive_sha256':digest(raw),'outer_reference_provided_in_current_message':False,'zip_members':len(names),'manifest_files':len(records),'manifest_bytes':len(z.read('manifest.json')),'listed_total_bytes':sum(x['actual_bytes'] for x in checks),'all_members_total_bytes':sum(i.file_size for i in z.infolist()),'crc_bad_member':z.testzip(),'duplicate_names':len(names)-len(set(names)),'unlisted_members':sorted(set(names)-set(listed)-{'manifest.json'}),'missing_members':sorted(set(listed)-set(names)),'safe_paths':safe,'all_files_match':all(x['matched'] for x in checks),'checks':checks}
        assert safe and report['all_files_match'] and not report['unlisted_members'] and not report['missing_members'] and not report['duplicate_names'] and not report['crc_bad_member']
        a.destination.mkdir(parents=True,exist_ok=True); z.extractall(a.destination)
    a.report.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    print(json.dumps({k:v for k,v in report.items() if k!='checks'},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
