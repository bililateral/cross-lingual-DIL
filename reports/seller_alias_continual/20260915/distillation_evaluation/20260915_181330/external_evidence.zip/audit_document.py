"""Check result-document rounded numeric tables against independently saved recomputations."""
from pathlib import Path
import argparse,json,csv,re
p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('audit',type=Path);a=p.parse_args();out=a.audit
read=lambda p:json.loads(p.read_text(encoding='utf8'))
comp=read(out/'recomputed_comparisons.json');absval=read(out/'absolute_metrics.json')['first_domain_final'];cls=read(out/'macro_micro.json')
trans=list(csv.DictReader((out/'six_ap_transitions.csv').open()));lines=(a.root/'docs/SELLER_ALIAS_DISTILLATION_RESULT.zh.md').read_text().splitlines();section=None;checks=[]
for lineno,line in enumerate(lines,1):
 if line.startswith('| 顺序/首域'):section='order';continue
 if line.startswith('| 顺序/新域'):section='transition';continue
 if line.startswith('| 指标 |'):section='metric';continue
 if line.startswith('| 首域micro'):section='micro';continue
 if not line.startswith('|') or '|---' in line:continue
 cells=[x.strip() for x in line.strip('|').split('|')];expected=None
 if section=='order' and '/' in cells[0]:
  o=cells[0].split('/')[0];v=comp['sequential']['average_precision']['by_order'][o];expected=[v[k] for k in ['F_seq','F_distill','H','G_distill']]
 elif section=='transition' and '/' in cells[0]:
  o,d=cells[0].split('/');r=next(x for x in trans if x['order']==o and x['domain']==d);expected=[float(r[k]) for k in ['sequential_after','random_er_after','distillation_after','N_vs_seq']]
 elif section=='metric' and cells[0] in absval['distillation']:
  expected=[absval[r][cells[0]] for r in ['sequential','random_er','distillation']]
 elif section=='micro' and cells[0] in cls['distillation']['first_domain']['micro']:
  expected=[cls[r]['first_domain']['micro'][cells[0]] for r in ['sequential','random_er','distillation']]
 if expected is not None:
  assert len(expected)==len(cells)-1
  for text,v in zip(cells[1:],expected):
   n=float(text);decimals=len(text.split('.')[1]);ok=abs(n-v)<=.5*10**(-decimals)+1e-15;checks.append({'line':lineno,'table':section,'reported':text,'independent_value':v,'matches_rounding':ok});assert ok
result={'status':'PASS','rounded_table_cells_checked':len(checks),'checks':checks,'nonblocking_document_scope_correction':{'file':'docs/SELLER_ALIAS_DISTILLATION_RESULT.zh.md','line':13,'reported_max_complete_cache_bytes':205128,'actual_meaning':'maximum of six saved boundary snapshots','maximum_recorded_complete_history_state_bytes':205146,'location':'training.ABC_distill_stage2.maximum_history_bytes','difference_bytes':18,'still_within_1MiB':True,'minimal_correction':'Label 205128 as maximum saved snapshot; report 205146 as maximum complete history state checked across insertion/training.'}}
(out/'document_audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print(json.dumps({k:v for k,v in result.items() if k!='checks'},ensure_ascii=False,indent=2))
