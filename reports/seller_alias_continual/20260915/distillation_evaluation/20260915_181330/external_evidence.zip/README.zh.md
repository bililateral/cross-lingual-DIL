# 外审证据包

入口报告：DISTILLATION_RESULT_EXTERNAL_REVIEW.zh.md。

仅使用已保存的清单、指标、计数和盲分数；没有标签、缓存正文、模型或新的生产运行。完整实际范围见review_scope_and_verdict.json。17986项与随包脚本复跑的14130项范围有重叠，不合并计数。

重跑方式（Python + NumPy；将原review.zip解压为ROOT，输出至另一个OUT目录）：

```bash
python -B audit_numerics.py ROOT OUT
python -B audit_execution.py ROOT OUT
python -B audit_document.py ROOT OUT
```

`audit_execution.py`可另加 `--prior-archive "review_upload(3).zip"`，核对本次源码与上一轮未修提交的字节差分。本次审查实际提供了该选项。

`verify_archive.py ARCHIVE DESTINATION REPORT_JSON`用于核验与解压。当前消息未提供外层期望摘要，记录的是当前ZIP的实测大小和SHA。

附带的生产侧independent_check.py在完整临时副本中原字节执行；该源脚本仍在原review.zip中的评价目录。本证据包保留其复跑日志与输出；没有改写原independent_audit.json。

生产py310的三项Torch通过属于正式日志证据，本轮没有重跑Torch测试。本包不授权任何训练、项目连接或监督访问。R3只需文档澄清，不修改原科研记录。
