"""Independent saved-output audit. No production imports, labels, models or training.
Usage: python audit_numerics.py EXTRACTED_ROOT OUTPUT_DIR
"""
from pathlib import Path
import argparse, hashlib, json, math, csv, platform, sys, collections
import numpy as np
ORDERS=('ABC','BCA','CAB'); DOMAINS='ABC'
def read(p): return json.loads(p.read_text(encoding='utf-8'))
def write(p,x): p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def classify(c):
    t,p,n,z=[int(c[k]) for k in ('tp','fp','fn','tn')]
    den=math.sqrt((t+p)*(t+n)*(z+p)*(z+n));rec=t/(t+n) if t+n else 0.;spe=z/(z+p) if z+p else 0.
    return dict(precision=t/(t+p) if t+p else 0.,recall=rec,f1=2*t/(2*t+p+n) if 2*t+p+n else 0.,specificity=spe,balanced_accuracy=(rec+spe)/2,mcc=(t*z-p*n)/den if den else 0.)
def main():
    pa=argparse.ArgumentParser();pa.add_argument('root',type=Path);pa.add_argument('out',type=Path);args=pa.parse_args();root=args.root;out=args.out;out.mkdir(parents=True,exist_ok=True)
    evdir=root/'reports/seller_alias_continual/20260915/distillation_evaluation/20260915_181330';new=read(evdir/'evaluation.json');cols=new['columns'];assert len(cols)==22
    dirs={'distillation':evdir,'sequential':(root/new['config']['origin_evaluation']).parent,'random_er':(root/new['config']['baseline_evaluation']).parent}
    records={r:read(p/'evaluation.json') for r,p in dirs.items()};suffix={'distillation':('shared','distill_stage2','distill_stage3'),'sequential':('shared','stage2','stage3'),'random_er':('shared','er_stage2','er_stage3')}
    arrays={};all_arrays={};checks=collections.defaultdict(lambda:dict(values=0,max_absolute_difference=0.));bad=[]
    def close(a,b,category,path=''):
        a=np.asarray(a,dtype=float);b=np.asarray(b,dtype=float);assert a.shape==b.shape,(path,a.shape,b.shape)
        err=float(np.max(abs(a-b))) if a.size else 0.;r=checks[category];r['values']+=int(a.size);r['max_absolute_difference']=max(err,r['max_absolute_difference'])
        if not np.isfinite(a).all() or not np.isfinite(b).all() or err>1e-12:bad.append((path,err))
    def tree(a,b,category,path=''):
        if isinstance(a,dict):
            assert set(a)==set(b),(path,set(a)^set(b))
            for k in a:tree(a[k],b[k],category,path+'/'+k)
        elif isinstance(a,list):close(a,b,category,path)
        else:close(a,b,category,path)
    for role,d in dirs.items():
        e=records[role];assert e['columns']==cols
        pts={}
        for name,p in e['points'].items():
            f=p['file'];path=d/f['path'];assert path.stat().st_size==f['bytes'] and sha(path)==f['sha256']
            a=np.load(path,allow_pickle=False);assert a.dtype==np.float64 and a.shape==(60,22) and np.isfinite(a).all();pts[name]=a
            for di,dom in enumerate(DOMAINS):
                close([math.fsum(a[di*20:(di+1)*20,j])/20 for j in range(22)],[p['by_domain'][dom][c] for c in cols],'all_point_domain_means',role+'/'+name+'/'+dom)
            assert len(p['confusion'])==60
            for gi,c in enumerate(p['confusion']):
                assert set(c)=={'tp','fp','fn','tn'} and all(isinstance(v,int) and v>=0 for v in c.values()) and c['tp']+c['fn']==20 and c['fp']+c['tn']==358
                for k,v in classify(c).items():close(v,a[gi,cols.index(k)],'confusion_derived_metrics',role+'/'+name+'/'+str(gi)+'/'+k)
        all_arrays[role]=pts
        arrays[role]=np.stack([[pts[o+'_'+s] for s in suffix[role]] for o in ORDERS])
    eq={}
    for role in ('sequential','random_er'):
        eq[role]=bool(np.array_equal(arrays['distillation'][:,0],arrays[role][:,0]));assert eq[role]
    runroot=root/'reports/seller_alias_continual/20260915/distillation_execution/20260915_164430/job/run';run=read(runroot/'manifest.json');assert sha(runroot/'manifest.json')==new['score_manifest_sha256']
    positives=0
    for name,p in new['points'].items():
        f=run['points'][name]['scores']['development'];path=runroot/f['path'];assert sha(path)==f['sha256'] and path.stat().st_size==f['bytes'];a=np.load(path,allow_pickle=False)
        assert a.shape==(60,378) and a.dtype==np.float32 and np.isfinite(a).all()
        for row,c in zip(a,p['confusion']):assert int(np.count_nonzero(row>=0))==c['tp']+c['fp'];positives+=1
    draws=np.random.default_rng(20260910).integers(0,20,size=(5000,3,20));counts=np.zeros((5000,3,20),dtype=np.int64)
    for d in range(3):
        np.add.at(counts[:,d],(np.repeat(np.arange(5000),20),draws[:,d].ravel()),1)
    assert np.all(counts.sum(-1)==20)
    comparisons={};sample_cross_checks=0
    a=arrays['distillation']
    def get(t,i,stage,d):return t[i,stage,20*d:20*(d+1)]
    for ref in ('sequential','random_er'):
        b=arrays[ref];rr='seq' if ref=='sequential' else 'random_er'
        names=['H','N','G_distill','G_'+rr,'F_distill','F_'+rr,'second_distill_change','second_'+rr+'_change','final_distill_minus_'+rr]
        terms={k:[[] for _ in range(3)] for k in names};per={}
        for i,o in enumerate(ORDERS):
            d=DOMAINS.index(o[0]);second=DOMAINS.index(o[1]);local={}
            for k,obs in [('H',get(a,i,2,d)-get(b,i,2,d)),('F_distill',get(a,i,0,d)-get(a,i,2,d)),('F_'+rr,get(b,i,0,d)-get(b,i,2,d)),('second_distill_change',get(a,i,2,second)-get(a,i,1,second)),('second_'+rr+'_change',get(b,i,2,second)-get(b,i,1,second))]:
                terms[k][second if k.startswith('second') else d].append(obs);local[k]=np.array([math.fsum(obs[:,j])/20 for j in range(22)])
            for k,t1,t0,mode in [('N',a,b,'absolute'),('G_distill',a,a,'gain'),('G_'+rr,b,b,'gain')]:
                trans=[]
                for stage in (1,2):
                    nd=DOMAINS.index(o[stage]);obs=get(t1,i,stage,nd)-get(t0,i,stage if mode=='absolute' else stage-1,nd);terms[k][nd].append(obs);trans.append(np.array([math.fsum(obs[:,j])/20 for j in range(22)]))
                local[k]=sum(trans)/2;local[k+'_transitions']=np.stack(trans)
            per[o]=local
            for d in range(3):terms['final_distill_minus_'+rr][d].append(get(a,i,2,d)-get(b,i,2,d))
        summaries={};groupvals={}
        for k,obs in terms.items():
            mat=np.stack([sum(v)/len(v) for v in obs]);groupvals[k]=mat
            samples=sum(counts[:,d].dot(mat[d])/20 for d in range(3))/3
            ci=np.quantile(samples,[.025,.975],axis=0,method='linear')
            means=np.array([math.fsum(mat[:,:,j].ravel())/60 for j in range(22)])
            dm=np.array([[math.fsum(mat[d,:,j])/20 for j in range(22)] for d in range(3)])
            summaries[k]=(means,dm,ci)
            # Independent direct gathering cross-check, AP only, no new intervals/tests.
            direct=sum(mat[d,draws[:,d],0].mean(1) for d in range(3))/3
            assert np.max(np.abs(direct-samples[:,0]))<1e-12;sample_cross_checks+=len(direct)
        assert np.max(abs(groupvals['H']-(groupvals['F_'+rr]-groupvals['F_distill'])))<1e-14
        result={}
        for j,metric in enumerate(cols):
            con={k:{'mean':float(v[0][j]),'by_domain_or_first_domain':v[1][:,j].tolist(),'conditional_95pct_interval':v[2][:,j].tolist()} for k,v in summaries.items()}
            by={o:{k:float(v[j]) if v.ndim==1 else v[:,j].tolist() for k,v in local.items()} for o,local in per.items()}
            def means_dict(t,stage):return {o:{dom:float(math.fsum(get(t,i,stage,d)[:,j])/20) for d,dom in enumerate(DOMAINS)} for i,o in enumerate(ORDERS)}
            initial=all_arrays['sequential']['initial']
            absolute={'initial':{d:float(math.fsum(initial[20*di:20*(di+1),j])/20) for di,d in enumerate(DOMAINS)},'shared':means_dict(b,0),'final':{}}
            for role,t in [('distillation',a),(ref,b)]:
                row=means_dict(t,2);absolute['final'][role]={'by_order_and_domain':row,'domain_order_group_equal_mean':math.fsum(v for rs in row.values() for v in rs.values())/9}
            result[metric]={'contrasts':con,'by_order':by,'absolute':absolute}
        stored=new['comparison']['metrics'] if ref=='sequential' else new['versus_random_er']
        tree(result,stored,'complete_comparison_fields',ref)
        comparisons[ref]=result
    ap=comparisons['sequential']['average_precision'];h=ap['contrasts']['H'];n=ap['contrasts']['N'];cfg=new['config']['evaluation']
    same=[o for o,v in ap['by_order'].items() if v['H']>0 and v['G_distill']>=cfg['new_gain_min']]
    gates={'checks':{'retention':h['mean']>=cfg['retention_min'] and h['conditional_95pct_interval'][0]>0,'new_capability':n['conditional_95pct_interval'][0]>=cfg['new_difference_floor'],'same_order_learning_and_retention':len(same)>=cfg['same_orders']},'same_orders':same}
    gates['passed']=all(gates['checks'].values());assert gates==new['comparison']['gate'];incremental=comparisons['random_er']['average_precision']['contrasts']['H']['conditional_95pct_interval'][0]>0;assert incremental==new['incremental_retention_passed']
    first={};classification={};allfinal={}
    for role,t in arrays.items():
        ff=np.concatenate([get(t,i,2,i) for i in range(3)]);first[role]={c:math.fsum(ff[:,j])/60 for j,c in enumerate(cols)}
        allfinal[role]={c:math.fsum(t[:,2,:,j].ravel())/180 for j,c in enumerate(cols)}
        classification[role]={}
        for scope in ('first_domain','all_final_domains'):
            rows=[]
            for i,o in enumerate(ORDERS):
                cs=records[role]['points'][o+'_'+suffix[role][2]]['confusion'];rows.extend(cs[i*20:(i+1)*20] if scope=='first_domain' else cs)
            c={k:sum(row[k] for row in rows) for k in ('tp','fp','fn','tn')};classification[role][scope]={'counts':c,'micro':classify(c),'macro':{k:(first if scope=='first_domain' else allfinal)[role][k] for k in classify(c)}}
    transitions=[]
    for i,o in enumerate(ORDERS):
        for stage in (1,2):
            d=DOMAINS.index(o[stage]);row={'order':o,'stage':stage+1,'domain':o[stage]}
            for role,t in arrays.items():
                bef=math.fsum(get(t,i,stage-1,d)[:,0])/20;aft=math.fsum(get(t,i,stage,d)[:,0])/20;row.update({role+'_before':bef,role+'_after':aft,role+'_gain':aft-bef})
            row['N_vs_seq']=row['distillation_after']-row['sequential_after'];row['N_vs_random_er']=row['distillation_after']-row['random_er_after'];transitions.append(row)
    csvrows=[{'metric':c,**{role:first[role][c] for role in arrays},'new_minus_seq':first['distillation'][c]-first['sequential'][c],'new_minus_er':first['distillation'][c]-first['random_er'][c]} for c in cols]
    for filename,rows in [('first_domain_22_metrics.csv',csvrows),('six_ap_transitions.csv',transitions)]:
        with (out/filename).open('w',newline='',encoding='utf8') as f:w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
    write(out/'recomputed_comparisons.json',comparisons);write(out/'macro_micro.json',classification);write(out/'absolute_metrics.json',{'first_domain_final':first,'all_final_domains':allfinal})
    result={'status':'PASS' if not bad else 'FAIL','environment':{'python':sys.version,'platform':platform.platform(),'numpy':np.__version__},'comparisons_by_category':dict(checks),'floating_values_compared':sum(v['values'] for v in checks.values()),'maximum_absolute_difference':max(v['max_absolute_difference'] for v in checks.values()),'shared_matrices_exact':eq,'shared_exact_element_comparisons':7920,'blind_positive_count_checks':positives,'weighted_vs_direct_bootstrap_AP_values':sample_cross_checks,'bootstrap':{'replicates':5000,'seed':20260910,'sampling_unit':'20 groups per underlying domain; shared all methods times orders'},'gate':gates,'incremental_retention_passed':incremental,'mismatches':bad,'formal_labels_parsed':0,'production_imports':False,'AP_recomputed_from_truth':False,'model_loads':0,'scope':'Saved matrices, counts, blind score threshold totals, summaries and original prescribed bootstrap only; no new experiment or inference.'}
    write(out/'numeric_audit.json',result);print(json.dumps(result,ensure_ascii=False,indent=2));assert not bad
if __name__=='__main__':main()
