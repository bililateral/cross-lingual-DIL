"""Read-only audit of execution records and non-supervision artifacts.
No production import, model/cache payload load, network or label parser.
"""
from pathlib import Path
import argparse,hashlib,json,random,ast,collections,datetime,difflib,zipfile,math,re
import numpy as np
ORDERS=('ABC','BCA','CAB')
def read(p):return json.loads(p.read_text(encoding='utf8'))
def jb(x):return (json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def sha(b):return hashlib.sha256(b).hexdigest()
def file_record(p,base):return {'path':p.relative_to(base).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8')
def seed(*parts):return int.from_bytes(hashlib.sha256(jb(list(parts))).digest()[:8],'big')%(2**63-1)
def main():
 pa=argparse.ArgumentParser();pa.add_argument('root',type=Path);pa.add_argument('out',type=Path);pa.add_argument('--prior-archive',type=Path);a=pa.parse_args();root=a.root;out=a.out;out.mkdir(parents=True,exist_ok=True)
 b=root/'reports/seller_alias_continual/20260915';ex=b/'distillation_execution/20260915_164430';runroot=ex/'job/run';new=read(runroot/'manifest.json');c=new['config'];oldroot=root/c['origin_run'];old=read(oldroot/'manifest.json');erroot=root/c['baseline_run'];er=read(erroot/'manifest.json');evdir=b/'distillation_evaluation/20260915_181330';ev=read(evdir/'evaluation.json');probe_root=b/'replay_probe_execution/20260915_141813/job/run';probe=read(probe_root/'manifest.json')
 # Actual source files, frozen configurations and fixed-reference hashes.
 sources={}
 for role,r in [('expression',old),('random_er',er),('distillation',new)]:
  checks=[]
  for f in r['source_files']:
   actual=file_record(root/f['path'],root);assert actual==f,(role,f['path']);checks.append(actual)
  sources[role]=checks
 assert len(sources['expression'])==8 and len(sources['random_er'])==12 and len(sources['distillation'])==17
 for pathkey,key in [('origin_run','origin_manifest_sha256'),('origin_evaluation','origin_evaluation_sha256'),('baseline_run','baseline_run_sha256'),('baseline_evaluation','baseline_evaluation_sha256')]:
  p=root/c[pathkey];p=p/'manifest.json' if pathkey.endswith('_run') else p;assert sha(p.read_bytes())==c[key]
 assert c==read(root/'schema/step28_continual_distillation_policy.json')==ev['config'];assert sha((runroot/'manifest.json').read_bytes())==ev['score_manifest_sha256']
 for k in ('origin_run','origin_manifest_sha256','origin_evaluation','origin_evaluation_sha256','physical_updates','memory','evaluation','label_parses','runtime'):assert c[k]==er['config'][k],k
 assert c['distillation']=={'coefficient':.5,'target_dtype':'<f4','target_timing':'arrival_stage_end_after_reservoir_selection','refresh_survivors':False,'history_forward':'shared_bce_mse_train_mode','maximum_target_group_forwards':36}
 impl=b/'distillation_implementation';fix=read(impl/'review_verification.json')
 for f in fix['new_sources']:assert file_record(root/f['path'],root)==f
 old_diffs={}
 if a.prior_archive:
  with zipfile.ZipFile(a.prior_archive) as z:
   for f in new['source_files']:
    path=f['path'];now=(root/path).read_bytes()
    if path not in z.namelist():old_diffs[path]={'previously_absent':True};continue
    before=z.read(path)
    if before!=now:
     text=''.join(difflib.unified_diff(before.decode().splitlines(True),now.decode().splitlines(True),fromfile='previous/'+path,tofile='current/'+path));old_diffs[path]={'before_sha256':sha(before),'after_sha256':sha(now),'diff':text}
   path='scripts/step28_continual_distillation.py';bef=z.read(path)
   expected=bef.replace(b'def observe(gradient:',b'def observe_gradient(gradient:').replace(b'lambda g, n=name: observe(g, n)',b'lambda g, n=name: observe_gradient(g, n)')
   assert expected==(root/path).read_bytes()
  assert set(old_diffs)=={'scripts/step28_continual_distillation.py','tests/test_step28_continual_distillation_contracts.py'}
 dump(out/'source_integrity_and_D1_D2.json',{'sources':sources,'changes_from_previous_submission':old_diffs,'D1_current_hook_rename_exact':bool(a.prior_archive) if a.prior_archive else None,'D2_policy_present':file_record(root/'schema/step28_continual_population_policy.json',root),'prior_review_id':fix['reply_id'],'historical_three_errors_not_reclassified':True})
 # All attached NPY byte inventories (no reconstruction of labels).
 inventory=[]
 for p in sorted(root.rglob('*.npy')):
  x=np.load(p,allow_pickle=False);assert np.isfinite(x).all();assert (x.shape,x.dtype.str) in [((60,378),'<f4'),((60,22),'<f8'),((60,23),'<f8')]
  inventory.append({'path':p.relative_to(root).as_posix(),'shape':list(x.shape),'dtype':str(x.dtype),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())})
 dump(out/'array_inventory.json',inventory)
 # Fixed inputs, initialization and public identities.
 assert new['inputs']==old['inputs']==er['inputs'];assert new['pretrained']==old['pretrained']==er['pretrained']
 meta=new['inputs']['metadata'];assert len(meta)==240 and len({r['group_uid'] for r in meta})==240
 ids={d:sorted(r['group_uid'] for r in meta if r['split']=='train' and r['domain']==d) for d in 'ABC'}
 assert all(len(v)==60 for v in ids.values());valid=[r['group_uid'] for r in sorted(meta,key=lambda r:(r['domain'],int(r['group_index']))) if r['split']=='development'];assert len(valid)==60 and valid==new['inputs']['valid_group_ids'];assert probe['valid_ids']==valid
 history=[];paired=[];teachers=[];shared=[];loss_records=[]
 for order in ORDERS:
  assert new['starts'][order]==old['points']['initial']['checkpoint']['state_sha256']
  assert new['starts'][order+'_continuation']==old['points'][order+'_shared']['checkpoint']['state_sha256']
  rng=random.Random(seed(20260909,order,'memory'));kept=[];seen=0;previous_targets={}
  for stage in (1,2,3):
   name=order+('_shared' if stage==1 else '_distill_stage'+str(stage));oldname=order+('_shared' if stage==1 else '_stage'+str(stage));ername=name.replace('_distill_','_er_');t=new['training'][name]
   stream=seed(20260909,order,stage,'current');s_rng=random.Random(stream);schedule=[]
   for epoch in range(3):
    rows=ids[order[stage-1]].copy();s_rng.shuffle(rows);schedule.extend(rows)
   assert t['group_ids']==schedule==old['training'][oldname]['group_ids']==er['training'][ername]['group_ids'];assert t['dropout_stream']==stream==old['training'][oldname]['dropout_stream']==er['training'][ername]['dropout_stream']
   assert t['updates']==180 and t['first_adam_step']==180*(stage-1)+1 and t['last_adam_step']==180*stage
   paired.append({'name':name,'current_ids':schedule,'dropout_stream':stream,'adam_first':t['first_adam_step'],'adam_last':t['last_adam_step']})
   p=new['points'][name];assert p['full_model_and_adam_reloaded'];f=p['scores']['development'];assert file_record(runroot/f['path'],runroot)==f
   if stage==1:
    for k,v in old['training'][oldname].items():
     if k!='training_seconds':assert t[k]==v
    for k in ('model_state_sha256',):assert p[k]==old['points'][oldname][k]
    assert p['checkpoint']['state_sha256']==old['points'][oldname]['checkpoint']['state_sha256']
    sf=old['points'][oldname]['scores']['development'];assert (runroot/f['path']).read_bytes()==(oldroot/sf['path']).read_bytes();assert np.array_equal(np.load(runroot/f['path'],allow_pickle=False),np.load(oldroot/sf['path'],allow_pickle=False))
    shared.append({'order':order,'complete_model_and_adam_digest_matches':True,'actual_full_blind_score_bytes_match':True})
   else:
    draw=random.Random(seed(20260909,order,stage,'replay_draw'));expected_draws=[draw.choice(kept) for _ in range(180)]
    assert expected_draws==t['replay_group_ids']==er['training'][ername]['replay_group_ids']
    assert t['current_pair_presentations']==t['replay_pair_presentations']==68040 and t['reservoir_unchanged'] and t['targets_unchanged'] and t['distillation_coefficient']==.5 and t['final_index']==180
    branch=t['first_update'];assert branch['encoder_and_head_changed'] and set(branch['branches_squared_hook_norm'])=={'current','replay'}
    for v in branch['branches_squared_hook_norm'].values():assert set(v)=={'encoder','head'} and all(math.isfinite(x) and x>0 for x in v.values())
    for k in ('current_bce_by_epoch','replay_bce_by_epoch','replay_mse_by_epoch'):assert len(t[k])==3 and all(math.isfinite(x) and x>=0 for x in t[k])
    # Independently recover exact RNG/index length changes with immutable unknown body omitted.
    previous_name=order+('_shared' if stage==2 else '_distill_stage2');receipt=new['memory'][previous_name];d_rng=random.Random(seed(20260909,order,stage,'replay_draw'))
    variable=lambda i:len(jb({'index':i,'replay_rng':d_rng.getstate()}));start_len=variable(0);max_len=receipt['full_state_bytes']
    for index in range(1,181):d_rng.choice(kept);max_len=max(max_len,receipt['full_state_bytes']+variable(index)-start_len)
    assert max_len==t['maximum_history_bytes']
    history.append({'name':name,'replay_ids':expected_draws,'reported_history_max':t['maximum_history_bytes'],'conditional_reconstructed_history_max':max_len,'starting_payload_size_is_receipt_based':True})
    loss_records.append({'name':name,**{k:t[k] for k in ('current_bce_by_epoch','replay_bce_by_epoch','replay_mse_by_epoch','maximum_gradient_norm_before_clip','first_update')}})
   if stage<3:
    arriving=ids[order[stage-1]]
    for uid in arriving:
     seen+=1
     if len(kept)<6:kept.append(uid)
     else:
      j=rng.randrange(seen)
      if j<6:kept[j]=uid
    m=new['memory'][name];em=er['memory'][ername];newids=[u for u in kept if u in arriving];tr=m['teacher'];tar=tr['targets']
    assert m['retained_groups']==kept==em['retained_groups'] and m['added_groups']==arriving==em['added_groups'];assert m['seen']==seen and m['stage']==stage+1 and m['index']==0 and m['order']==order
    assert m['disk_roundtrip_exact'] and m['full_state_bytes']==m['file']['bytes'] and 0<m['full_state_bytes']<=1048576
    assert m['next_draw']==random.Random(seed(20260909,order,stage+1,'replay_draw')).choice(kept)
    assert tr['new_groups']==newids and tr['group_forwards']==len(newids) and tr['model_state_unchanged'];assert m['full_state_bytes']<=tr['maximum_insertion_history_bytes']<=1048576 and set(tar)==set(kept)
    for uid,v in tar.items():
     assert set(v)=={'point','model_state_sha256','pair_order_sha256','sha256'} and all(len(v[k])==64 for k in ('model_state_sha256','pair_order_sha256','sha256'))
     if uid in newids:assert v['point']==name and v['model_state_sha256']==p['model_state_sha256']
     else:assert v==previous_targets[uid]
    # Base64 alphabet contains no JSON-escaped characters: placeholder has exact length only.
    fake={u:{**v,'float32_base64':'A'*2016} for u,v in tar.items()};extra=len(jb({'replay':{},'targets':fake}))-len(jb({}));expected_size=em['full_state_bytes']+extra;assert expected_size==m['full_state_bytes']
    teacher_checks=[]
    if stage==1:
     pp=probe['points'][name];assert pp['source']['model_state_sha256']==p['model_state_sha256'];pf=pp['scores']['train'];assert file_record(probe_root/pf['path'],probe_root)==pf;prior=np.load(probe_root/pf['path'],allow_pickle=False);assert probe['train_ids'][order]==ids[order[0]]
     for uid,v in tar.items():
      raw=np.asarray(prior[probe['train_ids'][order].index(uid)],dtype='<f4').tobytes();assert sha(raw)==v['sha256'];teacher_checks.append({'uid':uid,'target_sha256':v['sha256'],'prior_same_model_train_blind_row_sha256_matches':True})
    teachers.append({'name':name,'retained_groups':kept.copy(),'new_groups':newids,'forwards':len(newids),'full_state_bytes':m['full_state_bytes'],'maximum_insertion_history_bytes':tr['maximum_insertion_history_bytes'],'added_target_envelope_bytes':extra,'size_reconstructed_from_original_ER_receipt':expected_size,'old_survivors_unchanged':[u for u in tar if u not in newids],'evicted_target_uids':sorted(set(previous_targets)-set(tar)),'first_stage_blind_value_checks':teacher_checks,'seconds':tr['seconds']})
    previous_targets=tar
 assert sum(t['forwards'] for t in teachers)==new['teacher_group_forwards']==25
 assert sum(t['updates'] for t in new['training'].values())==new['physical_updates']==1620
 assert new['group_forwards_with_replay']==1080 and len(new['points'])==9 and len(new['memory'])==6 and len(new['models'])==3
 assert new['label_parses']=={'train':1,'development':0,'heldout':0,'owners':0};assert ev['label_parses']=={'train':0,'development':1,'heldout':0,'owners':0}
 assert read(runroot/'access.json')=={'train_parse_attempts':1,'development':0,'heldout':0,'owners':0};assert read(evdir/'access.json')=={'status':'COMPLETE_GATE_PASSED_VALID_PARSE_STARTING','development_parse_attempts':1,'train':0,'heldout':0,'owners':0}
 # Log event checks independent of summary flags.
 text=(ex/'job/train.log').read_text();assert 'Ran 3 tests in 1.319s' in text and '\nOK\n' in text and 'Traceback' not in text;events=[]
 for line in text.splitlines():
  if line.startswith('{'):events.append(json.loads(line))
 point_events=[v for v in events if v.get('event')=='point_reloaded'];assert len(point_events)==9 and {v['point'] for v in point_events}==set(new['points'])
 for pe in point_events:
  for k,v in new['points'][pe['point']]['timing'].items():assert pe[k]==v
 for o in ORDERS:
  for s in (1,2,3):
   q=[v['completed'] for v in events if (v.get('segment')==o+'_shared' if s==1 else v.get('order')==o and v.get('stage')==s and v.get('event')=='replay_updates')];assert q==[30,60,90,120,150,180]
 assert events[-1]['status']==new['status'] and new['torch_contracts']=={'passed':3,'skipped':0}
 # Transfer: distinguish bytes actually present from receipt-only files.
 transfer=read(ex/'completion_transfer.json');sync=read(ex/'completion_sync.json');comp=read(ex/'completion.json');actual=[];omitted=[]
 for f in transfer['files']:
  pth=root/f['path']
  if pth.is_file():assert file_record(pth,root)==f;actual.append(f)
  else:omitted.append(f)
 assert len(transfer['files'])==32 and sum(f['bytes'] for f in transfer['files'])==2355700
 assert sync['files']==32 and sync['bytes']==2355700 and sync['remote_receipt_sha256']==sha((ex/'completion_transfer.json').read_bytes())
 for name,m in new['memory'].items():
  remote=[f for f in transfer['files'] if f['path']==(runroot/m['file']['path']).relative_to(root).as_posix()];assert len(remote)==1 and remote[0]['bytes']==m['file']['bytes'] and remote[0]['sha256']==m['file']['sha256']
 mod=read(runroot/'model_verification.json');assert mod=={'manifest_sha256':sha((runroot/'manifest.json').read_bytes()),'files':[{k:v[k] for k in ('path','bytes','sha256')} for _,v in sorted(new['models'].items())]}
 for rec in transfer['models_remaining_linux']:
  match=next(m for m in new['models'].values() if rec['path'].endswith('/'+m['path']));assert rec['sha256']==match['sha256'] and rec['bytes']==match['bytes'] and match['actual_loaded_model_equals_replayed_state']
 assert transfer['models_remaining_linux']==sync['models_remaining_linux']
 checkpoint_max=max(p['checkpoint']['bytes'] for p in new['points'].values());model_bytes=sum(m['bytes'] for m in new['models'].values());bound=checkpoint_max+model_bytes+sum(f['bytes'] for f in transfer['files'])
 assert bound==comp['conservative_execution_payload_bound_bytes']==11319334525 and model_bytes==5660853090 and new['budget']['peak_observed_bytes']==11319124226
 final_event=next(p for p in point_events if p['point']=='CAB_distill_stage3');assert final_event['peak_observed_bytes']+new['models']['CAB_distill_stage3']['bytes']==new['budget']['peak_observed_bytes']
 started=(ex/'job/started.txt').read_text().strip();finished=(ex/'job/finished.txt').read_text().strip();elapsed=(datetime.datetime.fromisoformat(finished)-datetime.datetime.fromisoformat(started)).total_seconds();assert elapsed==4531==comp['full_process_seconds'];assert (ex/'job/exit_status.txt').read_text().strip()=='0';res=(ex/'job/resource_usage.log').read_text();assert '1:15:31' in res and 'Exit status: 0' in res
 times={'formal_training_seconds':sum(v['training_seconds'] for v in new['training'].values()),'inference_seconds_including_replay':sum(v['timing']['inference_seconds_including_replay'] for v in new['points'].values()),'teacher_seconds':sum(v['teacher']['seconds'] for v in new['memory'].values())}
 for k,v in times.items():assert abs(v-new[k])<1e-8 and abs(v-comp[k])<1e-8
 evaluator=read(ex/'evaluation_execution.json');assert evaluator['exit_code']==0 and evaluator['elapsed_seconds']==comp['evaluation_seconds'];assert datetime.datetime.fromisoformat(evaluator['time'])>datetime.datetime.fromisoformat(finished)
 audit={'status':'PASS','environment_record':new['environment'],'source_counts':{k:len(v) for k,v in sources.items()},'all_npy_loaded':len(inventory),'npys_by_shape':dict(collections.Counter(str(v['shape']) for v in inventory)),'current_schedule_positions_compared':1620,'replay_draw_positions_compared':1080,'paired_current_dropout_streams':9,'shared_complete_state_and_score_checks':shared,'first_stage_teacher_raw_target_hash_checks':18,'new_second_stage_teacher_raw_values_recomputed':0,'target_forwards':25,'current_edge_presentations':1620*378,'historical_edge_presentations':1080*378,'actual_model_payload_rehash_in_audit':False,'cache_payloads_loaded':0,'formal_labels_parsed':0,'production_torch_tests_recorded':{'passed':3,'skipped':0,'seconds':1.319},'torch_tests_rerun_in_audit':False,'log_update_progress_events':54,'log_point_reload_events':9,'recorded_model_count':3,'recorded_cache_count':6,'maximum_cached_state_across_recorded_phases':max([t['maximum_insertion_history_bytes'] for t in teachers]+[v['reported_history_max'] for v in history]),'result_limits':'Model/Adam restores, cache body sizes and one-time parser accesses are code plus production receipts, not auditor reloading forbidden payloads.'}
 resources={'started':started,'finished':finished,'outer_and_GNU_time_seconds':elapsed,**times,'point_total_seconds_including_score_and_state_handling':sum(v['timing']['total_point_seconds'] for v in new['points'].values()),'maximum_checkpoint_bytes':checkpoint_max,'three_final_models_bytes':model_bytes,'transfer_records_count':len(transfer['files']),'transfer_total_bytes':sum(f['bytes'] for f in transfer['files']),'actually_attached_transfer_files':len(actual),'actually_rehashed_transfer_bytes':sum(f['bytes'] for f in actual),'receipt_only_transfer_files':omitted,'sampled_run_peak_bytes':new['budget']['peak_observed_bytes'],'observed_checkpoint_model_coexistence_identity_matches':True,'conservative_execution_payload_upper_bound_bytes':bound,'cap_bytes':2**34,'exact_instantaneous_peak_claimed':False,'evaluation_seconds':evaluator['elapsed_seconds'],'host_rss_from_GNU_kbytes':11085356,'caveat':'Bound for declared run/transfer payload, not all project disk, temporary OS allocation, write volume, or exact instantaneous disk peak.'}
 dump(out/'execution_audit.json',audit);dump(out/'resource_audit.json',resources);dump(out/'history_and_targets.json',{'schedules':paired,'replay':history,'targets':teachers});dump(out/'training_loss_records.json',loss_records)
 print(json.dumps(audit,ensure_ascii=False,indent=2));print(json.dumps(resources,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
