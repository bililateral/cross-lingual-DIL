"""Additional hand-constructed CPU evidence; no formal labels/text, LaBSE or production run."""
from pathlib import Path
import copy,hashlib,json,random,sys,tempfile,unittest
from types import SimpleNamespace
from unittest.mock import patch
import numpy as np
import torch
sys.path[:0]=['/mnt/data/distillation_audit/work/tests','/mnt/data/distillation_audit/work/scripts']
import step28_continual_distillation as d
from test_step28_continual_distillation_contracts import fixtures,labelled
RESULT={};torch.set_num_threads(1)
class ExtraCPUChecks(unittest.TestCase):
 def test_mse_reaches_both_modules_with_analytic_gradient(self):
  torch.manual_seed(171)
  m=d.core.build_model(torch.nn.Sequential(torch.nn.Linear(3,4),torch.nn.Dropout(.2)),4,5)
  m.train();p=m.pair_logits(m.encoder(torch.arange(12).reshape(4,3).float()/10+.7))
  y=torch.tensor([1.,0.,0.,0.,1.,0.]);z=torch.linspace(-1,1,6)
  total,bce,mse=d.historical_loss(p,y,z,.5);pars=list(m.parameters())
  b=torch.autograd.grad(bce,pars,retain_graph=True)
  g=torch.autograd.grad(total,pars,retain_graph=True)
  hand=torch.autograd.grad(p,pars,grad_outputs=(torch.sigmoid(p.detach())-y+(p.detach()-z))/6)
  for a,v in zip(g,hand):torch.testing.assert_close(a,v,rtol=1e-6,atol=1e-7)
  n=len(list(m.encoder.parameters()));diff={}
  for label,sl in [('encoder',slice(0,n)),('head',slice(n,None))]:
   diff[label]=sum(float((a-v).square().sum()) for a,v in zip(g[sl],b[sl]));self.assertGreater(diff[label],0)
  RESULT['mse_analytic_gradient']={'history_edges':6,'coefficient':.5,'mse':float(mse.detach()),'weighted_mse_gradient_squared_by_module':diff,'note':'Toy autograd differences, not production hook contribution percentages.'}
 def test_teacher_uid_edges_mixed_modes_rng_and_exception_restore(self):
  torch.manual_seed(33);random.seed(44);np.random.seed(55)
  model=d.core.build_model(torch.nn.Sequential(torch.nn.Linear(3,4),torch.nn.Dropout(.2)),4,5)
  model.train();model.encoder[0].eval();model.head[0].eval()
  groups,meta=fixtures();train=labelled(groups['train']);budget=SimpleNamespace(check=lambda *a:None)
  state=d.ReplayState(d.data.Memory(d.data.seed_for(20260909,'ABC','memory')),'ABC',2)
  calls=[]
  def logits(m,g,c,check=lambda:None):
   self.assertFalse(m.training);self.assertTrue(torch.is_inference_mode_enabled());calls.append(g.uid)
   offset=(int(hashlib.sha256(g.uid.encode()).hexdigest()[:8],16)%1000)/1000
   # Deliberately consume the CPU RNG even in inference: tests actual fork/restore, not a no-op RNG path.
   inp=torch.arange(84).reshape(28,3).float()/84+offset+torch.rand(1)*.01
   return m.pair_logits(m.encoder(inp))
  perstage=[]
  with patch.object(d.core,'logits',side_effect=logits):
   for arrival in (1,2):
    if arrival==2:
     with torch.no_grad():model.head[-1].bias.add_(.5)
     state=d.ReplayState(state.memory,'ABC',3,state.targets)
    current=d.current_groups(train,meta,'ABC'[arrival-1]);point='ABC_shared' if arrival==1 else 'ABC_distill_stage2'
    previous=copy.deepcopy(state.targets);modes=[x.training for x in model.modules()]
    rng=torch.get_rng_state().clone();prng=random.getstate();nrng=np.random.get_state()
    digest=d.core.state_digest(model.state_dict());calls.clear()
    receipt=d.populate_targets(model,state,current,point,d.pilot.contract(),budget)
    self.assertEqual(calls,receipt['new_groups']);self.assertEqual(modes,[x.training for x in model.modules()]);self.assertTrue(torch.equal(rng,torch.get_rng_state()))
    self.assertEqual(prng,random.getstate());after=np.random.get_state();self.assertEqual(nrng[0],after[0]);np.testing.assert_array_equal(nrng[1],after[1]);self.assertEqual(nrng[2:],after[2:])
    self.assertEqual(digest,d.core.state_digest(model.state_dict()))
    new=[g for g in state.memory.groups if g.uid in receipt['new_groups']]
    with torch.random.fork_rng(devices=[]):
     expected=d.core.score(copy.deepcopy(model),new,d.pilot.contract())
    for g,v in zip(new,expected):
     np.testing.assert_array_equal(state.target(g),v)
     self.assertGreater(float(np.std(v)),0)
     self.assertEqual(state.targets[g.uid]['model_state_sha256'],digest)
     self.assertEqual(state.targets[g.uid]['pair_order_sha256'],hashlib.sha256(d.data.json_bytes(g.sellers)).hexdigest())
    for uid in previous.keys() & state.targets.keys():self.assertEqual(previous[uid],state.targets[uid])
    self.assertEqual(set(state.targets),{g.uid for g in state.memory.groups})
    with tempfile.TemporaryDirectory() as temp:
     out=Path(temp);(out/'memory').mkdir();restored,record=d.save_memory(state,current,point,out,budget)
     self.assertIsNot(restored,state);self.assertEqual(restored.to_bytes(),state.to_bytes())
     self.assertEqual(restored.draw().uid,record['next_draw'])
    perstage.append({'stage':arrival,'target_forwards':receipt['group_forwards'],'full_fixture_bytes':len(state.to_bytes()),'maximum_insertion_fixture_bytes':receipt['maximum_insertion_history_bytes'],'survivors':len(previous.keys()&state.targets.keys()),'evicted':len(previous.keys()-state.targets.keys()),'uid_edge_scores_exact':True,'mode_cpu_rng_preserved':True})
   # Exceptional teacher scorer also restores CPU RNG and mixed modes.
   bad=d.ReplayState(d.data.Memory(d.data.seed_for(20260909,'ABC','memory')),'ABC',2)
   before=torch.get_rng_state().clone();modes=[x.training for x in model.modules()]
   def fail(*args,**kwargs):model.eval();torch.rand(9);raise RuntimeError('synthetic scorer failure')
   with patch.object(d.core,'score',side_effect=fail):
    with self.assertRaisesRegex(RuntimeError,'synthetic scorer failure'):d.populate_targets(model,bad,d.current_groups(train,meta,'A'),'ABC_shared',d.pilot.contract(),budget)
   self.assertTrue(torch.equal(before,torch.get_rng_state()));self.assertEqual(modes,[x.training for x in model.modules()])
  RESULT['teacher_checks']={'stages':perstage,'exception_restore':True,'cpu_rng_actually_consumed_inside_mock_logits':True,'cuda_rng_executed':False,'formal_data_reads':0}
if __name__=='__main__':
 suite=unittest.defaultTestLoader.loadTestsFromTestCase(ExtraCPUChecks);r=unittest.TextTestRunner(verbosity=2).run(suite)
 RESULT['tests']={'run':r.testsRun,'passed':r.testsRun-len(r.errors)-len(r.failures)-len(r.skipped),'errors':len(r.errors),'failures':len(r.failures),'skipped':len(r.skipped)}
 Path('/mnt/data/distillation_audit/extra_cpu_checks.json').write_text(json.dumps(RESULT,ensure_ascii=False,indent=2)+'\n');print(json.dumps(RESULT,ensure_ascii=False,indent=2));sys.exit(0 if r.wasSuccessful() else 1)
