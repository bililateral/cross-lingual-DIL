"""Prepare an isolated candidate fix; never alter submitted source bytes."""
from pathlib import Path
import difflib,json,shutil
root=Path('/mnt/data/distillation_review_original');trial=Path('/mnt/data/distillation_audit/patch_trial')
assert not trial.exists();shutil.copytree(root,trial)
changes={}
r='scripts/step28_continual_distillation.py';old=(root/r).read_text()
new=old.replace('        def observe(gradient: Any, name: str) -> None:', '        def observe_gradient(gradient: Any, name: str) -> None:').replace('lambda g, n=name: observe(g, n)', 'lambda g, n=name: observe_gradient(g, n)')
assert new!=old;changes[r]=(old,new)
r='tests/test_step28_continual_distillation_contracts.py';old=(root/r).read_text()
new=old.replace('targets, coefficient=coefficient)', 'targets, observe=(step == 1), coefficient=coefficient)')
new=new.replace("                    self.assertGreater(log['branches_squared_hook_norm']['replay']['encoder'], 0)","                    if step == 1:\n                        self.assertGreater(log['branches_squared_hook_norm']['replay']['encoder'], 0)\n                    else:\n                        self.assertTrue(all(v == 0 for branch in log['branches_squared_hook_norm'].values() for v in branch.values()))")
assert new!=old;changes[r]=(old,new)
patch=''
for path,(old,new) in changes.items():
 (trial/path).write_text(new)
 patch+=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+path,tofile='b/'+path))
Path('/mnt/data/distillation_audit/minimal_observe_fix.patch').write_text(patch)
print(patch)
