"""Reproduce the submitted observer-name collision using two CPU toy updates only."""
from pathlib import Path
import copy,json,sys,traceback
from types import SimpleNamespace
from unittest.mock import patch
import numpy as np
import torch
sys.path[:0]=['/mnt/data/distillation_audit/work/scripts']
import step28_continual_distillation as d
c=d.pilot.contract();torch.set_num_threads(1);torch.manual_seed(171)
m=d.core.build_model(torch.nn.Sequential(torch.nn.Linear(3,4),torch.nn.Dropout(.2)),4,5)
o=d.core.make_optimizer(m,c)
cur=SimpleNamespace(labels=(0,1,0,1,0,0),offset=.1)
hist=SimpleNamespace(labels=(1,0,0,0,1,0),offset=.7)
z=np.linspace(-1,1,6,dtype=np.float32)
def logits(model,group,config,check=lambda:None):
 return model.pair_logits(model.encoder(torch.arange(12).reshape(4,3).float()/10+group.offset))
result={'formal_data_reads':0,'production_train_calls':0,'LaBSE_loads':0,'torch':torch.__version__,'steps':[]}
with patch.object(d.core,'logits',side_effect=logits):
 for step,observe in [(1,True),(2,False)]:
  before=d.core.state_digest(m.state_dict());row={'toy_step':step,'observe':observe}
  try:
   log=d.observed_update(m,o,cur,hist,c,19+step,39+step,lambda:None,z,observe=observe)
   row['returned']=True
  except Exception as e:
   row.update(returned=False,error_type=type(e).__name__,error=str(e),traceback=traceback.format_exc())
  row['adam_steps']=sorted(set(float(s['step']) for s in o.state.values()))
  row['model_changed']=d.core.state_digest(m.state_dict())!=before
  row['remaining_tensor_hooks']=sum(len(p._backward_hooks or {}) for p in m.parameters())
  result['steps'].append(row)
assert result['steps'][0]['returned']
assert result['steps'][1]['error_type']=='KeyError' and result['steps'][1]['error']=="'encoder'"
assert result['steps'][1]['adam_steps']==[2.0] and result['steps'][1]['model_changed']
Path('/mnt/data/distillation_audit/observe_collision.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
