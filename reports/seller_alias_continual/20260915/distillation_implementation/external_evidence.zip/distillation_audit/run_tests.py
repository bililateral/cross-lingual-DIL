from pathlib import Path
import argparse, importlib.util, json, os, platform, sys, time, unittest
p=argparse.ArgumentParser();p.add_argument('--root',default='/mnt/data/distillation_audit/work');p.add_argument('--out',required=True);p.add_argument('--mode',choices=['torch3','affected'],default='torch3');a=p.parse_args()
root=Path(a.root);sys.path[:0]=[str(root/'tests'),str(root/'scripts')]
import torch
threads=1;torch.set_num_threads(threads)
env={'python':sys.version,'platform':platform.platform(),'torch':torch.__version__,'cuda_runtime':torch.version.cuda,'cuda_available':torch.cuda.is_available(),'torch_threads':torch.get_num_threads(),'numpy':__import__('numpy').__version__,'root':str(root),'formal_supervision_reads':0,'pretrained_models_loaded':0,'production_runs':0,'notes':'Tests use CPU toy models and synthetic temporary CSVs only. Production dataset test explicitly excluded.'}
print(json.dumps(env,ensure_ascii=False,indent=2),flush=True)
loader=unittest.defaultTestLoader
names=['test_step28_continual_distillation_contracts.TorchContracts'] if a.mode=='torch3' else ['test_step28_continual_distillation_contracts','test_step28_continual_replay_contracts','test_step28_continual_expression_run_contracts.PilotContracts','test_step28_continual_population_contracts.MetricContracts']
def flatten(s):
 for t in s:
  if isinstance(t,unittest.TestSuite): yield from flatten(t)
  else: yield t
excluded=[];tests=[]
for name in names:
 for t in flatten(loader.loadTestsFromName(name)):
  if t.id().endswith('.test_real_public_inputs_read_no_supervision_or_heldout'):
   excluded.append({'test':t.id(),'reason':'Requires absent formal public corpus; not invoked, not counted as executed or passed.'})
  else: tests.append(t)
start=time.perf_counter();r=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(tests));sec=time.perf_counter()-start
v={'environment':env,'mode':a.mode,'executed_ids':[t.id() for t in tests],'tests_run':r.testsRun,'passed':r.testsRun-len(r.failures)-len(r.errors)-len(r.skipped),'failures':[(t.id(),s) for t,s in r.failures],'errors':[(t.id(),s) for t,s in r.errors],'skipped':[(t.id(),s) for t,s in r.skipped],'excluded':excluded,'seconds':sec,'success':r.wasSuccessful()}
Path(a.out).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n');print('RESULT',json.dumps({k:v[k] for k in ('mode','tests_run','passed','skipped','excluded','seconds','success')},ensure_ascii=False),flush=True)
sys.exit(0 if r.wasSuccessful() else 1)
