from pathlib import Path, PurePosixPath
import argparse, hashlib, json, zipfile
p=argparse.ArgumentParser();p.add_argument('--zip',default='/mnt/data/review_upload(3).zip');p.add_argument('--root',default='/mnt/data/distillation_review_original');p.add_argument('--out',default='/mnt/data/distillation_audit/manifest_verification.json');p.add_argument('--extract',action='store_true');a=p.parse_args()
zpath=Path(a.zip);root=Path(a.root);expected_size=2779184;expected_hash='e8ed210a126bfedb424f2d5896c5a71338c59d67638182773f45a64df814da1d'
b=zpath.read_bytes();sha=lambda x:hashlib.sha256(x).hexdigest()
with zipfile.ZipFile(zpath) as z:
 names=z.namelist();m=json.loads(z.read('manifest.json'));files=m['files'];listed=[x['path'] for x in files]
 assert len(names)==len(set(names))
 assert all(not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts for n in names)
 assert set(names)==set(listed)|{'manifest.json'}
 assert z.testzip() is None
 if a.extract:
  assert not root.exists(), 'extract into new directory only';root.mkdir();z.extractall(root)
 rows=[]
 for f in files:
  data=z.read(f['path']);local=(root/f['path']).read_bytes()
  rows.append(dict(path=f['path'],expected_bytes=f['bytes'],actual_bytes=len(local),actual_sha256=sha(local),ok=len(data)==f['bytes'] and sha(data)==f['sha256'] and data==local))
 out=dict(zip_bytes=len(b),zip_sha256=sha(b),zip_matches=len(b)==expected_size and sha(b)==expected_hash,members=len(names),listed_files=len(files),crc_ok=True,listed_total_bytes=sum(x['bytes'] for x in files),manifest_bytes=len(z.read('manifest.json')),all_files_match=all(x['ok'] for x in rows),files=rows)
 assert out['zip_matches'] and out['all_files_match']
 Path(a.out).write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({k:v for k,v in out.items() if k!='files'},ensure_ascii=False,indent=2))
