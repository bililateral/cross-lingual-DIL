# 随机ER＋阶段入库logit保持：方案与实现外审

## 结论

**已确认基线的科学比较可以成立，但当前提交版不能进入正式Linux训练。存在一项确证的阻断性 REPRODUCIBILITY_DEFECT（D1）：观察开关被同名函数覆盖，非首更新在Adam已执行后抛错。另有一项非阻断的外审包旧测试依赖缺口（D2）。没有另行发现需要改变数据、损失、种子、阈值、容量或评价门的 SCIENTIFIC_BLOCKER。**

本轮仍是方案／实现审查。没有项目Linux连接、资源探测、部署、正式监督解析、正式模型加载、LaBSE更新或新实验结果。CPU玩具模型、玩具Adam保存恢复与临时手工CSV测试已实际执行；它们不消费本轮正式监督许可。旧阶段已消费的许可没有延续为本轮启动授权。

最小修复已在独立副本试验通过，但提交原件未变，不能将其判作已经修复。主执行者应只应用明确修复并完成针对性复核，随后仍按既定流程另报新Linux阶段并暂停；本外审不批准启动。

## 1. 归档、冻结来源与读取范围

归档 `/mnt/data/review_upload(3).zip` 实际 **2779184字节**，SHA256：

`e8ed210a126bfedb424f2d5896c5a71338c59d67638182773f45a64df814da1d`

ZIP CRC通过。149个成员＝148份清单文件＋根manifest.json，无重复、缺失或额外成员。148份实际文件逐项大小／SHA一致；清单文件合计4262060字节，根manifest32922字节，解压合计4294982字节。结束后再次校验原字节保持不变。

原expression八份、原ER十二份来源均匹配历史正式manifest；四个政策固定的原运行／评价JSON摘要全部匹配。新 `sources()` 实际包含 **17份**（原十二份＋新runner／policy／test／Bash及列入依赖的population测试源），不是上一诊断的16份。该计数变化是来源范围，不是多了一个科研方法。

已全文审读新runner698行、新测试303行、新政策、Bash、两份新方案／实现文档；旧直接依赖逐行审读本轮调用的模型／优化器／池化／logits／BCE／保存恢复、Memory、监督对齐、阶段日程、旧完整门、原22指标和共享bootstrap／比较路径。原模型核心全文审读。没有将所有旧run入口、无关Archive路径、长交接总档及148份全部背景文件冒称逐字全文语义审读。

历史原文：本轮重新全文读取8e6b1e2a原ER实现回复及633ea43b原ER结果回复。六轮联合与缓存内外诊断按随附结果文档、当前会话已给原文和闭环附记核对；不声称重新全文阅读附件中的每一份其他历史回复或执行未取得的旧外审补充脚本。当前方案的DER部分另核读原论文第3节、式5／6和算法1／2，含PDF第3／4页视觉核对；LPR仅核读官方摘要，未做外部文献综述或实现复现。

文件证据：`manifest_verification.json`、`final_integrity.json`、`source_snapshot.json`、`static_and_saved_evidence.json`。

## 2. D1：观察参数被局部函数遮蔽，阻断非首更新

**分类：REPRODUCIBILITY_DEFECT；严重性：阻断本提交版正式启动。** 不与旧资源R1或上一诊断耗时D1共用问题身份；本报告D1专指distillation观察开关。

位置：`scripts/step28_continual_distillation.py:252–301`，尤其260、266、270、290、297行；调用点321–323行。

函数接收布尔参数 `observe`，并在260行按它决定是否创建 `before` 摘要。随后定义 `def observe(gradient, name)`，把同一局部变量重新绑定为函数。函数对象为真，因此原本的 `observe=False` 分支仍注册hook、仍执行观察检查；而 `before` 是空字典。297行读取 `before['encoder']` 抛 `KeyError`。注意296行 `optimizer.step()` 已先执行。

实际CPU最小反例，仅两个玩具更新：

| 调用 | observe | 结果 | 调用后Adam step | 参数已变化 |
|---|---:|---|---:|---:|
| 第一次 | True | 正常返回 | 1 | 是 |
| 第二次 | False | KeyError: 'encoder' | 2 | 是 |

两个调用结束后hook均已移除。错误不是hook泄漏、MSE未接入或空Adam，而是Python名称遮蔽。生产 `train_replay` 只在i=0传True；若初始化、首域及第一ER更新先前都通过，ABC第二域第2个更新（全作业第182个新物理更新）将进入同一错误路径。失败应保持失败状态，不可将部分更新解释成有效负结果，也不可自动续跑绕过一次性监督边界。

现有三个Torch测试都能通过的原因也已核实：两次真实更新均省略 `observe`，因此始终使用True；阶段日程测试把整个 `observed_update` 替换成mock。它们没有覆盖生产的True→False转换。

**最小修复**：只把内部hook函数改名为 `observe_gradient` 并更新lambda引用，保留布尔 `observe`；不改损失、系数、学习率、随机流或更新次数。把既有 `test_real_update_zero_equivalence_nonzero_reference_and_reload` 的第二次更新改为 `observe=False`，分支梯度观察断言只在首步执行；保留第二步参数／Adam参考及磁盘恢复检查。这样TorchContracts仍为3项，生产监督前的“3通过、0跳过”合同不用改。

本审查在 `patch_trial` 独立副本实际应用上述最小补丁，修改后的三个Torch用例全部通过。原提交目录与最初工作副本未改。修复候选不是新的冻结来源，不替主执行者应用或部署。

证据：`reproduce_observe_collision.py`、`observe_collision.json/.log`、`minimal_observe_fix.patch`、`make_patch_trial.py`、`patched_torch3.json/.log`。

## 3. 实际测试；D2为旧测试的缺文件范围，不是正式数据缺失

环境：Linux 6.18.44 x86_64、Python3.13.5、Torch2.10.0+cpu、NumPy2.3.5；Torch计算线程1，CUDA不可用。不是生产py310／CUDA／LaBSE环境。

| 范围 | 实际结果 | 计数边界 |
|---|---|---|
| 提交版新TorchContracts单独执行 | 3通过、0跳过，1.883594秒 | 包含于后续集合，不能再加一次 |
| 提交版受影响范围 | 38执行：35通过、3错误、0失败、0跳过，14.855361秒 | 39候选中先排除1个缺正式公开语料测试 |
| 其中新增合同集 | 10/10通过（7夹具＋3Torch） | 不等于生产全路径正确，D1已提供反例 |
| 其中旧replay | 11/11通过，含旧Torch1项 | 未重新训练ER |
| 其中旧expression PilotContracts | 9/9通过 | 真实公开输入测试未执行、未计通过或跳过 |
| 其中旧population MetricContracts | 5通过、3错误 | 缺旧policy，下述D2 |
| 额外CPU针对性测试 | 2通过、0跳过，1.463秒 | MSE梯度与teacher真张量／模式／RNG／边序 |
| 最小修复副本TorchContracts | 3通过、0跳过，2.151982秒 | 是修复候选的独立运行，不升级原件结果 |
| 静态／入口检查 | 13份Python AST、新Bash `bash -n`、新CLI `--help`通过 | 没执行正式Bash或CLI生产动作 |

本地“39项35通过4跳过”和本地最终“7通过3跳过”保留为当地记录，不替本轮实跑。不能把本轮重复单跑、集合运行、修复候选复跑相加成更多独立通过用例。

测试对Windows的平台标识使用mock，评价及parser调用只在自产临时手工CSV夹具中发生；没有对正式数据运行 `train/evaluate/attach_labels`。没有读取正式缓存payload。玩具 `save_state/restore_state` 实际读写CPU模型与Adam；不能把“没有正式模型加载”缩写成“完全没有任何模型状态加载”。

### D2：旧population测试所需非监督policy未随包提供

**分类：REPRODUCIBILITY_DEFECT；严重性：非阻断的外审包测试可复现范围缺口。**

以下三个测试实际在 `data.policy()` 处报 `FileNotFoundError`：

- `test_all_three_required_cache_points_must_exist`
- `test_bootstrap_pairs_orders_and_equal_domains`
- `test_failed_run_stops_before_truth_access`

缺文件为 `schema/step28_continual_population_policy.json`，它是普通配置JSON，不是正式标签、模型或语料。本包新生产路径不调用这个旧policy，三个新Torch门也不需要它，因此不能据此声称新训练入口有同样依赖失败，更不能否认原工作区可能已经通过这三项。

**最小处置**：在便携重跑材料中附原字节policy，或明确将这三项列为本附件不可复跑而缩小便携命令范围。无需补监督、权重或旧数据，无需重开关闭分支。本报告保留真实3错误日志，不把它们改写成通过或事后自动跳过。

## 4. 科研问题与方法身份

固定缓存成员、淘汰、抽样、当前群日程、文本、模型与优化器，只增历史logit约束，是可以回答“在本固定路径中，改变历史训练目标是否改善旧域留出能力且保留新学习”的基线干预。它不是选择器，也不要求六轮全历史联合的经验可行性必然转化为有限记忆成功。

原DER在训练轨迹中保存logit；DER++算法分别抽取历史匹配样本和历史真值样本。本方案在明确阶段末生成目标、同一完整历史群共享BCE/MSE前向，且使用二值单logit及既定1/0.5系数，故正确身份是**随机完整群ER＋阶段入库logit保持适配基线**，不是原版DER++复现或创新。原文核对来源：NeurIPS2020论文第3节式5／6、算法1／2；LPR官方摘要只支持保留优化使用方式的可能性，不能证明本项目有相同机制。

教师为eval输出，学生历史支为train/dropout输出，约束还包含随机扰动一致性；无法把未来差异唯一称为纯遗忘机制、随机选择、过拟合、权重错误或梯度冲突的证据。旧输出可能不正确，也可能与新域学习取舍；0.5是预固定值而非已证最优。

原ER三门失败、缓存局部识别收益、未重放54群参与过首域训练、原valid负主端点、固定阈值收益及micro precision下降均保留；“AP/MAP未改善”不扩大到所有指标。本新方法没有任何正式结果，不能用软件测试中的保存ER矩阵别名当作新方法数值。

## 5. 目标函数与真实MSE证据

除D1控制流以外，更新计算为：

`mean BCE_current + mean BCE_history + 0.5 * mean((history_logit-z)**2)`。

当前分支调用不变 `core.backward_group`；历史只调用一次 `core.logits`，同一predicted用于BCE与MSE，共同反传；之后一次统一裁剪和一次AdamW。没有把两组BCE改为756边整体均值，没有新增teacher常驻模型或额外优化步。`historical_loss`拒绝attached target、形状不符、非有限目标和负系数。

附带手算x=[0,2]、y=[0,1]、z=[-1,0]得到MSE=2.5，0.5*MSE=1.25；梯度为 `(sigmoid(x)-y)/2+(x-z)/2`，实跑通过。系数0与不变core.update在模型及完整Adam摘要上精确一致。非零系数和独立三项loss一次backward参考比较，参数容差rtol1e-6/atol1e-7，Adam一二阶矩rtol1e-5/atol1e-8；step连续，实际磁盘恢复后继续。**非零参考不是全状态逐字节精确一致的声明。**

外审另用真实autograd比较“历史BCE”与“BCE＋0.5MSE”的梯度，并用手工上游logit导数验证；编码器和头的差分平方范数均严格大于0（约0.230431471、0.730656140）。这提供小CPU模型上MSE确实影响两模块梯度的证据，而不只是总梯度非零。

正式hook记录的是分支中每次hook事件平方范数之和。历史分支已经合并BCE和MSE，不能从其非零单独分离MSE，更不能求贡献百分比、最终梯度范数或梯度冲突角度。真实LaBSE的六段首更新仍须提供既定证据；无需额外例行GPU smoke。

## 6. 目标生命周期、边序、完整状态与供数

`populate_targets`先完成该域60群的一次Algorithm R入库；逐次移除被淘汰群目标并检查完整包，再仅评分最后保留的新域群。旧域存活目标不刷新，逐项摘要核对；第三域不再生成目标。

原manifest中240条train/valid公开metadata实际可读。本次不调用缺语料的 `public_inputs`，而独立以这些已保存ID重建：1620条当前日程、1080条历史抽样均匹配原SEQ/ER记录。目标前向数为ABC=6+3=9、BCA=6+3=9、CAB=6+1=7，共25，小于预定36。这是由固定成员确定的计数，不是本轮正式teacher已评分25次。

目标由刚完成阶段的本分支模型取得；`persistence.point`已实际恢复完整状态，再作target scoring。保存float32小端原始378logit，base64编码，附point、模型摘要及账号顺序摘要。固定sorted sellers、`itertools.combinations`标签顺序与`torch.triu_indices`输出顺序相同；在该不变映射下，账号序列摘要足以约束边序，无需另引入冗余身份机制。ID只用于装配与审计，不进入文本模型。

`torch.random.fork_rng`保存CPU及本设备CUDA状态；finally逐模块恢复training标志。补充CPU例故意让eval logits消耗Torch RNG，并设置混合模块模式，实际核对正常和异常路径均恢复；逐UID逐边目标与独立固定小模型评分完全相等。另一阶段真实改变玩具头偏置，确认新群取新时点输出、旧群不刷新、淘汰目标删除。**CUDA RNG、BF16和真实LaBSE未实际执行。**

`ReplayState.to_bytes`把原Memory文本／标签／reservoir RNG、重放RNG／索引及完整targets字典全部序列化；逐群入库、逐目标追加及每次draw均检查1MiB。9072字节只是6×378×4裸数组，base64本身已为12096字节，尚未计正文和元数据。本实现还分别记录装入最大值和训练阶段最大值，不能混称一个字段覆盖另一范围。手工fixture总字节56249/56266只是手工数据，不是正式缓存占用。

`save_memory`确实写盘、read_bytes、完整from_bytes恢复和roundtrip，主循环接收恢复对象、重新绑定memory后供数。训练函数只收当前域及自身状态，draw按自身RNG，target按自身group UID解码；没有从历史UID回查已淘汰监督或其他顺序缓存。Windows完整门仅对缓存字节核验，不反序列化标签，目标元数据与成员／源点／旧目标不刷新由回执交叉检查。回执和哈希核验不是Windows独立解码并验证每个目标logit。

## 7. 重建、更新数、评分与监督门

D1修复前这些是实现意图而非可完成运行；除此之外首域恢复链正确：按原初始化和180步完整重建，对模型、全Adam状态及完整60×378原valid分数要求精确一致；再创建优化器并从刚保存的全状态恢复，不能改成加载推理权重后空Adam。181／361起步及180／360／540终点检查保留，第二阶段亦真实恢复全状态。旧config用于历史状态匹配，新Budget采用本轮合同，不能把旧config的2160数误当本轮更新量。

工作量为540首域＋1080后续＝1620新物理更新；九点双遍valid＝1080群前向；三最终推理模型、六缓存快照；25次新增target群前向另记。当前边呈现612360、历史408240不变。没有另外启动train缓存内外诊断。MSE复用历史编码但增加loss/gradient运算，target推理和存储也有额外开销，故不是完全等计算／等实际占用比较。

生产run在正式监督前运行三个CPU TorchContracts且要求3通过0跳过；当前未覆盖的False路径应并入其中一个既有测试。之后才允许唯一train解析。Windows先检查原证据及全部新九点、六缓存、目标元数据、日程／Adam／更新、来源、真实评分文件、共享全状态与预算；再检查原ER参考，之后写一次valid尝试记录并解析一次。完整门失败在解析之前，禁止旧生产run/evaluate及test/owners路径。

夹具中错误teacher时点、旧目标刷新、错误系数、错误目标数和边序均在解析前被拒绝；缓存使用故意不可解码的opaque字节，也通过正常只哈希路径。这是夹具执行证据，不是正式Linux／Windows完整门已通过。

## 8. 评价端点、random_er角色与共享bootstrap

相对SEQ：H为最终首域绝对AP差；N为六次新域刚学完绝对AP差；G_distill／G_seq分别用自己的before/after；F为共同首域起点减最终。三门保持H均值≥.01且条件区间下界>0、N下界≥−.01、至少两个相同顺序同时H_o>0且该顺序两次G_distill均值≥.02。

相对ER的参考从其九个保存点加原initial组成10点，键映射正确，shared22实际三对一致。包装器将参照字段改为G_random_er、F_random_er、second_random_er_change、G_random_er_transitions、final_distill_minus_random_er和absolute.random_er；没有把旧ER增益／遗忘仍标SEQ。额外 `incremental_retention_passed` 只检验相对ER的H区间下界>0，不能替代 `comparison.gate` 三门；二者分别保存，不自动把仅胜较差ER登记为缓解成功。

22列包括AP／梯形PR-AUC／ROC／FPR召回、Brier与clipped log_loss、六个固定阈值分类量、MAP／MRR及Recall/NDCG@1/3/5/10；每群混淆计数全部保存。macro是逐群均值；micro从相同报告范围的计数相加后计算，不能平均群precision当micro。新evaluate并未生成独立micro汇总字段，但保存完整计数，结果报告可无标签补算，不是缺少科研信息。此基线沿用22列，不要求额外加入此前训练诊断的第23列BCE；train在线BCE/MSE记录是另一类量。

bootstrap仅一次生成5000×3×20索引，seed20260910，并将同一draws对象用于两种参照。按底层域把重复转移或顺序的同一群轨迹先等权平均，再使用同域20群索引；不当作40群／60群独立观测，不将3顺序称3随机种子。

本审查把旧ER保存矩阵仅作为“新接口的测试输入别名”，独立用20-bin出现次数加权方式对照生产直接索引，核对两个参照×22指标×9对比×6个摘要值共2376项，最大差1.11e-16；字段角色检查通过。数字仍是旧ER软件参照，不是蒸馏结果，也不是从盲分数重新算AP。完整56份随包NPY实际读入检查形状／dtype／有限性，原SEQ11与ER9矩阵文件映射核验通过；没有重开历史监督。

valid重复开发、固定训练路径条件区间、次要区间未校正均保留，不增加显著性门或新独立性主张。

## 9. 资源与未执行范围

政策与原ER的单GPU／单CPU线程、3小时／16GiB新增运行载荷一致；单可见CUDA、BF16支持、24GiB空闲显存及16GiB可用主存的入口检查未改。空闲显存不替代恢复阶段的现场空闲GPU检查。本次没有项目Linux连接或资源探测；75—110分钟仍为计划估计，不能用本次CPU秒数预测真实LaBSE耗时。

Budget继续仅覆盖run观测范围；大checkpoint与最终推理模型共存后强制盘点，再删除本次临时工作状态。最终manifest和模型回执晚写，外围日志位于job父目录，结果阶段仍应合并这些收尾量与完整GNU time，报告最终总量和观测／保守上界的不同范围。旧R1在633ea43b声明范围内闭合，本文不以重复读取同一Budget重开它，也不把未运行的新阶段资源口径先宣布为实测通过。

正式运行仍需提供：修复后py310三项CPU零跳过；三首域模型／Adam／全分数精确重建；六段真实首更新证据及181／361连续性；真实25次teacher评分、CUDA RNG／模式路径、六份完整状态字节及磁盘恢复供数；1620更新、九点双遍、三最终模型；完整门后一次valid、shared22精确匹配与新旧全部评价；实际大文件共存、外围日志／晚写回执与完整耗时。它们是既有批准合同，不是外审追加的GPU smoke或新实验。

## 10. 问题分类与处置边界

| 分类 | 确认问题 | 最小处理 |
|---|---|---|
| SCIENTIFIC_BLOCKER | 未发现另需更换科学配置的问题 | 不改变数据、系数、阈值、种子、端点 |
| REPRODUCIBILITY_DEFECT D1 | observe布尔参数被同名函数遮蔽；生产第二个后续更新将抛错 | 两处hook改名；把既有CPU更新用例第二步设False；复核新冻结来源 |
| REPRODUCIBILITY_DEFECT D2 | 外审包缺旧population policy，3个旧测试在加载配置前失败 | 附非监督旧policy或明确缩小便携测试范围；不阻断新生产依赖 |
| OUT_OF_SCOPE_OVERDESIGN | 新选择器、分层缓存、容量／权重／阈值搜索、新种子、全套smoke、监控／签名／硬化 | 不作为修复要求，不扩授权 |

**当前提交版不通过实现准备性放行。最小候选修复已有真实小CPU验证，但主执行者尚未应用，本轮不能登记正式运行、更不能判方法有效或无效。** 既有结果闭环与当前方案身份保持不变。修复和针对性复核后仍须另报Linux阶段并暂停；本报告不恢复启动，不开放test或任何新监督权限。

## 身份与外部来源范围

本回复模型自述为GPT-6 Astra Pro。现有工具不能读取本网页当前消息的model_slug；不根据正文自述改写随附历史gpt-6-pro消息属性，也不伪造当前网页属性。

仅核对方法身份的外部一手来源：

1. Buzzega et al., *Dark Experience for General Continual Learning: a Strong, Simple Baseline*, NeurIPS2020，论文第3节式5/6与算法1/2，https://proceedings.neurips.cc/paper/2020/file/b704ea2c39778f07c617f6b7ce480e9e-Paper.pdf 。未在本轮复现其公开实验。
2. Yoo et al., *Layerwise Proximal Replay: A Proximal Point Method for Online Continual Learning*, ICML2024官方摘要，https://proceedings.mlr.press/v235/yoo24a.html 。未核读其实现，不据此推断本项目机制。
