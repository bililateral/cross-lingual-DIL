"""Exercise comparison/role naming on existing saved matrices only, not a new arm's result."""
from pathlib import Path
import json,sys
import numpy as np
sys.path[:0]=['/mnt/data/distillation_audit/work/scripts']
import step28_continual_distillation as d
root=Path('/mnt/data/distillation_review_original');out=Path('/mnt/data/distillation_audit');c=d.contract();orders=['ABC','BCA','CAB']
def load(path):
 p=root/path;e=json.loads(p.read_bytes());return {name:np.load(p.parent/row['file']['path'],allow_pickle=False) for name,row in e['points'].items()}
seq=load(c['origin_evaluation']);erraw=load(c['baseline_evaluation']);er={n.replace('_er_stage','_stage'):a for n,a in erraw.items()};er['initial']=seq['initial']
new={n.replace('_er_stage','_distill_stage'):a for n,a in erraw.items()} # software test aliases only
rng=np.random.default_rng(20260910);draws=rng.integers(0,20,size=(5000,3,20))
weights=np.array([[np.bincount(x,minlength=20) for x in trial] for trial in draws])
checks=0;maxdiff=0.;cases={}
def ck(a,b):
 global checks,maxdiff
 a=np.asarray(a,dtype=float);b=np.asarray(b,dtype=float);assert a.shape==b.shape
 diff=float(np.max(np.abs(a-b))) if a.size else 0.;maxdiff=max(maxdiff,diff);checks+=a.size
 np.testing.assert_allclose(a,b,rtol=0,atol=2e-15)
for role,ref in [('sequential',seq),('random_er',er)]:
 result=d.compare(new,ref,draws,c,role)
 tag='seq' if role=='sequential' else 'random_er'
 for col,metric in enumerate(d.metrics.COLUMNS):
  val=lambda a,n,dom:a[n][20*'ABC'.index(dom):20*('ABC'.index(dom)+1),col]
  keys=['H','N','G_distill','G_'+tag,'F_distill','F_'+tag,'second_distill_change','second_'+tag+'_change','final_distill_minus_'+tag]
  buckets={k:{dom:[] for dom in 'ABC'} for k in keys}
  for o in orders:
   start=val(ref,o+'_shared',o[0]);dn=val(new,o+'_distill_stage3',o[0]);dr=val(ref,o+'_stage3',o[0])
   for k,a in [('H',dn-dr),('F_distill',start-dn),('F_'+tag,start-dr)]:buckets[k][o[0]].append(a)
   for stage in (2,3):
    dom=o[stage-1];an=val(new,o+'_distill_stage'+str(stage),dom);ar=val(ref,o+'_stage'+str(stage),dom)
    bn=val(new,o+('_shared' if stage==2 else '_distill_stage2'),dom);br=val(ref,o+('_shared' if stage==2 else '_stage2'),dom)
    for k,a in [('N',an-ar),('G_distill',an-bn),('G_'+tag,ar-br)]:buckets[k][dom].append(a)
   buckets['second_distill_change'][o[1]].append(val(new,o+'_distill_stage3',o[1])-val(new,o+'_distill_stage2',o[1]))
   buckets['second_'+tag+'_change'][o[1]].append(val(ref,o+'_stage3',o[1])-val(ref,o+'_stage2',o[1]))
   for dom in 'ABC':buckets['final_distill_minus_'+tag][dom].append(val(new,o+'_distill_stage3',dom)-val(ref,o+'_stage3',dom))
  for key,b in buckets.items():
   delta=np.stack([np.stack(b[dom]).mean(0) for dom in 'ABC'])
   sampled=np.sum(weights*delta[None,:,:],axis=(1,2))/60.
   s=result['metrics'][metric]['contrasts'][key];ck(s['mean'],delta.mean());ck(s['by_domain_or_first_domain'],delta.mean(1));ck(s['conditional_95pct_interval'],np.quantile(sampled,[.025,.975]))
  def keys_rec(v):
   if isinstance(v,dict):
    for k,x in v.items():yield k;yield from keys_rec(x)
   elif isinstance(v,list):
    for x in v:yield from keys_rec(x)
  kk=set(keys_rec(result['metrics'][metric]));assert 'G_er' not in kk and 'F_er' not in kk
  if role=='random_er':assert not kk & {'G_seq','F_seq','G_seq_transitions','sequential','second_seq_change','final_distill_minus_seq'}
 ap=result['metrics']['average_precision'];cases[role]={'H':ap['contrasts']['H'],'N':ap['contrasts']['N'],'gate':result['gate'],'role_keys':sorted(ap['contrasts'])}
 # All H/N differences are exactly zero when software aliases the same existing ER arm.
 if role=='random_er':assert ap['contrasts']['H']['mean']==0 and ap['contrasts']['N']['mean']==0
result={'numeric_comparisons':checks,'maximum_absolute_difference':maxdiff,'bootstrap_replicates':5000,'bootstrap_seed':20260910,'same_draws_object_for_both_references':True,'independent_bootstrap_route':'per-domain 20-bin occurrence counts rather than production direct indexing','cases':cases,'scope':'Old saved matrices used as software fixtures for the new naming/comparison wrapper; NOT distillation results, NOT new inferential findings, no label parses.'}
(out/'comparison_recheck.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2))
