"""Read-only source/saved-evidence audit. No production public_inputs, label parser, model loader or evaluator."""
from pathlib import Path
import ast,hashlib,json,random,subprocess,sys
import numpy as np
root=Path('/mnt/data/distillation_review_original');out=Path('/mnt/data/distillation_audit')
load=lambda p:json.loads((root/p).read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest()
c=load('schema/step28_continual_distillation_policy.json')
seq=load(c['origin_run']+'/manifest.json');er=load(c['baseline_run']+'/manifest.json')
def canonical(v):return (json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def seed_for(seed,*parts):return int.from_bytes(hashlib.sha256(canonical([seed,*parts])).digest()[:8],'big')%(2**63-1)
source_rows=[]
for role,run in [('expression',seq),('random_er',er)]:
 for f in run['source_files']:
  b=(root/f['path']).read_bytes();ok=len(b)==f['bytes'] and sha(b)==f['sha256'];assert ok
  source_rows.append({'role':role,**f,'actual_match':ok})
for p,h in [(c['origin_run']+'/manifest.json',c['origin_manifest_sha256']),(c['origin_evaluation'],c['origin_evaluation_sha256']),(c['baseline_run']+'/manifest.json',c['baseline_run_sha256']),(c['baseline_evaluation'],c['baseline_evaluation_sha256'])]:assert sha((root/p).read_bytes())==h
assert seq['inputs']==er['inputs']
meta=seq['inputs']['metadata'];assert len(meta)==240
schedule_checks=0;draw_checks=0;history={}
for order in ['ABC','BCA','CAB']:
 rng=random.Random(seed_for(20260909,order,'memory'));kept=[];seen=0;stages=[]
 for stage in (1,2,3):
  ids=sorted(m['group_uid'] for m in meta if m['split']=='train' and m['domain']==order[stage-1]);assert len(ids)==60
  s=seed_for(20260909,order,stage,'current');r=random.Random(s);rows=[]
  for _ in range(3):x=ids.copy();r.shuffle(x);rows+=x
  name=order+('_shared' if stage==1 else '_stage'+str(stage));assert seq['training'][name]['group_ids']==rows
  ename=name.replace('_stage','_er_stage');assert er['training'][ename]['group_ids']==rows
  assert seq['training'][name]['dropout_stream']==s==er['training'][ename]['dropout_stream'];schedule_checks+=len(rows)
  if stage==3:continue
  for uid in ids:
   seen+=1
   if len(kept)<6:kept.append(uid)
   else:
    j=rng.randrange(seen)
    if j<6:kept[j]=uid
  mr=er['memory'][ename];assert kept==mr['retained_groups'] and ids==mr['added_groups'] and seen==mr['seen']
  dr=random.Random(seed_for(20260909,order,stage+1,'replay_draw'));draws=[dr.choice(kept) for _ in range(180)]
  assert draws==er['training'][order+'_er_stage'+str(stage+1)]['replay_group_ids'];draw_checks+=len(draws)
  new=[uid for uid in kept if uid in ids]
  stages.append({'arrival_stage':stage,'retained_groups':kept.copy(),'new_target_groups':new,'target_forwards':len(new),'legacy_full_state_bytes':mr['full_state_bytes']})
 history[order]={'stages':stages,'target_forwards':sum(s['target_forwards'] for s in stages)}
assert [history[o]['target_forwards'] for o in history]==[9,9,7]
arrays=[]
for p in sorted(root.rglob('*.npy')):
 a=np.load(p,allow_pickle=False);assert np.isfinite(a).all();arrays.append({'path':str(p.relative_to(root)),'shape':list(a.shape),'dtype':str(a.dtype),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())})
refs={};mapped={}
for role,path in [('sequential',c['origin_evaluation']),('random_er',c['baseline_evaluation'])]:
 e=load(path);refs[role]={}
 for name,row in e['points'].items():
  f=row['file'];p=root/Path(path).parent/f['path'];assert p.stat().st_size==f['bytes'] and sha(p.read_bytes())==f['sha256']
  a=np.load(p,allow_pickle=False);assert a.dtype==np.float64 and a.shape==(60,22)
  refs[role][name]=a
for order in history:assert np.array_equal(refs['sequential'][order+'_shared'],refs['random_er'][order+'_shared'])
mapping={'initial':c['origin_evaluation']+'::initial'}
for name in refs['random_er']:mapping[name.replace('_er_stage','_stage')]=c['baseline_evaluation']+'::'+name
assert len(mapping)==10
ast_rows=[]
for p in sorted(root.joinpath('scripts').glob('*.py'))+sorted(root.joinpath('tests').glob('*.py')):
 t=ast.parse(p.read_text(),filename=str(p));ast_rows.append({'path':str(p.relative_to(root)),'lines':len(p.read_text().splitlines()),'ast_ok':True})
bash=root/'scripts/run_step28_distillation_linux_20260915.sh';b=subprocess.run(['bash','-n',str(bash)],capture_output=True,text=True);assert b.returncode==0
cli=subprocess.run([sys.executable,'-B',str(root/'scripts/step28_continual_distillation.py'),'--help'],capture_output=True,text=True);assert cli.returncode==0
(out/'cli_help.log').write_text(cli.stdout+cli.stderr)
result={'original_expression_sources':len(seq['source_files']),'original_er_sources':len(er['source_files']),'source_checks':source_rows,'pinned_four_json_hashes_match':True,'same_saved_public_input_mapping':True,'saved_metadata_rows':len(meta),'paired_current_schedule_updates':schedule_checks,'paired_replay_draws':draw_checks,'teacher_forward_total':sum(x['target_forwards'] for x in history.values()),'history':history,'arrays':arrays,'reference_mapping_count':len(mapping),'reference_mapping':mapping,'shared22_arrays_exact':3,'ast':ast_rows,'bash_syntax_ok':True,'cli_help_ok':True,'absent_legacy_policy':'schema/step28_continual_population_policy.json','formal_public_inputs_called':False,'formal_labels_read':False,'raw_caches_read':False,'model_payloads_loaded':False,'old_production_evaluations_called':False,'scope':'Saved evidence mapping, no new result and no label-derived AP recomputation.'}
(out/'static_and_saved_evidence.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['original_expression_sources','original_er_sources','same_saved_public_input_mapping','saved_metadata_rows','paired_current_schedule_updates','paired_replay_draws','teacher_forward_total','reference_mapping_count','shared22_arrays_exact','bash_syntax_ok','cli_help_ok','scope']},ensure_ascii=False,indent=2));print('Arrays',len(arrays),'AST',len(ast_rows))
