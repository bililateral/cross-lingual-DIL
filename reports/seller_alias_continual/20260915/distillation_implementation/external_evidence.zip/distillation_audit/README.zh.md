# 本证据包的使用与范围

主要报告：`REVIEW.zh.md`。当前提交版有D1阻断；`minimal_observe_fix.patch`只是经隔离CPU验证的候选，没有应用到用户提交原件。

## 脚本与日志对应

- `verify_bundle.py`：核验指定ZIP和148份清单文件；输出初始／最终完整性JSON。
- `run_tests.py`：`--mode torch3`运行三个新CPU用例；`--mode affected`运行受影响夹具范围，明确排除缺正式公开语料的一项。当前附件还缺旧population policy，后者真实结果为35通过＋3配置加载错误；不要把日志改写为全通过。
- `reproduce_observe_collision.py`：两个CPU玩具更新复现提交版 `observe=False` 的错误；脚本用断言确认错误确实发生，退出0不等于被审更新函数通过。
- `make_patch_trial.py`：只在新隔离目录建立两文件最小修复，并生成patch；`patched_torch3.log`是修复候选的三个CPU用例，不能计入提交版通过数量。
- `extra_cpu_checks.py`：两个额外真实CPU测试，检查MSE独立梯度、目标UID／边／时点／淘汰、不刷新、实际消耗后CPU RNG及模块模式恢复。没有CUDA验证。
- `audit_static_and_saved.py`：冻结来源、旧公开metadata、1620当前日程、1080重放抽样、25目标前向推导、保存数组、AST／CLI／Bash语法。
- `audit_compare_saved.py`：旧保存矩阵作为新比较接口的软件夹具，独立核对2376个汇总／区间值及random_er字段。不产生新方法实验结果。

## 路径与复跑

原审查默认目录是 `/mnt/data/distillation_review_original`，工作副本 `/mnt/data/distillation_audit/work`，修复试验 `/mnt/data/distillation_audit/patch_trial`。审查产物写入 `/mnt/data/distillation_audit`。脚本里这些路径为明确常量；在其他环境复跑时改成对应的空临时目录即可。通用清单及测试脚本也提供参数：

```sh
export PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
python -B verify_bundle.py --zip 'review_upload(3).zip' --root /tmp/distill_review --extract --out /tmp/manifest_check.json
python -B run_tests.py --root /tmp/distill_review --mode torch3 --out /tmp/torch3.json
```

应使用不含正式模型／监督的临时审查副本，仅执行手工测试。不要用本证据包启动生产train、evaluate、模型验证CLI或Linux Bash入口。新源码与测试的最终冻结、生产py310三项零跳过和用户恢复仍属于主项目既定流程，本包不替代。

`affected_tests.log`、`torch3.log`中同名用例重复出现，是单跑和集合复跑；修复候选也是另一版本，不能合并重复计数。旧历史原文提取只是阅读辅助，不包含在本证据ZIP，不将其历史脚本执行归到本次。
