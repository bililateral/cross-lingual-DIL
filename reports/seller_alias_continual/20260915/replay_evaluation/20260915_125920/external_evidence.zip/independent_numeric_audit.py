"""Independent audit of saved metrics/counts only. No production imports or labels/models.
Usage: python independent_numeric_audit.py /path/to/extracted_archive /path/to/output
"""
from pathlib import Path
import collections
import csv
import hashlib
import json
import math
import platform
import sys
import time
import numpy as np

ROOT = Path(sys.argv[1] if len(sys.argv)>1 else '/mnt/data/replay_result_review')
OUT = Path(sys.argv[2] if len(sys.argv)>2 else '/mnt/data/replay_result_audit')
OUT.mkdir(parents=True, exist_ok=True)
NEW_DIR = ROOT/'reports/seller_alias_continual/20260915/replay_evaluation/20260915_125920'
OLD_DIR = ROOT/'reports/seller_alias_continual/20260910/expression_evaluation/20260910_171540'
RUN_DIR = ROOT/'reports/seller_alias_continual/20260915/replay_execution/20260915_112424/job/run'
ORDERS=('ABC','BCA','CAB'); DOMAINS='ABC'
started=time.monotonic()

def read(p): return json.loads(p.read_bytes())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
new,old,run=read(NEW_DIR/'evaluation.json'),read(OLD_DIR/'evaluation.json'),read(RUN_DIR/'manifest.json')
cols=new['columns']; assert cols==old['columns'] and len(cols)==22
checks=collections.Counter(); maxerr=collections.defaultdict(float); mismatches=[]

def check(actual, expected, category, path=''):
    """Compare complete nested records, preserving boolean/integer semantics."""
    if isinstance(expected,dict):
        assert set(actual)==set(expected),(category,path,set(actual)^set(expected))
        for k,v in expected.items(): check(actual[k],v,category,path+'/'+k)
    elif isinstance(expected,list):
        assert len(actual)==len(expected),(category,path)
        for i,(a,b) in enumerate(zip(actual,expected)): check(a,b,category,path+'/'+str(i))
    elif isinstance(expected,bool) or isinstance(expected,str) or expected is None:
        checks[category+'_nonnumeric']+=1
        assert actual==expected,(category,path,actual,expected)
    else:
        checks[category]+=1
        err=abs(float(actual)-float(expected));maxerr[category]=max(maxerr[category],err)
        if not math.isfinite(float(actual)) or err>1e-12:
            mismatches.append({'category':category,'path':path,'actual':actual,'expected':expected,'error':err})

def arrays(folder,record):
    ans={}
    for name,p in record['points'].items():
        f=p['file']; path=folder/f['path']
        assert path.stat().st_size==f['bytes'] and sha(path)==f['sha256']
        x=np.load(path,allow_pickle=False)
        assert x.shape==(60,22) and x.dtype==np.float64 and np.isfinite(x).all()
        ans[name]=x.reshape(3,20,22)
        by={d:dict(zip(cols,x[i*20:(i+1)*20].mean(axis=0).tolist())) for i,d in enumerate(DOMAINS)}
        check(by,p['by_domain'],'all_point_domain_means',name)
    return ans
A=arrays(NEW_DIR,new);B=arrays(OLD_DIR,old)
# Independent joint tensor: arm x order x time x domain x group x metric.
T=np.empty((2,3,3,3,20,22),dtype=np.float64)
for o,order in enumerate(ORDERS):
    for s in range(3):
        n=order+('_shared' if s==0 else '_er_stage'+str(s+1))
        b=order+('_shared' if s==0 else '_stage'+str(s+1))
        T[0,o,s]=A[n];T[1,o,s]=B[b]
    assert np.array_equal(T[0,o,0],T[1,o,0])

# One domain-group resampling realization reused for ALL arms, orders, times and metrics.
draws=np.random.default_rng(20260910).integers(0,20,size=(5000,3,20))
frequency=np.zeros((5000,3,20),dtype=np.int64)
for b in range(5000):
    for d in range(3): frequency[b,d]=np.bincount(draws[b,d],minlength=20)
weights=frequency.reshape(5000,60)/60.0
keys=('H','N','G_er','G_seq','F_er','F_seq','second_er_change','second_seq_change','final_er_minus_seq')
by_domain={k:[[] for _ in DOMAINS] for k in keys}
order_values={}; transitions=[]
for o,order in enumerate(ORDERS):
    f,m,l=[DOMAINS.index(x) for x in order]
    loc={'H':T[0,o,2,f]-T[1,o,2,f],
         'F_er':T[0,o,0,f]-T[0,o,2,f],
         'F_seq':T[1,o,0,f]-T[1,o,2,f]}
    for k in ('H','F_er','F_seq'): by_domain[k][f].append(loc[k])
    pairs={k:[] for k in ('N','G_er','G_seq')}
    for s,d in [(1,m),(2,l)]:
        ns=T[0,o,s,d]-T[1,o,s,d]
        ge=T[0,o,s,d]-T[0,o,s-1,d]
        gs=T[1,o,s,d]-T[1,o,s-1,d]
        for k,v in [('N',ns),('G_er',ge),('G_seq',gs)]:
            by_domain[k][d].append(v);pairs[k].append(v)
        transitions.append({'order':order,'stage':s+1,'domain':DOMAINS[d],
                            'er_before_ap':float(T[0,o,s-1,d,:,0].mean()),
                            'er_after_ap':float(T[0,o,s,d,:,0].mean()),
                            'seq_before_ap':float(T[1,o,s-1,d,:,0].mean()),
                            'seq_after_ap':float(T[1,o,s,d,:,0].mean()),
                            'N_ap':float(ns[:,0].mean()),'G_er_ap':float(ge[:,0].mean()),'G_seq_ap':float(gs[:,0].mean())})
    for k,arm in [('second_er_change',0),('second_seq_change',1)]:
        loc[k]=T[arm,o,2,m]-T[arm,o,1,m];by_domain[k][m].append(loc[k])
    for d in range(3): by_domain['final_er_minus_seq'][d].append(T[0,o,2,d]-T[1,o,2,d])
    order_values[order]=(loc,pairs)

# Averaging repeated appearances BEFORE bootstrap is equivalent to sampling the
# shared underlying groups once per domain in the complete trajectory tensor.
V={k:np.stack([np.stack(v,axis=0).mean(axis=0) for v in vv],axis=0) for k,vv in by_domain.items()}
boot={k:weights@v.reshape(60,22) for k,v in V.items()}
# Check the weighted-count bootstrap against direct indexing for all 5000 AP samples.
for k in keys:
    direct=np.asarray([np.mean([V[k][d,draws[b,d],0].mean() for d in range(3)]) for b in range(5000)])
    err=float(np.max(np.abs(direct-boot[k][:,0])))
    assert err<1e-14,(k,err)

rebuilt={}
for c,metric in enumerate(cols):
    contrasts={k:{'mean':float(v[:,:,c].mean()),
                  'by_domain_or_first_domain':v[:,:,c].mean(axis=1).tolist(),
                  'conditional_95pct_interval':np.quantile(boot[k][:,c],[.025,.975]).tolist()}
               for k,v in V.items()}
    bo={}
    for order,(loc,pairs) in order_values.items():
        bo[order]={k:float(v[:,c].mean()) for k,v in loc.items()}
        for k in ('N','G_er','G_seq'):
            bo[order][k]=float(np.stack(pairs[k])[:,:,c].mean())
            bo[order][k+'_transitions']=[float(v[:,c].mean()) for v in pairs[k]]
    absolute={'initial':{d:float(B['initial'][i,:,c].mean()) for i,d in enumerate(DOMAINS)},
              'shared':{order:{d:float(T[1,o,0,i,:,c].mean()) for i,d in enumerate(DOMAINS)} for o,order in enumerate(ORDERS)},
              'final':{}}
    for arm,armname in [(0,'er'),(1,'sequential')]:
        absolute['final'][armname]={'by_order_and_domain':{order:{d:float(T[arm,o,2,i,:,c].mean()) for i,d in enumerate(DOMAINS)} for o,order in enumerate(ORDERS)},
                                 'domain_order_group_equal_mean':float(T[arm,:,2,:,: ,c].mean())}
    rebuilt[metric]={'contrasts':contrasts,'by_order':bo,'absolute':absolute}
check(rebuilt,new['comparison']['metrics'],'comparison_rebuild')
ap=rebuilt['average_precision'];h=ap['contrasts']['H'];n=ap['contrasts']['N']
same=[o for o in ORDERS if ap['by_order'][o]['H']>0 and ap['by_order'][o]['G_er']>=.02]
gates={'retention':h['mean']>=.01 and h['conditional_95pct_interval'][0]>0,
       'new_capability':n['conditional_95pct_interval'][0]>=-.01,
       'same_order_learning_and_retention':len(same)>=2}
gate={'checks':gates,'same_orders':same,'passed':all(gates.values())}
check(gate,new['comparison']['gate'],'gate')
assert np.allclose(V['H'],V['F_seq']-V['F_er'],rtol=0,atol=1e-15)
assert np.allclose(boot['H'],boot['F_seq']-boot['F_er'],rtol=0,atol=1e-15)

# Reconstruct six classification metrics from saved counts; no truth vector.
confusion_summaries={};score_summaries={}
for arm,record,vals in [('er',new,A),('sequential',old,B)]:
    for name,p in record['points'].items():
        counts=np.asarray([[row[k] for k in ['tp','fp','fn','tn']] for row in p['confusion']])
        assert counts.shape==(60,4) and np.all(counts>=0) and np.all(counts==np.floor(counts))
        tp,fp,fn,tn=counts.T
        assert np.all(tp+fn==20) and np.all(fp+tn==358)
        totalpos=tp+fp
        precision=np.divide(tp,totalpos,out=np.zeros(60,dtype=float),where=totalpos!=0)
        recall=tp/(tp+fn);specificity=tn/(tn+fp)
        f1=2*tp/(2*tp+fp+fn)
        denom=np.sqrt((tp+fp).astype(float)*(tp+fn)*(tn+fp)*(tn+fn))
        mcc=np.divide(tp*tn-fp*fn,denom,out=np.zeros(60,dtype=float),where=denom!=0)
        calculated={'precision':precision,'recall':recall,'f1':f1,'specificity':specificity,
                    'balanced_accuracy':(recall+specificity)/2,'mcc':mcc}
        for k,v in calculated.items():
            check(v.tolist(),vals[name][:,:,cols.index(k)].ravel().tolist(),'classification_from_saved_counts',arm+'/'+name+'/'+k)
        if arm=='er':
            f=run['points'][name]['scores']['development'];path=RUN_DIR/f['path']
            assert sha(path)==f['sha256'] and path.stat().st_size==f['bytes']
            scores=np.load(path,allow_pickle=False)
            assert scores.shape==(60,378) and scores.dtype==np.float32 and np.isfinite(scores).all()
            pp=(scores>=0).sum(axis=1)
            assert np.array_equal(pp,tp+fp)
            checks['label_free_score_positive_count_checks']+=60
            score_summaries[name]={'shape':list(scores.shape),'dtype':str(scores.dtype),
                'minimum':float(scores.min()),'maximum':float(scores.max()),'predicted_positive':int(pp.sum()),
                'counts_match_per_group':True}
    names=[o+('_er_stage3' if arm=='er' else '_stage3') for o in ORDERS]
    totals={k:sum(row[k] for name in names for row in record['points'][name]['confusion']) for k in ['tp','fp','fn','tn']}
    tp,fp,fn,tn=[totals[k] for k in ['tp','fp','fn','tn']]
    confusion_summaries[arm]={'counts':totals,'decisions':tp+fp+fn+tn,
        'micro_precision':tp/(tp+fp),'micro_recall':tp/(tp+fn),
        'micro_f1':2*tp/(2*tp+fp+fn),'micro_specificity':tn/(tn+fp),
        'positive_prediction_rate':(tp+fp)/(tp+fp+fn+tn),
        'no_positive_prediction_groups':sum(sum(row[k] for k in ['tp','fp'])==0 for name in names for row in record['points'][name]['confusion'])}

# Only arithmetic supplements; not new inferential endpoints.
supplements={}
for k in ('average_precision','map','f1'):
    c=cols.index(k)
    supplements[k]={'first_domain_shared':float(np.mean([T[0,o,0,o,:,c].mean() for o in range(3)])),
        'first_domain_final_er':float(np.mean([T[0,o,2,o,:,c].mean() for o in range(3)])),
        'first_domain_final_seq':float(np.mean([T[1,o,2,o,:,c].mean() for o in range(3)])),
        'second_domain_learned_er':float(np.mean([T[0,o,1,DOMAINS.index(order[1]),:,c].mean() for o,order in enumerate(ORDERS)])),
        'second_domain_learned_seq':float(np.mean([T[1,o,1,DOMAINS.index(order[1]),:,c].mean() for o,order in enumerate(ORDERS)])),
        'second_domain_final_er':float(np.mean([T[0,o,2,DOMAINS.index(order[1]),:,c].mean() for o,order in enumerate(ORDERS)])),
        'second_domain_final_seq':float(np.mean([T[1,o,2,DOMAINS.index(order[1]),:,c].mean() for o,order in enumerate(ORDERS)]))}

# Collect every comparison discrepancy; fail instead of silently revising records.
report={'status':'PASS' if not mismatches else 'FAIL','environment':{'python':platform.python_version(),'numpy':np.__version__,'system':platform.platform()},
        'production_functions_called':False,'label_parses':0,'model_loads':0,'training_updates':0,
        'metric_matrix_count':len(A)+len(B),'matrix_shapes':[60,22],'new_blind_score_count':len(score_summaries),
        'shared_arrays_exact':3,'bootstrap_seed':20260910,'bootstrap_replicates':5000,
        'bootstrap_draws_sha256':hashlib.sha256(draws.astype('<i8',copy=False).tobytes()).hexdigest(),
        'bootstrap_implementation':'shared 5000x3x20 indices converted to per-domain occurrence weights; all 198 metric contrasts; 45000 AP samples additionally checked by direct indexing',
        'checks':dict(checks),'max_absolute_errors':dict(maxerr),'mismatches':mismatches,
        'new_evaluation_sha256':sha(NEW_DIR/'evaluation.json'),'old_evaluation_sha256':sha(OLD_DIR/'evaluation.json'),
        'gate':gate,'comparison':{'metrics':rebuilt},'transitions':transitions,
        'supplements':supplements,'confusion_summaries':confusion_summaries,'score_summaries':score_summaries,
        'seconds':time.monotonic()-started}
(OUT/'independent_numeric_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
with (OUT/'all22_final_comparison.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f);w.writerow(['metric','SEQ_final_equal_mean','ER_final_equal_mean','ER_minus_SEQ','conditional_95pct_low','conditional_95pct_high'])
    for k in cols:
        a=rebuilt[k]['absolute']['final'];c=rebuilt[k]['contrasts']['final_er_minus_seq'];w.writerow([k,a['sequential']['domain_order_group_equal_mean'],a['er']['domain_order_group_equal_mean'],c['mean'],*c['conditional_95pct_interval']])
with (OUT/'six_ap_transitions.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=list(transitions[0]));w.writeheader();w.writerows(transitions)
print(json.dumps({k:report[k] for k in ['status','environment','checks','max_absolute_errors','mismatches','gate','seconds']},ensure_ascii=False,indent=2))
print('AP:',json.dumps(ap['contrasts'],ensure_ascii=False,indent=2))
print('SUPPLEMENTS:',json.dumps(supplements,ensure_ascii=False,indent=2))
print('COUNTS:',json.dumps(confusion_summaries,ensure_ascii=False,indent=2))
assert not mismatches
