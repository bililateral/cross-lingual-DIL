"""Audit supplied execution records without importing runner, reading labels/cache or loading models."""
from pathlib import Path
import collections
import datetime as dt
import hashlib
import json
import math
import platform
import random
import sys
import zipfile
import numpy as np
ROOT=Path(sys.argv[1] if len(sys.argv)>1 else '/mnt/data/replay_result_review')
OUT=Path(sys.argv[2] if len(sys.argv)>2 else '/mnt/data/replay_result_audit');OUT.mkdir(parents=True,exist_ok=True)
EX=ROOT/'reports/seller_alias_continual/20260915/replay_execution/20260915_112424'
RUN=EX/'job/run'
EV=ROOT/'reports/seller_alias_continual/20260915/replay_evaluation/20260915_125920'
OLD_RUN=ROOT/'reports/seller_alias_continual/20260910/expression_execution/20260910_154137/run'
ORDERS=('ABC','BCA','CAB')

def read(p):return json.loads(p.read_bytes())
def canonical(obj):return (json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode('utf8')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def seed(*parts):return int.from_bytes(hashlib.sha256(canonical(list(parts))).digest()[:8],'big')%(2**63-1)
def filematch(path,rec):
    assert path.is_file(),str(path)
    assert path.stat().st_size==rec['bytes'] and digest(path)==rec['sha256'],str(path)
    return True

run=read(RUN/'manifest.json');old=read(OLD_RUN/'manifest.json');ev=read(EV/'evaluation.json');policy=read(ROOT/'schema/step28_continual_replay_policy.json')
assert run['config']==policy==ev['config']
assert policy['origin_manifest_sha256']==digest(OLD_RUN/'manifest.json')
assert policy['origin_evaluation_sha256']==digest(ROOT/policy['origin_evaluation'])
assert ev['score_manifest_sha256']==digest(RUN/'manifest.json')
source_checks=[]
for rec in run['source_files']:
    source_checks.append({'path':rec['path'],'current_bytes_match_manifest':filematch(ROOT/rec['path'],rec)})
assert run['source_files'][:8]==old['source_files'] and len(run['source_files'])==12
# Optional historical implementation ZIP: compare actual frozen bytes, not prior verdict.
previous_zip=ROOT.parent/'replay_review.zip'
if previous_zip.exists():
    with zipfile.ZipFile(previous_zip) as z:
        for item in source_checks:
            item['prior_implementation_zip_bytes_equal']=(ROOT/item['path']).read_bytes()==z.read(item['path'])
            assert item['prior_implementation_zip_bytes_equal']
assert run['inputs']==old['inputs'] and run['pretrained']==old['pretrained']
assert run['label_parses']=={'train':1,'development':0,'heldout':0,'owners':0}
assert ev['label_parses']=={'train':0,'development':1,'heldout':0,'owners':0}
assert read(RUN/'access.json')=={'train_parse_attempts':1,'development':0,'heldout':0,'owners':0}
assert read(EV/'access.json')=={'status':'COMPLETE_GATE_PASSED_VALID_PARSE_STARTING','development_parse_attempts':1,'train':0,'heldout':0,'owners':0}
assert run['torch_contracts']=={'passed':1,'skipped':0}
assert run['status']=='COMPLETE_RANDOM_GROUP_ER_1620_RELOADED_VALID_BLIND'
assert not (RUN/'failure.json').exists()
meta=run['inputs']['metadata']
assert len(meta)==240 and len({m['group_uid'] for m in meta})==240
assert collections.Counter((m['split'],m['domain']) for m in meta)=={(s,d):n for s,n in [('train',60),('development',20)] for d in 'ABC'}
lookup={m['group_uid']:m for m in meta}
valid=run['inputs']['valid_group_ids']
assert len(valid)==60 and len(set(valid))==60
assert valid==[m['group_uid'] for m in sorted((r for r in meta if r['split']=='development'),key=lambda r:(r['domain'],int(r['group_index'])))]
assert old['config']['initialization_seed']==20260909

initial=old['points']['initial']['checkpoint']['state_sha256']
expected_names={order+('_shared' if s==1 else '_er_stage'+str(s)) for order in ORDERS for s in [1,2,3]}
assert set(run['training'])==set(run['points'])==expected_names
assert set(run['models'])=={o+'_er_stage3' for o in ORDERS}
assert set(run['memory'])=={o+s for o in ORDERS for s in ['_shared','_er_stage2']}
shared_checks={};schedule_checks={};memory_checks={};branches={};point_checks={}
for order in ORDERS:
    assert run['starts'][order]==initial
    sn=order+'_shared';a=run['points'][sn];b=old['points'][sn]
    assert a['checkpoint']['state_sha256']==b['checkpoint']['state_sha256']
    assert a['model_state_sha256']==b['model_state_sha256']
    assert a['scores']==b['scores']
    assert run['starts'][order+'_continuation']==b['checkpoint']['state_sha256']
    shared_checks[order]={'initial_digest_matches':True,'full_state_digest_matches':True,'model_digest_matches':True,
                         'blind_score_file_hash_matches_origin':True,'continuation_digest_matches':True,
                         'note':'The old blind score file and actual checkpoint are not present for new array/load tests.'}
    reservoir=random.Random(seed(20260909,order,'memory'));kept=[];seen=0
    for s in [1,2,3]:
        name=order+('_shared' if s==1 else '_er_stage'+str(s));oldname=order+('_shared' if s==1 else '_stage'+str(s))
        current=sorted(m['group_uid'] for m in meta if m['split']=='train' and m['domain']==order[s-1])
        rng=random.Random(seed(20260909,order,s,'current'));expected=[]
        for epoch in range(3):
            ids=current.copy();rng.shuffle(ids);expected.extend(ids)
        t=run['training'][name];ot=old['training'][oldname]
        assert t['group_ids']==ot['group_ids']==expected
        assert t['dropout_stream']==ot['dropout_stream']==seed(20260909,order,s,'current')
        assert t['first_adam_step']==(s-1)*180+1 and t['last_adam_step']==s*180 and t['updates']==180
        assert math.isfinite(t['training_seconds']) and t['training_seconds']>0
        assert math.isfinite(t['maximum_gradient_norm_before_clip']) and t['maximum_gradient_norm_before_clip']>0
        if s==1:
            assert {k:v for k,v in t.items() if k!='training_seconds'}=={k:v for k,v in ot.items() if k!='training_seconds'}
            assert t['order_sha256']==hashlib.sha256(canonical(expected)).hexdigest()
            shared_checks[order]['all_shared_training_records_except_time_exact']=True
        else:
            assert t['reservoir_unchanged'] and t['final_index']==180
            assert t['current_pair_presentations']==t['replay_pair_presentations']==68040
            assert len(t['replay_group_ids'])==180 and set(t['replay_group_ids'])<=set(kept)
            assert not set(t['replay_group_ids'])&set(current)
            br=t['first_update']['branches_squared_hook_norm']
            assert set(br)=={'current','replay'} and all(set(x)=={'encoder','head'} for x in br.values())
            assert all(math.isfinite(v) and v>0 for x in br.values() for v in x.values())
            assert t['first_update']['encoder_and_head_changed']
            assert len(t['current_bce_by_epoch'])==len(t['replay_bce_by_epoch'])==3
            assert all(math.isfinite(v) and v>=0 for key in ['current_bce_by_epoch','replay_bce_by_epoch'] for v in t[key])
            branches[name]={'first_update':t['first_update'],'current_bce_by_epoch':t['current_bce_by_epoch'],
                            'replay_bce_by_epoch':t['replay_bce_by_epoch'],
                            'historical_online_bce_strictly_decreases':all(x>y for x,y in zip(t['replay_bce_by_epoch'],t['replay_bce_by_epoch'][1:]))}
        schedule_checks[name]={'updates':180,'first_adam_step':t['first_adam_step'],'last_adam_step':t['last_adam_step'],
                              'current_ids_and_dropout_match_original':True,'current_unique_groups':len(set(expected))}
        p=run['points'][name];f=p['scores']['development']
        assert set(p['scores'])=={'development'} and p['full_model_and_adam_reloaded']
        assert p['checkpoint']['path']=='work/'+name+'.pt'
        assert f['path']=='scores/'+name+'_development.npy'
        filematch(RUN/f['path'],f)
        scores=np.load(RUN/f['path'],allow_pickle=False)
        assert scores.shape==(60,378) and scores.dtype==np.float32 and np.isfinite(scores).all()
        point_checks[name]={'actual_score_file_hash_match':True,'shape':[60,378],'dtype':'float32','all_finite':True,
                           'full_model_adam_reload_recorded':True,'timing':p['timing']}
        if s<3:
            for uid in current:
                seen+=1
                if seen<=6:kept.append(uid)
                else:
                    idx=reservoir.randrange(seen)
                    if idx<6:kept[idx]=uid
            m=run['memory'][name]
            assert m['added_groups']==current and m['retained_groups']==kept
            assert m['seen']==seen==60*s and m['stage']==s+1 and m['order']==order and m['index']==0
            assert m['disk_roundtrip_exact'] and m['file']['bytes']==m['full_state_bytes'] and 0<m['full_state_bytes']<=1048576
            nex=run['training'][order+'_er_stage'+str(s+1)]
            draw_rng=random.Random(seed(20260909,order,s+1,'replay_draw'))
            # No memory payload is constructed/parsed. Its byte content is constant
            # during training, so the change in wrapper length is independently knowable.
            def overhead(index):return len(canonical({'memory':None,'order':order,'stage':s+1,'index':index,'replay_rng':draw_rng.getstate()}))
            initial_overhead=overhead(0);sizes=[m['full_state_bytes']];drawn=[]
            for index in range(1,181):
                drawn.append(draw_rng.choice(kept));sizes.append(m['full_state_bytes']+overhead(index)-initial_overhead)
            assert drawn==nex['replay_group_ids'] and drawn[0]==m['next_draw']
            assert max(sizes)==nex['maximum_history_bytes']
            memory_checks[name]={'snapshot_bytes_recorded':m['full_state_bytes'],'stage_training_max_bytes_recomputed_from_rng_length_delta':max(sizes),
                'seen':seen,'retained_domain_counts':dict(collections.Counter(lookup[uid]['domain'] for uid in kept)),
                'replayed_domain_presentations':dict(collections.Counter(lookup[uid]['domain'] for uid in drawn)),
                'per_retained_group_draw_counts':dict(collections.Counter(drawn)),
                'algorithm_R_members_match':True,'all_180_draws_match':True,'rng_wrapper_byte_delta_matches':True,
                'disk_payload_available_to_this_audit':False,'transient_insertion_payloads_available':False}

receipt=read(RUN/'model_verification.json')
assert receipt=={'manifest_sha256':digest(RUN/'manifest.json'),
                 'files':[{k:v[k] for k in ['path','bytes','sha256']} for _,v in sorted(run['models'].items())]}
assert all(m['actual_loaded_model_equals_replayed_state'] for m in run['models'].values())
assert sum(t['updates'] for t in run['training'].values())==run['physical_updates']==1620
assert run['group_forwards_with_replay']==9*60*2==1080
train_seconds=sum(t['training_seconds'] for t in run['training'].values())
inference_seconds=sum(p['timing']['inference_seconds_including_replay'] for p in run['points'].values())
point_seconds=sum(p['timing']['total_point_seconds'] for p in run['points'].values())
assert train_seconds==run['formal_training_seconds'] and inference_seconds==run['inference_seconds_including_replay']
log=(EX/'job/train.log').read_text()
assert 'Ran 1 test in 0.761s' in log and '\nOK\n' in log and 'skipped=' not in log
entries=[json.loads(line) for line in log.splitlines() if line.startswith('{')]
counts=collections.Counter(row.get('event',row.get('status')) for row in entries)
assert counts['updates']==18 and counts['replay_updates']==36 and counts['point_reloaded']==9
for name in expected_names:
    if name.endswith('_shared'):
        rows=[x for x in entries if x.get('segment')==name]
    else:
        rows=[x for x in entries if x.get('order')==name[:3] and x.get('stage')==int(name[-1])]
    assert [x['completed'] for x in rows]==[30,60,90,120,150,180]
    pe=[x for x in entries if x.get('point')==name];assert len(pe)==1
    assert all(pe[0][k]==run['points'][name]['timing'][k] for k in ['inference_seconds_including_replay','total_point_seconds'])
assert entries[-1]['status']==run['status']
progress=read(RUN/'progress.json')
for k,v in progress.items():
    if k!='status':assert v==run[k],k
assert progress['status']=='RUNNING'

# Audit the AFTER-run inventory; absent cache/model bytes remain receipt-level evidence.
inv=read(EX/'completion_files.json');res=read(EX/'resources.json');completion=read(EX/'completion.json')
assert completion['inventory_sha256']==digest(EX/'completion_files.json')
present=[];absent=[]
for rec in inv['files']:
    p=ROOT/rec['path']
    if p.exists():filematch(p,rec);present.append(rec['path'])
    else:absent.append(rec['path'])
    rel=str(Path(rec['path']).relative_to(RUN.relative_to(ROOT))) if str(RUN.relative_to(ROOT))+'/' in rec['path'] else None
    if rel and rel.startswith('models/'):
        nm=Path(rel).stem
        assert all(rec[k]==run['models'][nm][k] for k in ['bytes','sha256'])
    if rel and rel.startswith('memory/'):
        nm=Path(rel).stem
        assert all(rec[k]==run['memory'][nm]['file'][k] for k in ['bytes','sha256'])
small=[f for f in inv['files'] if f['copy_to_windows']]
models=[f for f in inv['files'] if not f['copy_to_windows']]
assert len(small)==25 and sum(f['bytes'] for f in small)==2233363
assert len(models)==3 and sum(f['bytes'] for f in models)==5660849925
whole=sum(f['bytes'] for f in inv['files'])
assert whole==inv['whole_job_final_bytes']==res['whole_job_final_bytes']==5663083288
outer=sum(f['bytes'] for f in inv['files'] if Path(f['path']).parent==((EX/'job').relative_to(ROOT)))
assert outer==res['outer_job_bytes']==11452
late=(RUN/'manifest.json').stat().st_size+(RUN/'model_verification.json').stat().st_size
assert late==res['late_manifest_and_model_receipt_bytes']==163164
max_checkpoint=max(p['checkpoint']['bytes'] for p in run['points'].values())
assert max_checkpoint==5656121635
coexisting=sum(m['bytes'] for m in run['models'].values())+max_checkpoint
upper=whole+max_checkpoint
assert coexisting==res['coexisting_major_payload_bytes']==11316971560
assert upper==res['conservative_execution_payload_upper_bound_bytes']==11319204923
assert run['budget']['peak_observed_bytes']==res['run_peak_observed_bytes'] and run['budget']['peak_observed_bytes']<=upper<16*1024**3
assert inv['work_files']==[] and res['work_files_remaining']==0
start=dt.datetime.fromisoformat((EX/'job/started.txt').read_text().strip());end=dt.datetime.fromisoformat((EX/'job/finished.txt').read_text().strip())
assert (end-start).total_seconds()==res['outer_timestamp_seconds']==4442
assert (EX/'job/exit_status.txt').read_text().strip()=='0'
assert train_seconds==res['formal_training_seconds'] and inference_seconds==res['scoring_seconds_including_replay'] and point_seconds==res['point_seconds_including_scoring']
assert run['budget']['elapsed_seconds']==res['run_elapsed_seconds']<10800
launch=read(EX/'launch.json');assert launch['CUDA_VISIBLE_DEVICES']=='0' and launch['resource_limits']=={'updates':1620,'cpu_threads':1,'timeout_hours':3,'output_GiB':16}
assert sorted(launch['source_files'],key=lambda x:x['path'])==sorted(run['source_files'],key=lambda x:x['path'])
assert run['environment']==old['environment']
coexistence_progression={}
for order in ORDERS:
    pe=next(x for x in entries if x.get('point')==order+'_er_stage3')
    after=pe['peak_observed_bytes']+run['models'][order+'_er_stage3']['bytes']
    coexistence_progression[order]={'last_point_logged_peak':pe['peak_observed_bytes'],'new_inference_bytes':run['models'][order+'_er_stage3']['bytes'],'sum':after}
assert coexistence_progression['CAB']['sum']==run['budget']['peak_observed_bytes']
report={'status':'PASS_SUPPLIED_RECORDS_AND_BYTES','environment':{'python':platform.python_version(),'numpy':np.__version__,'system':platform.platform()},
    'production_functions_called':False,'label_parses':0,'memory_payload_deserializations':0,'model_loads':0,'training_updates':0,
    'source_checks':source_checks,'metadata_rows':len(meta),'valid_ids_order_matches_domain_group_index':True,
    'shared_checks':shared_checks,'schedules':schedule_checks,'memory_checks':memory_checks,'branch_evidence':branches,'point_checks':point_checks,
    'log_event_counts':dict(counts),'physical_updates':1620,'current_edge_presentations':1620*378,'replay_edge_presentations':1080*378,
    'current_schedule_entries_checked':9*180,'replay_draw_entries_checked':6*180,
    'model_receipt_matches_manifest_and_completion_inventory':True,'runtime_environment_recorded':run['environment'],
    'production_cpu_contract_log':{'passed':1,'skipped':0,'seconds':.761,'executed_in_this_audit':False},
    'label_access_records_consistent':True,'once_only_access_is_not_an_independent_filesystem_audit':True,
    'inventory':{'actual_attached_files_rehashed':len(present),'receipt_only_absent_files':absent,
                 'small_file_count_recorded':len(small),'small_file_bytes_recorded':sum(f['bytes'] for f in small),
                 'six_cache_snapshot_bytes_total':sum(m['full_state_bytes'] for m in run['memory'].values())},
    'resource_recalculation':{'R1_status':'CLOSED_FOR_DECLARED_JOB_PAYLOAD_AND_WALL_TIME',
        'formal_training_seconds':train_seconds,'inference_seconds_inside_point_seconds':inference_seconds,'point_seconds':point_seconds,
        'timestamp_seconds':(end-start).total_seconds(),'gnu_time_elapsed_recorded':'1:14:01',
        'start_timezone':str(start.tzinfo),'whole_job_final_bytes':whole,'outer_job_bytes':outer,
        'late_receipts_bytes':late,'maximum_single_checkpoint_recorded_bytes':max_checkpoint,
        'major_coexistence_bytes':coexisting,'conservative_job_upper_bound_bytes':upper,
        'run_observed_maximum_recorded_bytes':run['budget']['peak_observed_bytes'],'output_cap_bytes':16*1024**3,
        'bound_is_not_exact_instantaneous_peak':True,'coexistence_progression':coexistence_progression},
    'limitations':['Actual weights/checkpoints and cache byte payloads are absent by design; only existing receipts plus frozen code and supplied files are audited.',
                   'No new GPU execution, production entry/evaluation, filesystem access monitoring or old-label/AP recomputation was performed.',
                   'All intermediate insertion payload byte sizes are not attached; cap-check execution is supported by source and successful recorded run, not independent payload measurement.']}
(OUT/'independent_execution_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in report.items() if k not in ['point_checks','source_checks','branch_evidence','schedules','shared_checks','memory_checks']},ensure_ascii=False,indent=2))
print('MEMORY',json.dumps(memory_checks,ensure_ascii=False,indent=2))
