# 随机完整群ER结果外审证据包

首先阅读 `REPLAY_RESULT_EXTERNAL_REVIEW.zh.md`。本包是新增审查材料，不替换原归档中的来源、运行结果、评价结果或结果初稿。

## 文件

- `manifest_verification.json`：送审ZIP及81份清单文件的初始核验。
- `final_integrity_and_scope.json`：审查结束后原始字节复核及实际执行/未执行范围。
- `independent_numeric_audit.py/.json/.log`：20份保存指标、9份新盲分数、计数和共享底层群bootstrap独立核算。
- `independent_execution_audit.py/.json/.log`：来源、日程、无标签缓存成员/抽样/RNG长度、执行记录和资源口径核验。
- `draft_numeric_check.json`：原结果初稿99个表格单元格舍入核验。
- `all22_final_comparison.csv`：22指标最终均值/差及既有条件区间；是机器审计导出，不是新评价。
- `six_ap_transitions.csv`：六次新域转移的已保存AP及H/N/G所用数量。
- `evidence_manifest.json`：本证据包其他文件的大小及SHA256。

## 仅用保存结果复算

需要Python及NumPy；本次独立环境为Python 3.13.5、NumPy 2.3.5。将原 `review_upload.zip` 解压后，从本目录运行以下命令，输出位置应与原解压目录分开：

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 python -B independent_numeric_audit.py /path/to/extracted_archive /path/to/new_audit_output
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 python -B independent_execution_audit.py /path/to/extracted_archive /path/to/new_audit_output
```

脚本不导入生产runner，不读取正式标签/owners，不反序列化历史缓存，不加载模型，不训练，也不调用正式评价入口。执行证据脚本只在原解压目录的父目录存在 `replay_review.zip` 时额外比较前次实现送审的12份来源原字节；该额外比较不沿用前次外审结论。

数值脚本从已保存指标重建汇总/对比/区间，并从已保存混淆计数重建六个分类指标。它不能在没有原标签的条件下重新计算AP或检索指标。盲分数仅用于无标签形状/有限性/阈值阳性数量检查。

生产CPU TorchContracts、完整Adam/模型恢复、一次性监督、缓存payload字节由所附生产记录及冻结调用链支持；不能称本包在新环境再次执行了这些生产操作。源码/回执支持与独立字节/算术核验的区别见报告。

## 结论范围

固定合成场景下预定缓解三门失败，随机ER保留为有效负基线。R1在声明的job执行载荷/完整历时范围关闭，不将上界称为精确瞬时峰值。没有批准或执行新实验。
