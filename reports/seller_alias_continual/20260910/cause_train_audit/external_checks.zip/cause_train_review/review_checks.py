"""Independent, synthetic-only checks of the attached production functions.

No project supervision, original data, original manifest, LaBSE, CUDA, or remote
machine is used. Catalog, labels, score files, and checkpoint receipts below are
explicit toy fixtures. The copied production Python sources are unchanged.
"""
from __future__ import annotations
import copy, csv, hashlib, itertools, json, os, platform, sys, tempfile, unittest
from pathlib import Path
from unittest.mock import patch
import numpy as np

HERE = Path(__file__).resolve().parent
PROJECT = HERE / 'project'
sys.path.insert(0, str(PROJECT / 'scripts'))
import step28_continual_cause_train as trial
import step28_continual_cause_probe as probe
import step28_continual_population_data as data
import step28_continual_population_evaluate as metrics

CATALOG = {
 'topics': [{'subcategories': [{'products':['商品甲','商品乙'], 'details':['详情甲','详情乙']}]}],
 'qualifiers':['规格甲','规格乙'],
 'title_templates':['{product}｜{qualifier}','【{qualifier}】{product}','{product}({qualifier})'],
 'intros':['介绍{product}','供给{product}'],
 'packaging':['包装甲','包装乙'], 'delivery':['配送甲','配送乙'],
 'service_phrases':[[f'服务家{i}位{j}' for j in range(2)] for i in range(4)],
 'description_templates':[
  '{intro}；{detail}；{packaging}；{delivery}；{service}',
  '{service}·{delivery}·{packaging}·{detail}·{intro}',
  '{detail}/{intro}/{service}/{packaging}/{delivery}'],
}
data.write_json(PROJECT/'schema/step28_continual_catalog.json', CATALOG)
CONFIG = json.loads((HERE.parent/'implementation.json').read_text())['original_config']
LEFT, RIGHT = np.triu_indices(28,1)
OWNERS = [i//2 for i in range(16)] + [8+i//3 for i in range(12)]
LABELS = tuple(int(OWNERS[i]==OWNERS[j]) for i,j in zip(LEFT,RIGHT))

def group(uid='toy_group', labels=LABELS):
    sellers=tuple(f'{uid}_seller_{i:02}' for i in range(28))
    items=[]
    for i in range(28):
        style=(i%3,(i//3)%3,(i//9)%4)
        rows=[]
        for k in range(2+i%3):
            product=CATALOG['topics'][0]['subcategories'][0]['products'][(i+k)%2]
            fields={'product':product, 'qualifier':CATALOG['qualifiers'][k%2],
                    'intro':CATALOG['intros'][k%2].format(product=product),
                    'detail':CATALOG['topics'][0]['subcategories'][0]['details'][k%2],
                    'packaging':CATALOG['packaging'][k%2], 'delivery':CATALOG['delivery'][k%2],
                    'service_position':k%2}
            title,desc=probe.render(style,fields,CATALOG)
            rows.append((f'{uid}_item_{i:02}_{k:02}',title,desc))
        items.append(tuple(rows))
    g=data.Group(uid,sellers,tuple(items),labels)
    g.validate()
    return g

def codes(g):
    styles=np.asarray([probe.decode(rows[0][1],rows[0][2],CATALOG)[0] for rows in g.items])
    return (styles[LEFT]==styles[RIGHT]).astype(int) @ np.array([4,2,1])

def stage_log(meta,order,stage):
    stream=data.seed_for(CONFIG['initialization_seed'],order,stage,'current')
    supply=[data.Group(r['group_uid'],(),()) for r in meta if r['split']=='train' and r['domain']==order[stage-1]]
    ids=[g.uid for g in data.schedule(supply,3,stream)]
    return {'updates':180,'current_group_ids':ids,
            'current_order_sha256':hashlib.sha256(data.json_bytes(ids)).hexdigest(),
            'current_dropout_stream':stream,'replay_group_ids':[],
            'current_pair_presentations':68040,'replay_pair_presentations':0,
            'first_update_modules':{k:{'finite_nonzero_gradient':True,'parameters_changed':True} for k in ('encoder','head')}}

class GateFixture:
    """A complete toy run for exercising the REAL Windows complete gate.
    No real checkpoint-state equality or original training is claimed.
    """
    def __init__(self,root):
        self.root=root
        self.run=root/'reports/run'; self.old=root/'toy_old'
        (self.run/'scores').mkdir(parents=True); (self.old/'scores').mkdir(parents=True)
        self.groups={}; self.meta=[]
        self.labelled_valid=[]
        for split,count in [('train',60),('development',20)]:
            self.groups[split]=[]
            for domain in 'ABC':
                for i in range(count):
                    uid=f'toy_{split}_{domain}_{i:02}'
                    g=group(uid)
                    if split=='development': self.labelled_valid.append(g)
                    self.groups[split].append(data.Group(g.uid,g.sellers,g.items,None))
                    self.meta.append({'group_uid':uid,'split':split,'domain':domain,'group_index':str(i),
                                      'items':str(sum(map(len,g.items))),'accounts':'28'})
        self.meta.sort(key=lambda r:(r['domain'],int(r['group_index'])))
        self.checked={'toy_public_fixture':True}
        pairs=[trial.reassign(g,CATALOG) for g in self.groups['train']]
        self.inputs={'files':self.checked,'metadata':self.meta,
                     'original_train_sha256':trial.public_digest(self.groups['train']),
                     'reassigned_train_sha256':trial.public_digest([g for g,_ in pairs]),
                     'valid_sha256':trial.public_digest(self.groups['development']),
                     'transformations':[r for _,r in pairs]}
        labelled_train=[data.Group(g.uid,g.sellers,g.items,LABELS) for g in self.groups['train']]
        changed_train=[trial.reassign(g,CATALOG)[0] for g in labelled_train]
        self.manipulation=trial.manipulation(labelled_train,changed_train,CATALOG)
        self.original={'config':CONFIG,'orders':[]}
        self.record={'status':trial.COMPLETE,'contract':trial.contract(),'source_files':trial.sources(),
                     'original_manifest_sha256':probe.RUN_SHA,'physical_updates':2700,
                     'label_parses':{'train':1,'development':0,'heldout':0,'owners':0},
                     'budget':{'elapsed_seconds':1,'peak_observed_bytes':1},'inputs':self.inputs,
                     'orders':[],'retained_files_verified':[],'manipulation':self.manipulation}
        rng=np.random.default_rng(451)
        self.scores={}
        for order in probe.ORDERS:
            shared=f'toy_shared_full_state_{order}'
            old={'order':order,'points':{},'training':{'shared':stage_log(self.meta,order,1),
                'sequential':[stage_log(self.meta,order,2),stage_log(self.meta,order,3)]}}
            log={'order':order,'points':{},'training':{},'models':{},
                 'branch_start_state_sha256':dict.fromkeys(trial.BRANCHES,shared)}
            for key in trial.POINTS:
                stage=1 if key=='shared' else int(key[-1])
                log['training'][key]=stage_log(self.meta,order,stage)
                name=key.replace('original','sequential')
                arr=rng.normal(size=(60,378)).astype(np.float32)
                arr[:,::19]=0.0  # Include score ties in AP and retrieval checks.
                path=self.run/'scores'/f'{order}_{name}_development.npy'
                np.save(path,arr,allow_pickle=False)
                self.scores[(order,key)]=arr
                p={'model_state_sha256':f'toy_model_state_{order}_{key}',
                   'checkpoint':{'state_sha256':shared if key=='shared' else f'toy_full_state_{order}_{key}'},
                   'full_model_and_adam_reloaded':True,
                   'scores':{'development':data.record(path,self.run)}}
                log['points'][key]=p
                if key=='shared' or key.startswith('original'):
                    old_path=self.old/'scores'/f'{order}_{name}_development.npy'
                    np.save(old_path,arr,allow_pickle=False)
                    op=copy.deepcopy(p);op['scores']['development']=data.record(old_path,self.old)
                    old['points'][name]=op
            m={'path':f'models/{order}_reassigned.pt','bytes':1,'sha256':'toy_inference_file',
               'actual_loaded_model_equals_replayed_state':True}
            log['models']['reassigned']=m
            self.record['retained_files_verified'].append({k:m[k] for k in ('path','bytes','sha256')})
            self.record['orders'].append(log);self.original['orders'].append(old)
        self.write(self.record)
    def write(self,record): data.write_json(self.run/'manifest.json',record)
    def gate(self):
        with patch.object(probe,'RUN',self.old):
            return trial.validated_scores(self.run,self.original,self.groups,self.meta,self.checked)
    def evaluate(self,destination):
        with patch.object(data,'ROOT',self.root),patch.object(probe,'RUN',self.old), \
             patch.object(probe,'original_manifest',return_value=self.original), \
             patch.object(trial,'public_inputs',return_value=(self.groups,self.meta,self.checked)), \
             patch.object(trial,'sources',return_value=self.record['source_files']), \
             patch.object(trial,'attach_labels',return_value=self.labelled_valid) as attach:
            try:
                result=trial.evaluate(self.run,destination)
                return {'result':result,'toy_valid_attach_calls':attach.call_count}
            except Exception as exc:
                return {'exception_type':type(exc).__name__,'exception':str(exc),
                        'toy_valid_attach_calls':attach.call_count,'destination_exists':destination.exists()}

class SyntheticChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory(prefix='cause_train_review_')
        cls.fx=GateFixture(Path(cls.temp.name))
    @classmethod
    def tearDownClass(cls): cls.temp.cleanup()
    def test_direct_cycle_no_global_rename(self):
        g=group(); changed,r=trial.reassign(g,CATALOG)
        self.assertIs(changed.labels,g.labels)
        expected=[probe.decode(x[0][1],x[0][2],CATALOG)[0] for x in g.items]
        actual=[probe.decode(x[0][1],x[0][2],CATALOG)[0] for x in changed.items]
        k=data.seed_for(20260910,g.uid,'style_cycle')%27+1
        self.assertEqual(actual,expected[k:]+expected[:k]);self.assertEqual(r['offset'],k)
        self.assertNotEqual(changed.items,probe.views(g,CATALOG)[0]['reassigned'].items)
        for old,new in zip(g.items,changed.items):
            for a,b in zip(old,new):
                self.assertEqual(a[0],b[0])
                fa,fb=probe.decode(a[1],a[2],CATALOG)[1],probe.decode(b[1],b[2],CATALOG)[1]
                self.assertEqual({k:v for k,v in fa.items() if k!='service'}, {k:v for k,v in fb.items() if k!='service'})
    def test_manipulation_joint_counts(self):
        g=group();changed,_=trial.reassign(g,CATALOG)
        result=trial.manipulation([g],[changed],CATALOG)
        for name,item in [('original',g),('reassigned',changed)]:
            expected=np.zeros((2,8),int)
            for y,c in zip(g.labels,codes(item)): expected[y,c]+=1
            np.testing.assert_array_equal(result['tables'][name][0],expected)
        np.testing.assert_array_equal(np.asarray(result['tables']['original']).sum(1),np.asarray(result['tables']['reassigned']).sum(1))
    def test_changed_edges_can_preserve_association_with_exact_20_positives(self):
        uid=next(f'toy_invariant_{i}' for i in range(200) if data.seed_for(20260910,f'toy_invariant_{i}','style_cycle')%27+1==14)
        comps=[(i,i+14) for i in range(8)]+[(8,9,10),(11,12,13),(22,23,24),(25,26,27)]
        owner={v:c for c,comp in enumerate(comps) for v in comp}
        labels=tuple(int(owner[i]==owner[j]) for i,j in zip(LEFT,RIGHT))
        self.assertEqual(sum(labels),20)
        g=group(uid,labels); changed,_=trial.reassign(g,CATALOG)
        self.assertTrue(np.any(codes(g)!=codes(changed)))
        tables=trial.manipulation([g],[changed],CATALOG)['tables']
        self.assertEqual(tables['original'],tables['reassigned'])
    def test_complete_label_alignment_and_toy_csv_single_parse(self):
        g=group();pairs=[{'group_uid':g.uid,'seller_uid_left':g.sellers[i],
              'seller_uid_right':g.sellers[j],'label':str(y)} for i,j,y in zip(LEFT,RIGHT,g.labels)]
        self.assertEqual(data.align_labels(g,list(reversed(pairs))),g.labels)
        with self.assertRaises(ValueError): data.align_labels(g,pairs[:-1]+[pairs[0]])
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);path=root/'train/supervision/pairs.csv';path.parent.mkdir(parents=True)
            with path.open('w',encoding='utf-8',newline='') as stream:
                writer=csv.DictWriter(stream,fieldnames=list(pairs[0]));writer.writeheader();writer.writerows(reversed(pairs))
            data.write_json(root/'manifest.json',{'files':{'train/supervision/pairs.csv':data.record(path,root)}})
            self.assertEqual(trial.attach_labels([data.Group(g.uid,g.sellers,g.items)],root,'train'),[g])
    def test_public_reader_toy_240_groups_without_supervision_or_test(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);ds=root/'toy_data';ds.mkdir();(ds/'sources').mkdir()
            (ds/'sources/step28_continual_catalog.json').write_bytes(probe.CATALOG.read_bytes())
            fields=list(self.fx.meta[0]);group_path=ds/'groups.csv'
            with group_path.open('w',encoding='utf-8',newline='') as stream:
                writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader();writer.writerows(self.fx.meta)
            recorded={'groups.csv':data.record(group_path,ds)}
            for split,groups in self.fx.groups.items():
                path=ds/split/'items.jsonl';path.parent.mkdir()
                with path.open('wb') as stream:
                    for g in groups:
                        for seller,items in zip(g.sellers,g.items):
                            for uid,t,d in items: stream.write(data.json_bytes({'group_uid':g.uid,'seller_uid':seller,'item_uid':uid,'title':t,'description':d}))
                recorded[f'{split}/items.jsonl']=data.record(path,ds)
            data.write_json(ds/'manifest.json',{'files':recorded});data.write_json(ds/'validation.json',{'toy':True})
            original={'config':{'data_root':'toy_data','data_manifest_sha256':data.sha256(ds/'manifest.json'),
                   'data_validation_sha256':data.sha256(ds/'validation.json')},
                   'evaluation_group_ids':{'development':[g.uid for g in self.fx.groups['development']]}}
            opened=[];real_open=Path.open
            def guard(p,*args,**kwargs):
                text=p.as_posix()
                if '/heldout/' in text or '/supervision/' in text or 'owners' in text: raise AssertionError('Forbidden payload')
                opened.append(text);return real_open(p,*args,**kwargs)
            with patch.object(data,'ROOT',root),patch.object(Path,'open',guard):
                groups,meta,checked=trial.public_inputs(original)
            self.assertEqual({k:len(v) for k,v in groups.items()},{'train':180,'development':60})
            self.assertEqual(len(meta),240);self.assertEqual(set(checked),{'groups.csv','train/items.jsonl','development/items.jsonl'})
            self.assertTrue(all(g.labels is None for gs in groups.values() for g in gs));self.assertTrue(opened)
    def test_schedule_validates_both_branches_and_rejects_seed_change(self):
        for log,old in zip(self.fx.record['orders'],self.fx.original['orders']):
            trial.validate_training(log,self.fx.meta,CONFIG,old)
            bad=copy.deepcopy(log);bad['training']['reassigned_stage3']['current_dropout_stream']+=1
            with self.assertRaises(ValueError):trial.validate_training(bad,self.fx.meta,CONFIG,old)
    def test_first_domain_sign_and_exclusion(self):
        arrays={}
        for order in probe.ORDERS:
            i='ABC'.index(order[0])
            for key in trial.POINTS:
                v=np.full((60,1),999.)
                v[i*20:(i+1)*20]=10 if key=='shared' else 13 if key.startswith('original') else 11
                arrays[(order,key)]=v
        result=trial.contrasts(arrays,0)
        np.testing.assert_array_equal(result['original_minus_reassigned_first_domain_change_stage3'],np.full((3,20),2))
        np.testing.assert_array_equal(result['reassigned_first_domain_change_stage3'],np.ones((3,20)))
    def test_retrieval_all_ten_columns_against_query_loop(self):
        g=group();rng=np.random.default_rng(5);s=rng.integers(-2,3,size=(3,378)).astype(float)
        actual=metrics.retrieval(np.tile(g.labels,(3,1)),s,28); expected=[]
        for scores in s:
            adj=np.full((28,28),-np.inf);rel=np.zeros((28,28),int)
            adj[LEFT,RIGHT]=adj[RIGHT,LEFT]=scores;rel[LEFT,RIGHT]=rel[RIGHT,LEFT]=g.labels
            queries=[]
            for i in range(28):
                ranked=sorted((j for j in range(28) if j!=i),key=lambda j:(-adj[i,j],j))
                ranks=[r+1 for r,j in enumerate(ranked) if rel[i,j]];n=len(ranks)
                ap=sum((j+1)/r for j,r in enumerate(ranks))/n
                recalls=[sum(r<=k for r in ranks)/n for k in (1,3,5,10)]
                ndcg=[sum(1/np.log2(r+1) for r in ranks if r<=k)/sum(1/np.log2(r+1) for r in range(1,min(n,k)+1)) for k in (1,3,5,10)]
                queries.append([ap,1/min(ranks),*recalls,*ndcg])
            expected.append(np.mean(queries,0))
        np.testing.assert_allclose(actual,expected,rtol=0,atol=1e-15)
    def test_real_complete_gate_accepts_complete_toy_payload(self):
        self.fx.write(self.fx.record);scores,record=self.fx.gate();self.assertEqual(len(scores),15)
        self.assertEqual(record['manipulation'],self.fx.manipulation)
    def test_real_evaluator_900_ap_all_22_columns_transitions_and_bootstrap(self):
        from sklearn.metrics import average_precision_score
        self.fx.write(self.fx.record)
        outcome=self.fx.evaluate(self.fx.root/'reports/baseline_evaluation')
        self.assertNotIn('exception',outcome);self.assertEqual(outcome['toy_valid_attach_calls'],1)
        r=outcome['result'];self.assertEqual(len(r['columns']),22);self.assertEqual(len(r['points']),15)
        ref={}
        for key,scores in self.fx.scores.items():
            arr=np.load(self.fx.root/'reports/baseline_evaluation'/r['points']['_'.join(key)]['file']['path'])
            ap=np.asarray([average_precision_score(LABELS,row) for row in scores])
            np.testing.assert_allclose(arr[:,0],ap,rtol=0,atol=1e-15);self.assertEqual(arr.shape,(60,22));ref[key]=ap
        delta=np.stack([(ref[(o,'original_stage3')]-ref[(o,'reassigned_stage3')])['ABC'.index(o[0])*20:('ABC'.index(o[0])+1)*20] for o in probe.ORDERS])
        rng=np.random.default_rng(20260910);draws=rng.integers(0,20,size=(5000,3,20))
        boot=np.array([sum(np.mean(delta[j,draws[k,j]]) for j in range(3))/3 for k in range(5000)])
        got=r['contrasts']['average_precision']['original_minus_reassigned_first_domain_change_stage3']
        self.assertAlmostEqual(got['mean'],float(delta.mean()),places=15)
        np.testing.assert_allclose(got['conditional_95pct_interval'],np.quantile(boot,[.025,.975]),rtol=0,atol=1e-15)
        for order in probe.ORDERS:
            for branch in trial.BRANCHES:
                for stage in (2,3):
                    before='shared' if stage==2 else f'{branch}_stage2'
                    d=order[stage-1];i='ABC'.index(d)
                    want=float((ref[(order,f'{branch}_stage{stage}')]-ref[(order,before)])[20*i:20*(i+1)].mean())
                    tr=r['transitions'][f'{order}_{branch}_stage{stage}']
                    self.assertEqual(tr['trained_domain'],d)
                    self.assertAlmostEqual(tr['by_domain_change'][d]['average_precision'],want,places=15)

def demonstrate_gate_defect():
    with tempfile.TemporaryDirectory(prefix='cause_train_gate_counterexample_') as tmp:
        fx=GateFixture(Path(tmp));baseline=copy.deepcopy(fx.record)
        report={}
        for kind in ('missing','null','shortened_tables'):
            bad=copy.deepcopy(baseline)
            if kind=='missing': del bad['manipulation']
            elif kind=='null': bad['manipulation']=None
            else:
                bad['manipulation']['group_uids']=bad['manipulation']['group_uids'][:1]
                for k in bad['manipulation']['tables']: bad['manipulation']['tables'][k]=bad['manipulation']['tables'][k][:1]
            fx.write(bad)
            try:
                scores,record=fx.gate()
                report[kind]={'real_complete_gate_accepted':True,'score_arrays':len(scores)}
            except Exception as exc:
                report[kind]={'real_complete_gate_accepted':False,'exception':str(exc)}
            if kind in ('missing','null'):
                observed=fx.evaluate(fx.root/f'reports/evaluate_{kind}')
                if 'result' in observed:
                    report[kind].update(status=observed['result']['status'],
                                       train_manipulation=observed['result']['train_manipulation'],
                                       toy_valid_attach_calls=observed['toy_valid_attach_calls'])
                else: report[kind].update(observed)
        return report

if __name__=='__main__':
    import sklearn
    print('ENVIRONMENT',json.dumps({'platform':platform.platform(),'python':platform.python_version(),
          'numpy':np.__version__,'sklearn':sklearn.__version__,
          'project_supervision_parses':0,'remote_linux_connected':False,'gpu_training':False},ensure_ascii=False),flush=True)
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(SyntheticChecks)
    result=unittest.TextTestRunner(stream=sys.stdout,verbosity=2).run(suite)
    print('SYNTHETIC_TEST_SUMMARY',json.dumps({'run':result.testsRun,'failures':len(result.failures),
         'errors':len(result.errors),'skipped':len(result.skipped)}),flush=True)
    if result.wasSuccessful():
        defects=demonstrate_gate_defect()
        print('COUNTEREXAMPLES',json.dumps(defects,ensure_ascii=False,indent=2),flush=True)
        (HERE/'counterexamples.json').write_text(json.dumps(defects,ensure_ascii=False,indent=2)+'\n')
    else: sys.exit(1)
