# 附件独立审查：虚构数据复核包

复核对象是本轮十个附件，原始合计 145,063 字节。`inventory_and_scope.json` 列明独立复算的完整 SHA-256。

## 运行

保持解压目录结构，从有 NumPy 和 scikit-learn 的 Python 环境运行：

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 python -B cause_train_review/review_checks.py
```

Windows 可直接执行末尾的 `python -B ...` 命令。测试不需要 PyTorch、LaBSE 或 GPU，不连接任何远程机器。输出中的 `toy_valid_attach_calls` 是被替换为虚构群供数的函数调用次数，不是实际项目 valid CSV 解析次数。

## 数据与实测范围

`project/scripts` 的六份生产 Python 和 `project/tests` 的一份上传测试均为本轮附件原字节副本；`project/schema/step28_continual_cause_train_policy.json` 也是附件原字节副本。仅为恢复导入名去掉上传名中的 `(2)` / `(3)`。

**`project/schema/step28_continual_catalog.json` 是审查者编写的虚构目录，绝非项目原目录。`project/schema/step28_continual_population_policy.json` 是把附件中的 original_config 重新序列化后用于虚构测试的辅助文件，其字节与未上传的原政策不相同。** 旧运行清单、模型回执、分数、群、标签和训练日志也全部是明确的虚构夹具，不能作为真实训练、原状态重建或完整真实数据 reader 核验的证据。

未执行上传的原 11 项测试套件；其 fixture 模块、原目录、旧运行清单及真实公开供数不齐。执行的是 `review_checks.py` 定义的 10 项独立合成测试：10 通过，0 失败，0 错误，0 跳过。环境为审查沙箱 Linux / Python 3.13.5 / NumPy 2.3.5 / scikit-learn 1.8.0。无实际项目监督解析、无 GPU 训练、无用户 Linux 连接。

## 已复现的同一门缺陷的三个表现

`validated_scores`、`validate_training`、`same_original_point` 均运行其原始函数本体；没有 mock 完整门。评价调用时，只替换不可获得的原项目读取、来源清单和 valid 供数为明示虚构夹具。

1. 从其他完整的虚构 manifest 删除 `manipulation`：实际完整门仍放行 15 份分数；评价调用一次虚构 valid 供数后，最终出现 `KeyError('manipulation')`。
2. 把 `manipulation` 设为 `null`：门仍放行；评价完成，结果中的 `train_manipulation` 为 null，虚构 valid 供数调用 1 次。
3. 把操纵表与群 ID 列表缩成 1 群：门仍放行 15 份分数。

这不表示正常 run 会自行漏写操纵表；生产 run 确实生成并保存此表。缺陷是 complete gate 没有核验其明确需要的操纵证据，导致不完整结果能够先进入 valid 解析。

最小修复是仅在既有 complete gate 内、valid 解析前，核对操纵对象、180 个群 ID 的顺序、八模式顺序、两份非负整数 (180,2,8) 计数、每群类计数 [358,20] 与两支全边模式边际；可用现有公开视图重算无标签模式边际。不需要新增监督读取、模型、种子、GPU 步数或全套旧核心回归。

完整实际输出见 `review_checks.log`，结构化反例见 `counterexamples.json`。
