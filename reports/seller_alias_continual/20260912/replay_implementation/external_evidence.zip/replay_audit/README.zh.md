# 本次外审证据

本目录记录2026-09-12对用户提供的replay_review.zip的审查。没有读取正式监督、加载LaBSE或执行正式Linux训练。review.zh.md是审查正文；review_scope_and_disposition.json给出审读与执行边界。证据只覆盖当前提交文件，不能替代生产执行回执。

Torch单独执行的结果：torch_contracts.log / torch_contracts_result.json。
20个独立本地用例的结果：local_contracts.log / local_contracts_result.json。集合包含同一个Torch用例，不能将两次运行相加为21个独立测试。

原始zip与58份文件核验：manifest_verification.json。
审查后复核、ZIP CRC及共存量估算：final_integrity_and_scope.json。
AST、Bash语法、历史NPY/来源及保存矩阵算术核验：static_and_history_checks.json。
CLI只执行了帮助：cli_help.txt。

在原项目目录复现指定CPU张量用例的命令：

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=scripts:tests python -B -m unittest -v \
  test_step28_continual_replay_contracts.TorchContracts
```

本次20个用例集合等于新replay完整模块11个用例，加旧expression模块除 `test_real_public_inputs_read_no_supervision_or_heldout` 外的9个用例。没有运行缺席的原population MetricContracts。附包原“28通过、1跳过”是历史本地记录，不是本外审的实跑计数。

报告中的R1是非阻断的资源记录范围缺口，不是已经发生超预算的证据。最终资源报告须区分run目录观测峰值、整个作业目录最终占用和完整进程历时。所有历史数值复核均只使用保存指标，未重评旧标签。
