# 随机完整群ER方案与实现外审

审查日期：2026-09-12。对象：用户本轮提交的 `replay_review.zip`。本结论适用固定expression合成场景、随机完整群ER基线和本次冻结路径，不适用于真实中文暗网效果、同一控制者跨阶段的新马甲追踪、自有关系选择算法、创新或论文录用。

## 结论

**具备转入“等待用户明确恢复的Linux阶段”的条件。未发现科研阻断项；发现一项非阻断的资源记录口径缺口。** 它影响资源报告的覆盖范围，不影响本次目标函数、H/N/G、配对日程或监督边界；不需要改动数据、种子、系数、阈值，不要求新增LaBSE smoke或正式更新。

本审查没有连接项目Linux、启动正式训练、解析正式train/valid监督或读取test/owners。用户批准配置和本轮外审均不等于恢复Linux启动。正式运行结果尚不存在；不能给出随机ER有效或无效的判断。

## 1. 附件实际完整性与审读范围

| 核验项 | 实际结果 |
|---|---|
| ZIP大小 | 443486字节，与提交声明一致 |
| ZIP SHA256 | `beccdf85d9bf9b2d091d326bb24fac1d8fabeafe42efa3c9a25ff6082a5a9aac`，一致 |
| ZIP成员 | 59：58份清单文件与根目录manifest.json |
| 58份清单文件大小与SHA256 | 全部匹配，无额外归档成员 |
| 清单正文合计 | 1158931字节 |
| 根manifest | 11943字节；不在58份正文合计之内 |
| 解压总字节 | 1170874字节，含根manifest |
| ZIP CRC | 全部通过 |
| 原八份来源 | 与原expression执行manifest中的source_files逐项精确一致 |
| 原运行与评价哈希 | 与新政策所固定的两个SHA256一致 |
| 审查结束后复核 | 58份文件仍全部匹配；未改动提交文件 |

manifest和历史文档中的“未建包/待切换账号/尚未发送”属于制包前记录；实际ZIP和当前用户消息已更新提交状态。它们不构成研究配置漂移，也不应要求再次换账号。

全文审读了新runner、新政策、新测试、新Bash入口，以及原八份冻结依赖。相关批准计划、ER实现说明、第二路接口说明、并行计划、联合结果、表达数据说明、送审请求和四份相关历史外审正文作了全文审读。较长的AGENTS、研究纪律、交接总档及已关闭旧分支背景文件作完整性核验和相关上下文查阅，**不把这些背景文档的全文语义审读也计入已完成范围**。所有16个JSON作了解码，16个NPY作了完整数组读取、形状/类型/有限性核验；这不等于对每个历史指标重新评价。

完整来源简称：

- R：`scripts/step28_continual_replay.py`；T：`tests/test_step28_continual_replay_contracts.py`；S：`scripts/run_step28_replay_linux_20260912.sh`。
- E：`scripts/step28_continual_expression_run.py`；C：`scripts/step28_continual_population.py`；D：`scripts/step28_continual_population_data.py`；P：`scripts/step28_continual_population_run.py`。
- 原其余依赖为expression政策、population评价模块、expression合同测试、原expression Bash。文末列出12份来源的实际SHA256。

没有取得正式原文数据、二值监督CSV、owners、LaBSE权重、原训练checkpoint或原60×378分数文件，因而没有在本环境执行真实origin全链、首域重建或真实评分。附件所含的是保存指标及历史执行/评价证据；无需补交被排除的正式材料。

## 2. 实际执行：真实CPU张量通过，但不是LaBSE通过

环境：Linux 6.18.35 x86_64 / glibc 2.41，Python 3.13.5，Torch 2.10.0+cpu；无CUDA构建，CUDA不可用；Torch计算线程为1。历史生产manifest记录的是Python 3.10.19、Torch 2.9.1+cu130、CUDA 13.0、RTX 5090，不是本次实跑环境。

| 执行项目 | 实际结果 | 证据性质 |
|---|---|---|
| 指定TorchContracts单独执行 | 1通过、0失败、0错误、0跳过；0.788525秒 | 真CPU张量、真autograd、真AdamW、真磁盘状态保存恢复 |
| 新replay完整合同集 | 11个用例全部通过 | 10个非正式夹具合同用例及上述Torch用例 |
| 附件内可运行的旧expression合同用例 | 9个全部通过 | 手工数据/模拟与实际指标计算混合，不是正式数据重跑 |
| 上述两个集合合并运行 | 20个独立用例全部通过、0跳过；7.518991秒 | Torch也在集合中，不能把单独执行再加成21个用例 |
| 8个Python源文件AST解析 | 通过 | 仅语法/静态证据 |
| 2个Bash入口`bash -n` | 通过 | 未执行训练Bash |
| 新CLI `--help` | 通过 | 不调用train/evaluate |
| 16个历史NPY | 均为60×22、float64、全有限 | 保存指标读取，不是重新算旧标签指标 |

未执行旧expression的 `test_real_public_inputs_read_no_supervision_or_heldout`：所需正式公开输入未随包提供。它被明确排除，没有冒计为通过或skip。原population的8个MetricContracts测试源文件没有随包提供，因此本次没有重跑这些用例。附件报告的“28通过、1跳过”作为此前本地记录保留；本审查自己的可复核结论是上述20个独立用例通过。

T:293–335的Torch用例实际使用小线性编码器、dropout和成对头，替换core.logits，构造4个账号/6条边的小张量。两次逻辑更新中：

1. observed_update与不变core.update的模型state digest和Adam state digest分别精确相等。
2. 独立构造两项mean BCE、将损失相加后一次backward的参考路径，参数逐项满足 `rtol=1e-6, atol=1e-7`。
3. 第一次更新后实际保存完整状态，创建新优化器并恢复，再执行第二次更新；Adam步数继续而非归零。

**独立loss和参考路径的断言是参数近似相等，不是独立路径的整个Adam逐字节相等。** 精确模型/Adam比较发生在observed_update与旧core.update之间。测试中也未覆盖LaBSE tokenization、原商品重数池化、BF16、CUDA或实际activation checkpointing；不能将“真实张量通过”扩张成“真实LaBSE ER已经通过”。框架本身也不保证跨版本、跨平台或CPU/GPU之间的精确复现。

Windows评价相关用例是在Linux上将platform.system模拟成Windows运行，用的是临时手工监督；不是原生Windows正式评价。本次正式监督解析次数为0、正式LaBSE更新次数为0。

## 3. 首域重建、Adam连续性和实际工作量

### 3.1 状态链不是“推理权重＋空Adam”

R:281–311先加载同一原初始化，核对包含原metadata的初始化完整摘要，再创建AdamW并调用不变E.train_segment训练180步。R:224–229在首域后检查模型摘要、包含Adam的状态摘要以及完整60×378分数逐元素精确一致。随后实际删除当前优化器、重新创建优化器，并从刚保存的完整checkpoint执行core.restore_state。

这里重新创建优化器是为了验证完整状态恢复，不是以空Adam续训。若仅恢复推理权重，完整摘要/步数检查不能通过。第二阶段开始的真实Adam步应为181；第三阶段应为361。第二阶段point也实际保存、恢复完整模型和Adam，不能只靠manifest中的标志。

原config继续写入checkpoint metadata是为了匹配历史摘要；本轮执行预算使用单独的新合同Budget(out,c)，不能把旧config里的2160更新或历史预算误认为本轮运行预算。

### 3.2 当前日程与普通续训配对

E:139–159与R:188–199采用同一初始种子20260909、同一order/stage/current分流、每轮排序后shuffle，以及同一逐步dropout_current种子。额外历史分支使用自己的dropout_replay流。数据生成/统计bootstrap的20260910与初始化20260909职责不同，没有换种子。

普通续训与ER后续参数不应相等；需要相等的是首域完整起点，以及随后配对的当前数据/随机日程。R:413–422还在结果门中独立重算当前日程，首域日志除耗时外逐项对原运行核验。

### 3.3 数量落实在循环和文件生命周期里

| 项目 | 实现对应数量 |
|---|---:|
| 首域重建 | 3×180＝540个正式更新 |
| 有历史ER | 3×2×180＝1080个正式更新 |
| 合计 | 1620，不另跑普通续训，不另跑联合训练 |
| 新评分点 | 3个shared＋6个ER阶段点＝9 |
| 每点评分 | 完整60个valid群，保存前/实际重载后各一遍 |
| 评分群前向 | 9×60×2＝1080；不是新增1080个独立群 |
| 最终模型 | 每顺序最终推理模型1个，共3个 |
| 历史缓存快照 | 每顺序首域后、第二域后各1份，共6份 |
| 当前边呈现 | 1620×378＝612360 |
| 历史边呈现 | 1080×378＝408240 |
| 合计边呈现 | 1020600 |

R:291–335与P:77–127构成实际保存/恢复/双遍评分链；不是仅声明九个manifest名称。未保存第二阶段大模型作为永久结果，临时完整状态在验证后删除；第三域不再装入无用途缓存。以上是代码/夹具支持的编排结论，尚不是1620次生产更新已经完成的证据。

## 4. Algorithm R、全历史包字节与磁盘供数

D:211–233实现Algorithm R：前六个直接填槽；之后对已见群数seen均匀取整数，落入六个槽位才替换。R:72–77每个当前域取60个不同群并排序；R:312–318在阶段结束逐群装入一次，不按epoch重复装入。

第一批装完seen＝60，第二批装完seen＝120。reservoir RNG连续继承，不为第二批重新初始化。均匀reservoir不保证每个域都有代表；“强制每域分配缓存名额”会改变批准的随机ER，不能作为本轮修复。

### 4.1 计量不是只计Memory正文

R:89–107的外层包包含Memory完整内容、文字、账号/商品/群索引、完整边标签、seen、reservoir RNG、order、下一stage、更新index和replay RNG。D.Memory和外层ReplayState均按实际UTF-8序列化字节检查容量；超限抛异常，不删群凑预算、不截正文。

R:313–316逐次检查装入时的中间reservoir，R:111–116每次抽样更新后又检查包含变化中RNG/index的全包，因此并非只验阶段最终六群。`maximum_history_bytes`记录的是该ER训练阶段开始及抽样期间的最大值；装入过程也做了上限检查，但没有把那些值并入此字段。结果中不得把该字段称为“所有装入与训练中间状态的已记录全生命周期最大值”。这是字段解释边界，不是发现容量检查缺失。

本合同限制的是一条学习路径可用的历史序列化状态，不是Python进程全部RAM，也不是六个归档审计快照合计只能占1MiB。归档快照和训练轨迹不得反过来供数；其磁盘量归新增运行载荷统计。

### 4.2 真正使用磁盘恢复对象

R:120–137实际写盘、read_bytes、ReplayState.from_bytes并逐字节roundtrip，返回restored对象。R:317–318把该返回对象赋给state并将memory重新绑定到state.memory；下一阶段train_replay再由这个state.draw取完整Group。不是“恢复一次作展示，然后仍训练旧对象”。

非正式测试验证磁盘返回对象、下一抽样一致性，以及步索引73等中途状态恢复后的下一抽样。生产路径只保存两个阶段边界快照，不支持自动中途恢复整个失败训练；恢复抽样状态的正确性不应写成生产故障续训功能。

### 4.3 没有历史ID回查通路

正式train标签在离线装配层一次解析，训练函数只接当前60群及自己的ReplayState。R:182–221的历史数据直接来自缓存Group，不把日志中的UID拿回全历史字典检索，不读取归档快照或另一顺序作为供数。数据模块中存在的旧Archive/heldout入口不在本轮run路径被调用。

Windows的R:357–377只用公开ID独立重建Algorithm R成员和180次抽样轨迹；R:452–458对缓存只执行字节数/SHA256核验。测试故意把缓存设置成不可解析的非JSON字节仍能通过这一哈希路径，直接检验了“Windows不为核验缓存而解析train标签”的边界。完整正文/标签roundtrip证据来自Linux，不应伪称Windows又独立审了一遍缓存标签。

## 5. observed_update与两项损失和

实际目标是

`L = (1/378) Σ BCE(current) + (1/378) Σ BCE(history)`。

C:113–140与R:147–179都只zero_grad一次，分别对两支mean BCE反传，然后对累积梯度统一裁剪、AdamW.step一次。没有额外优化步，没有把756条边整体平均，也没有再除以2。这个目标的未裁剪梯度是两项梯度相加；不能以Adam的某些缩放近似不变性替代精确目标合同。

R.observed_update只在每个ER段首个正式更新替代core.update，共六个正式ER首更新；它本身不是额外增加的一步。hook注册在每支backward期间，返回None并在finally移除；计算detach后的平方和不写回梯度。它额外做的是观察/摘要与同步，不增加LaBSE前后向或optimizer.step。该使用方式符合PyTorch Tensor.register_hook的返回语义。

分支记录严格为各hook调用事件梯度的平方范数之和。若某参数产生多个事件，Σ||g_e||²一般不等于||Σg_e||²；不同分支还可能相互抵消。故这些量支持“该支确实传到编码器/头且有限非零”，不能解释为最终累积梯度范数、历史贡献百分比、样本选择贡献或纯风格因果机制。`gradient_norm_before_clip`才是另行记录的统一裁剪前总梯度量。

真实CPU用例已经补足了当前包原本缺失的真实小张量一致性证据。但正式Linux仍必须在正式监督读取前运行同一TorchContracts并得到1通过、0跳过；之后每段真实LaBSE首更新证据、全Adam和全分数恢复也仍须通过。这些属于已有生产门，不新增例行GPU smoke。

## 6. H/N/G、同顺序要求、完整门与22指标

R:466–509按底层域取固定20群。

- H：ER最终首域AP减普通续训最终首域AP。由于shared精确一致，也等于F_SEQ−F_ER，但最终绝对能力仍单列。
- N：六次新域刚学完时ER减普通续训的绝对AP，不是两方法增益之差。
- G：每种方法自己的after−before；第三阶段使用各自第二阶段起点。

一个说明N不能由增益差代替的算术反例：ER由0.10到0.30、普通续训由0.50到0.60，增益差为+0.10，但刚学完绝对差为−0.30。这里是定义检验，不是新实验结果。

同顺序门在R:518–524逐顺序同时要求 `H_o>0` 与 `mean(G_ER_stage2,G_ER_stage3)>=.02`，再数是否至少两个。不能把ABC/BCA的H通过和BCA/CAB的G通过拼成“至少两个”；交集只有BCA。其余两个门也准确保留：H均值>=.01且95%条件区间下界>0；N的95%条件区间下界>=−.01。

R:551一次生成5000×3×20索引，seed20260910。同一底层域的群索引复用于所有方法、时间、顺序和指标。每个域在六转移中重复出现两次，R:508先把同域的两条逐群对比平均，再以该域20个群为单位bootstrap；没有伪装成40个独立群。现有用例与显式5000次循环参考一致。

AP为主要端点。MAP及另外指标完整输出，但不替换AP门，也没有私自增加新的MAP数值门。R:539–549输出9点评分对应的22列逐群矩阵、各域均值和混淆计数；R:510–517保留共同初始化、shared、每顺序/域最终绝对能力及总体平均，contrast还含H/N/G/F和第二域最终变化。旧方法矩阵从固定评价文件加载，只复用、不解析旧标签重评；新三个shared矩阵必须np.array_equal旧22指标。

完整门在valid解析之前执行：原来源/运行/评价/预训练映射、1620更新、9点、3个最终模型及Linux哈希回执、6个缓存及成员/下一抽样/全轨迹、起点、步数、当前日程、ER分支、分数文件实际哈希/形状/有限性、shared完整状态与分数、预算记录均检查。不能由一个COMPLETE字符串代替；failure.json会拒绝评价。Windows只在门通过后调用一次development attach_labels。

新输出中的旧方法完整混淆计数来自被政策固定的原evaluation.json，新JSON并未再复制全部旧计数。形成最终报告时可以联合这两个固定文件展示，不能为补表重新解析旧标签。

本审查只从附件保存矩阵复核旧对比算术：原首域平均遗忘0.058931997672200524、条件区间[0.035618890616752864,0.08315973181613398]，以及原整体资格失败等均吻合。这不产生本轮ER结果。原三轮FAILED保留；六轮联合经验兼顾的诊断不改写原记录，也不证明ER必然受益。

## 7. 资源、输出共存量与唯一非阻断缺口

R:234–260要求Linux、恰好一张可见CUDA卡、BF16支持、至少24GiB空闲显存、16GiB可用主存和16GiB磁盘空间，并限制Torch计算线程。S设置数值库线程、tokenizer并行/offline变量与3小时timeout。GPU是否真正空闲仍需要用户恢复阶段中的实查；仅空闲显存条件不能替代空闲设备核验。本次没有执行该检查或选择设备。

16GiB是本轮新增运行载荷上限，不是显存上限。Budget使用新合同；不沿用旧运行的更大预算。

大文件生命周期已落实：每次写大状态前预留，真实保存/恢复，最终推理模型与完整Adam checkpoint同时存在时R:322强制盘点，之后才删除本轮临时checkpoint。按附件原manifest记录的最大文件大小估算，三个推理文件与一个完整状态共11316967009字节，即约11.317GB/10.540GiB，另加评分、缓存和回执。这个数字是历史文件规格下的共存估计，**不是本轮实际峰值**；也不是11.32GiB。

55—75分钟训练、75—110分钟完整运行是已批准计划的先验估计。当前CPU测试不能验证这些估计；正式训练时间可由九段training_seconds合计，完整历时和退出状态应由Bash外围记录提供，不能拿前者替代后者。

### REPRODUCIBILITY_DEFECT R1：资源记录覆盖范围有限，非科研阻断

位置：P:38–60，R:249、336–353，S:20–28。

Budget.root为`$out/run`，但Bash的train.log、resource_usage.log、时间戳和退出状态位于父目录`$out`。此外r.budget在最终manifest和model_verification写入之前取样。因此该字段不能独立证明整个Bash作业目录及所有收尾文件的完整占用，也不是整个外层进程历时。

最小反例是计量关系：`bytes(run)<=cap`并不推出`bytes(run)+bytes(外围日志)<=cap`；最后一次快照之后写的文件也不在该快照中。这是由代码范围直接得出的反例，不是声称本次真实运行已经超预算。

受影响的是“全作业新增载荷/完整耗时已由该字段全面核验”的资源复现声明，不是ER训练正确性、1MiB活跃历史状态上限或H/N/G。大权重共存检查确实存在；已有说明也谨慎称其为观测峰值，因此严重度低，不作为启动阻断。

最小处理：最终结果资源表单列Budget覆盖范围、外层日志及收尾文件字节、作业目录最终实际总量，并用外层time/时间戳/exit_status报告完整历时。保留原大状态共存记录；不要将“最终目录大小”也冒称瞬时峰值。不要求另造资源监控系统、不要求改动原八份来源或研究合同，不增加正式更新。

## 8. 问题分级与不应追加的工作

| 分类 | 本轮结论 | 受影响主张与处理 |
|---|---|---|
| SCIENTIFIC_BLOCKER | 未发现 | 目标、历史供数、起点配对、端点与同顺序bootstrap未发现需阻止该配置实验的问题 |
| REPRODUCIBILITY_DEFECT | R1一项、非阻断 | 仅资源记录范围；按第7节补足最终报告口径 |
| OUT_OF_SCOPE_OVERDESIGN | 不追加 | 不为本轮要求新数据、换种子、改系数/阈值、强制域均衡缓存、稀疏关系选择器、例行GPU smoke、重跑闭环联合、全局一次性访问安全账本或跨环境逐位一致保证 |

未做的真实LaBSE实验不是已经发现的代码失败；历史正确性证据也不是新runner生产通过。对不能由本包验证的事项保留状态“待正式运行门验证”，既不伪称通过，也不把它们转化为额外研究分支。

## 9. 生产阶段仍须给出的证据

这不是新增审批清单，而是本次已有合同在真实环境中的验收：

1. 在用户单独恢复后才连接、同步、核验来源与空闲资源；正式监督前TorchContracts必须1通过、0跳过。正式train解析一次，valid/test/owners在Linux不解析。
2. 每顺序初始化及首域模型/完整Adam/全部盲分数精确匹配原shared；真实step181/361连续；六段ER首更新两支均传到encoder/head；真实缓存尺寸、保存恢复、成员/抽样及阶段冻结符合记录。
3. 1620实际更新、9点评分双遍一致、3个最终推理模型实际重载、6个缓存快照和文件哈希齐全；完整结果门通过，退出状态和资源实际记录可核验。不能把模拟或本次CPU夹具挪用作这些证据。
4. Windows完整门后仅一次valid解析，三shared的22列精确匹配旧矩阵；报告H/N/G、条件区间、同顺序交集、MAP、22指标、混淆与绝对能力。没有test/owners评价，也没有旧顺序重评。

旧文本/仅品类变化实验的有效负结果不撤销；固定表达变化场景中的共享表达贡献不能升格为唯一原因或纯风格因果结论。六轮联合只是离线经验兼顾参照，不证明收敛、唯一机制或有限记忆收益。随机ER即使通过本次门，也只支持当前固定场景和路径下的开发性保持—学习收益，不支持等计算优势、自有算法新颖性、真实市场效果或论文录用。

**最终判定：准备条件成立；正式Linux启动许可仍未恢复。本次到此为实现审查结论，不是实验有效性结论。**

## 10. 证据文件与框架语义参考

同目录日志/JSON：manifest_verification.json、final_integrity_and_scope.json、torch_contracts.log、torch_contracts_result.json、local_contracts.log、local_contracts_result.json、static_and_history_checks.json、cli_help.txt。所有时间均为本审查实际夹具执行时间，不是生产耗时。历史AP复核使用保存指标和原汇总函数，未读取原标签或重新评分。

框架语义参考是PyTorch官方2.9文档的Tensor.register_hook和Reproducibility说明；只用于hook返回语义及跨环境复现限制，不用于证明本项目实验结果。地址：

`https://docs.pytorch.org/docs/2.9/generated/torch.Tensor.register_hook.html`

`https://docs.pytorch.org/docs/2.9/notes/randomness.html`

### 12份全文审读的生产来源及实际SHA256

- `scripts/step28_continual_expression_run.py`

  `3df878e3d78c07444cc0400b574adaf3a495b74fe193a14853706c7e9f67a760`

- `schema/step28_continual_expression_run_policy.json`

  `8b5b37089e2cbcff41a1950c6313344ff5ade627ff9371682294f4bfae8c7ccc`

- `scripts/step28_continual_population.py`

  `f8f158fff648990ae575228d1b8dc112ac8c515ec5d6acc23a598120d770db20`

- `scripts/step28_continual_population_data.py`

  `49cca1268b57422a46deefa8bc360423ccaeb8b5062750a39b540f0fb400e08d`

- `scripts/step28_continual_population_evaluate.py`

  `398825da73b25b3d06420d7a75428451f38ff97f1239af02120d4921c70bca4a`

- `scripts/step28_continual_population_run.py`

  `f0da5d51bb1291abe3417e5d695d8fc9134522d9fc7ced536417f4e484ab25e4`

- `tests/test_step28_continual_expression_run_contracts.py`

  `f504a95e23c0628a3efe34274f9dba879f135bf6c9043c0dbadcc7b51352de1a`

- `scripts/run_step28_expression_linux_20260910.sh`

  `81f560597f517bf4b71f5c07e041518b0c9de1250787e85268ffbd1a36b7395e`

- `scripts/step28_continual_replay.py`

  `52a636f7db653bc17c3de55db489d411cc002ed329e8a39f413cf4425885e2cb`

- `schema/step28_continual_replay_policy.json`

  `f40da291139388d82229519fc7d340c50ad691ab24a02cc6a6887a56684767bd`

- `tests/test_step28_continual_replay_contracts.py`

  `21dd89d84e7ffd3f011210933d449acfb03c825886d110f139a9816b67234289`

- `scripts/run_step28_replay_linux_20260912.sh`

  `42746db3388b985de8a1a8e5ef1f2ebe1ea61738fa8bc30976986b8a4156c87d`

