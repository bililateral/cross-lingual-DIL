"""One unchanged S trajectory, restored local interventions, then one valid opening."""
from __future__ import annotations

import argparse
from collections import defaultdict
import csv
import os
from pathlib import Path
import random
import shutil
import signal
import threading
import traceback
from typing import Any

import numpy as np

import step28_retention_diagnostic as method
import step28_record_replay_run as previous_run
import step28_retention_diagnostic_evaluate as evaluation

record, diag = method.record, method.diagnostics
data, parent, core, base = method.data, method.parent, method.core, method.base
previous = previous_run.previous


class Budget(previous_run.Budget):
    def __init__(self, root: Path):
        super().__init__(root)
        self.limits = method.policy()["runtime"]
        self.forward_groups = self.physical_updates = self.gradient_groups = 0

    def forward(self, count: int) -> None:
        self.forward_groups += count
        if self.forward_groups > 6500:
            raise ValueError("Approved no-gradient forward count exceeded")
        self.check()

    def updated(self, groups: int) -> None:
        self.physical_updates += 1
        self.gradient_groups += groups
        if self.physical_updates > 672 or self.gradient_groups > 1056:
            raise ValueError("Approved update scope exceeded")
        self.check()

    def snapshot(self) -> dict:
        return {**super().snapshot(), "forward_groups": getattr(self, "forward_groups", 0),
                "physical_updates": getattr(self, "physical_updates", 0),
                "gradient_groups": getattr(self, "gradient_groups", 0)}


def parse_selected(job: Path, groups: list, c: dict, split: str) -> list:
    """One attempted scan of the combined file, aligning only preselected AB groups."""
    if split not in ("train", "development") or len(groups) != (120 if split == "train" else 40):
        raise ValueError("Only the approved AB population may be aligned")
    ledger = data.read_json(job / "access.json")
    key = "train" if split == "train" else "valid"
    if ledger[key] != 0:
        raise ValueError("Supervision parse already attempted; no retry")
    if split == "development" and not (job / "before_valid.json").is_file():
        raise ValueError("Complete blind gate required before valid parsing")
    ledger[key] = 1
    data.write_json(job / "access.json", ledger)
    root = data.ROOT / c["data_root"]
    name = f"{split}/supervision/pairs.csv"
    metadata = data.read_json(root / "manifest.json")
    allowed = {g.uid for g in groups}
    if len(allowed) != len(groups):
        raise ValueError("Repeated supervision population")
    rows = defaultdict(list)
    with data.verify(root / name, metadata["files"][name]).open(encoding="utf-8", newline="") as stream:
        reader = csv.DictReader(stream)
        if reader.fieldnames != ["group_uid", "seller_uid_left", "seller_uid_right", "label"]:
            raise ValueError("Binary supervision schema differs")
        for row in reader:
            if row["group_uid"] in allowed:
                rows[row["group_uid"]].append(row)
    if set(rows) != allowed:
        raise ValueError("Selected supervision coverage differs")
    result = []
    for g in groups:
        labels = data.align_labels(g, rows[g.uid])
        if sum(labels) != 20:
            raise ValueError("Expected 20 positive account pairs")
        result.append(data.Group(g.uid, g.sellers, g.items, labels))
    return result


def save_scores(root: Path, tag: str, model: Any, groups: list, c: dict, budget: Budget) -> dict:
    budget.forward(len(groups))
    with diag.neutral(model):
        values = diag.score(model, groups, c, "S", budget.check)
    return previous.save_array(root / "scores" / (tag + ".npy"), values, root)


def cache_output(root: Path, tag: str, model: Any, memory: Any, c: dict,
                 budget: Budget) -> dict:
    import torch
    groups = [] if memory is None else sorted(memory.reservoir.groups, key=lambda g: g.uid)
    scores, errors = [], []
    with diag.neutral(model):
        for group in groups:
            budget.forward(1)
            live = record.reference(model, group, c, budget.check)
            target = memory.tables[group.uid]
            table, reference = torch.from_numpy(live), torch.from_numpy(target)
            a0 = record.assignment(group)
            seed = data.seed_for(20261008, "ABC", 2, group.uid, "diagnostic_regroup")
            a1 = record.assignment(group, seed)
            score = record.account_logits(table, a0)
            e0 = (score-record.account_logits(reference, a0)).double().numpy()
            e1 = (record.account_logits(table, a1)-record.account_logits(reference, a1)).double().numpy()
            coarse = record.account_logits(method.project_means(table-reference, a0), a1).double().numpy()
            scores.append(score.numpy())
            errors.append({"uid": group.uid, "D0": float(np.mean(e0**2)), "D1": float(np.mean(e1**2)),
                           "Dcoarse": float(np.mean(coarse**2)),
                           "fine_and_coupling": float(np.mean(e1**2-coarse**2))})
    values = np.asarray(scores, np.float32).reshape(len(groups), 378)
    matrix, counts = evaluation.group_metrics(groups, values) if groups else (np.empty((0, 23), np.float64), [])
    path = root / "scores" / (tag + "_cache_metrics.npy")
    return {"ids": [g.uid for g in groups], "errors": errors, "counts": counts,
            "scores": previous.save_array(root / "scores" / (tag + "_cache.npy"), values, root),
            "metrics": previous.save_array(path, matrix, root)}


def epoch_output(root: Path, model: Any, optimizer: Any, current: list, memory: Any,
                 valid: list, c: dict, stage: int, epoch: int, budget: Budget) -> dict:
    if len(current) != 48 or len(valid) != 40 or any(g.labels is not None for g in valid):
        raise ValueError("Epoch input scope differs")
    if parent.adam_step(optimizer) != (stage-1)*288+epoch*48:
        raise ValueError("Epoch is not at its actual optimizer endpoint")
    tag = f"S_stage{stage}_epoch{epoch}"
    before = None if memory is None else memory.to_bytes()
    fit_rec = save_scores(root, tag + "_fit", model, current, c, budget)
    fit = previous.array(root, fit_rec, (48, 378), np.float32)
    fit_metrics, counts = evaluation.group_metrics(current, fit)
    result = {"stage": stage, "epoch": epoch, "adam_step": parent.adam_step(optimizer),
              "fit_ids": [g.uid for g in current], "fit_counts": counts,
              "fit": previous.save_array(root / "scores" / (tag + "_fit_metrics.npy"), fit_metrics, root),
              "cache": cache_output(root, tag, model, memory, c, budget),
              "valid": save_scores(root, tag + "_valid", model, valid, c, budget), "valid_labels_used": False}
    if before != (None if memory is None else memory.to_bytes()):
        raise ValueError("Epoch diagnostic changed bounded history")
    data.write_json(root / "diagnostics" / (tag + ".json"), result)
    return result


def probes(root: Path, model: Any, optimizer: Any, memory: Any, schedule: list,
           valid: list, c: dict, k: int, budget: Budget) -> dict:
    tag = f"probe{k}"
    before = save_scores(root, tag + "_before", model, valid, c, budget)
    cache_before = cache_output(root, tag + "_before", model, memory, c, budget)
    def observe(current_model, row):
        budget.updated(2)
        name = f"{tag}_r{row['r']}_a{row['a']}_f{row['f']}"
        return {"valid": save_scores(root, name + "_valid", current_model, valid, c, budget),
                "cache": cache_output(root, name, current_model, memory, c, budget)}
    rows = method.probe_block(model, optimizer, memory, schedule, c, k, observe, budget.check)
    after = save_scores(root, tag + "_restored", model, valid, c, budget)
    cache_after = cache_output(root, tag + "_restored", model, memory, c, budget)
    for left, right, shape in ((before, after, (40, 378)),
                              (cache_before["scores"], cache_after["scores"], (6, 378))):
        if not np.array_equal(previous.array(root, left, shape, np.float32),
                              previous.array(root, right, shape, np.float32)):
            raise ValueError("Actual restored blind predictions differ")
    result = {"k": k, "before": before, "cache_before": cache_before, "rows": rows,
              "restored": after, "cache_restored": cache_after, "restored_predictions_equal": True}
    data.write_json(root / "diagnostics" / (tag + ".json"), result)
    return result


def endpoint(root: Path, model: Any, optimizer: Any, current: list, calibration: list,
             memory: Any, valid_rec: dict, c: dict, stage: int, budget: Budget) -> tuple[dict, Any]:
    name = f"S_stage{stage}"
    cal_rec = save_scores(root, name + "_cal", model, calibration, c, budget)
    cal = previous.array(root, cal_rec, (12, 378), np.float32)
    mapping = parent.calibration.fit(cal, np.asarray([g.labels for g in calibration], np.uint8),
                                     role="calibration", check=budget.check)
    if mapping["status"] != "PASS_CALIBRATION_FIT":
        raise ValueError("Calibration failed; no retry")
    stage_map = dict(zip(("a", "b"), parent.calibration.parameters(mapping)))
    if stage == 1:
        memory = record.Memory("ABC")
        memory.maps = {"first": stage_map}
        def source(g):
            budget.forward(1)
            with diag.neutral(model):
                return record.reference(model, g, c, budget.check)
        memory.retain(current, 1, source)
    payload = memory.to_bytes()
    memory_path = root / "memory" / (name + ".bin")
    memory_path.write_bytes(payload)
    if record.Memory.from_bytes(memory_path.read_bytes()).to_bytes() != payload:
        raise ValueError("Memory roundtrip differs")
    state = diag.rng_state()
    metadata = {"stage": stage, "adam_step": parent.adam_step(optimizer), "rng": state,
                "memory": data.record(memory_path, root)}
    full_path = root / "work" / (name + ".pt")
    budget.check(base.persistence.checkpoint_reserve(model, optimizer))
    full = core.save_state(full_path, model, optimizer, metadata)
    if core.restore_state(full_path, model, optimizer, full["state_sha256"]) != metadata:
        raise ValueError("Full endpoint restoration differs")
    diag.restore_rng(state)
    restored_cal = save_scores(root, name + "_restored_cal", model, calibration, c, budget)
    if not np.array_equal(cal, previous.array(root, restored_cal, (12, 378), np.float32)):
        raise ValueError("Endpoint restored calibration scores differ")
    model_path = root / "models" / (name + ".pt")
    budget.check(base.persistence.checkpoint_reserve(model, None))
    inference = core.save_state(model_path, model, None, metadata)
    if core.restore_state(model_path, model, None, inference["state_sha256"]) != metadata:
        raise ValueError("Inference endpoint restoration differs")
    diag.restore_rng(state)
    result = {"stage": stage, "adam_step": parent.adam_step(optimizer), "valid": valid_rec,
              "calibration": cal_rec, "calibration_ids": [g.uid for g in calibration], "mapping": mapping,
              "maps": {"first": memory.maps["first"], "stage": stage_map}, "restoration_verified": True,
              "full": {**full, "path": full_path.relative_to(root).as_posix()},
              "model": {**inference, "path": model_path.relative_to(root).as_posix()},
              "memory": data.record(memory_path, root), "memory_summary": memory.summary()}
    # Keep necessary source identity before removing a temporary full state.
    data.write_json(root / (name + ".json"), result)
    base.persistence.remove_work_file(full_path, root)
    return result, memory


def train(job: Path, budget: Budget) -> tuple[dict, list]:
    root, c = job / "run", method.config()
    root.mkdir()
    for sub in ("scores", "diagnostics", "models", "memory", "work"):
        (root / sub).mkdir()
    public, metadata, checked = base.public.public_inputs(c)
    _, full_partition = base.partition(public, metadata, c)
    partition = {role: [row for row in rows if row["domain"] in "AB"] for role, rows in full_partition.items()}
    ids = {row["group_uid"] for rows in partition.values() for row in rows}
    train_groups = [g for g in public["train"] if g.uid in ids]
    valid = [g for g in public["development"] if g.uid in ids]
    del public, metadata, full_partition
    train_groups = parse_selected(job, train_groups, c, "train")
    lookup = {g.uid: g for g in train_groups}
    selected = {role: {domain: [lookup[row["group_uid"]] for row in partition[role] if row["domain"] == domain]
                       for domain in "AB"} for role in ("fit", "calibration")}
    archive = core.model_files(base.model_config(c, "split_rank"))
    if any(archive[k] != c["models"]["split_rank"][k] for k in ("file_count", "total_size_bytes", "content_sha256")):
        raise ValueError("Pinned Chinese BGE archive differs")
    random.seed(c["initialization_seed"])
    np.random.seed(c["initialization_seed"])
    model = record.load_model(c)
    optimizer = core.make_optimizer(model, c)
    manifest = {"status": "RUNNING", "source_files": method.sources(), "partition": partition,
                "public_inputs": checked, "pretrained_archive": archive, "epochs": [], "probes": [],
                "stages": [], "endpoints": [], "valid_ids": [g.uid for g in valid],
                "initial_model": core.state_digest(model.state_dict()), "initial_adam": core.state_digest(optimizer.state_dict())}
    manifest["initial"] = save_scores(root, "initial", model, valid, c, budget)
    data.write_json(root / "startup.json", manifest)
    memory = None
    for stage, domain in enumerate("AB", 1):
        current, calibration = selected["fit"][domain], selected["calibration"][domain]
        schedule, schedule_seed = parent.schedule(current, parent.contract(), "ABC", stage)
        if parent.adam_step(optimizer) != (stage-1)*288:
            raise ValueError("S stage Adam continuity differs")
        if memory is not None:
            memory.begin_stage(2)
            manifest["probes"].append(probes(root, model, optimizer, memory, schedule, valid, c, 0, budget))
        history_before = None if memory is None else memory.summary()
        rows = []
        for step, group in enumerate(schedule, 1):
            budget.phase = f"S_stage{stage}_step{step}"
            history, target = memory.draw() if memory is not None else (None, None)
            row = record.update(model, optimizer, group, history, target, c, "S", "ABC", stage, step, budget.check)
            budget.updated(1 if history is None else 2)
            row.update(step=step, current_uid=group.uid, history_uid=None if history is None else history.uid)
            rows.append(row)
            if step % 48 == 0:
                manifest["epochs"].append(epoch_output(root, model, optimizer, current, memory, valid,
                                                       c, stage, step//48, budget))
            if stage == 2 and step in method.POINTS:
                manifest["probes"].append(probes(root, model, optimizer, memory, schedule, valid, c, step, budget))
            if step == 1 or step % 24 == 0:
                print(data.json_bytes({"event": "updates", "stage": stage, "step": step,
                                       **budget.snapshot()}).decode(), flush=True)
        history_after = None if memory is None else memory.summary()
        if memory is not None and any(history_before[key] != history_after[key] for key in ("members", "seen", "origins", "tables")):
            raise ValueError("Main S stage mutated old membership/source")
        manifest["stages"].append({"stage": stage, "schedule_seed": schedule_seed, "rows": rows,
                                   "history_before": history_before, "history_after": history_after})
        point, memory = endpoint(root, model, optimizer, current, calibration, memory,
                                 manifest["epochs"][-1]["valid"], c, stage, budget)
        manifest["endpoints"].append(point)
    manifest.update(status="ALL_TRAINING_AND_BLIND_OUTPUTS_SAVED", counts=budget.snapshot())
    data.write_json(root / "manifest.json", manifest)
    return manifest, valid


def blind_gate(root: Path, manifest: dict) -> None:
    if (manifest["status"] != "ALL_TRAINING_AND_BLIND_OUTPUTS_SAVED" or manifest["source_files"] != method.sources()
            or manifest["counts"]["physical_updates"] != 672 or manifest["counts"]["gradient_groups"] != 1056
            or manifest["counts"]["forward_groups"] > 6500
            or [(r["stage"], r["epoch"]) for r in manifest["epochs"]] != [(s, e) for s in (1, 2) for e in range(1, 7)]
            or [p["k"] for p in manifest["probes"]] != list(method.POINTS)
            or len(manifest["valid_ids"]) != 40 or len(set(manifest["valid_ids"])) != 40):
        raise ValueError("Incomplete diagnostic before valid opening")
    for stage in manifest["stages"]:
        if [row["step"] for row in stage["rows"]] != list(range(1, 289)):
            raise ValueError("Incomplete main S updates")
        domain = "AB"[stage["stage"]-1]
        allowed = {row["group_uid"] for row in manifest["partition"]["fit"] if row["domain"] == domain}
        seed = data.seed_for(parent.contract()["schedule_seed"], "ABC", stage["stage"], "current")
        stream, expected_schedule = random.Random(seed), []
        for _ in range(6):
            sequence = sorted(allowed)
            stream.shuffle(sequence)
            expected_schedule.extend(sequence)
        if (len(allowed) != 48 or stage["schedule_seed"] != seed
                or [row["current_uid"] for row in stage["rows"]] != expected_schedule):
            raise ValueError("Main S used wrong fitting groups")
        if stage["stage"] == 1:
            if stage["history_before"] is not None or any(r["history_uid"] is not None for r in stage["rows"]):
                raise ValueError("First stage used historical inputs")
        else:
            before, after = stage["history_before"], stage["history_after"]
            if (before["count"] != 0 or after["count"] != 288 or len(before["members"]) != 6
                    or any(before[k] != after[k] for k in ("members", "seen", "origins", "tables"))
                    or any(r["history_uid"] not in before["members"] for r in stage["rows"])):
                raise ValueError("Main S history lifecycle differs")
    expected = [(r, a, f) for r in range(1, 7) for a, f in method.CONDITIONS]
    for block in manifest["probes"]:
        if [(r["r"], r["a"], r["f"]) for r in block["rows"]] != expected or not block["restored_predictions_equal"]:
            raise ValueError("Missing intervention/restoration")
        if any(row["source_state"] != block["rows"][0]["source_state"] or row["adam_step"] != 289+block["k"]
               for row in block["rows"]):
            raise ValueError("Interventions did not share model and optimizer origin")
        for row in block["rows"]:
            if row["history_uid"] != block["cache_before"]["ids"][row["r"]-1]:
                raise ValueError("Probe did not cover its fixed historical group")
            if row["current_uid"] != manifest["stages"][1]["rows"][block["k"]+row["r"]-1]["current_uid"]:
                raise ValueError("Probe current schedule differs")
            if row["seeds"] != {role: method.seeds(block["k"], row["r"], role) for role in ("current", "history")}:
                # JSON roundtrip represents tuples as lists.
                if row["seeds"] != {role: list(method.seeds(block["k"], row["r"], role)) for role in ("current", "history")}:
                    raise ValueError("Paired random streams differ")
    partition = manifest["partition"]
    if ([r["group_uid"] for r in partition["development"]] != manifest["valid_ids"]
            or any(sum(r["domain"] == d for r in partition[role]) != count
                   for role, count in (("fit", 48), ("calibration", 12), ("development", 20)) for d in "AB")):
        raise ValueError("AB role identity/count differs")
    def array(rec, shape, dtype):
        value = previous.array(root, rec, shape, dtype)
        if not np.isfinite(value).all():
            raise ValueError("Nonfinite blind output")
        return value
    def cache(entry, n):
        if len(entry["ids"]) != n or len(set(entry["ids"])) != n or len(entry["errors"]) != n:
            raise ValueError("Cache coverage differs")
        array(entry["scores"], (n, 378), np.float32)
        array(entry["metrics"], (n, 23), np.float64)
    array(manifest["initial"], (40, 378), np.float32)
    for entry in manifest["epochs"]:
        if entry["valid_labels_used"] is not False or len(entry["fit_ids"]) != 48:
            raise ValueError("Epoch blind/fit status differs")
        array(entry["valid"], (40, 378), np.float32)
        array(entry["fit"], (48, 23), np.float64)
        cache(entry["cache"], 0 if entry["stage"] == 1 else 6)
    for block in manifest["probes"]:
        before = array(block["before"], (40, 378), np.float32)
        restored = array(block["restored"], (40, 378), np.float32)
        if not np.array_equal(before, restored):
            raise ValueError("Saved restoration predictions differ")
        for key in ("cache_before", "cache_restored"):
            cache(block[key], 6)
        for row in block["rows"]:
            array(row["output"]["valid"], (40, 378), np.float32)
            cache(row["output"]["cache"], 6)
            if row["output"]["cache"]["ids"] != block["cache_before"]["ids"]:
                raise ValueError("Cache evaluation pairing differs")
    if [p["stage"] for p in manifest["endpoints"]] != [1, 2] or any(not p["restoration_verified"] for p in manifest["endpoints"]):
        raise ValueError("Endpoint restoration missing")
    for point in manifest["endpoints"]:
        array(point["valid"], (40, 378), np.float32)
        array(point["calibration"], (12, 378), np.float32)
        data.verify(root / point["model"]["path"], point["model"])
        data.verify(root / point["memory"]["path"], point["memory"])


def validate_gate(job: Path, path: Path) -> dict:
    p, gate = method.policy(), data.read_json(path)
    if (gate.get("status") != "APPROVED_RETENTION_DIAGNOSTIC_FORMAL" or gate.get("source_files") != method.sources()
            or gate.get("job") != job.relative_to(data.ROOT).as_posix() or gate.get("runtime") != p["runtime"]
            or gate.get("supervision") != p["supervision"] or gate.get("review_disposition") != "NO_OPEN_BLOCKERS"):
        raise ValueError("Matching reviewed formal gate required")
    for mode in ("cpu", "gpu"):
        evidence = data.read_json(data.verify(data.ROOT / gate[mode]["path"], gate[mode]))
        if (evidence.get("status") != "PASS_HANDWRITTEN_ONLY" or evidence.get("mode") != mode
                or evidence.get("source_files") != method.sources()):
            raise ValueError("Matching actual qualification required")
        if mode == "gpu" and (evidence["native"]["projected_total_seconds"] > 43200
                              or evidence["native"]["projected_peak_output_bytes"] > 16*2**30):
            raise ValueError("Native projection exceeds approved budget")
    return p


def execute(job: Path, gate_path: Path) -> dict:
    import torch
    from step28_record_replay_verify import preflight
    p = validate_gate(job, gate_path)
    if job.exists() or not job.is_relative_to(data.ROOT / "reports"):
        raise ValueError("Independent new job required")
    resources = preflight()
    if shutil.disk_usage(data.ROOT).free < 16*2**30:
        raise ValueError("Insufficient output space")
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    numerics = parent.configure_numerics()
    torch.cuda.set_per_process_memory_fraction(28*2**30/torch.cuda.get_device_properties(0).total_memory, 0)
    job.mkdir(parents=True)
    data.write_json(job / "access.json", dict(train=0, valid=0, heldout=0, owners=0))
    data.write_json(job / "execution.json", {"gate": data.record(gate_path, data.ROOT), "sources": method.sources(),
                                           "resources": resources, "numerics": numerics})
    budget, stopped = Budget(job), threading.Event()
    def watchdog():
        while not stopped.wait(1):
            try:
                budget.check()
            except BaseException as exc:
                data.write_json(job / "failure.json", {"status": "BUDGET_STOP_NO_RETRY", "error": str(exc), "budget": budget.snapshot()})
                os._exit(2)
    def terminate(signum, frame):
        raise RuntimeError("Terminated; preserve failed attempt, no automatic retry")
    signal.signal(signal.SIGTERM, terminate)
    watcher = threading.Thread(target=watchdog, daemon=True)
    watcher.start()
    try:
        manifest, valid = train(job, budget)
        blind_gate(job / "run", manifest)
        data.write_json(job / "before_valid.json", {"status": "PASS_COMPLETE_BLIND_GATE",
            "manifest": data.record(job / "run/manifest.json", job), "access": data.read_json(job / "access.json")})
        labelled = parse_selected(job, valid, method.config(), "development")
        evaluation.collect(job / "run", manifest, labelled, job / "evaluation", budget.check)
        del labelled, valid
        evaluation.finalize(job / "evaluation", budget.check)
        access = data.read_json(job / "access.json")
        if access != dict(train=1, valid=1, heldout=0, owners=0):
            raise ValueError("Completion access ledger differs")
        result = {"status": "COMPLETE_LOCAL_RETENTION_DIAGNOSTIC", "physical_updates": 672,
                  "access": access, "budget": budget.snapshot(), "overall_pass_gate": False,
                  "evaluation": data.record(job / "evaluation/evaluation.json", job)}
        with budget.lock:
            budget.check(16384)
            data.write_json(job / "completion.json", result)
        return result
    except BaseException:
        data.write_json(job / "failure.json", {"status": "FAILED_NO_AUTOMATIC_RETRY",
            "traceback": traceback.format_exc(), "budget": budget.snapshot(), "access": data.read_json(job / "access.json")})
        raise
    finally:
        stopped.set()
        watcher.join(timeout=2)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--gate", type=Path, required=True)
    args = parser.parse_args()
    if os.name != "posix":
        parser.error("Scientific execution requires the existing Linux py310")
    execute(args.out.resolve(), args.gate.resolve())
