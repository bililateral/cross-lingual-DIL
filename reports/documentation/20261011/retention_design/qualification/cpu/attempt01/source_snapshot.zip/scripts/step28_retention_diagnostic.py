"""Exact two-factor local intervention on C versus full S; not a new method."""
from __future__ import annotations

import ast
import copy
from pathlib import Path
from typing import Any, Callable

import numpy as np

import step28_record_replay as record
import step28_replay_diagnostics as diagnostics

data, parent, core, base = record.data, record.parent, record.core, record.base
POLICY = data.ROOT / "schema/step28_retention_diagnostic_policy.json"
POINTS = (0, 48, 144, 240)
CONDITIONS = ((0, 0), (1, 0), (0, 1), (1, 1))


def policy() -> dict:
    p = data.read_json(POLICY)
    if (p["order"] != "ABC" or p["domains"] != "AB" or p["seed"] != "s0"
            or p["main_method"] != "S" or p["checkpoints"] != list(POINTS)
            or p["conditions"] != [list(v) for v in CONDITIONS]
            or [p[k] for k in ("main_updates", "probe_updates", "physical_updates",
                               "gradient_group_presentations", "epoch_diagnostic_points")]
            != [576, 96, 672, 1056, 12] or p["maximum_forward_groups"] != 6500
            or p["memory_maximum_bytes"] != 1048576):
        raise ValueError("Approved local diagnostic scope differs")
    return p


def config() -> dict:
    c = record.config()
    c["runtime"] = policy()["runtime"]
    return c


def sources() -> list[dict]:
    names = ["scripts/step28_retention_diagnostic" + s + ".py"
             for s in ("", "_run", "_evaluate", "_verify")]
    names += ["tests/test_step28_retention_diagnostic.py", "tests/test_step28_record_replay.py"]
    paths = {data.ROOT / n for n in names}
    pending = list(paths)
    while pending:
        for node in ast.walk(ast.parse(pending.pop().read_text(encoding="utf-8"))):
            imports = ([v.name for v in node.names] if isinstance(node, ast.Import)
                       else [node.module] if isinstance(node, ast.ImportFrom) else [])
            for name in imports:
                if name and name.startswith("step28_"):
                    path = data.ROOT / "scripts" / (name + ".py")
                    if path not in paths:
                        paths.add(path)
                        pending.append(path)
    paths.update(data.ROOT / "schema" / name for name in (
        "step28_retention_diagnostic_policy.json", "step28_record_replay_policy.json",
        "step28_bge_continual_policy.json", "step28_alias_ranking_policy.json",
        "step28_chinese_base_policy.json"))
    paths.update(data.ROOT / policy()[key] for key in ("contract", "authorization"))
    paths.add(data.ROOT / "scripts/run_step28_retention_diagnostic_linux_20261011.sh")
    return [data.record(path, data.ROOT) for path in sorted(paths)]


def project_means(error: Any, slots: np.ndarray) -> Any:
    """Orthogonal block-average projection; within-account pairs map to zero."""
    import torch
    means = record.account_logits(error, slots)
    matrix = error.new_zeros((28, 28))
    a, b = torch.triu_indices(28, 28, 1, device=error.device)
    matrix[a, b], matrix[b, a] = means, means
    i, j = torch.triu_indices(len(slots), len(slots), 1, device=error.device)
    assigned = torch.as_tensor(slots, device=error.device)
    return matrix[assigned[i], assigned[j]]


def objective(table: Any, group: Any, seed: int, reference: np.ndarray,
              a: int, f: int) -> tuple[Any, dict]:
    import torch
    if (a, f) not in CONDITIONS or reference is None:
        raise ValueError("One of four historical interventions is required")
    # Preserve the actual native endpoint arithmetic, including pooled FP32 targets.
    arm = "C" if (a, f) == (1, 1) else "S"
    native, log = record.objective(table, group, seed, arm, reference)
    slots0, slots1 = record.assignment(group), record.assignment(group, seed)
    target = torch.as_tensor(reference, device=table.device, dtype=table.dtype)
    error = table - target
    coarse = record.account_logits(project_means(error, slots0), slots1).square().mean()
    d0 = (record.account_logits(table, slots0)-record.account_logits(target, slots0)).square().mean()
    d1 = (record.account_logits(table, slots1)-record.account_logits(target, slots1)).square().mean()
    factor_a, factor_f = .25*(coarse-d0), .25*(d1-coarse)
    loss = native
    if (a, f) == (1, 0):
        loss = native + factor_a
    elif (a, f) == (0, 1):
        loss = native + factor_f
    log.update(Dcoarse=float(coarse.detach()), factor_a=float(factor_a.detach()),
               factor_f=float(factor_f.detach()), a=a, f=f, weighted=float(loss.detach()))
    return loss, log


def seeds(k: int, r: int, role: str) -> tuple[int, int]:
    if k not in POINTS or r not in range(1, 7) or role not in ("current", "history"):
        raise ValueError("Unapproved probe identity")
    return tuple(data.seed_for(20261011, "retention_probe", "ABC", k, r, role, kind)
                 for kind in ("dropout", "regroup"))


def update(model: Any, optimizer: Any, current: Any, history: Any, reference: np.ndarray,
           c: dict, k: int, r: int, a: int, f: int, check: Callable = lambda: None) -> dict:
    import torch
    if parent.adam_step(optimizer) != 288+k or (a, f) not in CONDITIONS:
        raise ValueError("Probe must start from its unchanged S/Adam state")
    model.train()
    optimizer.zero_grad(set_to_none=True)
    optimizer.param_groups[0]["lr"] = parent.stage_lr(k+1)
    optimizer.param_groups[1]["lr"] = .001
    logs = {}
    for role, group, target in (("current", current, None), ("history", history, reference)):
        drop, regroup = seeds(k, r, role)
        callback = None
        if role == "history":
            callback = lambda values, g, seed, arm, source: objective(values, g, seed, source, a, f)
        logs[role] = record.backward_group(model, group, c, "S", drop, regroup, target,
                                          check, objective_fn=callback)
    norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 1., error_if_nonfinite=True)
    check()
    optimizer.step()
    return {**logs, "gradient_norm": float(norm), "encoder_lr": parent.stage_lr(k+1),
            "head_lr": .001, "adam_step": parent.adam_step(optimizer),
            "total": sum(row["weighted"] for row in logs.values())}


def host_copy(value: Any) -> Any:
    import torch
    if torch.is_tensor(value):
        return value.detach().cpu().clone()
    if isinstance(value, dict):
        return {k: host_copy(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return type(value)(host_copy(v) for v in value)
    return copy.deepcopy(value)


class Snapshot:
    """One temporary full S state, reused across mutually exclusive probe updates."""

    def __init__(self, model: Any, optimizer: Any, memory: Any):
        self.model = host_copy(model.state_dict())
        self.adam = host_copy(optimizer.state_dict())
        self.grads = host_copy([p.grad for p in model.parameters()])
        self.rng = diagnostics.rng_state()
        self.modes = [m.training for m in model.modules()]
        self.memory = None if memory is None else memory.to_bytes()
        self.digests = [core.state_digest(v) for v in (self.model, self.adam, self.grads)]

    def restore(self, model: Any, optimizer: Any, memory: Any) -> None:
        if (None if memory is None else memory.to_bytes()) != self.memory:
            raise ValueError("Probe changed bounded history/draw state")
        model.load_state_dict(self.model)
        # CPU optimizers otherwise alias the saved moments and corrupt the snapshot.
        optimizer.load_state_dict(host_copy(self.adam))
        for p, g in zip(model.parameters(), self.grads, strict=True):
            p.grad = None if g is None else g.to(device=p.device, copy=True)
        for module, mode in zip(model.modules(), self.modes, strict=True):
            module.training = mode
        diagnostics.restore_rng(self.rng)
        self.verify(model, optimizer, memory)

    def verify(self, model: Any, optimizer: Any, memory: Any) -> None:
        actual = [core.state_digest(v) for v in
                  (model.state_dict(), optimizer.state_dict(), [p.grad for p in model.parameters()])]
        if (actual != self.digests or diagnostics.rng_state() != self.rng
                or [m.training for m in model.modules()] != self.modes
                or (None if memory is None else memory.to_bytes()) != self.memory):
            raise ValueError("Actual restored model/Adam/grad/RNG/mode/Memory differs")


def probe_block(model: Any, optimizer: Any, memory: Any, schedule: list, c: dict,
                k: int, observe: Callable, check: Callable = lambda: None) -> list[dict]:
    if k not in POINTS or len(schedule) != 288 or len(memory.reservoir.groups) != 6:
        raise ValueError("Fixed four-point six-group probe scope differs")
    state = Snapshot(model, optimizer, memory)
    rows = []
    try:
        for r, history in enumerate(sorted(memory.reservoir.groups, key=lambda g: g.uid), 1):
            current = schedule[k+r-1]
            for a, f in CONDITIONS:
                state.restore(model, optimizer, memory)
                row = update(model, optimizer, current, history, memory.tables[history.uid],
                             c, k, r, a, f, check)
                row.update(k=k, r=r, a=a, f=f, current_uid=current.uid, history_uid=history.uid,
                           source_state=state.digests, seeds={role: seeds(k, r, role) for role in ("current", "history")})
                row["output"] = observe(model, row)
                rows.append(row)
    finally:
        state.restore(model, optimizer, memory)
    return rows
