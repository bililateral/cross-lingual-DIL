"""Independent handwritten formulas, actual updates, restoration and scoped wiring."""
from __future__ import annotations

import copy
import itertools
import os
from pathlib import Path
import tempfile
import unittest
from unittest import mock

import numpy as np
import torch

import step28_retention_diagnostic as method
import step28_retention_diagnostic_run as run
import step28_retention_diagnostic_evaluate as evaluation
from test_step28_record_replay import handmade_group, tiny_model, literal_scores

record, data, core = method.record, method.data, method.core


def unequal_group(uid="unequal"):
    g = handmade_group(uid, 4)
    return data.Group(g.uid, g.sellers, tuple(rows[:2+i%3] for i, rows in enumerate(g.items)), g.labels)


def literal_projection(error, slots):
    pairs = list(itertools.combinations(range(len(slots)), 2))
    blocks = {}
    for index, (i, j) in enumerate(pairs):
        if slots[i] != slots[j]:
            blocks.setdefault(tuple(sorted((slots[i], slots[j]))), []).append(index)
    means = {key: torch.stack([error[i] for i in indices]).mean() for key, indices in blocks.items()}
    return torch.stack([error.new_zeros(()) if slots[i] == slots[j]
                        else means[tuple(sorted((slots[i], slots[j])))] for i, j in pairs])


def literal_objective(table, group, seed, target, a, f):
    slots = [record.assignment(group), record.assignment(group, seed)]
    scores = [literal_scores(table, s) for s in slots]
    truth = torch.tensor(group.labels, dtype=table.dtype, device=table.device)
    supervised = sum(record.parent.ranking.objectives(v, truth, .5)["total"] for v in scores)/2
    if target is None:
        return supervised
    source = torch.as_tensor(target, dtype=table.dtype, device=table.device)
    d0, d1 = [(v-literal_scores(source, s)).square().mean() for v, s in zip(scores, slots)]
    coarse = literal_scores(literal_projection(table-source, slots[0]), slots[1]).square().mean()
    return .1*supervised + (.5-.25*a)*d0 + .25*(a-f)*coarse + .25*f*d1


def fixture():
    c, model = method.config(), tiny_model()
    current, history = handmade_group("current"), handmade_group("history")
    source = record.reference(model, history, c)
    optimizer = core.make_optimizer(model, c)
    record.update(model, optimizer, current, None, None, c, "S", "ABC", 1, 1)
    # One actual warmup update; the phase counter is explicitly a hand fixture.
    for state in optimizer.state.values():
        state["step"].fill_(288)
    return c, model, optimizer, current, history, source


class RetentionTests(unittest.TestCase):
    def test_projection_and_factor_derivatives_match_enumeration(self):
        group = unequal_group()
        n = sum(map(len, group.items))
        table = torch.linspace(-.8, 1.7, n*(n-1)//2, dtype=torch.float64, requires_grad=True)
        source = np.sin(np.arange(len(table), dtype=np.float64)*.19)
        slots = record.assignment(group)
        projected = method.project_means(table, slots)
        torch.testing.assert_close(projected, literal_projection(table, slots), rtol=1e-12, atol=1e-12)
        torch.testing.assert_close(literal_scores(table-projected, slots), torch.zeros(378, dtype=torch.float64), rtol=0, atol=2e-15)
        gradients = {}
        for a, f in method.CONDITIONS:
            actual, _ = method.objective(table, group, 17, source, a, f)
            expected = literal_objective(table, group, 17, source, a, f)
            torch.testing.assert_close(actual, expected, rtol=1e-11, atol=1e-12)
            ga, = torch.autograd.grad(actual, table, retain_graph=True)
            ge, = torch.autograd.grad(expected, table, retain_graph=True)
            torch.testing.assert_close(ga, ge, rtol=1e-10, atol=1e-12)
            gradients[a, f] = ga
        self.assertGreater(float((gradients[0, 1]-gradients[0, 0]).abs().max()), 1e-6)
        # Removing F would produce the S gradient and must be distinguished.
        self.assertFalse(torch.allclose(gradients[0, 1], gradients[0, 0], rtol=1e-6, atol=1e-9))

    def test_zero_fine_value_does_not_erase_coupling_gradient(self):
        group = unequal_group("coupling")
        slots = record.assignment(group)
        n = len(slots)
        x = torch.arange(n*(n-1)//2, dtype=torch.float64)/100
        x = method.project_means(x, slots).detach().requires_grad_(True)
        a1 = record.assignment(group, 17)
        pe = method.project_means(x, slots)
        r, s = record.account_logits(pe, a1), record.account_logits(x-pe, a1)
        full = ((r+s).square()-r.square()).mean()
        pure = s.square().mean()
        gf, = torch.autograd.grad(full, x, retain_graph=True)
        gp, = torch.autograd.grad(pure, x)
        self.assertAlmostEqual(float(full.detach()), 0., delta=1e-10)
        self.assertGreater(float((gf-gp).abs().max()), 1e-6)
        self.assertLess(float(gp.abs().max()), 1e-10)

    def test_all_four_real_vjp_and_adam_updates_match_literal_reference(self):
        c, original, original_adam, current, history, source = fixture()
        for a, f in method.CONDITIONS:
            model, direct = copy.deepcopy(original), copy.deepcopy(original)
            oa, ob = [core.make_optimizer(m, c) for m in (model, direct)]
            oa.load_state_dict(copy.deepcopy(original_adam.state_dict()))
            ob.load_state_dict(copy.deepcopy(original_adam.state_dict()))
            actual = method.update(model, oa, current, history, source, c, 0, 1, a, f)
            direct.train()
            ob.zero_grad(set_to_none=True)
            total = 0.
            for role, group, target in (("current", current, None), ("history", history, source)):
                drop, regroup = method.seeds(0, 1, role)
                torch.manual_seed(drop)
                z = record.record_vectors(direct, group, c)
                i, j = torch.triu_indices(len(z), len(z), 1)
                table = direct.head(torch.cat(((z[i]-z[j]).abs(), z[i]*z[j]), 1)).flatten()
                loss = literal_objective(table, group, regroup, target, a, f)
                total += float(loss.detach())
                loss.backward()
            self.assertAlmostEqual(actual["total"], total, delta=3e-6)
            torch.nn.utils.clip_grad_norm_(direct.parameters(), 1.)
            for left, right in zip(model.parameters(), direct.parameters()):
                torch.testing.assert_close(left.grad, right.grad, rtol=8e-5, atol=3e-7)
            ob.param_groups[0]["lr"], ob.param_groups[1]["lr"] = record.parent.stage_lr(1), .001
            ob.step()
            for left, right in zip(model.parameters(), direct.parameters()):
                torch.testing.assert_close(left, right, rtol=3e-5, atol=3e-7)
            self.assertEqual(record.parent.adam_step(oa), 289)

    def test_full_probe_block_restores_next_real_S_update(self):
        c, model, optimizer, current, _, _ = fixture()
        groups = [handmade_group(f"history{i:02}") for i in range(48)]
        memory = record.Memory("ABC")
        with method.diagnostics.neutral(model):
            memory.retain(groups, 1, lambda g: record.reference(model, g, c))
        memory.begin_stage(2)
        other = copy.deepcopy(model)
        oo = core.make_optimizer(other, c)
        oo.load_state_dict(copy.deepcopy(optimizer.state_dict()))
        other_memory = record.Memory.from_bytes(memory.to_bytes())
        initial = method.Snapshot(model, optimizer, memory)
        rows = method.probe_block(model, optimizer, memory, [current]*288, c, 0, lambda m, row: {"observed": True})
        self.assertEqual([(r["r"], r["a"], r["f"]) for r in rows],
                         [(r, a, f) for r in range(1, 7) for a, f in method.CONDITIONS])
        initial.verify(model, optimizer, memory)
        h, target = memory.draw()
        reference_h, reference_t = other_memory.draw()
        expected = record.update(other, oo, current, reference_h, reference_t, c, "S", "ABC", 2, 1)
        actual = record.update(model, optimizer, current, h, target, c, "S", "ABC", 2, 1)
        self.assertEqual(actual, expected)
        self.assertEqual(core.state_digest(model.state_dict()), core.state_digest(other.state_dict()))
        self.assertEqual(core.state_digest(optimizer.state_dict()), core.state_digest(oo.state_dict()))

    def test_unequal_size_query_rank_and_factorial_pairing(self):
        groups = [handmade_group("metric")]
        score = np.linspace(-1., 2., 378, dtype=np.float32)[None]
        metrics, _ = evaluation.group_metrics(groups, score)
        expected = record.base.objectives(torch.from_numpy(score[0]).double(),
                                          torch.tensor(groups[0].labels).double(), 1)["rank"]
        self.assertAlmostEqual(metrics[0, -1], float(expected), delta=1e-12)
        values = np.zeros((4, 6, 4, 20, 23))
        for j, (a, f) in enumerate(method.CONDITIONS):
            values[:, :, j] = 3 + 2*a - f + 5*a*f
        effects = evaluation.effects(values)
        for name, number in (("A_without_F", 2), ("A_with_F", 7), ("F_without_A", -1),
                             ("F_with_A", 4), ("C_minus_S", 6), ("interaction", 5)):
            np.testing.assert_array_equal(effects[name], np.full((4, 6, 20, 23), number))

    def test_full_672_update_entry_blind_gate_and_single_AB_collection(self):
        # Formal file/model loaders alone are replaced; actual tiny training, probes,
        # checkpoint recovery, blind gate and saved-score metrics execute end to end.
        public, metadata = {"train": [], "development": []}, []
        for split, count in (("train", 60), ("development", 20)):
            for domain in "ABC":
                for i in range(count):
                    g = handmade_group(f"{split}_{domain}_{i:02}")
                    public[split].append(data.Group(g.uid, g.sellers, g.items))
                    metadata.append({"group_uid": g.uid, "domain": domain, "split": split})
        truth = {g.uid: handmade_group(g.uid).labels for gs in public.values() for g in gs}
        def attach(job, groups, c, split):
            ledger = data.read_json(job / "access.json")
            key = "train" if split == "train" else "valid"
            self.assertEqual(ledger[key], 0)
            self.assertTrue(all("_C_" not in g.uid for g in groups))
            ledger[key] = 1
            data.write_json(job / "access.json", ledger)
            return [data.Group(g.uid, g.sellers, g.items, truth[g.uid]) for g in groups]
        c = method.config()
        archive = {k: c["models"]["split_rank"][k] for k in ("file_count", "total_size_bytes", "content_sha256")}
        with tempfile.TemporaryDirectory(dir=os.environ["RETENTION_TEST_ROOT"]) as tmp:
            job = Path(tmp)
            data.write_json(job / "access.json", dict(train=0, valid=0, heldout=0, owners=0))
            budget = run.Budget(job)
            # The native fit routine is unchanged and already qualified. A fixed positive
            # affine map avoids making this tiny random fixture a calibration convergence test.
            with mock.patch.object(run.base.public, "public_inputs", return_value=(public, metadata, {})), \
                 mock.patch.object(run, "parse_selected", side_effect=attach), \
                 mock.patch.object(run.core, "model_files", return_value=archive), \
                 mock.patch.object(run.record, "load_model", side_effect=lambda c: tiny_model()), \
                 mock.patch.object(run.parent.calibration, "fit", return_value={"status": "PASS_CALIBRATION_FIT"}), \
                 mock.patch.object(run.parent.calibration, "parameters", return_value=(1., 0.)):
                manifest, valid = run.train(job, budget)
            self.assertEqual((budget.physical_updates, budget.gradient_groups), (672, 1056))
            self.assertEqual(data.read_json(job / "access.json")["valid"], 0)
            run.blind_gate(job / "run", manifest)
            broken = copy.deepcopy(manifest)
            broken["probes"][0]["rows"].pop()
            with self.assertRaises(ValueError):
                run.blind_gate(job / "run", broken)
            broken = copy.deepcopy(manifest)
            broken["epochs"].pop()
            with self.assertRaises(ValueError):
                run.blind_gate(job / "run", broken)
            labelled = attach(job, valid, c, "development")
            collected = evaluation.collect(job / "run", manifest, labelled, job / "evaluation")
            self.assertEqual(len(collected["probes"]), 96)
            self.assertEqual(len(collected["epochs"]), 12)
            self.assertEqual(set(collected["domains"]), {"A", "B"})

    def test_selected_label_parser_rejects_early_valid_and_counts_failed_attempt(self):
        with tempfile.TemporaryDirectory(dir=os.environ["RETENTION_TEST_ROOT"]) as tmp:
            job = Path(tmp)
            data.write_json(job / "access.json", dict(train=0, valid=0, heldout=0, owners=0))
            groups = [handmade_group(f"v{i}") for i in range(40)]
            with self.assertRaises(ValueError):
                run.parse_selected(job, groups, {"data_root": str(job / "missing")}, "development")
            self.assertEqual(data.read_json(job / "access.json")["valid"], 0)
            groups = [handmade_group(f"t{i}") for i in range(120)]
            with self.assertRaises(FileNotFoundError):
                run.parse_selected(job, groups, {"data_root": str(job / "missing")}, "train")
            self.assertEqual(data.read_json(job / "access.json")["train"], 1)
            with self.assertRaises(ValueError):
                run.parse_selected(job, groups, {}, "train")
