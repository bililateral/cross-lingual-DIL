#!/usr/bin/env bash
# One bounded attempt; an independent reviewed gate is required for GPU/formal modes.
set -euo pipefail
cd -- "$(dirname -- "$(realpath -- "$0")")/.."
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export TOKENIZERS_PARALLELISM=false PYTHONDONTWRITEBYTECODE=1
export CUBLAS_WORKSPACE_CONFIG=:4096:8
mode="${1:?cpu, gpu or formal required}"
shift
py=/home/yongpeng/miniconda3/envs/py310/bin/python
case "$mode" in
  cpu)
    export CUDA_VISIBLE_DEVICES=""
    exec timeout --signal=TERM --kill-after=10s 300s taskset -c 0 "$py" -B \
      scripts/step28_retention_diagnostic_verify.py cpu "$@"
    ;;
  gpu)
    export CUDA_VISIBLE_DEVICES=0
    exec timeout --signal=TERM --kill-after=10s 600s taskset -c 0 "$py" -B \
      scripts/step28_retention_diagnostic_verify.py gpu "$@"
    ;;
  formal)
    export CUDA_VISIBLE_DEVICES=0
    export RECORD_REPLAY_STARTED_EPOCH="$(date +%s.%N)"
    exec timeout --signal=TERM --kill-after=10s 43200s taskset -c 0 "$py" -B \
      scripts/step28_retention_diagnostic_run.py "$@"
    ;;
  *) exit 2 ;;
esac
