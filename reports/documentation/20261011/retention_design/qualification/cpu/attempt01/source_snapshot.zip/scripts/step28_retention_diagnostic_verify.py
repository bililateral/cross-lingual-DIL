"""Linux-only bounded handwritten qualification; native requires reviewed sources."""
from __future__ import annotations

import time
STARTED = time.monotonic()

import argparse
import os
from pathlib import Path
import sys
import threading
import traceback
import unittest

import numpy as np
import psutil
import torch

import step28_retention_diagnostic as method
from step28_record_replay_verify import preflight

data, record, core, diag = method.data, method.record, method.core, method.diagnostics


def original_update(model, optimizer, current, history, target, c, arm, check):
    """Original C/S objectives on exactly the diagnostic's paired random inputs."""
    model.train()
    optimizer.zero_grad(set_to_none=True)
    optimizer.param_groups[0]["lr"], optimizer.param_groups[1]["lr"] = method.parent.stage_lr(1), .001
    for role, group, source in (("current", current, None), ("history", history, target)):
        dropout, regroup = method.seeds(0, 1, role)
        record.backward_group(model, group, c, arm, dropout, regroup, source, check)
    torch.nn.utils.clip_grad_norm_(model.parameters(), 1., error_if_nonfinite=True)
    optimizer.step()


def signature(model, optimizer):
    return [core.state_digest(v) for v in (model.state_dict(), optimizer.state_dict(), [p.grad for p in model.parameters()])]


def native(check, progress, handmade):
    resources = preflight()
    numerics = method.parent.configure_numerics()
    torch.cuda.set_per_process_memory_fraction(28*2**30/torch.cuda.get_device_properties(0).total_memory, 0)
    c = method.config()
    progress("load_pinned_chinese_BGE")
    model = record.load_model(c)
    if not model.encoder[0].auto_model.is_gradient_checkpointing or not torch.cuda.is_bf16_supported():
        raise ValueError("Required native checkpointing/BF16 is missing")
    current, history = [handmade.handmade_group("native_"+role, 8, 254) for role in ("current", "history")]
    for g in (current, history):
        lengths = [len(t) for t in model.encoder.tokenizer(method.base.record_texts(g, "separate_moments"),
                                                          padding=False, truncation=False)["input_ids"]]
        if len(lengths) != 448 or set(lengths) != {256}:
            raise ValueError("Native maximum shape is not N224/channel-token256")
    tick = time.monotonic()
    with diag.neutral(model):
        target = record.reference(model, history, c, check)
    torch.cuda.synchronize()
    source_seconds = time.monotonic()-tick
    optimizer = core.make_optimizer(model, c)
    tick = time.monotonic()
    record.update(model, optimizer, current, None, None, c, "S", "ABC", 1, 1, check)
    torch.cuda.synchronize()
    first_seconds = time.monotonic()-tick
    for state in optimizer.state.values():
        state["step"].fill_(288)
    # Handwritten continuation fixture: one actual warmup update, counter 288.
    initial = method.Snapshot(model, optimizer, None)
    timings, rows, endpoint_checks = [], {}, {}
    for a, f in method.CONDITIONS:
        progress(f"maximum_shape_a{a}_f{f}")
        initial.restore(model, optimizer, None)
        tick = time.monotonic()
        row = method.update(model, optimizer, current, history, target, c, 0, 1, a, f, check)
        torch.cuda.synchronize()
        timings.append(time.monotonic()-tick)
        actual = signature(model, optimizer)
        gradients = {name: float(parameter.grad.norm()) for name, parameter in model.named_parameters()
                     if name in ("head.0.weight", "head.2.weight") or name.endswith("layer.0.attention.self.query.weight")}
        if len(gradients) != 3 or any(not np.isfinite(v) or v <= 0 for v in gradients.values()):
            raise ValueError("Actual encoder/head gradient missing")
        if actual[0] == initial.digests[0] or method.parent.adam_step(optimizer) != 289:
            raise ValueError("Native parameter update absent")
        rows[f"a{a}_f{f}"] = {"loss": row, "gradient_norms": gradients, "actual_state": actual}
        if (a, f) in ((0, 0), (1, 1)):
            initial.restore(model, optimizer, None)
            original_update(model, optimizer, current, history, target, c, "S" if a == 0 else "C", check)
            if signature(model, optimizer) != actual:
                raise ValueError("Diagnostic endpoint differs from original native C/S update")
            endpoint_checks["S" if a == 0 else "C"] = True
    initial.restore(model, optimizer, None)
    tick = time.monotonic()
    with diag.neutral(model):
        record.score(model, [current, history], c, check)
    torch.cuda.synchronize()
    forward_seconds = (time.monotonic()-tick)/2
    del initial
    progress("actual_probe_loop_and_next_S_update_neutrality")
    small_current = handmade.handmade_group("small_current")
    history_groups = [handmade.handmade_group(f"small_history{i}") for i in range(48)]
    memory = record.Memory("ABC")
    with diag.neutral(model):
        memory.retain(history_groups, 1, lambda g: record.reference(model, g, c, check))
    memory.begin_stage(2)
    origin = method.Snapshot(model, optimizer, memory)
    branch = record.Memory.from_bytes(memory.to_bytes())
    h, t = branch.draw()
    expected_log = record.update(model, optimizer, small_current, h, t, c, "S", "ABC", 2, 1, check)
    expected, expected_rng = signature(model, optimizer), diag.rng_state()
    origin.restore(model, optimizer, memory)
    def observe(m, row):
        with diag.neutral(m):
            values = record.score(m, [small_current], c, check)
        return {"blind_finite": bool(np.isfinite(values).all())}
    probe_rows = method.probe_block(model, optimizer, memory, [small_current]*288, c, 0, observe, check)
    origin.verify(model, optimizer, memory)
    h, t = memory.draw()
    actual_log = record.update(model, optimizer, small_current, h, t, c, "S", "ABC", 2, 1, check)
    if expected != signature(model, optimizer) or expected_rng != diag.rng_state() or actual_log != expected_log:
        raise ValueError("Actual next S update differs after complete native probe block")
    parameter_bytes = sum(p.numel()*p.element_size() for p in model.parameters())
    projection = 1.25*(672*max(first_seconds, *timings)+6500*max(source_seconds, forward_seconds))+3600
    output_projection = int(1.1*(8*parameter_bytes+2*2**30))
    return {"resources": resources, "numerics": numerics, "maximum_records": 224, "channel_tokens": 256,
            "first_update_seconds": first_seconds, "intervention_update_seconds": timings,
            "source_seconds": source_seconds, "worst_eval_group_seconds": forward_seconds,
            "original_endpoint_bitwise_checks": endpoint_checks, "conditions": rows,
            "complete_probe_loop_updates": len(probe_rows), "next_S_model_adam_grad_rng_bitwise_equal": True,
            "parameter_bytes": parameter_bytes, "projected_total_seconds": projection,
            "projected_peak_output_bytes": output_projection,
            "within_formal_budget": projection <= 43200 and output_projection <= 16*2**30,
            "fixture": "Handwritten only; one real warmup update with phase counter set to 288; no formal inputs"}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("cpu", "gpu"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--gate", type=Path)
    parser.add_argument("--prior-seconds", type=float, default=0)
    args = parser.parse_args()
    args.output = args.output.resolve()
    if os.name != "posix" or args.output.exists() or args.prior_seconds < 0:
        parser.error("Linux, new attempt and honest cumulative time required")
    args.output.mkdir(parents=True)
    sys.path.insert(0, str(data.ROOT / "tests"))
    import test_step28_retention_diagnostic as handmade
    os.environ["RETENTION_TEST_ROOT"] = str(args.output)
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    process = psutil.Process()
    limits = method.policy()["cpu_verification" if args.mode == "cpu" else "native_verification"]
    report = {"status": "RUNNING", "mode": args.mode, "source_files": method.sources(),
              "formal_inputs": False, "formal_labels": False, "prior_seconds": args.prior_seconds,
              "peak_rss_bytes": 0, "numerics": method.parent.configure_numerics()}
    stopped, lock = threading.Event(), threading.RLock()
    def write():
        with lock:
            report["elapsed_seconds"] = time.monotonic()-STARTED
            report["cumulative_seconds"] = args.prior_seconds+report["elapsed_seconds"]
            if torch.cuda.is_initialized():
                report["peak_cuda_reserved_bytes"] = torch.cuda.max_memory_reserved()
            data.write_json(args.output / "result.json", report)
    def check():
        report["peak_rss_bytes"] = max(report["peak_rss_bytes"], process.memory_info().rss)
        total = 0
        for path in args.output.parent.rglob("*"):
            try:
                if path.is_file():
                    total += path.stat().st_size
            except FileNotFoundError:
                pass
        if (time.monotonic()-STARTED+args.prior_seconds >= limits["maximum_seconds"]
                or report["peak_rss_bytes"] > (2 if args.mode == "cpu" else 64)*2**30
                or total > limits["maximum_evidence_bytes"]
                or (torch.cuda.is_initialized() and torch.cuda.max_memory_reserved() > 28*2**30)):
            raise RuntimeError("Approved cumulative verification budget exceeded")
    def progress(stage):
        report["stage"] = stage
        write()
    def watchdog():
        while not stopped.wait(.5):
            try:
                check()
            except BaseException as exc:
                report.update(status="BUDGET_STOP", error=str(exc))
                write()
                os._exit(2)
    watcher = threading.Thread(target=watchdog, daemon=True)
    watcher.start()
    try:
        if len(process.cpu_affinity()) != 1 or any(os.environ.get(k) != "1" for k in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS")):
            raise ValueError("One CPU and pre-import single-thread environment required")
        if args.mode == "cpu":
            if os.environ.get("CUDA_VISIBLE_DEVICES") != "":
                raise ValueError("CPU qualification must disable CUDA")
            suite = unittest.defaultTestLoader.loadTestsFromTestCase(handmade.RetentionTests)
            from test_step28_record_replay import RecordReplayTests
            suite.addTest(RecordReplayTests("test_chunked_vjp_every_parameter_and_actual_adam_match_direct_autograd"))
            with (args.output / "unittest.txt").open("w", encoding="utf-8") as stream:
                result = unittest.TextTestRunner(stream=stream, verbosity=2, failfast=True).run(suite)
            report.update(tests_run=result.testsRun, failures=len(result.failures), errors=len(result.errors), skipped=len(result.skipped))
            if not result.wasSuccessful() or result.skipped:
                raise RuntimeError("Affected handwritten checks failed")
        else:
            if args.gate is None:
                raise ValueError("Reviewed matching source gate required for native GPU")
            gate = data.read_json(args.gate)
            if (gate.get("status") != "APPROVED_RETENTION_DIAGNOSTIC_NATIVE" or gate.get("source_files") != method.sources()
                    or gate.get("review_disposition") != "NO_OPEN_BLOCKERS"):
                raise ValueError("Reviewed native gate differs")
            cpu = data.read_json(data.verify(data.ROOT / gate["cpu"]["path"], gate["cpu"]))
            if cpu.get("status") != "PASS_HANDWRITTEN_ONLY" or cpu.get("source_files") != method.sources() or cpu.get("mode") != "cpu":
                raise ValueError("Matching CPU evidence required")
            report["native"] = native(check, progress, handmade)
        check()
        report["status"] = "PASS_HANDWRITTEN_ONLY"
    except BaseException:
        report.update(status="FAIL", traceback=traceback.format_exc())
        raise
    finally:
        stopped.set()
        watcher.join(timeout=2)
        write()


if __name__ == "__main__":
    main()
