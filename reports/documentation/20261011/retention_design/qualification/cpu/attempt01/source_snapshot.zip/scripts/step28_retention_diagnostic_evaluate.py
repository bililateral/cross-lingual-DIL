"""Collect one opened AB result batch, then use only saved metric matrices."""
from __future__ import annotations

from pathlib import Path
from typing import Callable

import numpy as np

import step28_retention_diagnostic as method

data, parent, previous = method.data, method.parent, method.diagnostics.previous
COLUMNS = (*parent.metrics.COLUMNS, "query_rank_loss")
WEIGHTS = {"A_without_F": (-1, 1, 0, 0), "A_with_F": (0, 0, -1, 1),
           "F_without_A": (-1, 0, 1, 0), "F_with_A": (0, -1, 0, 1),
           "C_minus_S": (-1, 0, 0, 1), "interaction": (1, -1, -1, 1)}


def group_metrics(groups: list, scores: np.ndarray) -> tuple[np.ndarray, list]:
    if any(g.labels is None for g in groups):
        raise ValueError("Metrics require authorized, aligned labels")
    truth = np.asarray([g.labels for g in groups], np.uint8)
    matrix, counts = parent.metrics.group_metrics(truth, scores)
    ranks = []
    left, right = np.triu_indices(28, 1)
    for labels, values in zip(truth, scores, strict=True):
        m = np.full((28, 28), -np.inf, np.float64)
        y = np.zeros((28, 28), bool)
        m[left, right], m[right, left] = values, values
        y[left, right], y[right, left] = labels, labels
        denominator = np.logaddexp.reduce(m, axis=1)
        positive = np.array([m[i, y[i]].mean() for i in range(28)])
        ranks.append(float(np.mean(denominator-positive)))
    result = np.column_stack((matrix, ranks))
    if result.shape != (len(groups), 23) or not np.isfinite(result).all():
        raise ValueError("Incomplete metric collection")
    return result, counts


def collect(root: Path, manifest: dict, labelled: list, out: Path, check: Callable = lambda: None) -> dict:
    if [g.uid for g in labelled] != manifest["valid_ids"]:
        raise ValueError("Valid pairing differs")
    out.mkdir()
    first_map = manifest["endpoints"][0]["maps"]["first"]
    result = {"status": "COLLECTING", "source_files": method.sources(), "columns": list(COLUMNS),
              "valid_ids": manifest["valid_ids"], "domains": [r["domain"] for r in manifest["partition"]["development"]],
              "probes": {}, "epochs": [], "endpoints": {}, "initial": {}}
    def save(tag, rec, mapping=None):
        check()
        values = previous.array(root, rec, (40, 378), np.float32)
        if mapping is not None:
            transformed = parent.calibration.transform(values, mapping)
            parent.calibration.preserve_order(values, transformed)
            values = transformed
        metrics, counts = group_metrics(labelled, values)
        return {"matrix": previous.save_array(out / (tag + ".npy"), metrics, out), "counts": counts}
    result["initial"] = save("initial", manifest["initial"])
    for block in manifest["probes"]:
        for row in block["rows"]:
            key = f"k{block['k']}_r{row['r']}_a{row['a']}_f{row['f']}"
            result["probes"][key] = {role: save(key + "_" + role, row["output"]["valid"], mapping)
                                     for role, mapping in (("raw", None), ("first-cal", first_map))}
            cache = row["output"]["cache"]
            result["probes"][key]["cache"] = {"matrix": previous.save_array(out / (key + "_cache.npy"),
                previous.array(root, cache["metrics"], (6, 23), np.float64), out),
                "counts": cache["counts"], "errors": cache["errors"], "ids": cache["ids"]}
    for epoch in manifest["epochs"]:
        tag = f"stage{epoch['stage']}_epoch{epoch['epoch']}"
        n = 0 if epoch["stage"] == 1 else 6
        result["epochs"].append({"stage": epoch["stage"], "epoch": epoch["epoch"],
            "valid": save(tag + "_valid", epoch["valid"]), "fit_ids": epoch["fit_ids"],
            "fit": previous.save_array(out / (tag + "_fit.npy"), previous.array(root, epoch["fit"], (48, 23), np.float64), out),
            "cache_ids": epoch["cache"]["ids"],
            "cache": previous.save_array(out / (tag + "_cache.npy"), previous.array(root, epoch["cache"]["metrics"], (n, 23), np.float64), out)})
    for point in manifest["endpoints"]:
        key = f"stage{point['stage']}"
        result["endpoints"][key] = {"raw": save(key + "_raw", point["valid"])}
        for role in ("first", "stage"):
            result["endpoints"][key][role + "-cal"] = save(key + "_" + role, point["valid"], point["maps"][role])
    result["status"] = "ALL_LOCAL_DIAGNOSTIC_MATRICES_SAVED"
    data.write_json(out / "collected.json", result)
    return result


def effects(values: np.ndarray) -> dict[str, np.ndarray]:
    """Input: points x historical groups x four conditions x evaluation groups x metrics."""
    if values.ndim != 5 or values.shape[:3] != (4, 6, 4) or values.shape[-1] != 23:
        raise ValueError("Fixed factorial axes required")
    return {name: np.einsum("c,krcgm->krgm", weights, values) for name, weights in WEIGHTS.items()}


def describe(values: np.ndarray, draws: np.ndarray) -> dict:
    estimates = values[draws].mean(1)
    interval = np.quantile(estimates, [.025, .975], axis=0).T
    return {name: {"mean": float(values[:, i].mean()), "conditional_95pct_interval": interval[i].tolist()}
            for i, name in enumerate(COLUMNS)}


def finalize(out: Path, check: Callable = lambda: None) -> dict:
    collected = data.read_json(out / "collected.json")
    if (collected["status"] != "ALL_LOCAL_DIAGNOSTIC_MATRICES_SAVED" or collected["source_files"] != method.sources()
            or collected["columns"] != list(COLUMNS) or len(collected["probes"]) != 96):
        raise ValueError("Incomplete saved collection; do not reopen labels")
    domains = np.asarray(collected["domains"])
    if domains.shape != (40,) or any(np.sum(domains == d) != 20 for d in "AB"):
        raise ValueError("AB metric population differs")
    result = {"columns": list(COLUMNS), "primary": "A/raw/query_rank_loss: F_without_A, F_with_A, C_minus_S",
              "comparisons": {}, "cache_comparisons": {}, "absolute_endpoints": {}, "overfitting": {},
              "delta_orientation": "condition differences; lower is better for brier/log_loss/query_rank_loss",
              "overall_pass_gate": False, "automatic_followup": False,
              "limits": "One S trajectory, one seed, local off-policy updates, reused development valid; no historical root-cause or long-horizon efficacy claim."}
    for role in ("raw", "first-cal", "cache"):
        n = 6 if role == "cache" else 40
        matrices = np.empty((4, 6, 4, n, 23), np.float64)
        for i, k in enumerate(method.POINTS):
            for r in range(1, 7):
                for j, (a, f) in enumerate(method.CONDITIONS):
                    rec = collected["probes"][f"k{k}_r{r}_a{a}_f{f}"][role]["matrix"]
                    matrices[i, r-1, j] = previous.array(out, rec, (n, 23), np.float64)
        for name, values in effects(matrices).items():
            check()
            if role == "cache":
                result["cache_comparisons"][name] = {"mean": dict(zip(COLUMNS, values.mean((0, 1, 2)).tolist())),
                    "by_point_and_history": values.mean(2).tolist(), "interval": None,
                    "reason": "Six trained cache groups are not unseen evaluation identities"}
                continue
            for domain in "AB":
                rows = np.flatnonzero(domains == domain)
                draws = np.random.Generator(np.random.PCG64(data.seed_for(
                    20261011, "retention_probe", domain, "bootstrap"))).integers(0, 20, (5000, 20))
                v = values[:, :, rows]
                # Average the fixed 24 interventions first; resample only whole evaluation groups.
                summary = {"aggregate": describe(v.mean((0, 1)), draws),
                           "by_point": {str(k): describe(v[i].mean(0), draws) for i, k in enumerate(method.POINTS)},
                           "by_point_and_history": v.mean(2).tolist()}
                result["comparisons"][f"{role}/{domain}/{name}"] = summary
    for point, roles in collected["endpoints"].items():
        result["absolute_endpoints"][point] = {}
        for role, rec in roles.items():
            matrix = previous.array(out, rec["matrix"], (40, 23), np.float64)
            result["absolute_endpoints"][point][role] = {d: dict(zip(COLUMNS, matrix[domains == d].mean(0).tolist())) for d in "AB"}
    columns = [COLUMNS.index(k) for k in method.diagnostics.COLUMNS]
    for stage, current_domain in enumerate("AB", 1):
        rows = [e for e in collected["epochs"] if e["stage"] == stage]
        if [e["epoch"] for e in rows] != list(range(1, 7)):
            raise ValueError("Incomplete six-epoch curves")
        valid = np.stack([previous.array(out, e["valid"]["matrix"], (40, 23), np.float64) for e in rows])[:, :, columns]
        for role, n, domain in (("fit", 48, current_domain), ("cache", 0 if stage == 1 else 6, "A")):
            train = np.stack([previous.array(out, e[role], (n, 23), np.float64) for e in rows])[:, :, columns]
            result["overfitting"][f"stage{stage}/{role}/{domain}"] = method.diagnostics.curve_comparison(
                train, valid[:, domains == domain], data.seed_for(20260930, "ABC", stage, role, domain, "diagnostics"))
    result.update(status="STATISTICS_COMPLETE_REQUIRES_VALID_COMPLETION", source_files=method.sources(),
                  collected=data.record(out / "collected.json", out))
    data.write_json(out / "evaluation.json", result)
    return result
