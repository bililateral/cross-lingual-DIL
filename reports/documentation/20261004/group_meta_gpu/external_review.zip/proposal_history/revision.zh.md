# 审查者建议代码 v1→v2 修正记录

## 发现与归属

交叉静态审查发现，**审查者新写、未运行的** `exact_hvp_torch_suggestion.py`（v1）把全部参数的梯度初始化并返回为零张量。若某参数在本次目标完全未被使用，原 `loss.backward()` 应保留 `p.grad=None`；v1 返回零会使随后 AdamW 可能对该参数施加权重衰减并推进既有状态。这是建议代码的实现缺陷，不能归咎于用户提交的原实现，也不是 NumPy 数学公式错误。

没有发生原生/Torch 执行失败。本环境无 torch，缺陷由逐行静态审查识别。v1 原件保留，没有覆盖。

## v2 修改

`exact_hvp_torch_suggestion_v2.py` 为每个参数维护参与掩码，分别观察支持一阶梯度、query 梯度、支持 HVP 中 `autograd.grad` 是否返回非 None。全部路径都未使用的参数最终返回 None；有连接但导数恰为零的参数继续返回零张量。beta=0 的支持目标分支同样遵守此规则。

`exact_hvp_torch_suggestion_v1_to_v2.patch` 是完整源码差分。改动不改梯度公式、四群目标、固定率、全参数 HVP 或图释放次序。

Caller 的必要语义：先执行 `optimizer.zero_grad(set_to_none=True)`，再按原参数名称把每项赋给 `.grad`（None 保持 None，张量可 detach 后赋值）；之后只做原来的一次全局裁剪及一次 AdamW 更新。禁止用 `zeros_like` 填充返回的 None；也不要把零张量误判为 None。正式接入应比较原模型和新路径每个参数的 None/非 None 模式，以及全部数值梯度和 Adam 状态。

## 执行状态

- v1、v2 均仅通过本环境 Python `py_compile`，不是运行通过。
- 两个 NumPy 脚本及对应 result.json 是实际执行的独立数学证据，与 PyTorch 运行证据严格区分。
- v2 没有加载 BGE，没有执行 CUDA、AdamW、dropout 或 functional_call；资源可行性未知。
- 输入 ZIP 及解包源程序未修改；没有实现 formal runner 或授予正式训练准入。
