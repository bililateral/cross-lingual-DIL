"""UNEXECUTED PyTorch engineering suggestion, not a production patch.

The audit environment lacks torch. Only syntax compilation was performed.
Returns exact analytical meta-gradient components; it does NOT return a scalar
on which calling backward() would recover the meta-gradient. Caller must assign
the returned gradients, apply the original one global clip, and step AdamW once.

Each term must compute an ENTIRE group's original scalar loss, evaluate supplied
parameter tensors, restore the same per-role dropout stream on every call, and
have no mutable parameter/buffer/Python state or global RNG side effects. The
original FP32/eager/microbatch/input/labels/logit targets remain caller duties.
For this project support terms are L_current_support and
0.1*L_history_support + 0.5*MSE_history_support. Query terms are
L_current_query and rho*L_history_query. Do not split relations or accounts.
"""
from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
import math

import torch


def exact_staged_meta_gradient(
    parameters: Mapping[str, torch.Tensor],
    support_terms: Sequence[Callable[[Mapping[str, torch.Tensor]], torch.Tensor]],
    query_terms: Sequence[Callable[[Mapping[str, torch.Tensor]], torch.Tensor]],
    rates: Mapping[str, float],
    beta: float,
) -> tuple[dict[str, torch.Tensor], dict[str, float | int]]:
    """For constant diagonal A: gs + beta * [v - Hs^T (A^T v)].

    The suggested caller must compare complete raw gradients and the subsequent
    model/Adam state to the existing objective/update before resource admission.
    No approximation, clipping, optimizer action, offload, autocast, checkpoint,
    group selection, or random-number draw is implemented in this function.
    """
    names = tuple(parameters)
    theta = tuple(parameters.values())
    if not theta or set(names) != set(rates) or any(not p.requires_grad for p in theta):
        raise ValueError("All named trainable parameters and constant rates are required")
    if not math.isfinite(beta) or beta < 0 or any(
        not isinstance(rates[name], (int, float)) or not math.isfinite(rates[name]) or rates[name] < 0
        for name in names
    ):
        raise ValueError("Rates and beta must be finite nonnegative scalar constants")
    if len(support_terms) != 2 or len(query_terms) != 2:
        raise ValueError("Project contract requires two full support and two full query groups")

    # Phase A: no support graph survives the next whole-group term.
    result = [torch.zeros_like(p) for p in theta]
    support_value = 0.0
    for term in support_terms:
        loss = term(parameters)
        if loss.ndim != 0:
            raise ValueError("Each group must produce one complete scalar loss")
        gradients = torch.autograd.grad(loss, theta, create_graph=False, allow_unused=True)
        support_value += float(loss.detach())
        with torch.no_grad():
            for destination, gradient in zip(result, gradients, strict=True):
                if gradient is not None:
                    destination.add_(gradient)
        del loss, gradients
    if beta == 0:
        return dict(zip(names, result, strict=True)), {
            "support": support_value, "query": 0.0, "total": support_value,
            "logical_group_roles": 2, "physical_full_group_forwards": 2,
        }

    # The independent leaf representation releases the *long-lived* support
    # graph. Its omitted composition derivative is recovered EXACTLY in phase C.
    with torch.no_grad():
        fast = {name: (p - float(rates[name]) * gs).requires_grad_(True)
                for name, p, gs in zip(names, theta, result, strict=True)}
    phi = tuple(fast.values())
    vector = [torch.zeros_like(p) for p in theta]
    query_value = 0.0
    for term in query_terms:
        loss = term(fast)
        if loss.ndim != 0:
            raise ValueError("Each group must produce one complete scalar loss")
        gradients = torch.autograd.grad(loss, phi, create_graph=False, allow_unused=True)
        query_value += float(loss.detach())
        with torch.no_grad():
            for destination, gradient in zip(vector, gradients, strict=True):
                if gradient is not None:
                    destination.add_(gradient)
        del loss, gradients
    del phi, fast  # No fast weights or query graph needed during HVP recomputation.
    with torch.no_grad():
        for index, name in enumerate(names):
            result[index].add_(vector[index], alpha=float(beta))
            # A is diagonal: A^T v = A v. Apply it BEFORE the Hessian product.
            vector[index].mul_(float(rates[name]))

    # Put each second-order graph inside its own function scope. Otherwise a
    # Python loop variable may keep a gradient tensor (and its graph) alive even
    # after deleting the tuple/list that originally contained it.
    def one_support_hvp(term):
        loss = term(parameters)
        gradients = torch.autograd.grad(loss, theta, create_graph=True, allow_unused=True)
        outputs, directions = [], []
        for gradient, direction in zip(gradients, vector, strict=True):
            if gradient is not None and gradient.requires_grad:
                outputs.append(gradient)
                directions.append(direction)
        if outputs:
            return torch.autograd.grad(
                outputs, theta, grad_outputs=directions,
                create_graph=False, retain_graph=False, allow_unused=True,
            )
        return (None,) * len(theta)

    # Phase C: exact reverse-over-reverse HVP, one full support group at a time.
    # vector is held constant; do not differentiate the query vector again.
    for term in support_terms:
        hessian_vector = one_support_hvp(term)
        with torch.no_grad():
            for destination, correction in zip(result, hessian_vector, strict=True):
                if correction is not None:
                    destination.add_(correction, alpha=-float(beta))
        del hessian_vector
    if any(not torch.isfinite(g).all() for g in result):
        raise ValueError("Non-finite raw complete meta-gradient")
    return dict(zip(names, result, strict=True)), {
        "support": support_value, "query": query_value,
        "total": support_value + float(beta) * query_value,
        "logical_group_roles": 4, "physical_full_group_forwards": 6,
    }
