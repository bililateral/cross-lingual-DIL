# 增量分项：固定参数起点与未来正式接入边界

审查对象：本次 `review(7).zip` 解包中的 request、GPU 合同、implementation、authorization、现有群元更新及直接父恢复/记忆/评价代码；复用 prior 中已经关闭的结论，不重新审基础数据或损失。本分项未加载任何正式文本、标签、旧模型或缓存，未连接 Linux，未运行 Torch/BGE/GPU，也没有产生新效果分数。以下源码行号均对应本包 `review7_extracted/` 的文件。

## 一、裁决

1. **拟议 `(inner_encoder_lr=1e-5, inner_head_lr=1e-3, rho=.1, beta=1)` 未发现明显的公式不自洽或足以否定单点试验的合理性错误。** 它是前瞻固定的开发起点，不是已经验证足够强、足够稳定或接近最优的参数。原生 GPU 未完成首个元更新，现有 Tiny 使用另一组放大差异的参数，因此不能凭 Tiny 二阶校正大小替本点判断有效校正规模。
2. **本次不能签发正式训练准入。** 已授权的是手写 GPU 范围，正式数据和旧实验权重均为 false；资源核验未完成原生元更新，formal runner 也尚不存在。本轮资源门未通过与算法效果失败不同。该边界无需新读取封存材料来证明。
3. **不要求现在先实现或训练四个机制对照。** 后续候选可按已确认顺序，先运行一个固定点并以旧合法开放 LOGIT0.1 作开发参照；前瞻固定观察量、取舍及停止条件即可。机制归因和原创性主张仍留待后续有针对性的比较。

证据：`authorization.json:2–12`；`docs/SELLER_ALIAS_GROUP_META_GPU.zh.md:9,29–35`；`docs/SELLER_ALIAS_GROUP_META_VALIDATION.zh.md:3–21,33,50,62–66`。原始 `direct_first/stdout.txt` 与 `offload_first/stdout.txt` 均止于 `native_meta_start step=1`；退出码分别 1/124，offload 无 result.json。

## 二、参数为什么可作为起点，哪些解释必须保留

### 2.1 内层 SGD 前瞻不是外层 AdamW 的一步预测

真实快参数构造是 `theta'_i = theta_i - alpha_i * grad_i Ls`，保留 `create_graph=True`；它没有使用 Adam 的一阶/二阶矩、bias correction、weight decay 或裁剪（`scripts/step28_group_meta.py:93–111`）。外层使用父日程与一次全参数裁剪、一次 AdamW：编码器外层率由 `stage_lr(step)` 决定，head 固定 `.001`（同文件 `180–209`；`step28_bge_continual.py:50–53`；`step28_continual_population.py:32–40`）。

因此，拿内层率与旧外层峰值同为 `1e-5/1e-3` 作为易解释的起点可以接受，但相同数值不能推出相近位移或“准确模拟旧 Adam 下一步”。内层位移是 `-A gs`，外层方向与旧存量矩和 clip 有关。内层编码器率固定，而外层编码器率逐阶段 warmup/decay，第 288 步为 0；这已是明示的候选定义，不是代码错误，也不能写成每一步每个参数都必须改变。

较小的内层率可能使校正弱，也可能仍有实质校正；仅凭数值大小不能判断。后续可从同一次已获准的原生核验中记录编码器/head 的位移规模与二阶校正量，作为解释信息，不把此建议升级为当前必须新增训练或多点搜索的阻断。

### 2.2 beta=1 与 rho=.1 并不保证“旧 LOGIT 权衡不变”

代码精确定义（`step28_group_meta.py:161–176`）：

\[
L_s=L_{Cs}+0.1L_{Hs}+0.5M_{Hs},\quad
L_q=L_{Cq}+\rho L_{Hq},\quad
J=L_s+\beta L_q(\theta-A\nabla L_s).
\]

`rho=.1` 让 query 中历史/当前基础监督的标量比例与 support 相同；`beta=1` 只让两目标的外部系数相同，不意味着损失数值、梯度范数或最终贡献相等。历史 logit MSE 只在 Hs 上一次，query 没有保存 logit 项。

为解释权重，在形式上的 `A=0` 极限（不是要求改代码运行对照）有：

\[
J_0=L_{Cs}+L_{Cq}+0.1(L_{Hs}+L_{Hq})+0.5M_{Hs}.
\]

相对两群 LOGIT0.1，当前/历史基础监督各出现两次而 MSE 仍只有一次；且每一步是另外完整群，不能逐样本视为同一损失乘 2。故候选变化包括额外群监督及相对权重结构，不能说仅在旧 LOGIT 上加入一个 Hessian 项。`beta=1` 本身没有明显不合理，但总梯度尺度、clip 命中和 MSE 相对影响未知，应由固定点结果检验。

**J 不再除 2 是既定定义。** 不应把 `/2` 当作无害的内存修复或实现归一化。它改变目标尺度；在继承旧 Adam 矩、固定 eps 和 clipping 的实际外层路径上，没有普遍的更新不变性。即使某一步裁剪后方向恰好相同，也不足以证明整个连续训练等价。GPU 合同第 9 行已明确“不另除以 2”，源码第 111 行与之相符。

### 2.3 创新和先导顺序

本分项承接已经关闭的 MLDG/MER/La-MAML 边界，不重新作原论文检索认证：`prior/primary_review.zh.md:36–46` 已说明 MLDG 同型目标、MER/La-MAML 的近邻关系，完整二阶不是新原理。最新用户和 `VALIDATION:3,15–21,50` 明确先候选、后机制对照，优先于 prior 里较早的四条件建议。效果若好，只能先支持整体候选值得追查，不能自动支持二阶或整群隔离的独立作用及原创性。

## 三、未来正式入口必须核对的实际差异

这些是**未来正式接入的最小验收事项**，不等于本轮已存在的新缺陷。当前没有 formal runner，不能把尚未实现的调用顺序描述成已犯错。

| 事项 | 必须如何核对 | 本包具体依据与限制 |
|---|---|---|
| 共同首域状态 | 从每顺序合法留存的 after1 完整文件恢复 model、全部 Adam 状态/组映射、计数 288、CPU/CUDA RNG、首映射和六群 LOGIT memory；校验实际加载结果，不能只比较文件 SHA，也不能重新初始化 Adam。 | `step28_continual_population.py:193–209` 已有加载后 model/optimizer digest 核对；`step28_bge_continual_run.py:230–240` 有首域计数和 RNG 恢复。GPU 手写的 warm 后将计数 1 改 288（gpu_check:120–126）不是这些真实历史矩的复用证据。 |
| 模型加载与运行配置 | 用元路径显式 eager、FP32、checkpoint 关闭的 loader，再加载旧完整状态；保留旧来源 metadata 与新执行配置的分别记录。不能把新配置写回旧来源以制造共同配置。 | 元 loader 为 `step28_group_meta.py:20–40`。旧 `restore_branch` 的第 231 行调用的是 `base.load_model`；后者没有显式 eager 参数（`step28_chinese_base.py:110–131`）。因此不能不加判断地将旧函数原样当成已完成新入口。 |
| 精度/预测与状态恢复分开 | 模型/Adam 字节恢复、在同一新配置下重复计算一致、旧配置与新配置预测差异，是三个不同问题。旧新预测不同不自动证明状态恢复错误；反过来状态相同不证明预测/后续训练完全配对。 | 旧 schema 的 `encoder_bf16=true, activation_checkpointing=true, microbatch=4`（`schema/step28_chinese_base_policy.json:84–86`）；旧编码器是 `torch.autocast(..., dtype=torch.bfloat16)`，其输出转 float32（base:201–215）。**本包证明的是 BF16 autocast，不应写成旧 FP16。** 新 GPU 设 microbatch32（gpu_check:102）、FP32/eager/无 checkpoint。 |
| 随机流 | 保留首域完整 RNG；继续原当前/support 供给随机流与新增 query 流的固定派生；将角色内 fork_rng 的作用和 microbatch 对 dropout 消费分组的变化报告清楚。检查核验、评估不提前消耗训练 RNG。 | `step28_bge_continual_run.py:58–73,163–177,204–205`；meta `149–155,234–246`。即使 seed 相同，microbatch4→32 的随机数消费与 padding/归约形状可变，不能称旧训练逐位配对。 |
| 历史 logit 生命周期 | 首域旧保存 raw logits 继续按其原值绑定 Hs UID/378边顺序；不按新 FP32 路径刷新旧幸存参考。阶段 2 后只为新进入六群缓存的当前群，用候选该阶段末的 eval 模型、约定配置产生 float32 raw logits；删除被淘汰群及参考，不重读。 | `Memory.retain`（bge_continual:130–154）只给 newcomers 评分；`base.score:223–229` 是 eval/inference 路径；meta reference 校验 `69–86`、MSE 位置 `161–167`。缓存用 float32 存储不表示来源推断本来就是 FP32，旧 BF16 输出的 float32 存储与新 eval 输出不应混淆。 |
| 记忆随机流与 1MiB | 复用原 Algorithm R seen/槽位/retention RNG、support draw 计数/状态及首映射；Hq 从存活其余五群选。所有持久方法设置和 RNG/map 状态计入同一个序列化额度。CAB 无首域幸存群的既有事实保留，不为了算法改重抽。 | `Memory.to_bytes/from_bytes:171–209`、meta `223–252`；CAB 是本包 prior 主审 `40` 的既有观测，本分项没有重新读取正式缓存独立复算。 |
| auxiliary 合并 | 阶段末必须合并并保存新的 group_meta 设置/日程和 checkpoint metadata，不能悄悄覆盖掉元方法状态。 | meta `250–252` 新写 `memory.auxiliary['group_meta']`；旧 runner `457` 是整字典赋值 `memory.auxiliary = point['learner_auxiliary']`。若未经适配照搬，会丢失新增元设置。这是明确的未来代码接入注意点，当前没有该 formal 调用路径，不能定性成当前已经发生的再现缺陷。 |
| 阶段与成本口径 | 冻结 ABC/BCA/CAB、阶段 2/3 各 288 更新、总 1728 真正 optimizer step，正 beta 为 6912 群梯度呈现，外层 Adam 计数连续；单步图构建/HVP/重计算另记时间。 | GPU 合同 `35`；meta `180–209,230,253–254`。旧两群 LOGIT 对应 3456 群呈现，不能表述成相同计算预算；stage1 仍复用旧结果。 |
| 评价与已开放 LOGIT0.1 对齐 | 核对合法旧结果的精确来源、相同 domain/group/query/candidate 顺序、首域/阶段映射、raw/stage-cal/first-cal 角色和指标/计数版本。候选 6 个终点与 18 套输出完整落盘后再开新 valid 标签；不得把已开发 valid 改名成独立 test。 | 旧 blind gate/expected endpoints 针对旧 arms 写死（bge_continual_run:244起；evaluate:19–28），不能直接改标记为通过。旧 O/N/Z 明确定义在 evaluate:101–106；primary 排序用 raw、识别用 stage-cal（113–115）。按验证计划保留旧域最终、新学完域、最终最新域及逐域识别取舍。 |
| 先导判据与授权 | 在新结果开放前固定主要观察量、可接受的新域/识别取舍、继续/停止规则、失败计费和明确总资源预算；对公开旧 LOGIT 只能作开发参照，不要求现在重训。 | VALIDATION `17–21,23–33,50`。手写授权 `formal_data=false, old_experiment_weights=false`，当前没有正式读数许可、运行器与可测完成时间，不能借余量先试正式群。 |

旧首域状态/参考的复用可以成立，即使新程序的数值配置不同；必须诚实界定成立的是“同一保存状态起跑”，不是“只有元目标一个变量改变”。新 FP32/eager/microbatch32 带来的预测及随机流差异均属开发比较限制。若后续资源方案包含重计算，还须说明其等价性验证、角色随机状态保持和实际 fast 参数传入，而非直接宣称等价。

## 四、分类与不应扩大范围的事项

- **SCIENTIFIC_BLOCKER（本轮结论边界）**：原生资源门未通过且无 formal runner/正式合同，不能发正式训练准入；不能声称 BGE GPU 二阶成功或算法效果失败。参数固定点自身未发现另一个科学阻断。
- **REPRODUCIBILITY_DEFECT（本分项现状）**：没有发现已经发生的新的参数/正式恢复缺陷。未来若覆盖 auxiliary、刷新旧 targets、伪称旧新分数逐位配对或只恢复计数，这才是具体缺陷；当前只能列入口验收要求。
- **后续建议**：一次成功的原生资源核验可顺便记录块位移/Hessian 校正与总梯度的比例；有利于解释该固定率实际强弱，但不能以此自动开展参数搜索。
- **过度设计**：现在强制先训练四个对照、重训旧 LOGIT/risk、扩展历史全集 UID 档案、新建教师、访问 owners/test 或新正式群以探内存、把对未来故障的全部猜想升级成当前阻断，均超出本增量范围。

## 五、本分项实际执行记录

实际执行：用标准库逐行读取上述文件；有针对性检索/追踪 model/Adam/RNG 恢复、precision/microbatch、reference retain/draw/score、auxiliary 覆盖和评价公式；读取三次 GPU 原始 stdout、退出码、墙钟、offload budget_stop 及 result 是否存在。参数分析为上述精确公式的代数展开，没有数值训练。

未执行：PyTorch/BGE、CUDA、服务器连接、正式或手写新训练、旧权重/缓存恢复、正式数据/标签/owners/test 访问、LOGIT0.1 数值结果重算或先导效果评测。本分项不以文件存在、执行者 PASS 或旧证据数量替代这些未完成事项。
