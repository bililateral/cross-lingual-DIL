# GPU入口与二阶语义分项审查

## 裁决范围与结论

本分项逐行阅读当前GPU检查器、包装脚本、元目标与更新函数，读取三次尝试的stdout/stderr/result或budget_stop原件，并把本包prior作为已关闭背景核对。没有重审旧数据/损失/记忆体系，没有运行Torch、CUDA或BGE，没有接触正式数据、旧实验权重或凭据。

结论：本轮GPU入口确实调用当前完整二阶实现，没有发现本轮偷偷detach内层梯度、改为只训练head、只计算两群或减少候选的确定缺陷。`save_on_cpu`改变保存供反向使用的张量位置，不以其名称为正确性证明；当前Tiny实际证据支持指定微型模型的数值梯度和真实Adam更新与直接路径一致，但原生BGE两条路径均未完成一次元更新。因此不能授予BGE GPU完整更新或正式训练准入，也不能把资源失败解释为算法效果失败。

发现一项确定且很窄的文案缺陷：GPU合同写“未适应query的一阶梯度”，本轮实际残差针对的是在快参数处求值、但停止内层梯度传播的一阶替代。建议归`REPRODUCIBILITY_DEFECT`，仅需勘误，单独不构成资源准入阻断。

## 1. 源码身份及真实调用链

独立AST比较表明，当前`step28_group_meta.py`相对prior原始实现中的`load_model`、`Settings`、`Episode`、`lookahead`、`GroupScorer`、`objective`、`update`完全同构；只有`train_stage`不同，对应primary_review已经关闭的beta0群呈现计数修正。不能笼统宣称两份完整源码字节相同。当前GPU检查器、元方法、包装脚本与tiny_first/direct_first/offload_first三个实际目录中的同名快照全部字节一致。

实际调用为包装脚本79–80行启动检查器；检查器139–141行在可选`save_on_cpu`上下文内调用`method.update`；元方法188–189行构造同一个`objective`再执行`loss.backward()`；201–205行统一clip一次并执行一次真实AdamW step。没有另一个GPU版元算法替代原函数。

原生检查器的warm是`parent.update(..., "seq", stage=1, step=1)`一次真实普通更新，之后把计数1显式置为288；这只构造连续Adam计数夹具，既不模拟288步真实首域训练，也不恢复旧实验动量。其后计划两次元更新，实际两个原生尝试都停在第一次元更新返回之前。

## 2. 原目标与二阶路径

`step28_group_meta.py:161–176`实际支持目标是：

\[
L_s=L(C_s;\theta)+0.1L(H_s;\theta)+0.5\operatorname{MSE}(z(H_s;\theta),z^*_{H_s}),
\]

查询目标是：

\[
L_q=L(C_q;\theta')+\rho L(H_q;\theta'),\qquad
\theta'=\theta-A\nabla L_s(\theta).
\]

支持历史监督系数0.1、独立MSE系数0.5、查询历史系数rho各在自己的位置；没有把MSE再乘0.1或rho。`lookahead:106–109`使用`autograd.grad(..., create_graph=True)`，快参数由`value - rate * grad`形成，没有对grad使用detach。`objective:143–144`根据`model.encoder.`前缀使用encoder内层率，其余注册参数使用head率。内层率为固定对角/分块矩阵A，真实外层仍为普通AdamW，不能叫Adam前瞻。

局部可微处，实际目标的梯度应为

\[
g_J=g_s+\beta\left(g_q-H_s^{\mathsf T}A^{\mathsf T}g_q\right),
\]

其中gq在theta'处求值。A固定且对角时为`gs + beta*(gq - Hs*A*gq)`。异率时必须保持此乘法次序，不能把它改为`A*Hs*gq`。这也是后续若使用显式HVP重排计算所必须保留的项。本分项没有独立在BGE上计算该式。

## 3. 四群和全参数的准确含义

`Episode.validate:69–86`保留四个完整、监督且群ID/账号/商品互斥的群；`objective:162–172`在正beta时实际前向四角色。GPU原生夹具105–119行构造四群，每群28账号、99商品，标题/描述共198段文本，既有完整378条无向关系与每查询27候选结构未削减。文本microbatch32只改变编码分块，不删除群内文本；`base.account_vectors:203–216`最终合并全部microbatch再计算账号表示与完整关系。

`objective:138–141`以全部注册参数构造参数字典，并拒绝其中任何冻结参数；`core.make_optimizer:32–40`将encoder和head完整参数分别交AdamW。`update:191–205`检查两模块有有限非零梯度，统一clip并step，没有head-only分支。

“全参数”因此在这里是没有人为冻结、筛选训练子集且全注册参数交给优化器；不应扩大成“原生BGE每个参数元素都已测得非零梯度/变化”。数值上未使用的参数可能grad=None，激活分支也可产生零梯度；本轮原生失败根本没有产生完整更新证据。Tiny的所有参数梯度比较不能替代BGE所有参数的检查。

## 4. functional_call、buffer与随机流

`GroupScorer`把模型作为注册子模块，参数字典使用`scorer.named_parameters()`，所以键与嵌套实际模块路径吻合。`torch.func.functional_call(scorer, (params, buffers), ..., strict=True)`要求提供的参数和buffer集合匹配；快参数不是通过复制普通模块、load_state_dict或optimizer.step来构造。`base.account_vectors`仍从正在调用的model取参数设备，并调用同一个encoder和pair head，没有在此绕过函数式参数。

buffer在142行`detach().clone()`，避免常规原地buffer更新直接污染原模型；但同一份buffers字典被四个角色共享。官方文档明确指出被调模块对参数/buffer的原地操作会反映到输入字典，所以“clone+functional_call”不能单独保证任意含可变buffer模型的角色完全隔离。当前已知BERT路径采用LayerNorm/静态索引buffer而非BatchNorm式运行均值，源码和原件没有给出实际buffer污染证据。这里是后续改变模型结构时应保留的语义条件，不是本轮已证BGE缺陷，也无需新建通用状态框架。

每角色前向在153–155行使用`fork_rng`并设置四个显式seed，CUDA_VISIBLE_DEVICES只露出GPU0；因此当前角色随机流在上下文结束后恢复调用方CPU/GPU0状态。关闭checkpoint使反向不会在函数式参数作用域之外重跑普通module而错用原权重。当前CPU暂存只保存/取回张量，不触发前向重算，因此没有新增的checkpoint快参数问题。

注意：本轮Tiny两路径终态一致并不独立排除二者共同存在的目标错误；prior的已关闭数学和神经检查才是直接背景。也不能把Tiny终态一致说成已逐字节检查原生BGE全部buffer/optimizer虚拟过程不变。

## 5. save_on_cpu能与不能证明什么

已通过浏览实际读取官方PyTorch v2.9.1 `torch/autograd/graph.py`，`pin_memory=False`时pack返回原设备与`tensor.cpu()`，unpack把保存值送回原设备。该版本代码没有按存储地址去重。本包报告的运行版本为2.9.1+cu130；官方标签源码是语义依据，不是安装目录逐字节认证。

GPU检查器25–26行可选上下文覆盖139–141行的整个update，因此支持前向、`create_graph=True`形成梯度图的计算、query前向以及外层backward都在该上下文内。原参数和Adam状态仍在原设备，快参数仍由相同可微表达式组成。保存张量到CPU本身不能类比为“对内层grad.detach()”；图边和保存的数值是不同层面的对象。

官方API要求unpack重建相同值/尺寸/dtype/device，且支持在backward或autograd.grad需要时取回。它提供了正确实现所依据的机制，但不能替代本项目真实版本/算子图的二阶核验。这里最强的新增直接证据是Tiny的全部参数梯度、模型及Adam状态两路径数值接近；BGE未完成，BGE双反向/资源峰值仍未知。

重复权重或中间值在多个microbatch中每次被save时，逐次tensor.cpu可能制造多个主存副本，技术上足以解释为何“offload显存很小但RSS很大”并非矛盾；但没有逐tensor归因，不能宣布它已被测明是本次128GiB超限的唯一原因。也不能保证仅启用去重就一定在128GiB以内完成全部元更新。

## 6. Tiny一致性与Hessian残差

检查器55–60行在两条路径前恢复同一模型与Adam状态；62–66行分别求support对原参数的梯度、query对fast的梯度、完整目标对原参数的梯度；74–80行另行构造目标并真实update，然后比较完整目标、所有参数梯度、模型state_dict和Adam state_dict。比较为rtol=1e-5、atol=1e-7，不能表述为所有张量逐位相同。原件两条路径的模块校正平方范数恰好相同，不改变上述一般容差。

记录的残差为：

\[
r=g_J-g_s-\beta g_q(\theta').
\]

这正针对“同一个数值theta'，但忽略theta'中gs对theta的依赖”的一阶内层stop-gradient替代。原件encoder平方范数`1.724615970033483e-7`、head平方范数`0.0011961045383941382`都超过代码阈值1e-14，两个模块都可区分该变体。测试没有单独构建运行一个detach变异模型，而是用代数残差检验其应有梯度差；不能夸大成所有伪实现变体都已逐个运行和排除。

合同条目1的“未适应query”不准确：真正未适应query应在theta而不是theta'处求值。独立Decimal标量例子给出精确梯度0.1064、在快参数处内层stop-gradient梯度0.308、未适应query梯度0.21，清楚说明两类对照不同。这个示例只是澄清语义，没有替代Tiny/BGE自动微分检查，也没有选择正式系数。

建议最小勘误为：`并与内层梯度stop-gradient的一阶替代区分（query仍在数值快参数处求值）`。补丁仅为拟议文案修正，未覆盖输入文件；implementation已用“内层detach的一阶替代”，无需改变其主结论或重跑资源尝试。

Tiny实际三次更新是warm、direct meta、恢复同一起点后的offload meta；两个元更新彼此并非连续状态，所以不能把tiny actual_updates=3理解为从一次warm连续训练两步的证据。原生本来计划连续两步，但两条路径实际都未完成第一步。

## 7. 原生失败边界与已证缺陷分级

direct原始traceback明确停在`lookahead:103 support(parameters)`里的`support:163 forward(params,1)`，最终为BERT历史support前向GELU分配失败。此时当前support已完成、历史support未完成，`autograd.grad(create_graph=True)`、query、外层backward和元Adam step都尚未执行。不能推断“只需再42MiB就会跑完”。

offload stdout只有warm_start和第一元更新start，budget_stop显示超RSS警戒；没有Python traceback或result，所以无法定位是support前向、内层梯度图、query还是最终backward中的哪一步。能确定warm返回之后已经进入元更新，不能确定完成了哪个更细子阶段。不能把88秒当一次元更新耗时或按它估计正式1728步总时长。

分级建议：

- `SCIENTIFIC_BLOCKER`：BGE GPU资源准入尚未成立、效果主张与正式训练准入无证据。这不是已证算法机制错误；保持精确目标的其他工程实现在该预算内能否成功仍未知。
- `REPRODUCIBILITY_DEFECT`：上述“未适应query”文案错误。最小勘误即可，不把它升级为必须重训或重跑BGE的阻断。
- 后续建议：下一等价实现保留全参数、四群、dropout种子/文本分块、引用目标、clip/Adam次序，并对其完整梯度与更新做直接/独立参考比较；原生资源证据仍需完成实际更新后再评估正式预算。
- 不应新增的过度设计：重新审查已关闭全部基础体系、全参数有限差分、强制现在先跑四条件机制对照、重读封存数据证明泛化、以静态hash/PASS数充当BGE运行证明。

## 8. 本分项独立执行证据与文献访问

实际执行`gpu_semantics_static_audit.py`，退出0、stderr为空：完成核心方法AST对比、9个实际运行源码快照字节对比、Tiny校正值和阈值原件复核、三种标量梯度的Decimal计算，以及精确文案补丁生成。所有神经更新次数为0。工具执行过程中没有下载/安装Torch，也没有尝试联系Linux主执行服务器。

输出：

- `gpu_semantics_evidence/result.json`：机器可读静态和标量计算证据，显式标记没有Torch/BGE执行，也没有独立重算Tiny原梯度。
- `gpu_semantics_evidence/proposed_contract_wording.patch`：未应用到输入的最小勘误。
- `gpu_semantics_static_stdout.txt`、`gpu_semantics_static_stderr.txt`：实际运行输出。

实际读取的官方资料（root如需在正文用网页引用，应自行open/find这些URL）：

1. PyTorch v2.9.1 graph.py：<https://github.com/pytorch/pytorch/blob/v2.9.1/torch/autograd/graph.py>。网页来源turn4view0/turn5view0，已定位`pack_to_cpu`/`unpack_from_cpu`；用途为源码语义，不是原生成功运行证明。
2. PyTorch 2.9 autograd：<https://docs.pytorch.org/docs/2.9/autograd.html>。网页来源turn4view3/turn5view2/turn5view3；已读saved_tensors_hooks/save_on_cpu及double-backward说明。
3. PyTorch 2.9 functional_call：<https://docs.pytorch.org/docs/2.9/generated/torch.func.functional_call.html>。网页来源turn4view2/turn5view1；已读参数/buffer替代、原地更新与严格匹配语义。
4. 另看官方saved tensors教程作为交叉背景：<https://docs.pytorch.org/tutorials/intermediate/autograd_saved_tensors_hooks_tutorial.html>；最终语义以2.9/v2.9.1为准。

保留访问限制：两条raw.githubusercontent.com v2.9.1直链被工具拒取；随后GitHub网页graph.py成功，saved_variable.cpp网页仍失败。没有把未能读到的v2.9.1 SavedVariable C++具体实现声称已读。未使用社区回答作技术裁决依据。
