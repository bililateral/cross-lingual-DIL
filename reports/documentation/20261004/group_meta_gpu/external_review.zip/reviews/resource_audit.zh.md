# GPU 增量资源证据独立审查

本分项只核对本包新增的 GPU 合同、授权、包装、实际三次尝试、源码/回传清单和相关报告。没有运行 BGE/GPU、没有连接原 Linux 环境、没有读取正式数据或旧权重。实际独立执行：15 份 Python 来源的 AST 解析、Bash `-n`、21 份来源与 42 份回传载荷的字节/SHA 检查、三个时间段和全部资源阈值的重算。可复算程序为 `resource_recompute.py`，输出为 `resource_calculations_recomputed.json`。

## 裁决

**本包支持“当前两条原生实现尚未获得 GPU 资源准入”；不支持“BGE GPU 二阶更新通过”，也不支持“算法效果失败”或“任何等价实现在该设备都不可能运行”。** Tiny CUDA 提供的是小模型上的实现一致性证据。原生 direct 明确在首个元更新的历史支持群前向时 OOM；offload 由 RSS 警戒触发终止，只留下首个元更新开始标记，未留下完成标记或成功 `result.json`。

### 问题分级

| 分类 | 本分项判断 | 是否阻断本轮增量审查 |
|---|---|---|
| SCIENTIFIC_BLOCKER | 原生完整元更新未完成资源核验，无法取得真实完整更新耗时/峰值并据此安排正式预算；资源准入保持关闭。它是正式接入的证据门，不是已证目标/梯度算法缺陷。 | 阻断正式训练准入，不阻断完成本次失败审查。 |
| REPRODUCIBILITY_DEFECT，文案 | GPU 合同第 15 行把 Tiny 比较对象写成“未适应 query 的一阶梯度”；代码实际比较已适应参数下、截断内层梯度的一阶替代。`implementation.zh.md:19` 的表述正确。 | 否，改正文案即可。 |
| REPRODUCIBILITY_DEFECT，证据保存 | 21 来源“在 Linux 逐文件匹配”、Linux AST/Bash 输出、CPU47 两秒空闲原采样、16:11:36 中途显存/RSS、16:14 GPU 空闲原记录未随新增原始证据保存。报告把它们写成观察，但本包独立审查只能将这些列为执行者陈述。 | 否，不改变 OOM 与 RSS 终止这两个已有原证据的结论；无需为这些补跑原生。 |
| 后续建议 | 下次同定义工程核验在昂贵计算之前保存有效配置/输入形状，在 support、inner-grad、query、outer-backward 等边界输出简短进度，保存已有资源实查 stdout。 | 非本轮阻断；用于下次失败定位，避免重复原生计算。 |
| 过度设计 | 为此次已停止的失败要求 cgroup 重构、完整进程审计体系、正式数据读取、重做旧基础、四条件训练或任意内存上限搜索。 | 不要求，不扩展范围。 |

## 原始三次尝试：重算结果

| 尝试 | 原始当地时间（UTC+8） | 包装秒数 | Python 内部计时 | 退出状态 | 可确认进度 |
|---|---|---:|---:|---:|---|
| tiny_first | 16:09:35–16:09:39 | 4 | 2.145142300054431 秒 | 0 | warm + direct meta + 恢复同一起点后的 offload meta，均为 Tiny；目标、所有参数梯度、模型与 Adam 状态比较通过。 |
| direct_first | 16:10:16–16:10:25 | 9 | 6.796184990089387 秒 | 1 | warm 已返回、reference 已计算，进入首个 meta；在历史 support 前向内 OOM。 |
| offload_first | 16:11:03–16:12:31 | 88 | 无最终 Python result | 124 | warm 已返回、reference 已计算，进入首个 meta；elapsed=81 秒采样触发 RSS 终止；后续清理至 finished 共 88 秒。 |

直接证据：各尝试 `started.txt:1`、`finished.txt:1`、`seconds.txt:1`、`exit_status.txt:1`；两次原生的 `stdout.txt:1–2`；direct 的 `stderr.txt:3–74`；offload 的 `budget_stop.txt:1` 与 `evidence/reports/offload_wrapper.log:1`。这三次快照脚本均与当前根目录三份脚本字节相同。

4+9+88=101 秒，剩余 3600−101=3499 秒。第一次启动至最后退出的连续日历区间是 176 秒；两次尝试间有 75 秒间隙。包中清楚采用“各包装运行墙钟之和”的预算口径，不能把 101 秒说成完整连续日历跨度，也不能把它当原生单步时间。内部 Python 计时从 `gpu_check.py:173` 开始，包装还覆盖进程导入与退出等待，二者不同并不矛盾。

原生 warm 确已经过 `gpu_check.py:123` 调用并返回，才会进行计数置换、计算 reference，再打印第 138 行的 meta 开始标记。将 Adam step=1 改为 288 是显式夹具（第 124–125 行）；这没有证明恢复过旧首域 Adam 状态，也没有声称真实执行了 288 次 warm。

## OOM 位置和内存事实

### direct

`direct_first/stderr.txt:8–17` 的栈为 `update → objective → lookahead → support → forward(params,1) → functional_call`；`step28_group_meta.py:161–167` 中该 role=1 是历史支持群。在支持总损失返回前，`lookahead:106–107` 的 `create_graph=True` 内层求导尚未调用，因此当前次原生失败不能覆盖 query 或完整 Hessian 反向。

`stderr.txt:66–74` 显示在 BERT intermediate activation/GELU 申请 42 MiB 失败。`direct_first/result.json:1` 的精确数值重算为：

| 项目 | 原值 | 二进制单位 |
|---|---:|---:|
| 最后区间 allocator allocated 峰值 | 28,248,230,400 bytes | 26.30821466445923 GiB |
| 最后区间 allocator reserved 峰值 | 30,058,479,616 bytes | 27.994140625 GiB |
| 原进程 ru_maxrss | 2,650,692 KiB | 2.5278968811035156 GiB |

报错文字同时明确 `28.00 GiB allowed`、设备报告容量约 31.36 GiB、尚有 2.67 GiB free。这里的“32GiB 显卡”是设备名义描述，运行时实际可见容量应按报错/设备查询记录。`gpu_check.py:171` 用 `28*2**30 / total_memory` 设置 allocator 限额；该限额不能等同全部进程显存。剩余物理显存与下一次申请 42 MiB 都不能给出完成元更新所需的总内存估计。错误消息的通用碎片化提示也不等于已定位本项目只需修改 allocator 配置。

### offload

`budget_stop.txt:1` 原值：elapsed=81，rss_kib=134863072，available_kib=123168432，evidence_bytes=115064。独立重算为：

- RSS 128.61544799804688 GiB，超过 128 GiB 警戒 0.615447998046875 GiB（630.21875 MiB）。
- 主机 MemAvailable 117.46257019042969 GiB，未触发低于 16 GiB 的停止条件。
- 证据目录约 0.10973358154296875 MiB，未触发 128 MiB 输出条件。
- elapsed=81 < remaining_seconds=3587，未触发时间条件。

据包装第 88–91 行，这一采样唯一触发条件为 RSS。第 62–64 行执行 `kill -KILL` 后等待；`offload_wrapper.log:1` 是包装第 64 行的 killed 子进程报告。exit124 是包装预算退出状态，不是 CUDA 异常类型，也不是原生模型主动返回的算法错误。

采样是 `ps` 获取的单进程 RSS，循环包含 `sleep 1`（第 83–93 行）；并非内核硬隔离，也没有全部采样序列。可确认这次触发采样值，不能把 128.615 GiB 标成精确最大 RSS，也不能证明没有短时更高值。

offload 被 SIGKILL，没有 Python traceback 和成功 `result.json`。原始记录只能定位“已进入第一次 method.update 且未留存其返回完成记录”；不能进一步指定停在 support、内层梯度、query 或 outer backward 中哪一个子阶段。支持本包结论的稳妥表述是“无已完成首个原生元更新的证据”，不能据此宣称完整反向已通过。

`implementation.zh.md:23` 的 16:11:36 RSS=35,651,780 KiB 与 GPU=5943 MiB 中途观察没有相应原始快照。报告可明确标成执行者观察，不宜当作独立测得值来作逐张量主存归因。“可能存在重复权重/中间张量副本，但没有逐张量归因”这个边界是恰当的；当前证据没有证明重复副本是唯一原因。

## 包装、授权和边界

`authorization.json:2–13` 把范围固定为 handwritten_only、3600 秒、128 GiB RSS 警戒、28 GiB allocator、128 MiB 输出，并明确 formal_data=false、old_experiment_weights=false。包装：

- 第 13–26 行从此前 `seconds.txt` 累计预算，拒绝没有结算文件的旧尝试；实际三个 remaining 值依次为 3600、3596、3587。
- 第 37–43 行最多四次尝试，native 要求 Tiny 已 PASS，offload 要求此前 direct 的 CUDA OOM；实际顺序符合授权的 tiny/direct/offload，未见第四次或修复重试。
- 第 45–49 行要求 GPU 空闲不少于 30720 MiB（30 GiB）、无其他计算 PID，主机 MemAvailable≥150994944 KiB（144 GiB）。三个 `resources.txt:1` 均记录 GPU 32063 MiB 和主机约 245 GiB，满足记录中的数值门。
- 第 73–80 行 GPU0、单线程环境、CPU affinity 及离线加载；Tiny/direct 的 result 实际记录 CPU affinity=[47]、Python3.10.19、Torch2.9.1+cu130、CUDA13.0、RTX5090。offload 无最终 result，环境相同是同一脚本路径的推断，不是假称拥有额外输出。

包装中的 GPU 无其他计算 PID 门是代码实设，但未保存其原始查询输出。CPU47 是否在前两秒完全空闲是外部检查，本包装只接收已检查 CPU 参数；其 200/200 jiffies 采样未保存。`implementation.zh.md:13` 的 16:14 利用率 0 同样只有叙述。以上不是已证资源违规；应区分来源证据强弱，不要求用封存数据或新训练补证。

## 清单复算能证明什么

根 `source_inventory.json` 的 21 项全部与本包对应载荷大小/SHA 一致，总载荷 329,891 bytes；`evidence/reports/source_inventory.json` 与根清单逐字节相同。三个 run 各保存入口、核心和包装三份脚本，它们分别与根源码逐字节一致。回传清单 42 项全部匹配其已展开载荷，总 103,075 bytes。没有差项。

这支持“本包来源及执行快照自洽”。单独一份源清单不能证明原服务器 21 个来源都经过实际读取与哈希比对，因为本包没有部署检查 stdout；不可把本地匹配等同独立重跑 Linux 部署验证。`implementation.zh.md:27` 提到的历史 `returned.zip` 压缩原档不在本包，只给了其展开载荷和清单，因此 44,223 bytes / e834…db7 压缩档身份本分项未独立计算；42 项展开载荷已核对，足以复查当前失败事实。

我在本会话当前执行环境重新做了 15 份 Python AST 解析和 Bash `-n`，全部通过。此事验证可读源码语法，不可表述为重新执行了 Linux py310 原生 BGE 或原环境语法命令。

## Tiny 结论用语的精确修正

`gpu_check.py:64–73` 计算 `support_gradient = ∂Ls/∂theta`、`query_gradient = ∂Lq/∂phi`，再检查完整梯度减去 `support_gradient + beta*query_gradient` 的非零量。phi 是已经过内层适应的 fast 参数。因此检查的是删除内层 Hessian 路径、保留适应点 phi 的一阶替代；不是在原 theta 计算未适应 query。两次修正平方范数在 encoder/head 分别为 1.724615970033483e-7 与 0.0011961045383941382，超过第 72 行的 1e-14 阈值，且直接/暂存结果相同。

合同第 15 行建议只改成：“并与截断内层梯度、仍在适应后参数计算 query 的一阶替代区分”。这是文案纠正，不更改代码目标、随机流、参量或数值结果，也不重开旧基础审查。
