"""Recompute only submitted resource/manifest facts; no torch or formal inputs.

Usage: python resource_recompute.py EXTRACTED_REVIEW_ROOT OUTPUT_JSON
"""
from pathlib import Path
from datetime import datetime
import argparse
import ast
import hashlib
import json
import subprocess


def verified_payloads(items, base):
    verified = []
    for row in items:
        value = (base / row["path"]).read_bytes()
        digest = hashlib.sha256(value).hexdigest()
        verified.append({"path": row["path"], "bytes": len(value), "sha256": digest,
                         "bytes_match": len(value) == row["bytes"],
                         "sha256_match": digest == row["sha256"]})
    return verified


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    sources = json.loads((root / "source_inventory.json").read_text())
    returned = json.loads((root / "evidence/reports/returned_inventory.json").read_text())
    runs = []
    for name in ("tiny_first", "direct_first", "offload_first"):
        path = root / "evidence/evidence" / name
        start = datetime.fromisoformat((path / "started.txt").read_text().strip())
        end = datetime.fromisoformat((path / "finished.txt").read_text().strip())
        resources = dict(item.split("=") for item in (path / "resources.txt").read_text().split())
        row = {
            "name": name, "started": start.isoformat(), "finished": end.isoformat(),
            "wall_seconds": (end - start).total_seconds(),
            "recorded_seconds": int((path / "seconds.txt").read_text()),
            "exit": int((path / "exit_status.txt").read_text()), "resources": resources,
            "source_copies_equal_to_root": {
                filename: (path / filename).read_bytes() == (root / "scripts" / filename).read_bytes()
                for filename in ("step28_group_meta.py", "step28_group_meta_gpu_check.py",
                                 "run_step28_group_meta_gpu_linux_20261004.sh")
            },
        }
        if (path / "result.json").exists():
            result = json.loads((path / "result.json").read_text())
            row.update(reported_python_seconds=result["seconds"],
                       peak_rss_gib=result["peak_rss_kib"] / 2**20,
                       gpu_last_interval_peak_allocated_gib=result["last_interval_peak_allocated_bytes"] / 2**30,
                       gpu_last_interval_peak_reserved_gib=result["last_interval_peak_reserved_bytes"] / 2**30)
        if (path / "budget_stop.txt").exists():
            stop = {key: int(value) for key, value in
                    (item.split("=") for item in (path / "budget_stop.txt").read_text().split())}
            row.update(
                budget_stop=stop, stop_rss_gib=stop["rss_kib"] / 2**20,
                stop_rss_overshoot_gib=(stop["rss_kib"] - 128 * 2**20) / 2**20,
                stop_rss_overshoot_mib=(stop["rss_kib"] - 128 * 2**20) / 2**10,
                stop_memavailable_gib=stop["available_kib"] / 2**20,
                stop_output_mib=stop["evidence_bytes"] / 2**20,
                triggered_by={"remaining_time": stop["elapsed"] >= int(resources["remaining_seconds"]),
                              "rss": stop["rss_kib"] > 128 * 2**20,
                              "memavailable": stop["available_kib"] < 16 * 2**20,
                              "output": stop["evidence_bytes"] > 128 * 2**20},
                cleanup_seconds=row["wall_seconds"] - stop["elapsed"])
        runs.append(row)
    python_files = [root / row["path"] for row in sources if row["path"].endswith(".py")]
    for filename in python_files:
        ast.parse(filename.read_text(), filename=str(filename))
    syntax = subprocess.run(["bash", "-n", str(root / "scripts/run_step28_group_meta_gpu_linux_20261004.sh")],
                            capture_output=True, text=True)
    report = {
        "scope": "Independent parsing/hash/unit arithmetic/AST/Bash syntax only; no GPU or formal data",
        "source_inventory_count": len(sources), "source_inventory_payloads": verified_payloads(sources, root),
        "root_and_returned_source_inventory_byte_equal":
            (root / "source_inventory.json").read_bytes() == (root / "evidence/reports/source_inventory.json").read_bytes(),
        "returned_inventory_payloads": verified_payloads(returned, root / "evidence"),
        "returned_payload_count": len(returned), "runs": runs,
        "total_wrapper_seconds": sum(row["wall_seconds"] for row in runs),
        "remaining_budget_seconds": 3600 - sum(row["wall_seconds"] for row in runs),
        "first_start_to_last_finish_seconds":
            (datetime.fromisoformat(runs[-1]["finished"]) - datetime.fromisoformat(runs[0]["started"])).total_seconds(),
        "current_environment_syntax_check": {"ast_file_count": len(python_files), "all_ast_parse": True,
                                             "bash_n_exit": syntax.returncode,
                                             "bash_stdout": syntax.stdout, "bash_stderr": syntax.stderr},
        "unpreserved_primary_observations": [
            "Linux source deployment verification stdout", "Linux AST and Bash syntax verification stdout",
            "CPU47 two-second 200/200-jiffies idle raw samples",
            "offload 2026-10-04 16:11:36 intermediate RSS/GPU raw sample",
            "2026-10-04 16:14 final GPU zero-utilization raw sample"],
        "limits": {"allocator_gib": 28, "rss_warning_gib": 128, "initial_gpu_free_gib": 30,
                   "initial_host_memavailable_gib": 144, "host_memavailable_stop_gib": 16, "output_mib": 128},
        "no_submitted_native_meta_completion_record": True,
    }
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"source_passed": sum(x["bytes_match"] and x["sha256_match"] for x in report["source_inventory_payloads"]),
                      "returned_passed": sum(x["bytes_match"] and x["sha256_match"] for x in report["returned_inventory_payloads"]),
                      "seconds": report["total_wrapper_seconds"], "remaining": report["remaining_budget_seconds"],
                      "ast_files": len(python_files), "bash_exit": syntax.returncode}, ensure_ascii=False))


if __name__ == "__main__":
    main()
