"""Independent source/record audit only; this program does not import Torch.

No production neural target or update is executed. The scalar arithmetic below
explains the exact meaning of the recorded Hessian residual, not a BGE test.
"""
from __future__ import annotations

import ast
from decimal import Decimal
import difflib
import hashlib
import json
from pathlib import Path
import platform
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / "review7_extracted"
OUT = Path(__file__).with_name("gpu_semantics_evidence")
OUT.mkdir(parents=True, exist_ok=True)


def functions(source: str) -> dict[str, str]:
    return {
        node.name: ast.dump(node, include_attributes=False)
        for node in ast.parse(source).body
        if isinstance(node, (ast.FunctionDef, ast.ClassDef))
    }


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


current = (SOURCE / "scripts/step28_group_meta.py").read_bytes()
with zipfile.ZipFile(SOURCE / "prior/reviewed_implementation.zip") as archive:
    previous = archive.read("scripts/step28_group_meta.py")
old_functions, new_functions = functions(previous.decode()), functions(current.decode())
comparison = {name: old_functions.get(name) == body for name, body in new_functions.items()}
assert all(comparison[name] for name in ("load_model", "Settings", "Episode", "lookahead", "GroupScorer", "objective", "update"))
assert not comparison["train_stage"]

snapshots = []
for attempt in ("tiny_first", "direct_first", "offload_first"):
    for filename in ("step28_group_meta.py", "step28_group_meta_gpu_check.py", "run_step28_group_meta_gpu_linux_20261004.sh"):
        original = (SOURCE / "scripts" / filename).read_bytes()
        saved = (SOURCE / "evidence/evidence" / attempt / filename).read_bytes()
        assert original == saved
        snapshots.append({"attempt": attempt, "filename": filename, "identical": True, "sha256": digest(saved)})

tiny = json.loads((SOURCE / "evidence/evidence/tiny_first/result.json").read_text())
corrections = tiny["evidence"]["hessian_correction_squared_norms"]
assert len(corrections) == 2
assert corrections[0] == corrections[1]
assert all(value > 1e-14 for record in corrections for value in record.values())

p, alpha, beta = map(Decimal, (".3", ".2", ".7"))
gs = p - 1
fast = p - alpha * gs
gq_fast = fast + 1
gradient_exact = gs + beta * (1 - alpha) * gq_fast
gradient_detach_inner = gs + beta * gq_fast
gradient_unadapted = gs + beta * (p + 1)
assert gradient_exact == Decimal(".1064")
assert gradient_detach_inner == Decimal(".308")
assert gradient_unadapted == Decimal(".21")

contract = (SOURCE / "docs/SELLER_ALIAS_GROUP_META_GPU.zh.md").read_text()
original_wording = "并与未适应query的一阶梯度区分"
proposed_wording = "并与内层梯度stop-gradient的一阶替代区分（query仍在数值快参数处求值）"
assert contract.count(original_wording) == 1
revised = contract.replace(original_wording, proposed_wording)
patch = "".join(difflib.unified_diff(
    contract.splitlines(keepends=True), revised.splitlines(keepends=True),
    fromfile="a/docs/SELLER_ALIAS_GROUP_META_GPU.zh.md",
    tofile="b/docs/SELLER_ALIAS_GROUP_META_GPU.zh.md"))
(OUT / "proposed_contract_wording.patch").write_text(patch)

result = {
    "audit_scope": "source AST, raw record arithmetic, scalar illustration; no neural execution",
    "python": sys.version,
    "platform": platform.platform(),
    "torch_imported_or_executed": False,
    "bge_executed": False,
    "formal_data_opened": False,
    "previous_method_sha256": digest(previous),
    "current_method_sha256": digest(current),
    "top_level_ast_equality": comparison,
    "attempt_source_snapshots": snapshots,
    "tiny_hessian_squared_norms_read_from_raw_record": corrections,
    "tiny_raw_gradients_available": False,
    "tiny_parity_values_independently_recomputed": False,
    "scalar_illustration": {
        "support": "0.5 * (p - 1)^2",
        "query": "0.5 * (p + 1)^2",
        "p": str(p), "alpha": str(alpha), "beta": str(beta),
        "fast": str(fast),
        "exact_gradient": str(gradient_exact),
        "inner_stop_gradient_mutant": str(gradient_detach_inner),
        "unadapted_query_mutant": str(gradient_unadapted),
        "recorded_formula_would_measure": "g_full - g_support - beta * g_query_at_fast",
        "not_a_new_bge_hyperparameter_or_experiment": True,
    },
    "source_locations": {
        "wrapper_calls_gpu_check": "scripts/run_step28_group_meta_gpu_linux_20261004.sh:79-80",
        "offload_scope": "scripts/step28_group_meta_gpu_check.py:25-26,139-141",
        "four_group_target": "scripts/step28_group_meta.py:149-176",
        "create_graph_and_fast": "scripts/step28_group_meta.py:103-111",
        "functional_parameter_buffer_route": "scripts/step28_group_meta.py:138-155",
        "outer_backward_clip_adam": "scripts/step28_group_meta.py:180-209",
        "tiny_full_gradient_residual": "scripts/step28_group_meta_gpu_check.py:62-73",
        "tiny_parity": "scripts/step28_group_meta_gpu_check.py:55-83",
    },
    "observed_defect": {
        "class": "REPRODUCIBILITY_DEFECT",
        "severity": "wording_only",
        "blocks_resource_admission_by_itself": False,
        "original_phrase": original_wording,
        "proposed_phrase": proposed_wording,
        "patch_applied_to_input": False,
    },
}
(OUT / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print(json.dumps(result, ensure_ascii=False, indent=2))
