"""Executed NumPy check with nonlinear logits and the full MSE Hessian.

Complements exact_hvp_numpy_check.py: specifically detects discarding the
residual * second-derivative-of-logit term. No torch/BGE/formal data is used.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np


def loss_term(x, labels, target=None, weight=1.0, mse_weight=0.0):
    def evaluate(theta):
        u = x @ theta
        z = u + 0.35 * np.sin(u)
        dz = 1 + 0.35 * np.cos(u)
        ddz = -0.35 * np.sin(u)
        p = 1 / (1 + np.exp(-z))
        n = len(labels)
        value = weight * np.mean(np.logaddexp(0, z) - labels * z)
        gradient = weight * x.T @ ((p - labels) * dz) / n
        hessian = weight * (x.T * (p * (1 - p) * dz**2 + (p - labels) * ddz)) @ x / n
        mse_residual_hessian = np.zeros((len(theta), len(theta)))
        if target is not None:
            residual = z - target
            value += mse_weight * np.mean(residual**2)
            gradient += 2 * mse_weight * x.T @ (residual * dz) / n
            hessian += 2 * mse_weight * (x.T * dz**2) @ x / n
            mse_residual_hessian = 2 * mse_weight * (x.T * (residual * ddz)) @ x / n
            hessian += mse_residual_hessian
        return float(value), gradient, hessian, mse_residual_hessian
    return evaluate


def main():
    rng = np.random.default_rng(20261004)
    pairs = [(i, j) for i in range(28) for j in range(i + 1, 28)]
    owner = np.repeat(np.arange(12), [3] * 4 + [2] * 8)
    labels = np.asarray([float(owner[i] == owner[j]) for i, j in pairs])
    xs = []
    for role in range(4):
        accounts = rng.normal(size=(28, 7))
        mixing = rng.normal(size=(7, 7)) / np.sqrt(7)
        xs.append(np.asarray([(accounts[i] + accounts[j]) / 2 + 0.3 * accounts[i] * accounts[j]
                              for i, j in pairs]) @ mixing)
    reference = rng.normal(scale=0.6, size=len(pairs))
    support = [loss_term(xs[0], labels), loss_term(xs[1], labels, reference, 0.1, 0.5)]
    query = [loss_term(xs[2], labels), loss_term(xs[3], labels, weight=0.1)]
    theta = rng.normal(scale=0.3, size=7)
    def aggregate(terms, point):
        terms_at_point = [term(point) for term in terms]
        return tuple(sum(term[component] for term in terms_at_point) for component in range(4))
    ls, gs, hs, residual_hessian = aggregate(support, theta)
    cases = []
    for label, rates in (("proposed_rates", [1e-5] * 4 + [1e-3] * 3),
                         ("amplified_detection_fixture_only", [0.03] * 4 + [0.09] * 3)):
        a = np.diag(rates)
        phi = theta - a @ gs
        lq, v, _, _ = aggregate(query, phi)
        expected = gs + v - hs.T @ (a.T @ v)
        staged = gs + v
        for term in support:
            staged -= term(theta)[2].T @ (a.T @ v)
        def objective(point):
            s, g, _, _ = aggregate(support, point)
            return s + aggregate(query, point - a @ g)[0]
        errors = {}
        fd_vectors = {}
        for epsilon in (1e-4, 1e-5, 1e-6):
            fd = np.zeros(7)
            for index in range(7):
                offset = np.zeros(7)
                offset[index] = epsilon
                fd[index] = (objective(theta + offset) - objective(theta - offset)) / (2 * epsilon)
            fd_vectors[str(epsilon)] = fd.tolist()
            errors[str(epsilon)] = float(np.max(np.abs(fd - expected)))
        gn_mse_mutation = gs + v - (hs - residual_hessian).T @ (a.T @ v)
        gn_error = float(np.max(np.abs(gn_mse_mutation - expected)))
        wrong_order = gs + v - a.T @ (hs.T @ v)
        entry = {
            "name": label, "rates": rates, "support": ls, "query": lq, "total": ls + lq,
            "exact_gradient": expected.tolist(), "staged_gradient": staged.tolist(),
            "fd_vectors": fd_vectors, "fd_maximum_absolute_errors": errors,
            "staged_maximum_absolute_error": float(np.max(np.abs(staged - expected))),
            "Gauss_Newton_MSE_mutation_maximum_difference": gn_error,
            "drop_entire_Hessian_maximum_difference": float(np.max(np.abs(gs + v - expected))),
            "wrong_A_H_order_maximum_difference": float(np.max(np.abs(wrong_order - expected))),
        }
        assert entry["staged_maximum_absolute_error"] < 1e-13
        assert min(errors.values()) < 1e-8
        assert gn_error > 1e-6
        assert entry["wrong_A_H_order_maximum_difference"] > 1e-6
        cases.append(entry)
    report = {
        "status": "PASS", "numpy": np.__version__, "scope": "executed_NumPy_only_no_Torch_or_BGE",
        "logit_formula": "z_i(theta) = x_i @ theta + 0.35*sin(x_i @ theta)",
        "MSE_Hessian_formula": "2*mean(grad_z_i outer grad_z_i + (z_i-reference_i)*Hessian_z_i)",
        "MSE_coefficient": 0.5, "beta": 1.0, "rho": 0.1,
        "synthetic_accounts_per_role": 28, "relations_per_role": 378, "parameters": 7,
        "support_hessian_cross_block_norm": float(np.linalg.norm(hs[:4, 4:])),
        "MSE_residual_hessian_norm_before_inner_rate": float(np.linalg.norm(residual_hessian)),
        "MSE_residual_hessian": residual_hessian.tolist(), "cases": cases,
        "limits": ["algebraic fixture is not production ranking architecture", "no runtime resource inference",
                   "no PyTorch verification", "no BGE or Adam parity verification"],
    }
    path = Path(__file__).with_name("exact_hvp_nonlinear_numpy_result.json")
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": report["status"], "output": str(path),
                      "cases": [{k: v for k, v in case.items() if k not in (
                          "exact_gradient", "staged_gradient", "fd_vectors")}
                                for case in cases]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
