"""Independent float64 chain-rule check; no project imports or formal data.

Four artificial loss terms represent complete-group support/query roles. This is
a mathematical check of exact staged differentiation, not a BGE execution test.
The constructed logits are affine in seven parameters, giving an independent
closed-form dense Hessian with cross-block entries. Encoder/head labels only
identify different constant learning-rate blocks in this mathematical fixture.
"""
from __future__ import annotations

import json
import platform
from pathlib import Path

import numpy as np


def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))


def group_term(x, y, target=None, supervision_weight=1.0, mse_weight=0.0):
    def evaluate(theta):
        logits = x @ theta
        p = sigmoid(logits)
        n = len(y)
        value = supervision_weight * np.mean(np.logaddexp(0, logits) - y * logits)
        gradient = supervision_weight * x.T @ (p - y) / n
        hessian = supervision_weight * (x.T * (p * (1 - p))) @ x / n
        if target is not None:
            difference = logits - target
            value += mse_weight * np.mean(difference**2)
            gradient += 2 * mse_weight * x.T @ difference / n
            hessian += 2 * mse_weight * (x.T @ x) / n
        return float(value), gradient, hessian
    return evaluate


def combine(terms, theta):
    results = [term(theta) for term in terms]
    return (sum(row[0] for row in results),
            sum((row[1] for row in results), np.zeros_like(theta)),
            sum((row[2] for row in results), np.zeros((len(theta), len(theta)))))


def finite_gradient(function, point, epsilon):
    result = np.zeros_like(point)
    for index in range(len(point)):
        offset = np.zeros_like(point)
        offset[index] = epsilon
        result[index] = (function(point + offset) - function(point - offset)) / (2 * epsilon)
    return result


def finite_jacobian(function, point, epsilon):
    columns = []
    for index in range(len(point)):
        offset = np.zeros_like(point)
        offset[index] = epsilon
        columns.append((function(point + offset) - function(point - offset)) / (2 * epsilon))
    return np.stack(columns, axis=1)


def main():
    rng = np.random.default_rng(20261004)
    dimension = 7
    # 28 artificial accounts, all 378 unordered pairs. These are synthetic
    # algebraic fixtures and do not reproduce the production ranking loss.
    pairs = [(i, j) for i in range(28) for j in range(i + 1, 28)]
    owner = np.repeat(np.arange(12), [3] * 4 + [2] * 8)
    truth = np.asarray([float(owner[i] == owner[j]) for i, j in pairs])
    features = []
    for role in range(4):
        accounts = rng.normal(size=(28, dimension))
        mixing = rng.normal(size=(dimension, dimension)) / np.sqrt(dimension)
        features.append(np.asarray([(accounts[i] + accounts[j]) / 2 +
                                    0.3 * accounts[i] * accounts[j]
                                    for i, j in pairs]) @ mixing)
    reference = rng.normal(scale=0.6, size=len(pairs))
    support = [group_term(features[0], truth),
               group_term(features[1], truth, reference, 0.1, 0.5)]
    query = [group_term(features[2], truth), group_term(features[3], truth, supervision_weight=0.1)]
    theta = rng.normal(scale=0.3, size=dimension)
    beta = 1.0
    ls, gs, hs = combine(support, theta)
    fd_hessian = finite_jacobian(lambda value: combine(support, value)[1], theta, 1e-5)
    cases = []
    rate_matrices = {
        "proposed_two_block_rates": np.diag([1e-5] * 4 + [1e-3] * 3),
        "amplified_fixture_rates_only": np.diag([0.03] * 4 + [0.09] * 3),
    }
    # A deliberately nonsymmetric *constant* matrix catches a forgotten A^T;
    # this is an algebraic counterexample, not a proposed algorithm change.
    nonsymmetric = rate_matrices["amplified_fixture_rates_only"].copy()
    nonsymmetric[0, 5] = 0.017
    nonsymmetric[6, 1] = -0.011
    rate_matrices["transpose_counterexample_not_proposed"] = nonsymmetric
    for label, a in rate_matrices.items():
        phi = theta - a @ gs
        lq, v, _ = combine(query, phi)
        expected = gs + beta * (v - hs.T @ (a.T @ v))
        # Staged support/query evaluation and per-whole-term HVP accumulation.
        staged = gs + beta * v
        direction = a.T @ v
        for term in support:
            staged -= beta * term(theta)[2].T @ direction
        def objective(point):
            support_value, support_gradient, _ = combine(support, point)
            fast = point - a @ support_gradient
            return support_value + beta * combine(query, fast)[0]
        fd_results = {str(eps): finite_gradient(objective, theta, eps)
                      for eps in (1e-4, 1e-5, 1e-6)}
        fd_errors = {eps: float(np.max(np.abs(g - expected))) for eps, g in fd_results.items()}
        no_hessian = gs + beta * v
        wrong_order = gs + beta * (v - a.T @ (hs.T @ v))
        omitted_transpose = gs + beta * (v - hs.T @ (a @ v))
        from_numeric_hessian = gs + beta * (v - fd_hessian.T @ (a.T @ v))
        case = {
            "name": label,
            "A": a.tolist(),
            "support_value": ls, "query_value": lq, "total_value": objective(theta),
            "full_expected_gradient": expected.tolist(),
            "staged_gradient": staged.tolist(),
            "finite_difference_gradients": {key: g.tolist() for key, g in fd_results.items()},
            "maximum_absolute_errors": {
                "staged_vs_analytic": float(np.max(np.abs(staged - expected))),
                "scalar_central_difference": fd_errors,
                "numeric_hessian_chain_rule": float(np.max(np.abs(from_numeric_hessian - expected))),
            },
            "mutation_maximum_absolute_differences": {
                "drop_hessian": float(np.max(np.abs(no_hessian - expected))),
                "A_after_Hessian_wrong_order": float(np.max(np.abs(wrong_order - expected))),
                "omit_A_transpose": float(np.max(np.abs(omitted_transpose - expected))),
            },
        }
        assert case["maximum_absolute_errors"]["staged_vs_analytic"] < 1e-13
        assert min(fd_errors.values()) < 1e-8
        assert case["maximum_absolute_errors"]["numeric_hessian_chain_rule"] < 1e-9
        assert case["mutation_maximum_absolute_differences"]["drop_hessian"] > 1e-6
        assert case["mutation_maximum_absolute_differences"]["A_after_Hessian_wrong_order"] > 1e-6
        if label == "transpose_counterexample_not_proposed":
            assert case["mutation_maximum_absolute_differences"]["omit_A_transpose"] > 1e-6
        cases.append(case)
    report = {
        "status": "PASS",
        "scope": "independent_NumPy_float64_algebra_only_no_BGE_no_Torch_execution",
        "python": platform.python_version(), "numpy": np.__version__,
        "synthetic_accounts_per_role": 28, "unordered_pairs_per_role": len(pairs),
        "parameter_dimension": dimension, "encoder_indices": [0, 1, 2, 3], "head_indices": [4, 5, 6],
        "theta": theta.tolist(),
        "hessian_max_absolute_symmetry_error": float(np.max(np.abs(hs - hs.T))),
        "hessian_numeric_check_max_absolute_error": float(np.max(np.abs(hs - fd_hessian))),
        "cross_block_hessian_frobenius_norm": float(np.linalg.norm(hs[:4, 4:])),
        "exact_formula": "gs + beta * (v - Hs.T @ (A.T @ v))",
        "cases": cases,
        "not_demonstrated": ["production objective values", "PyTorch execution", "BGE gradients",
                             "GPU/RSS feasibility", "formal effectiveness", "Adam update parity"],
    }
    destination = Path(__file__).with_name("exact_hvp_numpy_result.json")
    destination.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": report["status"], "output": str(destination),
                      "cases": [{"name": case["name"], **case["maximum_absolute_errors"],
                                 "mutations": case["mutation_maximum_absolute_differences"]}
                                for case in cases]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
