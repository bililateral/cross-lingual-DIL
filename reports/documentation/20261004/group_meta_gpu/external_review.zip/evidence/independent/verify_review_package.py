"""Independent bounded receipt/source/log audit. Does not import or run Torch."""
from __future__ import annotations

import argparse
import ast
from collections import Counter
from datetime import datetime
import difflib
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import zipfile

EXPECTED = {
    "bytes": 427942,
    "members": 73,
    "sha256": "636f8a2f41d2c6a5cc80e697b2e38044868de9e5152e45c75c0c5f9e104d7eb2",
}


def digest(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    blob = args.archive.read_bytes()
    with zipfile.ZipFile(args.archive) as archive:
        files = {entry.filename: archive.read(entry) for entry in archive.infolist()}
        receipt = {
            "bytes": len(blob), "sha256": digest(blob),
            "members": len(archive.infolist()), "crc_error": archive.testzip(),
            "duplicate_names": [key for key, count in Counter(archive.namelist()).items() if count != 1],
            "uncompressed_payload_bytes": sum(entry.file_size for entry in archive.infolist()),
        }
    assert all(receipt[key] == value for key, value in EXPECTED.items())
    assert receipt["crc_error"] is None and not receipt["duplicate_names"]

    manifests = {}
    for name, prefix in (
        ("review_manifest.json", ""), ("source_inventory.json", ""),
        ("evidence/reports/source_inventory.json", ""),
        ("evidence/reports/returned_inventory.json", "evidence/"),
    ):
        rows = []
        for entry in json.loads(files[name]):
            value = files[prefix + entry["path"]]
            rows.append({"path": entry["path"], "bytes": len(value), "sha256": digest(value),
                         "matches": len(value) == entry["bytes"] and digest(value) == entry["sha256"]})
        assert all(row["matches"] for row in rows)
        manifests[name] = {"entries": len(rows), "matching": len(rows), "rows": rows}
    payload_set = {row["path"] for row in json.loads(files["review_manifest.json"])}
    assert payload_set == set(files) - {"review_manifest.json"}

    snapshots = []
    for mode in ("tiny_first", "direct_first", "offload_first"):
        for program in ("step28_group_meta.py", "step28_group_meta_gpu_check.py",
                        "run_step28_group_meta_gpu_linux_20261004.sh"):
            row = {"attempt": mode, "program": program,
                   "identical": files[f"scripts/{program}"] == files[f"evidence/evidence/{mode}/{program}"]}
            assert row["identical"]
            snapshots.append(row)

    import io
    with zipfile.ZipFile(io.BytesIO(files["prior/reviewed_implementation.zip"])) as prior:
        previous = prior.read("scripts/step28_group_meta.py").decode()
        current = files["scripts/step28_group_meta.py"].decode()
        old_tree, new_tree = ast.parse(previous), ast.parse(current)
        previous_functions = {node.name: ast.dump(node) for node in old_tree.body if isinstance(node, ast.FunctionDef)}
        current_functions = {node.name: ast.dump(node) for node in new_tree.body if isinstance(node, ast.FunctionDef)}
        unchanged = {name: previous_functions[name] == current_functions[name]
                     for name in ("load_model", "lookahead", "objective", "update")}
        assert all(unchanged.values())
        differences = "".join(difflib.unified_diff(previous.splitlines(True), current.splitlines(True),
                              fromfile="prior/scripts/step28_group_meta.py",
                              tofile="current/scripts/step28_group_meta.py"))
    (args.output / "meta_vs_original.diff").write_text(differences)

    runs = []
    for role in ("tiny_first", "direct_first", "offload_first"):
        prefix = f"evidence/evidence/{role}/"
        read = lambda name: files[prefix + name].decode().strip()
        start, end = datetime.fromisoformat(read("started.txt")), datetime.fromisoformat(read("finished.txt"))
        seconds = int(read("seconds.txt"))
        assert (end - start).total_seconds() == seconds
        result = json.loads(read("result.json")) if prefix + "result.json" in files else None
        runs.append({"name": role, "start": start.isoformat(), "end": end.isoformat(),
                     "wrapper_seconds": seconds, "exit_status": int(read("exit_status.txt")),
                     "stdout": read("stdout.txt"), "has_result_json": result is not None,
                     "result": result})
    assert sum(row["wrapper_seconds"] for row in runs) == 101
    assert [row["exit_status"] for row in runs] == [0, 1, 124]
    tiny, direct, offload = runs
    assert tiny["result"]["status"] == "PASS"
    assert direct["result"]["cuda_oom"] is True
    assert "values, history = forward(params, 1)" in direct["result"]["traceback"]
    assert offload["has_result_json"] is False
    stop = dict(value.split("=", 1) for value in files["evidence/evidence/offload_first/budget_stop.txt"].decode().split())
    stop = {key: int(value) for key, value in stop.items()}
    flags = {"rss_exceeded": stop["rss_kib"] > 128 * 2**20,
             "host_below_16gib": stop["available_kib"] < 16 * 2**20,
             "output_exceeded": stop["evidence_bytes"] > 128 * 2**20,
             "remaining_time_exceeded": stop["elapsed"] >= 3587}
    assert flags == {"rss_exceeded": True, "host_below_16gib": False,
                     "output_exceeded": False, "remaining_time_exceeded": False}
    reached_meta_call = all("native_meta_start step=1" in row["stdout"] for row in (direct, offload))
    assert reached_meta_call  # Reached first meta call; NOT a completed meta update.
    corrections = tiny["result"]["evidence"]["hessian_correction_squared_norms"]
    correction_values = {name: {"squared_norm": number, "norm": number**0.5}
                         for name, number in corrections[0].items()}
    assert corrections[0] == corrections[1]

    ast_files = []
    for name, value in sorted(files.items()):
        if name.startswith(("scripts/", "tests/")) and name.endswith(".py"):
            ast.parse(value.decode(), filename=name)
            ast_files.append(name)
    bash_check = subprocess.run(["bash", "-n"], input=files["scripts/run_step28_group_meta_gpu_linux_20261004.sh"],
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    assert bash_check.returncode == 0
    result = {
        "scope": "independent_python_receipt_source_and_log_analysis_only",
        "expected": EXPECTED, "receipt": receipt, "manifests": manifests,
        "execution_snapshots": snapshots, "prior_key_functions_ast_unchanged": unchanged,
        "runs": runs, "budget_stop": stop, "trigger_analysis": flags,
        "derived": {
            "sum_wrapper_seconds": 101, "arithmetic_remaining_seconds": 3499,
            "remaining_is_not_new_run_authorization": True,
            "observed_offload_rss_gib": stop["rss_kib"] / 2**20,
            "observed_offload_host_available_gib": stop["available_kib"] / 2**20,
            "observed_rss_excess_mib": (stop["rss_kib"] - 128 * 2**20) / 1024,
            "offload_observation_to_wrapper_exit_seconds": 88 - stop["elapsed"],
            "direct_peak_allocated_gib": direct["result"]["last_interval_peak_allocated_bytes"] / 2**30,
            "direct_peak_reserved_gib": direct["result"]["last_interval_peak_reserved_bytes"] / 2**30,
            "tiny_hessian_corrections": correction_values,
            "completed_native_meta_updates": 0,
            "native_warm_updates_supported_by_control_flow": 2,
        },
        "local_environment": {"python": sys.version, "executable": sys.executable,
            "torch_present": importlib.util.find_spec("torch") is not None,
            "numpy_present": importlib.util.find_spec("numpy") is not None,
            "ast_parsed_files": ast_files, "bash_syntax_returncode": bash_check.returncode},
        "did_not_execute": ["PyTorch", "CUDA", "BGE", "formal_data_loader", "old_weights", "training", "evaluation"],
    }
    (args.output / "audit.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"receipt": receipt, "manifest_matching": {key: val["matching"] for key, val in manifests.items()},
                      "key_functions_unchanged": unchanged, "derived": result["derived"],
                      "AST_files": len(ast_files), "bash_syntax_returncode": bash_check.returncode},
                     ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
