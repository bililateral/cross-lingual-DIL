#!/usr/bin/env python3
"""Independent source-extracted Python checks, explicitly without Torch/BGE.

This does NOT run the production Torch module, actual objective, or original test
suite. It runs exact AST-extracted Group/Episode/Settings classes (pure validators),
and evaluates a source query return expression with scalar numeric values. Mutants
are local copies; original evidence/source files remain untouched.
"""
from __future__ import annotations

import argparse
import ast
import copy
from dataclasses import asdict, dataclass, replace
import hashlib
import itertools
import json
import math
from pathlib import Path
import sys
from types import SimpleNamespace
from typing import Any

import numpy as np


def sha(path: Path) -> dict:
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def selected_classes(path: Path, names: set[str], mutate: str | None = None) -> dict:
    tree = ast.parse(path.read_text())
    classes = [copy.deepcopy(n) for n in tree.body if isinstance(n, ast.ClassDef) and n.name in names]
    assert {n.name for n in classes} == names
    if mutate == "remove_cross_group_items":
        class RemoveItemIntersection(ast.NodeTransformer):
            def visit_BoolOp(self, node):
                node = self.generic_visit(node)
                if isinstance(node.op, ast.Or):
                    node.values = [n for n in node.values if ast.unparse(n) != "items & seen_items"]
                return node
        classes = [RemoveItemIntersection().visit(n) for n in classes]
    module = ast.Module(body=[ast.ImportFrom(module="__future__", names=[ast.alias(name="annotations")], level=0), *classes], type_ignores=[])
    ast.fix_missing_locations(module)
    environment = {"dataclass": dataclass, "asdict": asdict, "Any": Any, "np": np, "math": math, "__name__": "__main__"}
    exec(compile(module, str(path), "exec"), environment)
    return environment


def outcome(fn):
    try:
        fn()
    except ValueError as exc:
        return {"accepted": False, "exception": "ValueError", "message": str(exc)}
    return {"accepted": True}


def source_return(path: Path, enclosing: str, nested: str):
    tree = ast.parse(path.read_text())
    parent = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == enclosing)
    child = next(n for n in parent.body if isinstance(n, ast.FunctionDef) and n.name == nested)
    expr = next(n.value for n in child.body if isinstance(n, ast.Return))
    return expr


def expression_value(expression, environment):
    tree = ast.Expression(body=copy.deepcopy(expression))
    ast.fix_missing_locations(tree)
    return eval(compile(tree, "source_expression_only", "eval"), {"__builtins__": {}}, environment)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--source", type=Path, required=True)
    p.add_argument("--input", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    args = p.parse_args()
    inputs = json.loads(args.input.read_text())
    meta_path = args.source / "scripts/step28_group_meta.py"
    data_path = args.source / "scripts/step28_continual_population_data.py"
    tests_path = args.source / "tests/test_step28_group_meta.py"
    native_path = args.source / "scripts/step28_group_meta_check.py"
    native_result = args.source / "reports/documentation/20261004/group_meta/native_probe_fixed/result.json"
    implementation = args.source / "reports/documentation/20261004/group_meta/implementation.zh.md"
    output = {"scope": inputs["scope"], "torch_imported": "torch" in sys.modules,
              "original_torch_test_suite_rerun": False, "native_model_rerun": False}
    Group = selected_classes(data_path, {"Group"})["Group"]
    env = selected_classes(meta_path, {"Settings", "Episode"})
    Episode = env["Episode"]
    owners = [i for i, n in enumerate([3] * 4 + [2] * 8) for _ in range(n)]
    labels = tuple(int(owners[i] == owners[j]) for i, j in itertools.combinations(range(28), 2))
    groups = []
    for g in range(4):
        uid = f"independent_{g}"
        groups.append(Group(uid, tuple(f"{uid}_seller_{i:02}" for i in range(28)),
                            tuple(tuple((f"{uid}_item_{i:02}_{j}", f"手写标题{i}", f"手写描述{j}")
                                        for j in range(2)) for i in range(28)), labels))
    ref = np.full(378, .25, dtype=np.float32)
    episode = Episode(*groups, ref, groups[1].uid)
    variants = {
        "valid_four_groups": episode,
        "repeated_group": replace(episode, current_query=episode.current_support),
        "cross_group_sellers": replace(episode, current_query=replace(groups[2], sellers=groups[0].sellers)),
        "cross_group_items": replace(episode, current_query=replace(groups[2], items=groups[0].items)),
        "reference_uid_mismatch": replace(episode, reference_uid=groups[3].uid),
        "reference_float64": replace(episode, reference=ref.astype(np.float64)),
        "reference_nan": replace(episode, reference=np.full(378, np.nan, dtype=np.float32)),
        # A declaration checks UID/type/shape, not provenance of arbitrary values.
        # The real stage's Memory.draw plus distinct-target spy supplies that link.
        "different_values_correct_uid": replace(episode, reference=np.full(378, -.75, dtype=np.float32)),
    }
    output["exact_source_validators"] = {name: outcome(value.validate) for name, value in variants.items()}
    assert output["exact_source_validators"]["valid_four_groups"]["accepted"]
    assert output["exact_source_validators"]["different_values_correct_uid"]["accepted"]
    for name in variants.keys() - {"valid_four_groups", "different_values_correct_uid"}:
        assert not output["exact_source_validators"][name]["accepted"], name
    MutatedEpisode = selected_classes(meta_path, {"Episode"}, "remove_cross_group_items")["Episode"]
    bad = variants["cross_group_items"]
    mutant = MutatedEpisode(*bad.groups(), bad.reference, bad.reference_uid)
    output["item_guard_mutant"] = outcome(mutant.validate)
    assert output["item_guard_mutant"]["accepted"]
    query = source_return(meta_path, "objective", "query")
    class PinRho(ast.NodeTransformer):
        def visit_Attribute(self, node):
            if ast.unparse(node) == "settings.query_history_weight":
                return ast.copy_location(ast.Constant(value=.3), node)
            return self.generic_visit(node)
    pinned = PinRho().visit(copy.deepcopy(query))
    output["query_expression"] = ast.unparse(query)
    output["rho_pinned_mutant_expression"] = ast.unparse(pinned)
    cases = []
    for case in inputs["query_cases"]:
        environment = {"current": case["current"], "history": case["history"],
                       "settings": SimpleNamespace(query_history_weight=case["rho"])}
        original = expression_value(query, environment)
        mutant = expression_value(pinned, environment)
        cases.append({**case, "source_expression": original, "pinned_rho": mutant,
                      "distinguishable": original != mutant})
    assert not cases[0]["distinguishable"] and cases[1]["distinguishable"]
    output["query_scalar_expression_cases"] = cases
    fixtures = []
    for path in (tests_path, native_path):
        for node in ast.walk(ast.parse(path.read_text())):
            if isinstance(node, ast.Call) and ast.unparse(node.func) in {"method.Settings", "Settings"}:
                fixtures.append({"path": str(path.relative_to(args.source)), "line": node.lineno,
                                 "expression": ast.unparse(node), "values": [ast.literal_eval(a) for a in node.args]})
    output["all_settings_constructor_fixtures"] = fixtures
    assert {row["values"][2] for row in fixtures} == {.3}
    assert {row["values"][3] for row in fixtures} == {.7}
    output["coverage_interpretation"] = [
        "Every explicit Settings fixture has rho=.3 and beta=.7; beta=0 is also exercised via replace.",
        "The actual source query uses the provided rho correctly. Pinning it to .3 is indistinguishable in all supplied fixture coefficient values; full Torch mutant suite was NOT executed.",
        "Current tests have no explicit cross-group item-only collision input. Exact extracted production validator rejects it; removing only this guard accepts it. Full original mutant suite was NOT executed.",
        "A second distinct nonzero rho and beta plus direct fast-value/rate mapping checks would close concrete coverage gaps; this is not evidence of a present wrong coefficient.",
    ]
    result = json.loads(native_result.read_text())["native"]["update"]
    encoder = result["module_gradient_norms"]["encoder"]
    head = result["module_gradient_norms"]["head"]
    combined = math.hypot(encoder, head)
    wrong_combined = math.hypot(encoder, inputs["printed_head_norm"])
    output["native_log_document_discrepancy"] = {
        "reported_encoder": encoder, "actual_head_in_result": head,
        "head_in_implementation_line44": inputs["printed_head_norm"],
        "reported_global": result["gradient_norm"], "sqrt_sum_module_squares": combined,
        "wrong_printed_head_implied_global": wrong_combined,
        "absolute_global_consistency_error": abs(combined-result["gradient_norm"]),
        "is_documentation_error": abs(head-inputs["printed_head_norm"]) > .01,
    }
    assert abs(combined - result["gradient_norm"]) < 1e-6
    assert abs(wrong_combined - result["gradient_norm"]) > .01
    output["sources"] = [sha(path) for path in (meta_path, data_path, tests_path, native_path, native_result, implementation, args.input, Path(__file__))]
    output["status"] = "PASS_INDEPENDENT_PURE_PYTHON_SOURCE_CHECKS_ONLY"
    args.output.write_text(json.dumps(output, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(output, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
