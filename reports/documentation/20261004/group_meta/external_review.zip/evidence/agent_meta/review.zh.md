# 实际二阶路径与测试覆盖：独立分审

## 范围与结论

本分审只读附件生产源码、直接表示/损失/优化器依赖、现有微型测试和原生检查器及结果；没有导入 PyTorch，没有重新运行原生 BGE、正式数据、GPU 或原测试套件。独立执行部分为：从真实源码 AST 精确提取的纯 Python `Group`/`Episode` 验证器，手写身份/商品/引用反例，对真实 query 返回表达式的数值求值及 rho 硬编码变异，以及原生文字/JSON 数值交叉核对。完整输入、代码、退出码、stdout/stderr 在同目录。

**当前生产路径静态上忠实实现 J=Ls+βLq(θ−A∇Ls)，没有发现 detach 内层、查询偷用原参数、仅训练头、临时 Adam 或只记录元损失而不反向的实际缺陷。** 这不等于本环境重跑认证；原生支持范围仍限附件记录的那一次完整元更新及两探针。确实发现一项现有报告数字错误，并发现几类现有测试可自洽漏检的具体变异。

## 1. 实际调用链及为什么不是伪二阶

|环节|源码位置|独立判断|
|---|---|---|
|原生 actual 入口|`scripts/step28_group_meta_check.py:84–86`|真实调用 `method.update`，只用包装器抓取目标、探针和 clip 前证据；不是替换训练梯度。|
|更新入口|`scripts/step28_group_meta.py:180–189`|检查连续 Adam 计数，`model.train()`、清 `.grad`，取得实际 objective 后对 loss 调 `backward()`。|
|全部命名参数|同文件 `138–144`|GroupScorer 注册原 model；完整 `named_parameters()` 字典、拒绝被冻结参数；以 `model.encoder.` 前缀分配内层编码器率，其余为头率。`allow_unused` 只允许结构上未被损失使用的参数，其 fast 值保持原值；不能据此声称每个登记参数都实质训练。|
|真实文本与头|`step28_chinese_base.py:194–220`；`step28_continual_population.py:14–27`|tokenizer 只接收标题/描述字符串；encoder(batch) 得到实际 embedding，分通道总体矩统计，再由对称头对378关系打分。函数式临时替换作用到同一注册子模块 `self.model.encoder/head`。|
|函数式快参数|`step28_group_meta.py:149–159`|每个角色以显式参数字典进入 `torch.func.functional_call(scorer, (params,buffers), ..., strict=True)`；UID不进模型。每角色 fork RNG 并复位 seed，语义是固定该次随机样本的可微目标。|
|Ls|同文件 `161–167`|明确 `Lbase(Cs)+.1*Lbase(Hs)+.5*MSE`，MSE只在历史support且teacher为固定 NumPy 数组转tensor。|
|二阶内层|同文件 `93–111`|先 `support(parameters)`，再 `autograd.grad(...create_graph=True,allow_unused=True)`，`fast=parameter−rate*gradient`，随后 `query(fast)`；没有 detach、复制模型训练或 optimizer。|
|Lq与总目标|同文件 `169–177`|query实际使用角色2、3，`current+settings.query_history_weight*history`；`settings.outer_weight`传给lookahead。|
|一次真实更新|同文件 `189–205`|对J反向后核对encoder/head梯度，设原有阶段外层lr，clip一次、optimizer.step一次，并验证步数。实际optimizer由继承的`make_optimizer`构造为两组AdamW（`step28_continual_population.py:32–40`）。|

数学上，`θ′=θ−A∇Ls` 的雅可比为 `I−AHs`，所以 `∇θJ=gs+β(I−HsA)gq`。A为固定对角率矩阵，Hs对称。该目标没有声称预测带一、二阶矩、裁剪或权衰减的真实 AdamW 下一步。二阶在局部活动区域内求导；除文档提及 Top5/ReLU 外，对称头的绝对值在零点也有分段边界（`step28_continual_population.py:27`）。这只是应准确解释局部求导，不是当前实现阻断。

`ranking.hard_candidates` 在 `scripts/step28_alias_ranking.py:106–107` detach的是离散负例排序索引；之后 `121–128` 从live scores取值并算softplus。这里的detach不是偷换成一阶元梯度。原生类中没有BatchNorm式running-stat更新；buffer复制隔离不构成参数断图。

## 2. 当前证据必须修正的一项文字错误

`reports/documentation/20261004/group_meta/implementation.zh.md:44` 将原生全模块head梯度范数写成 **0.99251316**。该次 `native_probe_fixed/result.json:1` 实际为 **0.9251316433178884**。应将报告改为0.92513164，原始JSON/日志保持不动。这不改变两探针Hessian路径或一次元更新结论。

独立算得encoder/head分模块范数平方和根为 **1.2321740542242985**，clip报告总范数为 **1.2320390939712524**，绝对差 **0.00013496025304604586**，相对差约 **0.00010954**。二者不是严格同一数值；可能涉及不同float32归约实现，但没有保存的原始梯度，本审查不独立定因。错写的head值反推总范数为1.2835367993，不能拿它声称和clip严格一致。

本审查最初自写核验错误地要求不同归约的范数在1e-6内相等，导致 `run_01` 失败。这是本审查的过强检验假设，失败原源码位于 `run_01/source_at_failure.py`，stdout/stderr/退出码原样保留。修正仅取消无依据的一致性阈值、改为完整报告差值；`run_02` 成功。不得把这次失败归因于附件算法失效，也不得隐去本方失败。

## 3. 现有证据能检查什么，以及具体漏检变异

|变异/故障|已有测试可辨性|依据及范围|
|---|---|---|
|`create_graph=False`或detach内层grad|通用helper测试应检出|`tests/test_step28_group_meta.py:36–54` 真实helper导数与0.1064比较；detach会给0.308。微型二阶校正还要求encoder/head均非零。这里是对源码测试的逻辑判断，本环境没运行torch mutant。|
|lookahead内query仍用原θ|通用helper测试应检出|同一标量正确值0.1064而未适配为0.21；若仅生产closure绕过fast，微型`q_fast`反向应失联或校正检查失败（`74–87`）。|
|原模型参数在虚拟步被改|微型较完整，原生仅两探针|微型`89–91`比较全部state_dict且.grad不被累积；原生`check.py:58–60`只比较两个指定参数。|
|临时Adam污染|虚拟构建原生有optimizer digest|`check.py:47,56–57`检查objective前后整个optimizer state_dict摘要相等；微型真实单步spy核对clip/step次数（`130–136`）。|
|rho在query写死为.3|**现有夹具系数无法分辨**|Tiny/spy/native的显式Settings全部rho=.3（测试31、163行；check43行）。当前真实172行传参正确；硬编码变异只是具体未覆盖风险。我们实际运行源码表达式：rho=.3时二者均4.5；rho=.8时正确7.0、硬编码4.5。|
|正beta固定成.7、仅beta0分支特判|**现有正值没有第二点**|全部正beta=.7，另有β0退化。helper的简单全局写死beta会被β0检查检出，但“正值固定.7”这类分支化错误没有第二个非零值约束。未跑torch mutant。|
|交换encoder/head内层lr或在objective错误映射|**自洽有限差分不认证目标率映射**|helper单标量率=.2；真实微型有限差分检验实现自身，模块校正只要求非零，spy只看Settings对象。当前143–144行映射正确，但尚无真实fast数值等于相应θ−αg的断言。|
|当前query误用current support|**有具体漏检可能**|现测试只替换历史query并断言梯度变化（`92–96`），没有当前query扰动。如果query角色2误写角色0，四群Episode/spy依然合法，其余二阶/有限差分/β0可继续自洽。当前生产169–172行正确。此项为静态推断，未跑torch mutant。|
|历史query误用history support|现有历史query扰动应检出|`92–96`替换历史query并要求真实梯度变化。|
|四群重UID、跨群账号复用|现有显式负例|`56–63`；本分审实际运行提取的原验证器也拒绝。|
|仅跨群商品复用、账号仍不同|**代码会拦，原测试无此单独输入**|真实77行检查`items & seen_items`。本分审对精确提取类运行反例，原类拒绝；只删商品交集guard的局部副本接受。没有运行整个torch变异测试套件。|
|错reference UID/dtype|代码与显式测试均有|生产82–85，测试64–67；本分审额外NaN反例也被拒绝。|
|错目标数值却声明正确UID|低层Episode单独无法认证来源|本分审实际把float32目标值从.25改−.75但保持UID，验证器接受。正常来源要由Memory.draw与stage的不同UID不同target数组断言补上（测试157–164）；这不是要求对受信调用者做防伪签名。|

最小补充应集中在数个廉价微型检查：两个不同非零rho/beta；按模块两种不同内层率核对真实fast值；单独更换current_query；只重复商品UID的负例。**这些是当前证据的具体覆盖缺口，不是已经发现生产计算错误，也不自动阻断本轮手写实现审查，更不要求新正式模型或全历史重跑。** 若要保留“非默认Settings已覆盖”的宽泛措辞，应收窄为“给定fixture的对象在stage原样透传”，或用上述微型检查补齐实际计算。

## 4. 原生检查的支持范围

原生`check.py:35–38`只做一真实warm，然后显式把Adam计数1改288；这不提供首阶段288更新后的真实动量。`84–86`再做一次完整元更新。两探针的`query_fast`来自fast节点，clip前比较 `full − support − βquery_fast`；结合源码图，这不是只用“总梯度非零”来声称Hessian存在。探针覆盖encoder第一层attention query.weight与head隐藏层weight（44–45），不是每个BGE参数逐个数值认证。

微型有限差分仅测输出头bias一个坐标（测试97–109），有完整计算自洽意义，但不独立保证全部排序头/encoder Hessian。没有声称该探针足以替代完整GPU路径。后续若为正式实验可行性核验，应按正式执行条件验证一次合法路径；不需要为了本轮结论重跑BGE。

## 5. 不应升级成本轮阻断的事项

- 给每个参数做有限差分、全Hessian显式构造、重跑所有旧基线，均超出必要范围。
- 强行要求本轮加入正式GPU或效果比较，违背本轮只实现与手写CPU的范围。
- 将低层Episode接收正确UID的不同参考值当成必须做密码学防伪的漏洞，不合适；应沿真实memory供给与绑定测试评估。
- beta0需要四群合法夹具、inner encoder lr允许0等边界，均有数学可解释性；未来正式合同若要求全部内层适配，可冻结正编码器率，不能据此把当前正率路径判错。

本分审的证据存放：`evidence/agent_meta/inputs.json`、`source_validator_and_coverage.py`、`findings.json`、`run_01/`、`norm_diagnostic/`、`run_02/`。读入来源大小与SHA在findings.json中，哈希仅用于来源身份，不能代替上述语义检查。
