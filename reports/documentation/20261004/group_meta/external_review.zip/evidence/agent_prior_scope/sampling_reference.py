"""Standard-library analytic reference and inventory for read-only prior-scope review."""
from __future__ import annotations

import argparse
from fractions import Fraction
import hashlib
import json
from math import comb
from pathlib import Path


SOURCES = [
    "reports/documentation/20261003/logit_low/external_review.zh.txt",
    "reports/documentation/20261003/risk_replay/external/risk_audit/deliverables/report.zh.txt",
    "docs/SELLER_ALIAS_LOGIT_RISK_RESULT.zh.md",
    "reports/seller_alias_continual/20261004/result_review/report.zh.md",
    "docs/SELLER_ALIAS_GROUP_META.zh.md",
]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--inputs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    inventory = []
    for relative in SOURCES:
        data = (args.source / relative).read_bytes()
        inventory.append({
            "path": relative,
            "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest(),
            "lines": len(data.decode("utf-8").splitlines()),
        })
    (args.output / "source_inventory.json").write_text(
        json.dumps(inventory, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    fixture = json.loads(args.inputs.read_text(encoding="utf-8"))
    n, a, b, k = (fixture[key] for key in (
        "population_groups", "groups_in_domain_a", "groups_in_domain_b", "retained_groups"
    ))
    assert a + b == n and 0 < k <= min(a, b)
    denominator = comb(n, k)
    no_a = Fraction(comb(b, k), denominator)
    no_b = Fraction(comb(a, k), denominator)
    # For nonempty samples from exactly two domains, zero-A and zero-B are disjoint.
    either = no_a + no_b
    assert Fraction(0) < either < Fraction(1)
    result = {
        "scope": "Pure combinatorial reference; no model, labels, training, resampling, or observed frequency",
        "inputs": fixture,
        "p_no_a_exact": str(no_a),
        "p_no_a": float(no_a),
        "p_no_b": float(no_b),
        "p_either_domain_absent_exact": str(either),
        "p_either_domain_absent": float(either),
        "expected_a_retained": float(Fraction(k * a, n)),
        "source_count": len(inventory),
        "source_lines": sum(item["lines"] for item in inventory),
        "interpretation": "An expected value of 3 per domain is not a per-domain coverage guarantee; do not re-draw an observed zero-domain cache after seeing results."
    }
    (args.output / "sampling_reference.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
