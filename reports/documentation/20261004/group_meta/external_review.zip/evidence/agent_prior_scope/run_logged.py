"""Run this subreview's actual reference and preserve command/stdout/stderr/exit code."""
from __future__ import annotations

from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys


root = Path(__file__).resolve().parent
source = root.parent.parent / "source"
argv = [
    sys.executable, str(root / "sampling_reference.py"),
    "--source", str(source),
    "--inputs", str(root / "inputs.json"),
    "--output", str(root),
]
command = {"argv": argv, "cwd": str(root), "started_utc": datetime.now(timezone.utc).isoformat()}
(root / "command.json").write_text(json.dumps(command, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
result = subprocess.run(argv, cwd=root, capture_output=True)
(root / "stdout.txt").write_bytes(result.stdout)
(root / "stderr.txt").write_bytes(result.stderr)
(root / "exit_code.txt").write_text(str(result.returncode) + "\n", encoding="ascii")
(root / "completion.json").write_text(json.dumps({"finished_utc": datetime.now(timezone.utc).isoformat(), "returncode": result.returncode}, indent=2) + "\n", encoding="utf-8")
sys.stdout.buffer.write(result.stdout)
sys.stderr.buffer.write(result.stderr)
raise SystemExit(result.returncode)
