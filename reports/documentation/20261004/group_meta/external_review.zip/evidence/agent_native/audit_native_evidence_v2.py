#!/usr/bin/env python3
"""Reanalyse the supplied Linux evidence without importing or simulating Torch.

The script verifies file identity and arithmetic, not that uploaded logs came
from an independently observed server. 'Execution complete' is not a scientific
PASS. The emitted source ledger identifies every actual file read.
"""
from __future__ import annotations

import argparse
import datetime
import difflib
import hashlib
import json
import math
from pathlib import Path
import re


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--inputs", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    config = json.loads(args.inputs.read_text())
    root = Path(config["source_root"])
    base = root / config["evidence_subdirectory"]
    args.out.mkdir(parents=True, exist_ok=True)
    ledger: dict[str, dict] = {}

    def read(path: Path) -> bytes:
        payload = path.read_bytes()
        ledger[str(path.relative_to(root))] = {
            "bytes": len(payload), "sha256": hashlib.sha256(payload).hexdigest()
        }
        return payload

    def text(path: Path) -> str:
        return read(path).decode("utf-8-sig")

    def load(path: Path):
        return json.loads(text(path))

    def inspect_record(record: dict, prefix: Path) -> dict:
        path = prefix / record["path"]
        if not path.exists():
            return {"path": record["path"], "state": "missing"}
        payload = read(path)
        actual = {"bytes": len(payload), "sha256": hashlib.sha256(payload).hexdigest()}
        ok = all(record[k] == actual[k] for k in actual)
        return {"path": record["path"], "state": "match" if ok else "changed", "actual": actual,
                "expected": {k: record[k] for k in actual}}

    def counts(rows: list[dict]) -> dict:
        return {state: sum(row["state"] == state for row in rows)
                for state in ("match", "changed", "missing")}

    review = load(root / "review_manifest.json")
    review_checks = [inspect_record(r, root) for r in review]
    linux = load(base / "linux_inventory.json")
    linux_source = [inspect_record(r, root) for r in linux["source"]]
    linux_evidence = [inspect_record(r, base) for r in linux["evidence"]]
    linux_documents = [inspect_record(r, root) for r in linux.get("root_documents", [])]
    initial = load(base / "source_inventory.json")
    initial_checks = [inspect_record(r, root) for r in initial]

    # Search all supplied payloads by identity to resolve superseded first-run
    # source without rewriting its manifest or claiming the final source matches.
    for path in sorted(root.rglob("*")):
        if path.is_file():
            read(path)
    reverse: dict[tuple[int, str], list[str]] = {}
    for path, identity in ledger.items():
        reverse.setdefault((identity["bytes"], identity["sha256"]), []).append(path)
    for row in initial_checks:
        if row["state"] == "changed":
            key = (row["expected"]["bytes"], row["expected"]["sha256"])
            row["archived_matching_payloads"] = reverse.get(key, [])
            row["classification"] = ("superseded_source_preserved" if reverse.get(key)
                                     else "initial_hash_only_no_payload")

    def duration(value: str) -> float:
        pieces = value.split(":")
        return sum(float(v) * (60 ** i) for i, v in enumerate(reversed(pieces)))

    def field(stderr: str, label: str, convert=float):
        found = re.search(r"^\s*" + re.escape(label) + r":\s*(.+)$", stderr, re.M)
        if not found:
            raise ValueError("Missing time-v field " + label)
        return convert(found.group(1).strip())

    runs = []
    source_text: dict[tuple[str, str], str] = {}
    for name in config["runs"]:
        directory = base / name
        result = load(directory / "result.json")
        stderr = text(directory / "stderr.txt")
        stdout = text(directory / "stdout.txt")
        start = text(directory / "started.txt").strip()
        finish = text(directory / "finished.txt").strip()
        exit_status = int(text(directory / "exit_status.txt"))
        sources = {}
        for filename in config["run_sources"]:
            p = directory / "source" / filename
            source_text[(name, filename)] = text(p)
            sources[filename] = ledger[str(p.relative_to(root))]
        runs.append({
            "name": name, "status": result["status"], "exit_status": exit_status,
            "time_exit_status": field(stderr, "Exit status", int),
            "started": start, "finished": finish,
            "timestamp_interval_whole_seconds": (datetime.datetime.fromisoformat(finish) -
                                                   datetime.datetime.fromisoformat(start)).total_seconds(),
            "program_wall_seconds_time_v": field(stderr, "Elapsed (wall clock) time (h:mm:ss or m:ss)", duration),
            "program_user_seconds_time_v": field(stderr, "User time (seconds)"),
            "program_system_seconds_time_v": field(stderr, "System time (seconds)"),
            "python_timed_body_seconds": result["seconds"],
            "max_rss_kib_time_v": field(stderr, "Maximum resident set size (kbytes)", int),
            "swaps_time_v": field(stderr, "Swaps", int),
            "cpu_affinity": result["cpu_affinity"],
            "stdout_markers": stdout.splitlines(),
            "snapshot_directory_bytes_du_sb": int(text(directory / "evidence_bytes.txt")),
            "sources": sources,
            "traceback": result.get("traceback"),
            "test_counts": result.get("tests")
        })

    diffs = []
    for old, new in config["source_transitions"]:
        for filename in config["run_sources"]:
            a = source_text[(old, filename)].splitlines(keepends=True)
            b = source_text[(new, filename)].splitlines(keepends=True)
            if a != b:
                diffs.extend(difflib.unified_diff(a, b, fromfile=old + "/" + filename,
                                                 tofile=new + "/" + filename))
    (args.out / "version_changes.diff").write_text("".join(diffs))

    native = load(base / config["native_run"] / "result.json")["native"]
    update = native["update"]
    settings = native["settings_fixture_only"]
    support = update["current_support"] + .1 * update["history_support"] + .5 * update["logit_mse"]
    query = update["current_query"] + settings["query_history_weight"] * update["history_query"]
    total = update["support"] + settings["outer_weight"] * update["query"]
    norm = math.hypot(*update["module_gradient_norms"].values())
    arithmetic = {
        "support_reconstructed_from_logged_components": support,
        "support_logged": update["support"], "support_difference": support - update["support"],
        "query_reconstructed_from_logged_components": query,
        "query_logged": update["query"], "query_difference": query - update["query"],
        "total_reconstructed_from_logged_components": total,
        "total_logged": update["total"], "total_difference": total - update["total"],
        "global_gradient_norm_reconstructed": norm,
        "global_gradient_norm_logged": update["gradient_norm"],
        "norm_difference": norm - update["gradient_norm"],
        "norm_relative_difference": (norm - update["gradient_norm"]) / update["gradient_norm"],
        "norm_interpretation": "Different float32 reductions; native tensors absent. Residual is reported without an unsupported equality gate or a claim of a proven error.",
        "scalar_objective_differences_below_1e_5": all(abs(v) < 1e-5 for v in
            (support - update["support"], query - update["query"], total - update["total"]))
    }
    implementation = text(base / "implementation.zh.md")
    line = next(line for line in implementation.splitlines() if "全模块梯度范数" in line)
    doc_head = float(re.search(r"/head([0-9.]+)", line).group(1))
    observed_head = update["module_gradient_norms"]["head"]
    documentation = {
        "path": str((base / "implementation.zh.md").relative_to(root)),
        "line": implementation.splitlines().index(line) + 1,
        "document_head_norm": doc_head, "original_result_head_norm": observed_head,
        "difference": doc_head - observed_head,
        "document_norm_hypot": math.hypot(update["module_gradient_norms"]["encoder"], doc_head),
        "current_documentation_mismatch": not math.isclose(doc_head, observed_head, rel_tol=1e-6)
    }
    totals = {
        "sum_program_wall_seconds_time_v": sum(r["program_wall_seconds_time_v"] for r in runs),
        "sum_program_user_seconds_time_v": sum(r["program_user_seconds_time_v"] for r in runs),
        "sum_program_system_seconds_time_v": sum(r["program_system_seconds_time_v"] for r in runs),
        "sum_python_timed_body_seconds": sum(r["python_timed_body_seconds"] for r in runs),
        "max_rss_kib_time_v": max(r["max_rss_kib_time_v"] for r in runs),
        "max_snapshot_directory_bytes_du_sb": max(r["snapshot_directory_bytes_du_sb"] for r in runs),
        "all_affinity_single_cpu47": all(r["cpu_affinity"] == [47] for r in runs),
        "all_time_statuses_match_files": all(r["exit_status"] == r["time_exit_status"] for r in runs),
        "all_swaps_zero": all(r["swaps_time_v"] == 0 for r in runs)
    }
    totals["max_rss_gib"] = totals["max_rss_kib_time_v"] / 1024 ** 2
    totals["successful_native_max_rss_gib"] = next(r["max_rss_kib_time_v"] for r in runs
                                                          if r["name"] == config["native_run"]) / 1024 ** 2
    totals["within_wall_budget"] = totals["sum_program_wall_seconds_time_v"] <= config["budgets"]["aggregate_seconds"]
    totals["within_rss_budget"] = totals["max_rss_kib_time_v"] * 1024 <= config["budgets"]["memory_bytes"]
    totals["within_observed_evidence_budget"] = totals["max_snapshot_directory_bytes_du_sb"] <= config["budgets"]["evidence_bytes"]
    exact_final = {
        "production_equals_successful_native": read(root / "scripts/step28_group_meta.py") ==
                                               read(base / config["native_run"] / "source/step28_group_meta.py"),
        "checker_equals_successful_native": read(root / "scripts/step28_group_meta_check.py") ==
                                            read(base / config["native_run"] / "source/step28_group_meta_check.py"),
        "tests_equal_tests_final": read(root / "tests/test_step28_group_meta.py") ==
                                   read(base / "tests_final/source/test_step28_group_meta.py")
    }
    probe_summary = {name: {**value,
        "hessian_norm_divided_by_outer_increment_norm": value["hessian_correction_norm"] / value["outer_increment_norm"]}
        for name, value in native["probes"].items()}
    summary = {
        "scope": config["scope"],
        "status": "AUDIT_COMPLETED_WITH_DOCUMENTATION_MISMATCH" if documentation["current_documentation_mismatch"] else "AUDIT_COMPLETED",
        "manifest_counts": {"review": counts(review_checks), "linux_source": counts(linux_source),
                            "linux_evidence": counts(linux_evidence), "linux_root_documents": counts(linux_documents),
                            "initial_source_against_final": counts(initial_checks)},
        "review_checks": review_checks, "linux_source_checks": linux_source,
        "linux_evidence_checks": linux_evidence, "linux_root_document_checks": linux_documents,
        "initial_source_checks": initial_checks, "runs": runs,
        "resource_totals": totals, "successful_native_arithmetic": arithmetic,
        "documentation_finding": documentation, "final_source_identity": exact_final,
        "probes_as_logged_not_recomputed": probe_summary,
        "native_actual_update_count": {
            "native_first": 0, "native_load_fixed": 1, "native_batch32": 1,
            "native_probe_fixed": 2, "total": 4,
            "basis": "Source call order plus preserved failure traces and completion markers; 3 warm calls and 1 completed meta call. Adam counter is expressly rebased 1 to 288, not 288 real updates."
        },
        "limits": [
            "Hash matches establish supplied-byte consistency only.",
            "No native gradient tensors are supplied; probe norms cannot be independently reconstructed from norms alone.",
            "Module norm squared-sum and clip_grad_norm_ reductions are different float32 calculations; their recorded residual is not independently resolved by this audit.",
            "The source defines residual grad_J-grad_Ls-beta*grad_fast_Lq, meaningful for the two instrumented parameter tensors only.",
            "Linux time-v sums include failures; Python-body seconds exclude earlier imports/initialization, and timestamps have only whole seconds.",
            "RSS is not an address-space peak. The launcher ulimit-v controls address space; evidence du-sb snapshots include filesystem directory accounting.",
            "Current code adds no full-model-native restore verification and no GPU execution evidence."
        ]
    }
    (args.out / "source_ledger.json").write_text(json.dumps(ledger, ensure_ascii=False, indent=2) + "\n")
    (args.out / "audit.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
    display = {k: summary[k] for k in ("scope", "status", "manifest_counts", "resource_totals",
                "successful_native_arithmetic", "documentation_finding", "final_source_identity",
                "probes_as_logged_not_recomputed", "native_actual_update_count", "limits")}
    display["initial_changes"] = [r for r in initial_checks if r["state"] != "match"]
    display["run_summaries"] = [{k: r[k] for k in ("name", "status", "exit_status",
        "program_wall_seconds_time_v", "program_user_seconds_time_v", "program_system_seconds_time_v",
        "max_rss_kib_time_v", "python_timed_body_seconds", "cpu_affinity")} for r in runs]
    print(json.dumps(display, ensure_ascii=False, indent=2))
    assert all(r["state"] == "match" for r in review_checks + linux_source + linux_evidence)
    assert arithmetic["scalar_objective_differences_below_1e_5"]
    assert all(exact_final.values())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
