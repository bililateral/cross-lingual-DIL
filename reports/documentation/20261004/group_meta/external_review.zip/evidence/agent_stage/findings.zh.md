# 独立分项审查：阶段路由、完整群隔离、设置与记忆

## 执行范围

本分项实际阅读 `docs/SELLER_ALIAS_GROUP_META.zh.md`、`scripts/step28_group_meta.py`、`tests/test_step28_group_meta.py`、`scripts/step28_group_meta_check.py`、`reports/documentation/20261004/group_meta/implementation.zh.md`，并追踪父 `step28_bge_continual.py` 的 `Memory/schedule/adam_step`、`step28_continual_population_data.py` 的 `Group/Memory/schedule/seed_for`，及相关原有测试。

本环境没有 Torch、Transformers 或 SentenceTransformers；未安装依赖。独立脚本直接导入只依赖标准库的数据模块，再从附件精确 AST 取出实际 `Settings/Episode/train_stage`、父 `Memory/schedule/adam_step` 以及校准参数检查。`parent.contract()` 的依赖闭包未在这个脚本中运行，而由明确标注的适配器返回包内原 policy JSON。真正神经网络 update 用显式路由 spy 替换；spy 只推进手写整数计数，不执行 AdamW。

实际运行命令、时间、stdout/stderr、退出码在 `outputs/01_actual_ast_routing/`。脚本为 `scripts/stage_memory_reference.py`，手写的 144 个完整群及全部设置在 `inputs/`，逐步路由在 `routes.json`，结果和来源大小/哈希在 `results.json`。本次共有 12 个正 beta 的完整阶段路由检查（三顺序、两个后续阶段、两套设置），另有变异与退化检查；实际神经网络/AdamW 更新为 0。退出码 0 表示本脚本所有预定断言成立，不能叫作 12×288 次真实训练。

## 阶段语义与检查结论

| 数字 | 实际含义与位置 |
|---|---|
| 48 | 当前域拟合群数，不含校准或 valid；父 `schedule` 校验长度和 UID 唯一性，`step28_bge_continual.py:56–62`。|
| 6 | 每个阶段当前日程为六轮；同时历史记忆容量也是六群，这是两个不同含义。|
| 288 | 48×6 个 support 位置，生产阶段 API 期望每位置一次 `update`；`step28_group_meta.py:234–249`。|
| 1152 | 正 beta 时每步 Cs/Hs/Cq/Hq 四群，4×288 次群呈现；不包括二阶计算的额外算术代价。|
| 576 | 原两群 LOGIT 在后续阶段的 2×288 次群呈现；也应为 beta=0 跳过 query 时的实际数量。|

当前 `Cq = sequence[(index // 48) * 48 + (index % 48 + 1) % 48]`，即每个 48 群排列内循环移一位（`step28_group_meta.py:240`）。独立执行验证每当前群作为 Cs、Cq 各出现六次，每步二者不同。Cq 通常就是下一步的 Cs，所以它是训练日程中的另一群，不是永久外层留出，更不是真正未见卖家。

`Hs` 继承父 `Memory.draw()` 的每步有放回抽取；`Hq` 从当步除 Hs 外的五群中以独立无状态随机流选取（`step28_group_meta.py:235–239`；父 `Memory.draw` 为 `step28_bge_continual.py:164–169`）。因此“无放回”只表达同一步不能重用 Hs；跨步允许重复，Hq 也可在其他步成为 Hs。独立 ABC/stage2 手写路由中 Hq 各群计数为 39、63、51、43、49、43，出现 53 次相邻步同 Hq；这不是 bug，也不是每群均分 48 次。三顺序两阶段在两套设置下均保持同一配对供给。

四种 dropout seeds 在每次调用中不同，分别沿用 current/support、history/support 及两条 meta-query 命名随机流（`step28_group_meta.py:243–246`）；本分项核验值与路由可重复性，不核验 Torch dropout 的执行或梯度。

## 完整群与参考绑定

`Episode.validate()` 先调用每个 `Group.validate()`，再检查四群 UID、seller UID 和 item UID 跨群不交叉（`step28_group_meta.py:69–86`）。独立构造的重复群、只重用 seller UID、只重用一个 item UID、参考 UID 绑定另一历史群、float64 参考均被当前生产验证器拒绝。

`reference_uid` 是显式身份标签，但标签本身不能认证数值来源：把另一群的 378 维参考塞进来而仍写正确 Hs UID，单独 `Episode.validate()` 会接受。这是该检查能力的边界，不是当前实际取值错。当前 stage 从父 `memory.draw()` 得到对应 `references[group.uid].copy()`，然后把同一 Hs UID 传入 Episode，实际路径绑定正确（`step28_bge_continual.py:167–169`；`step28_group_meta.py:235,241–242`）。阶段检查用参考与 `memory.references[Hs.uid]` 实际逐元素相等来发现错误，独立将 Hq 参考错绑到 Hs 的变异被拒绝，378/378 元素不符。

当前最终提供的阶段参考每个群数值不同，因此可以识别跨 UID 错绑；每群内部 378 边仍是常量，因此无法鉴别群内边顺序置换（`tests/test_step28_group_meta.py:155–164`）。所有 `handmade_group` 的标签又共享固定 owner 排列，shift 只改文本，不能很好识别另一群标签误用（`tests/test_step28_bge_continual_contracts.py:24–31`）。这些是现有证据盲区；本分项没有发现实际生产代码发生这些错绑。最小加强是让不同群用不同合法账号分区/边标签，以及每边不同的参考，再用独立预期核对实际目标；无需补跑整个原生 BGE 核验。本分项使用了每群每边均变化的手写参考，但没有执行神经损失。

原 identity 测试没有单独的 item 重用反例（`tests/test_step28_group_meta.py:56–67`）。独立删去 `items & seen_items` 的 AST 变异会接收只重用 item 的反例；给原测试补一个该反例即可。这是回归覆盖修补，当前代码的 item 检查本身正确。

## 当前应修的窄实现缺陷：beta=0 群呈现计数

`Settings` 接受 `outer_weight=0`，`lookahead` 明确在 beta=0 返回 support，关闭 query（`step28_group_meta.py:50–56,103–105`）。但 `train_stage` 对全部设置恒返回 `gradient_group_presentations = 4 * len(records)`（同文件 `253–254`）。实际可执行的 API 因而在 beta=0 时仍写 1152，真实应为 576。

本分项用精确 `lookahead` 的早返分支探针确认只调用 support、query 零调用，并用精确 `train_stage` 路由 spy 确认 beta=0 仍返回 1152。没有借此冒称跑过神经梯度；差异由源代码控制流直接决定。

最小修正是按 `settings.outer_weight > 0` 计算每步呈现数 4 或 2；并添加一项 beta=0 阶段计数断言。也可在阶段 API 明确拒绝 beta=0，仅把它保留在 objective/update 的退化核验，但改计数更小且不限制已有合法参数。该缺陷不推翻本包正 beta=.7 的原生元更新，亦不意味着当前没有正式运行的科研结果被污染。

## 设置传递：代码正确、现有证明不足

`Settings` 四个参数都没有默认值，合同亦称无正式默认值（`step28_group_meta.py:43–56`；合同 `23`）。因此应称“显式设置”，不能以默认/非默认掩盖未冻结正式参数。

当前 production `train_stage` 把其 settings 参数直接传给 update（`247–248`），并保存到 auxiliary（`250–252`）。独立以 (.03,.04,.3,.7) 与 (.015,.09,.8,.2) 两套设置，在三顺序两个后续阶段均验证原样送达、持久序列化一致。

原阶段 spy 只检查 setup() 的 (.03,.04,.3,.7)，然后又硬编码断言同一四元组（`tests/test_step28_group_meta.py:148–168`）。若生产路由把用户设置偷偷替换成这个常量，原夹具仍通过。独立真实 AST 变异也呈现：原四元组未被检出，第二四元组立即因 “Settings replaced” 被检出。最小修正是参数化该阶段测试为两个互不相同四元组，并从当前测试参数捕获 expected 设置；不是重写生产算法。

## 历史状态、预算与淘汰

新增算法复用父 `Memory`：Algorithm R 只接收当前 48 群；retain 先删除已淘汰群的 references/origins，旧存活 reference 保留；只给新入缓存群调用当前 stage 的 score callback（`step28_bge_continual.py:130–154`）。独立检查确认回调只接到新当前群，存活旧参考完全不变，已淘汰 UID 不再出现在 references/origins 中。

完整 JSON 计入 reservoir 群文本/标签/排序、Algorithm R RNG/seen、来源 logits/origins、first_map、history draw RNG/count、auxiliary 等字段（父文件 `171–187`）。新增 settings、completed_stage/query_schedule 在 stage 末进入 auxiliary 并调用 `to_bytes()`（新文件 `250–252`）。本手写样例包含这些字段后约 95,712–96,297 字节；这只是手写输入大小，不能替代真实缓存预算验收。向 auxiliary 额外塞入 1MiB padding 被整体预算检查拒绝。

独立在第 37 次历史 draw 后序列化/恢复，剩余 251 次 draw 的 UID 与 378 维参考完全一致；第 289 次 draw 被拒绝。它支持记忆状态恢复的结论，不是全阶段中断续跑或真实模型/Adam 恢复证明。

淘汰后不可重读，在本轮实际 API 上由只接收当前群与自包含记忆、没有 Archive 参数/回调来实现。父 Algorithm R 明确不保留全历史 ID 表，阶段唯一性最终依赖未来 runner 正确按冻结合约提供互不重叠阶段（`step28_continual_population_data.py:211–225`，注释 `212`）。旧 dispatcher 的不可 rewind 机制属于未变复用范围；本轮没有接入正式 runner，所以不能宣称已验证将来的正式旧数据访问闭环。无需本轮增加全历史名单、教师快照或读取淘汰数据来认证此点。

### 六群不保证覆盖每个旧域

在冻结 memory_seed=20260930、每个阶段 48 群、同一 Algorithm R 随机流下，插入第二域之后，本分项得到：ABC 保留首域 4 群、BCA 保留首域 2 群、CAB 保留首域 0 群。该“来源阶段数量”由插入次数和替换随机流决定，不依赖手写文本。CAB 的六群全为第二域，因此第三阶段 Hq 不会直接出现首域缓存。这是继承随机供给允许的结果，并非新增代码违规；它明确限制“群隔离保证所有旧域保持”的说法。不能为使算法更好看而在本轮偷偷改成分层保留。

## 科学/未来建议与不必要范围

四群在一个更新内按已声明 UID 隔离，仍来自当前训练集与反复使用的六群训练缓存。该设计可研究跨训练群的一步迁移倾向；不能单靠训练日志证明旧分布未见卖家 MAP、低 FPR 识别能力或新域学习改善。Hq 缺失旧域覆盖、训练外层反复使用、随机缓存代表性不足都是真实泛化差距，而不是本轮必须读取 test/owners 才能补齐的实现 bug。

正 beta 每阶段当前与历史群呈现各增加一倍，还增加完整二阶及 float32/no-checkpoint 执行成本。未来需要对齐实际群呈现与执行设置的普通四群联合目标，以及最直接的元重放/隔离对照，才能区分更多训练量、元更新、群隔离的贡献。本轮无需增加正式训练、所有旧权重基线、全参数穷尽探针或大规模消融。

阶段 1 没有历史群，不能伪造 Hs/Hq；合同已将其交给原基础训练。源阶段恢复、阶段末 score(eval) 编排、正式参数冻结、GPU 可行性、正式完整计量与评价门，都应由未来正式合同处理。当前没有该 runner 不是已经授权手写实现工作的新增阻断。
