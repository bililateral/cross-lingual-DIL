#!/usr/bin/env python3
"""Independent routing/memory audit using exact selected source AST, no Torch.

This is not a native model test. We import the standard-library data module,
compile exact source classes/functions for memory and routing, and replace only
the optimizer update with an explicitly named routing spy. Policy-file closure
checks and all neural/autograd code are outside this execution's scope.
"""
from __future__ import annotations

import argparse
import ast
import copy
import dataclasses
import hashlib
import importlib.util
import itertools
import json
import math
from pathlib import Path
import random
import sys
import types
from collections import Counter
from typing import Any, Callable

import numpy as np


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def extract(path, names, namespace, transform=None):
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    selected = [node for node in tree.body if getattr(node, "name", None) in names]
    assert {node.name for node in selected} == set(names)
    tree = ast.Module(body=selected, type_ignores=[])
    if transform:
        tree = transform.visit(tree)
    ast.fix_missing_locations(tree)
    exec(compile(tree, str(path), "exec", flags=__import__("__future__").annotations.compiler_flag), namespace)
    return namespace


def rejected(fn, kind=ValueError):
    try:
        fn()
    except kind as exc:
        return {"rejected": True, "type": type(exc).__name__, "message": str(exc)}
    return {"rejected": False}


class ConstantSettings(ast.NodeTransformer):
    def visit_Call(self, node):
        node = self.generic_visit(node)
        if isinstance(node.func, ast.Name) and node.func.id == "update":
            node.args[4] = ast.Call(func=ast.Name(id="Settings", ctx=ast.Load()),
                                    args=[ast.Constant(v) for v in (.03, .04, .3, .7)], keywords=[])
        return node


class SameCurrentQuery(ast.NodeTransformer):
    def visit_Assign(self, node):
        node = self.generic_visit(node)
        if any(isinstance(t, ast.Name) and t.id == "current_query" for t in node.targets):
            node.value = ast.Name(id="current_support", ctx=ast.Load())
        return node


class WrongReference(ast.NodeTransformer):
    def visit_Call(self, node):
        node = self.generic_visit(node)
        if isinstance(node.func, ast.Name) and node.func.id == "Episode":
            node.args[4] = ast.parse("memory.references[history_query.uid]", mode="eval").body
        return node


class RemoveItemIsolation(ast.NodeTransformer):
    def visit_BinOp(self, node):
        if (isinstance(node.op, ast.BitAnd) and isinstance(node.left, ast.Name)
                and node.left.id == "items" and isinstance(node.right, ast.Name)
                and node.right.id == "seen_items"):
            return ast.copy_location(ast.Constant(False), node)
        return self.generic_visit(node)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--evidence", type=Path, required=True)
    args = parser.parse_args()
    source, evidence = args.source.resolve(), args.evidence.resolve()
    paths = {"data": source / "scripts/step28_continual_population_data.py",
             "parent": source / "scripts/step28_bge_continual.py",
             "meta": source / "scripts/step28_group_meta.py",
             "calibration": source / "scripts/step28_alias_calibration.py",
             "policy": source / "schema/step28_bge_continual_policy.json",
             "tests": source / "tests/test_step28_group_meta.py"}
    inventory = [{"path": str(p.relative_to(source)), "bytes": p.stat().st_size, "sha256": sha(p)}
                 for p in paths.values()]
    spec = importlib.util.spec_from_file_location("audit_stage_data", paths["data"])
    data = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = data
    spec.loader.exec_module(data)
    calibration_ns = {"np": np, "BOUNDS": ((.001, 100.), (-100., 100.))}
    extract(paths["calibration"], {"parameters"}, calibration_ns)
    policy = json.loads(paths["policy"].read_text())
    parent_ns = {"data": data, "np": np, "json": json, "random": random, "hashlib": hashlib,
                 "Any": Any, "Callable": Callable, "ORDERS": ("ABC", "BCA", "CAB"),
                 "calibration": types.SimpleNamespace(parameters=calibration_ns["parameters"])}
    extract(paths["parent"], {"Memory", "schedule", "adam_step"}, parent_ns)
    parent = types.SimpleNamespace(**{name: parent_ns[name] for name in ("Memory", "schedule", "adam_step")})
    parent.contract = lambda: copy.deepcopy(policy)
    base_ns = {"data": data, "parent": parent, "np": np, "math": math,
               "dataclass": dataclasses.dataclass, "Any": Any, "Callable": Callable}
    extract(paths["meta"], {"Settings", "Episode", "train_stage"}, base_ns)
    Settings, Episode = base_ns["Settings"], base_ns["Episode"]

    def handmade(uid):
        # All text and labels here are generated by this audit, not formal data.
        owner = [i for i, n in enumerate([3] * 4 + [2] * 8) for _ in range(n)]
        labels = tuple(int(owner[i] == owner[j]) for i, j in itertools.combinations(range(28), 2))
        group = data.Group(uid, tuple(f"{uid}_seller_{i:02}" for i in range(28)),
                           tuple(tuple((f"{uid}_item_{i:02}_{j}", f"Handwritten title {i} {j}",
                                        f"Handwritten description {uid} {i} {j}") for j in range(2))
                                 for i in range(28)), labels)
        group.validate()
        return group

    groups = {domain: [handmade(f"{domain}_audit_{i:02}") for i in range(48)] for domain in "ABC"}
    def score(rows):
        return np.stack([np.arange(378, dtype=np.float32) / 10000
                         + ((ord(g.uid[0]) - 64) * 100 + int(g.uid.rsplit("_", 1)[1])) / 100
                         for g in rows]).astype(np.float32)

    def initial_memory(order):
        mem = parent.Memory(order, policy["memory_seed"], True, {"a": 1., "b": 0.})
        mem.retain(groups[order[0]], 1, score)
        return mem

    settings_input = [(.03, .04, .3, .7), (.015, .09, .8, .2)]
    result = {"scope": "Exact selected AST + standard library/NumPy; update is a routing spy; no Torch/BGE/model update",
              "policy_check_scope": "Loaded supplied JSON. parent.contract closure checks are not executed.",
              "source_inventory": inventory, "stage_cases": [], "mutations": {}, "validation": {},
              "memory": {}, "real_model_updates": 0}
    all_routes = []

    def run_stage(order, stage, settings, mem, optimizer, transform=None, check_settings=True):
        namespace = dict(base_ns)
        calls = []
        config = {"audit_only": True}
        def spy(model, optimizer, episode, received_config, received_settings, received_stage,
                step, seeds, check):
            episode.validate()
            assert received_config is config
            assert received_stage == stage and step == len(calls) + 1
            if check_settings:
                assert received_settings is settings or received_settings == settings, "Settings replaced"
            np.testing.assert_array_equal(episode.reference, mem.references[episode.history_support.uid])
            assert len(set(seeds)) == 4
            calls.append({"step": step, "uids": [g.uid for g in episode.groups()], "seeds": list(seeds),
                          "settings": dataclasses.asdict(received_settings)})
            optimizer.state["spy_only"]["step"] += 1  # Counter simulation, never AdamW.
            return {"stage": stage, "step": step, "spy": True}
        namespace["update"] = spy
        if transform:
            extract(paths["meta"], {"train_stage"}, namespace, transform)
        # Recompile even the unchanged function to bind this spy's namespace.
        else:
            extract(paths["meta"], {"train_stage"}, namespace)
        output = namespace["train_stage"](object(), optimizer, groups[order[stage - 1]], mem,
                                           config, order, stage, settings)
        return output, calls

    for order in ("ABC", "BCA", "CAB"):
        for set_index, values in enumerate(settings_input):
            settings = Settings(*values)
            mem = initial_memory(order)
            optimizer = types.SimpleNamespace(state={"spy_only": {"step": 288}})
            for stage in (2, 3):
                origins = {uid: row.copy() for uid, row in mem.references.items()}
                output, calls = run_stage(order, stage, settings, mem, optimizer)
                assert len(calls) == output["physical_updates"] == 288
                assert output["gradient_group_presentations"] == 1152
                assert mem.draw_count == 288
                for role in (0, 2):
                    assert set(Counter(call["uids"][role] for call in calls).values()) == {6}
                for index, call in enumerate(calls):
                    next_index = (index // 48) * 48 + (index % 48 + 1) % 48
                    assert call["uids"][2] == calls[next_index]["uids"][0]
                    assert call["uids"][1] != call["uids"][3]
                for uid, row in origins.items():
                    np.testing.assert_array_equal(row, mem.references[uid])
                assert mem.auxiliary["group_meta"]["settings"] == dataclasses.asdict(settings)
                restored = parent.Memory.from_bytes(mem.to_bytes())
                assert restored.to_bytes() == mem.to_bytes()
                current_counts = Counter(call["uids"][0] for call in calls)
                hist_support = Counter(call["uids"][1] for call in calls)
                hist_query = Counter(call["uids"][3] for call in calls)
                summary = {"order": order, "stage": stage, "settings_index": set_index,
                           "calls": len(calls), "claimed_group_presentations": output["gradient_group_presentations"],
                           "current_support_counts": sorted(set(current_counts.values())),
                           "history_support_counts": dict(sorted(hist_support.items())),
                           "history_query_counts": dict(sorted(hist_query.items())),
                           "history_query_consecutive_repeats": sum(calls[i]["uids"][3] == calls[i-1]["uids"][3]
                                                                      for i in range(1, 288)),
                           "serialized_bytes": len(mem.to_bytes())}
                result["stage_cases"].append(summary)
                all_routes.append({"order": order, "stage": stage, "settings_index": set_index, "calls": calls})
                if stage == 2:
                    called = []
                    def score_new(rows):
                        assert all(g.uid.startswith(order[1] + "_") for g in rows), "Old group re-scored"
                        called.extend(g.uid for g in rows)
                        return score(rows)
                    mem.retain(groups[order[1]], 2, score_new)
                    retained = {g.uid for g in mem.reservoir.groups}
                    assert set(mem.references) == set(mem.reference_origins) == retained
                    for uid in set(origins) & retained:
                        np.testing.assert_array_equal(origins[uid], mem.references[uid])
                    assert set(called) == retained - set(origins)
                    summary["newly_scored_uids"] = called
                    summary["evicted_uids"] = sorted(set(origins) - retained)

    quartet = [groups["A"][0], groups["B"][0], groups["A"][1], groups["B"][1]]
    episode = Episode(*quartet, score([quartet[1]])[0], quartet[1].uid)
    episode.validate()
    repeated_item = episode.current_support.items[0][0][0]
    items = [list(rows) for rows in episode.current_query.items]
    _, title, description = items[0][0]
    items[0][0] = (repeated_item, title, description)
    items = tuple(tuple(sorted(rows)) for rows in items)
    overlap_item_query = dataclasses.replace(episode.current_query, items=items)
    overlap_seller_query = dataclasses.replace(episode.current_query, sellers=episode.current_support.sellers)
    bad_cases = {
        "group_uid_overlap": dataclasses.replace(episode, current_query=episode.current_support),
        "seller_uid_overlap": dataclasses.replace(episode, current_query=overlap_seller_query),
        "item_uid_overlap": dataclasses.replace(episode, current_query=overlap_item_query),
        "reference_uid_mismatch": dataclasses.replace(episode, reference_uid=episode.history_query.uid),
        "reference_dtype_float64": dataclasses.replace(episode, reference=episode.reference.astype(np.float64)),
    }
    for label, candidate in bad_cases.items():
        result["validation"][label] = rejected(candidate.validate)
        assert result["validation"][label]["rejected"]
    wrong_values_own_tag = dataclasses.replace(episode, reference=score([episode.history_query])[0])
    result["validation"]["wrong_values_but_own_uid_tag"] = rejected(wrong_values_own_tag.validate)
    assert not result["validation"]["wrong_values_but_own_uid_tag"]["rejected"]

    mutated_ns = dict(base_ns)
    extract(paths["meta"], {"Episode"}, mutated_ns, RemoveItemIsolation())
    bad = bad_cases["item_uid_overlap"]
    mutant = mutated_ns["Episode"](*bad.groups(), bad.reference, bad.reference_uid)
    result["mutations"]["removed_item_isolation_accepts_overlap"] = not rejected(mutant.validate)["rejected"]
    assert result["mutations"]["removed_item_isolation_accepts_overlap"]
    # The supplied identity/reference unit test has no item-overlap case.
    tested_text = paths["tests"].read_text()
    identity_function = next(n for n in ast.walk(ast.parse(tested_text))
                             if isinstance(n, ast.FunctionDef) and n.name == "test_whole_group_identity_and_reference_binding")
    result["mutations"]["provided_identity_test_mentions_items"] = any(
        isinstance(n, ast.Attribute) and n.attr == "items" for n in ast.walk(identity_function))
    assert not result["mutations"]["provided_identity_test_mentions_items"]

    for name, transform, values in (
        ("hardcoded_fixture_settings_original_tuple", ConstantSettings(), settings_input[0]),
        ("hardcoded_fixture_settings_alternate_tuple", ConstantSettings(), settings_input[1]),
        ("current_query_equals_support", SameCurrentQuery(), settings_input[0]),
        ("history_query_target_bound_to_support_uid", WrongReference(), settings_input[0]),
    ):
        mem = initial_memory("ABC")
        optimizer = types.SimpleNamespace(state={"spy_only": {"step": 288}})
        state = rejected(lambda: run_stage("ABC", 2, Settings(*values), mem, optimizer, transform),
                         (ValueError, AssertionError))
        result["mutations"][name] = state
    assert not result["mutations"]["hardcoded_fixture_settings_original_tuple"]["rejected"]
    assert result["mutations"]["hardcoded_fixture_settings_alternate_tuple"]["rejected"]
    assert result["mutations"]["current_query_equals_support"]["rejected"]
    assert result["mutations"]["history_query_target_bound_to_support_uid"]["rejected"]

    mem = initial_memory("ABC")
    mem.begin_stage(2)
    for _ in range(37):
        mem.draw()
    restored = parent.Memory.from_bytes(mem.to_bytes())
    for _ in range(251):
        a, ar = mem.draw()
        b, br = restored.draw()
        assert a.uid == b.uid
        np.testing.assert_array_equal(ar, br)
    result["memory"]["remaining_251_draws_after_restore_exact"] = True
    result["memory"]["extra_289th_draw"] = rejected(mem.draw)
    assert result["memory"]["extra_289th_draw"]["rejected"]
    size_before = len(mem.to_bytes())
    mem.auxiliary["audit_padding"] = "x" * 1048576
    result["memory"]["auxiliary_budget_overflow"] = rejected(mem.to_bytes)
    assert result["memory"]["auxiliary_budget_overflow"]["rejected"]
    result["memory"]["normal_serialized_bytes_before_padding"] = size_before

    # beta=0 executes only support in the exact lookahead source. This probe
    # exercises its early return without claiming scalar autograd or Torch.
    class LossProbe(float):
        def new_zeros(self, shape):
            assert shape == ()
            return LossProbe(0)
    early_ns = {"math": math, "Callable": Callable}
    extract(paths["meta"], {"lookahead"}, early_ns)
    role_calls = {"support_group_calls": 0, "query_group_calls": 0}
    def support_probe(parameters):
        role_calls["support_group_calls"] += 2
        return LossProbe(1)
    def query_probe(parameters):
        role_calls["query_group_calls"] += 2
        raise AssertionError("beta=0 should not evaluate query")
    early_ns["lookahead"]({"p": 1}, support_probe, query_probe, {"p": .2}, 0.)
    mem = initial_memory("ABC")
    optimizer = types.SimpleNamespace(state={"spy_only": {"step": 288}})
    output, _ = run_stage("ABC", 2, Settings(.03, .04, .3, 0.), mem, optimizer)
    result["beta_zero_accounting"] = {"lookahead_role_probe": role_calls,
                                      "stage_reported_group_presentations": output["gradient_group_presentations"],
                                      "expected_from_executed_roles": 288 * role_calls["support_group_calls"],
                                      "actual_model_training": False}
    assert role_calls == {"support_group_calls": 2, "query_group_calls": 0}
    assert output["gradient_group_presentations"] == 1152

    evidence.mkdir(parents=True, exist_ok=True)
    (evidence / "inputs").mkdir(exist_ok=True)
    (evidence / "inputs" / "handwritten_groups.json").write_text(
        json.dumps({d: [g.payload() for g in rows] for d, rows in groups.items()}, ensure_ascii=False, indent=2) + "\n")
    (evidence / "inputs" / "settings_and_scope.json").write_text(json.dumps({
        "settings": settings_input, "extra_degenerate_beta": 0., "source_inventory": inventory,
        "policy": policy, "scope": result["scope"], "policy_check_scope": result["policy_check_scope"]}, indent=2) + "\n")
    (evidence / "routes.json").write_text(json.dumps(all_routes, indent=2) + "\n")
    (evidence / "results.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    print("COMPLETED: 12 positive-beta stage routing spies, 0 neural/AdamW updates; explicit defects/limits retained.")


if __name__ == "__main__":
    main()
