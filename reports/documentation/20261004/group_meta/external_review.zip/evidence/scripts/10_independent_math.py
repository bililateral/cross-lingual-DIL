#!/usr/bin/env python3
"""Independent analytical/NumPy audit; no Torch/BGE import or emulation.

The 28-account reference uses a deliberately small nonlinear three-parameter
score function. It independently implements BCE + query-rank + .5 Top5-hard,
and its exact local gradient/Hessian. It is a mathematical oracle, not a run of
the submitted production model or an empirical method comparison.
"""
from __future__ import annotations
import itertools, json, math, pathlib
import numpy as np

ROOT=pathlib.Path(__file__).resolve().parents[1]
INPUT=ROOT/'inputs'; INPUT.mkdir(exist_ok=True)
RESULT=ROOT/'outputs'/'10_math'; RESULT.mkdir(parents=True,exist_ok=True)
PAIRS=np.array(list(itertools.combinations(range(28),2)))

def scalar_case():
    t,a,b=.3,.2,.7
    ls=lambda x:.5*(x-1)**2
    lq=lambda x:.5*(x+1)**2
    fast=t-a*(t-1)
    exact=(t-1)+b*(1-a)*(fast+1)
    objective=lambda x:ls(x)+b*lq(x-a*(x-1))
    eps=1e-6
    finite=(objective(t+eps)-objective(t-eps))/(2*eps)
    result={'theta':t,'alpha':a,'beta':b,'fast':fast,
            'support_before':ls(t),'support_after':ls(fast),
            'query_before':lq(t),'query_after':lq(fast),
            'J':objective(t),'exact_gradient':exact,'finite_difference':finite,
            'detach_inner_gradient':(t-1)+b*(fast+1),
            'query_at_original_gradient':(t-1)+b*(t+1)}
    assert abs(exact-.1064)<1e-12 and abs(exact-finite)<1e-9
    assert ls(fast)<ls(t) and lq(fast)>lq(t)
    assert abs(exact-result['detach_inner_gradient'])>.1
    assert abs(exact-result['query_at_original_gradient'])>.1
    return result

def sigmoid(x):
    return 1/(1+np.exp(-x))

def make_fixture():
    rng=np.random.default_rng(1042026)
    raw=rng.normal(scale=.12,size=(4,378,3,3))
    curvature=(raw+raw.swapaxes(-1,-2))/2
    linear=rng.normal(scale=.55,size=(4,378,3))
    intercept=rng.normal(scale=.35,size=(4,378))
    owners=np.repeat(np.arange(12),[3]*4+[2]*8)
    labels=[]
    for role in range(4):
        permutation=rng.permutation(28)
        components=owners[permutation]
        labels.append((components[PAIRS[:,0]]==components[PAIRS[:,1]]).astype(float))
    labels=np.array(labels)
    assert (labels.sum(axis=1)==20).all()
    assert len({row.tobytes() for row in labels})==4
    targets=rng.normal(loc=np.arange(4)[:,None]*.17,scale=.25,size=(4,378)).astype(np.float32)
    theta=np.array([.23,-.31,.17],dtype=np.float64)
    rates=np.array([.031,.067,.113],dtype=np.float64)
    return dict(linear=linear,curvature=curvature,intercept=intercept,
                labels=labels,targets=targets,theta=theta,rates=rates)

def score(f,role,t):
    F,Q,c=f['linear'][role],f['curvature'][role],f['intercept'][role]
    return c+F@t+.5*np.einsum('i,nij,j->n',t,Q,t),F+np.einsum('nij,j->ni',Q,t),Q

def base_loss(f,role,t,label_role=None):
    """Exact derivatives inside a fixed Top5 ordering cell."""
    z,dz,ddz=score(f,role,t)
    y=f['labels'][role if label_role is None else label_role]
    prob=sigmoid(z)
    bce=float(np.mean(np.logaddexp(0,z)-y*z))
    grad=np.mean((prob-y)[:,None]*dz,axis=0)
    hess=np.mean((prob*(1-prob))[:,None,None]*np.einsum('ni,nj->nij',dz,dz)
                 +(prob-y)[:,None,None]*ddz,axis=0)
    rank,hard=0.,0.
    selections=[]
    for query in range(28):
        edges=np.flatnonzero((PAIRS==query).any(axis=1))
        positives=edges[y[edges]==1]
        negatives=edges[y[edges]==0]
        def other(edge):
            u,v=PAIRS[edge]; return int(v if u==query else u)
        selected=np.array(sorted(negatives,key=lambda k:(-z[k],other(k)))[:5])
        selections.append(tuple(int(k) for k in selected))
        local=z[edges]; maximum=float(local.max())
        weights=np.exp(local-maximum); weights/=weights.sum()
        rank+=(maximum+math.log(np.exp(local-maximum).sum())-z[positives].mean())/28
        average=weights@dz[edges]
        grad+=(average-dz[positives].mean(axis=0))/28
        hess+=(np.einsum('n,nij->ij',weights,ddz[edges])
               +np.einsum('n,ni,nj->ij',weights,dz[edges],dz[edges])
               -np.outer(average,average)-ddz[positives].mean(axis=0))/28
        for positive in positives:
            for negative in selected:
                delta=z[negative]-z[positive]
                ddelta=dz[negative]-dz[positive]
                dddelta=ddz[negative]-ddz[positive]
                p=float(sigmoid(delta)); w=.5/(28*len(positives)*5)
                hard+=float(np.logaddexp(0,delta))/(28*len(positives)*5)
                grad+=w*p*ddelta
                hess+=w*(p*(1-p)*np.outer(ddelta,ddelta)+p*dddelta)
    return bce+rank+.5*hard,grad,hess,tuple(selections)

def mse_loss(f,role,t,target_role):
    z,dz,ddz=score(f,role,t)
    residual=z-f['targets'][target_role].astype(float)
    return (float(np.mean(residual**2)),
            2*np.mean(residual[:,None]*dz,axis=0),
            2*np.mean(np.einsum('ni,nj->nij',dz,dz)+residual[:,None,None]*ddz,axis=0))

def support(f,t,target_role=1):
    current=base_loss(f,0,t); history=base_loss(f,1,t); mse=mse_loss(f,1,t,target_role)
    values=tuple(current[i]+.1*history[i]+.5*mse[i] for i in range(3))
    return (*values,(current[3],history[3]))

def query_loss(f,t,rho,history_role=3,wrong_labels=False):
    current=base_loss(f,2,t,label_role=0 if wrong_labels else None)
    history=base_loss(f,history_role,t,label_role=1 if wrong_labels else None)
    values=tuple(current[i]+rho*history[i] for i in range(3))
    return (*values,(current[3],history[3]))

def objective(f,t,rates,rho,beta,*,target_role=1,history_role=3,wrong_labels=False):
    s=support(f,t,target_role)
    fast=t-rates*s[1]
    q=query_loss(f,fast,rho,history_role,wrong_labels)
    gradient=s[1]+beta*(q[1]-s[2]@(rates*q[1]))
    return {'J':float(s[0]+beta*q[0]),'gradient':gradient,'support':s,'query':q,'fast':fast}

def finite_gradient(fn,t,eps=1e-5):
    out=[]
    for i in range(len(t)):
        d=np.zeros_like(t);d[i]=eps
        out.append((fn(t+d)-fn(t-d))/(2*eps))
    return np.array(out)

def finite_jacobian(fn,t,eps=1e-5):
    columns=[]
    for i in range(len(t)):
        d=np.zeros_like(t);d[i]=eps
        columns.append((fn(t+d)-fn(t-d))/(2*eps))
    return np.stack(columns,axis=1)

def pair_reference(f):
    t,A=f['theta'],f['rates']; rho,beta=.61,.43
    actual=objective(f,t,A,rho,beta)
    finite=finite_gradient(lambda x:objective(f,x,A,rho,beta)['J'],t)
    errors={}
    stable=True
    for role in range(4):
        value,gradient,hessian,selections=base_loss(f,role,t)
        errg=float(np.max(np.abs(gradient-finite_gradient(lambda x:base_loss(f,role,x)[0],t))))
        errh=float(np.max(np.abs(hessian-finite_jacobian(lambda x:base_loss(f,role,x)[1],t))))
        errors[str(role)]={'base_gradient_max_abs_error':errg,'base_hessian_max_abs_error':errh}
        assert errg<1e-8 and errh<1e-8
    for i in range(3):
        d=np.zeros(3);d[i]=1e-5
        for sign in [-1,1]:
            perturbed=objective(f,t+sign*d,A,rho,beta)
            stable &= (actual['support'][3]==perturbed['support'][3]
                       and actual['query'][3]==perturbed['query'][3])
    assert stable,'Reference point crossed a Top5 selection boundary'
    gradient_error=float(np.max(np.abs(actual['gradient']-finite)))
    assert gradient_error<1e-8
    gs,Hs=actual['support'][1:3];gq=actual['query'][1]
    mutants={
        'detach_inner':{'gradient':gs+beta*gq,'J':actual['J']},
        'query_at_original_theta':{'gradient':gs+beta*query_loss(f,t,rho)[1],
                                  'J':float(actual['support'][0]+beta*query_loss(f,t,rho)[0])},
        'wrong_hessian_matrix_order':{'gradient':gs+beta*(gq-A*(Hs@gq)),'J':actual['J']},
        'hardcode_rho_0p3':objective(f,t,A,.3,beta),
        'hardcode_beta_0p7':objective(f,t,A,rho,.7),
        'wrong_support_target_uid':objective(f,t,A,rho,beta,target_role=3),
        'query_history_uses_support_group':objective(f,t,A,rho,beta,history_role=1),
        'query_labels_from_wrong_groups':objective(f,t,A,rho,beta,wrong_labels=True),
        'inner_step_head_only':objective(f,t,A*np.array([0.,0.,1.]),rho,beta),
    }
    mutation_results=[]
    for name,mutant in mutants.items():
        delta=float(np.linalg.norm(mutant['gradient']-actual['gradient']))
        assert delta>1e-6,(name,delta)
        mutation_results.append({'mutation':name,'gradient':mutant['gradient'].tolist(),
             'gradient_difference_norm':delta,'J':float(mutant['J']),
             'finite_loss_and_nonzero_gradient':bool(np.isfinite(mutant['J']) and np.linalg.norm(mutant['gradient'])>0),
             'detected_by_independent_exact_gradient':True})
    zero=objective(f,t,A,rho,0.)
    assert np.array_equal(zero['gradient'],gs)
    result={'scope':'independent 3-parameter nonlinear NumPy scores, not production Torch/BGE',
       'accounts_per_group':28,'edges_per_group':378,'candidates_per_query':27,'positive_edges_per_group':20,
       'labels_differ_between_all_roles':True,'targets_vary_across_groups_and_edges':True,
       'theta':t.tolist(),'inner_rates':A.tolist(),'rho':rho,'beta':beta,
       'J':actual['J'],'support_loss':float(actual['support'][0]),'query_loss':float(actual['query'][0]),
       'fast_parameters':actual['fast'].tolist(),'exact_gradient':actual['gradient'].tolist(),
       'finite_difference_gradient':finite.tolist(),'gradient_max_abs_error':gradient_error,
       'support_hessian':Hs.tolist(),'noncommuting_HA_AH_norm':float(np.linalg.norm(Hs@np.diag(A)-np.diag(A)@Hs)),
       'local_top5_selection_stable':stable,'component_checks':errors,'beta_zero_equals_support_gradient':True,
       'mutants':mutation_results}
    return result

def main():
    scalar=scalar_case();fixture=make_fixture()
    np.savez_compressed(INPUT/'nonlinear_28_account_fixture.npz',**fixture)
    (INPUT/'math_fixture_description.json').write_text(json.dumps({
        'seed':1042026,'dtype':'float64 score arithmetic; float32 saved targets',
        'group_roles':['current_support','history_support','current_query','history_query'],
        'score_formula':'z_e(theta)=intercept_e+linear_e@theta+.5*theta.T@curvature_e@theta',
        'loss_formula':'BCE+mean_query(logsumexp(all 27)-mean(positives))+.5*mean_query_pair(softplus(top5_negative-positive))',
        'support_formula':'base(Cs)+.1*base(Hs)+.5*MSE(z_Hs,saved_Hs)',
        'query_formula':'base(Cq)+rho*base(Hq)',
        'all_inputs_handmade':True,'production_model_executed':False,
        'scalar_input':{'theta':.3,'alpha':.2,'beta':.7,'Ls':'.5*(theta-1)^2','Lq':'.5*(theta+1)^2'}
    },ensure_ascii=False,indent=2)+'\n')
    vector=pair_reference(fixture)
    result={'scalar':scalar,'nonlinear_pair_reference':vector,'status':'PASS'}
    (RESULT/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
