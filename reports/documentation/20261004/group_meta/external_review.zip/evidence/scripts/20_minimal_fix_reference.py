#!/usr/bin/env python3
"""Generate review-only minimal diff; check exact return-expression accounting.

The uploaded sources are not changed. This checks Python arithmetic/control
expressions and patch scope, not Torch execution or a new model experiment.
"""
import ast, difflib, hashlib, json, pathlib, types

ROOT=pathlib.Path(__file__).resolve().parents[2]
SOURCE=ROOT/'source'; EVIDENCE=ROOT/'evidence'
DEST=EVIDENCE/'proposed'; DEST.mkdir(exist_ok=True)
OUTPUT=EVIDENCE/'outputs'/'20_minimal_fixes'; OUTPUT.mkdir(parents=True,exist_ok=True)
code_path='scripts/step28_group_meta.py'
doc_path='reports/documentation/20261004/group_meta/implementation.zh.md'
old_code=(SOURCE/code_path).read_text()
old_doc=(SOURCE/doc_path).read_text()
needle='"gradient_group_presentations": 4 * len(records)'
replacement='"gradient_group_presentations": (2 if settings.outer_weight == 0 else 4) * len(records)'
assert old_code.count(needle)==1
assert old_doc.count('head0.99251316')==1
new_code=old_code.replace(needle,replacement)
new_doc=old_doc.replace('head0.99251316','head0.92513164')
patch=''.join(difflib.unified_diff(old_code.splitlines(True),new_code.splitlines(True),
                                fromfile='a/'+code_path,tofile='b/'+code_path))
patch+=''.join(difflib.unified_diff(old_doc.splitlines(True),new_doc.splitlines(True),
                                fromfile='a/'+doc_path,tofile='b/'+doc_path))
(DEST/'minimal_fixes.patch').write_text(patch)
(DEST/'step28_group_meta_proposed.py').write_text(new_code)

def count_expression(source):
    tree=ast.parse(source)
    fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='train_stage')
    ret=next(n for n in fn.body if isinstance(n,ast.Return))
    assert isinstance(ret.value,ast.Dict)
    expr=next(v for k,v in zip(ret.value.keys,ret.value.values)
              if isinstance(k,ast.Constant) and k.value=='gradient_group_presentations')
    return compile(ast.Expression(expr),'<exact-stage-return-expression>','eval')

before,after=count_expression(old_code),count_expression(new_code)
cases=[]
for beta in [0.,.2,.7]:
    namespace={'settings':types.SimpleNamespace(outer_weight=beta),'records':[None]*288}
    old=eval(before,namespace);new=eval(after,namespace)
    expected=288*(2 if beta==0 else 4)
    assert new==expected
    if beta>0: assert old==new
    cases.append({'beta':beta,'before':old,'after':new,'expected':expected})
old_tree,new_tree=ast.parse(old_code),ast.parse(new_code)
unchanged=[]
for name in ['lookahead','objective','update','load_model']:
    a=next(n for n in old_tree.body if getattr(n,'name',None)==name)
    b=next(n for n in new_tree.body if getattr(n,'name',None)==name)
    assert ast.dump(a)==ast.dump(b)
    unchanged.append(name)
result={'scope':'review-only patch, exact Python return expression and AST comparison',
        'source_files_modified':False,'torch_executed':False,'native_bge_rerun':False,
        'source_sha256':hashlib.sha256((SOURCE/code_path).read_bytes()).hexdigest(),
        'proposed_sha256':hashlib.sha256(new_code.encode()).hexdigest(),
        'cases':cases,'unchanged_training_function_AST':unchanged,
        'documentation_correction':{'old_head_norm':.99251316,'new_head_norm':.92513164},
        'status':'PASS'}
(OUTPUT/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
print(patch)
