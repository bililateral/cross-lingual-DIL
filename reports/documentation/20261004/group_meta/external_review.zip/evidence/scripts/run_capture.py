#!/usr/bin/env python3
"""Run a command, retain exact argv, stdout, stderr, exit code and timestamps."""
import argparse, datetime, json, os, pathlib, subprocess, sys, time

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--out', required=True)
    p.add_argument('--cwd', required=True)
    p.add_argument('command', nargs=argparse.REMAINDER)
    a=p.parse_args()
    command=a.command[1:] if a.command[:1]==['--'] else a.command
    dest=pathlib.Path(a.out); dest.mkdir(parents=True, exist_ok=True)
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    t=time.monotonic()
    with (dest/'stdout.txt').open('wb') as out, (dest/'stderr.txt').open('wb') as err:
        result=subprocess.run(command,cwd=a.cwd,stdout=out,stderr=err)
    meta={'argv':command,'cwd':a.cwd,'started_utc':started,
          'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'elapsed_seconds':time.monotonic()-t,'exit_code':result.returncode,
          'python':sys.executable}
    (dest/'run.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
    (dest/'exit_status.txt').write_text(str(result.returncode)+'\n')
    print(json.dumps(meta,ensure_ascii=False,indent=2))
    print((dest/'stdout.txt').read_text(errors='replace'))
    stderr=(dest/'stderr.txt').read_text(errors='replace')
    if stderr: print('CAPTURED STDERR\n'+stderr)
    return result.returncode

if __name__=='__main__': raise SystemExit(main())
