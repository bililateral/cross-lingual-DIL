#!/usr/bin/env python3
"""Package the completed independent review, without running any model.

--prepare stages original bytes, completed reference evidence and catalogs.
--pack adds the completed prepare log, indexes runs, manifests all payloads,
and writes and verifies the final ZIP. The final ZIP hash is reported outside
that ZIP to avoid a self-referential checksum.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[2]
DELIVERABLES = ROOT / "deliverables"
STAGING = ROOT / "bundle_staging"
ARCHIVE = ROOT.parent / "upload" / "review(6).zip"
ARCHIVE_SHA = "07cf8dfe944ad120922af6064d60a5037953e6c06ab170c56f6d8846e50895d6"


def sha(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def write_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def copy_file(src: Path, dest: Path) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dest)


def prepare() -> None:
    assert sha(ARCHIVE.read_bytes()) == ARCHIVE_SHA
    assert STAGING.name == "bundle_staging" and STAGING.parent == ROOT
    if STAGING.exists():
        shutil.rmtree(STAGING)
    STAGING.mkdir()
    copied_sources = []
    with zipfile.ZipFile(ARCHIVE) as z:
        assert z.testzip() is None
        assert len(z.namelist()) == len(set(z.namelist())) == 103
        for info in z.infolist():
            assert not info.is_dir()
            rel = Path(info.filename)
            assert not rel.is_absolute() and ".." not in rel.parts
            payload = z.read(info)
            current = ROOT / "source" / rel
            assert current.read_bytes() == payload, f"Original source changed: {rel}"
            copy_file(current, STAGING / "source" / rel)
            copied_sources.append({"path": f"source/{info.filename}", "bytes": len(payload),
                                   "sha256": sha(payload), "origin": "user_attachment_exact_bytes"})
    copy_file(ARCHIVE, STAGING / "input" / "review_original.zip")
    for name in ("group_meta_review.zh.txt", "README.zh.txt", "external_verdict.json"):
        copy_file(DELIVERABLES / name, STAGING / name)
    for path in sorted((ROOT / "evidence").rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(ROOT)
        if "__pycache__" in rel.parts or path.suffix == ".pyc":
            continue
        if rel.parts[1] == "agent_literature":
            continue  # normalized catalog below; no duplicate prose or tool ref IDs
        if "90_bundle_prepare" in rel.parts:
            continue  # this run's streams are still open until run_capture finishes
        copy_file(path, STAGING / rel)
    literature = json.loads((ROOT / "evidence/agent_literature/sources.json").read_text())
    sources = []
    for item in literature["sources"]:
        clean = {k: v for k, v in item.items() if k != "refs"}
        url = clean["url"]
        if "li2017metaDG.pdf" in url:
            clean["report_id"] = "W1"
        elif "1810.11910" in url:
            clean["report_id"] = "W2"
        elif "85b9a5ac" in url:
            clean["report_id"] = "W3"
        elif url.endswith("ops.py"):
            clean["report_id"] = "W4"
        elif url.endswith("model.py"):
            clean["report_id"] = "W5"
        sources.append(clean)
    web = {
        "review_date_utc": "2026-10-04",
        "scope": "Primary papers; MLDG author implementation read, no paper code executed.",
        "primary_sources_reopened_by_main_reviewer": ["W1", "W2", "W3", "W4", "W5"],
        "sources": sources,
        "additional_main_reviewer_abstract_pages": [
            "https://arxiv.org/abs/1710.03463", "https://arxiv.org/abs/1810.11910",
            "https://arxiv.org/abs/2007.13904"],
        "access_failures_in_subreview": [
            {k: v for k, v in row.items() if k != "ref"} for row in literature["access_failures"]],
        "copyright_scope": "Catalog and original analysis only; no full papers or copied repository included."
    }
    write_json(STAGING / "sources/web_sources.json", web)
    source_catalog = {
        "attachment": {"supplied_name": "review(6).zip", "bundle_path": "input/review_original.zip",
                       "bytes": ARCHIVE.stat().st_size, "sha256": ARCHIVE_SHA,
                       "external_expected_hash_supplied_this_turn": False},
        "note": "Inventory proves byte identity, not correctness. Read/ reuse boundaries are in the main report and prior-scope reading report.",
        "source_payloads": copied_sources,
        "mandatory_current_files": [
            "source/docs/SELLER_ALIAS_GROUP_META.zh.md",
            "source/scripts/step28_group_meta.py",
            "source/scripts/step28_group_meta_check.py",
            "source/tests/test_step28_group_meta.py",
            "source/reports/documentation/20261004/group_meta/implementation.zh.md"],
        "prior_review_reuse_inventory": "evidence/agent_prior_scope/source_inventory.json",
        "source_version_ledger": "evidence/agent_native/analysis_v2/source_ledger.json",
        "source_version_diff": "evidence/agent_native/analysis_v2/version_changes.diff",
        "known_unavailable_old_bodies": [
            "First 5969-byte SELLER_ALIAS_GROUP_META.zh.md body; original hash only",
            "docs/AI_RESEARCH_HANDOFF.zh.md",
            "docs/RESEARCH_DISCUSSION.zh.md"],
        "review_reference_inputs": [
            "evidence/inputs/math_fixture_description.json",
            "evidence/inputs/nonlinear_28_account_fixture.npz",
            "evidence/agent_meta/inputs.json",
            "evidence/agent_stage/inputs/handwritten_groups.json",
            "evidence/agent_stage/inputs/settings_and_scope.json",
            "evidence/agent_native/inputs.json",
            "evidence/agent_prior_scope/inputs.json"]
    }
    write_json(STAGING / "sources/source_index.json", source_catalog)
    print(json.dumps({"status": "PREPARED", "original_source_files": len(copied_sources),
                      "original_source_bytes": sum(x["bytes"] for x in copied_sources),
                      "original_source_modified": False, "torch_run": False,
                      "staged_files_before_prepare_log": sum(p.is_file() for p in STAGING.rglob("*"))},
                     ensure_ascii=False, indent=2))


def index_runs() -> dict:
    new = []
    for path in sorted((STAGING / "evidence").rglob("run.json")):
        meta = json.loads(path.read_text())
        folder = path.parent
        exit_path = folder / "exit_status.txt"
        assert exit_path.exists() and int(exit_path.read_text()) == meta["exit_code"]
        assert (folder / "stdout.txt").exists() and (folder / "stderr.txt").exists()
        entry = {
            "path": str(path.relative_to(STAGING)), "kind": "this_review_reference_or_diagnostic",
            "argv": meta["argv"], "cwd": meta["cwd"], "exit_code": meta["exit_code"],
            "elapsed_seconds": meta["elapsed_seconds"], "started_utc": meta["started_utc"],
            "finished_utc": meta["finished_utc"],
            "stdout": str((folder / "stdout.txt").relative_to(STAGING)),
            "stderr": str((folder / "stderr.txt").relative_to(STAGING)),
            "exit_status": str(exit_path.relative_to(STAGING)), "torch_or_bge_run": False
        }
        rel = str(path.relative_to(STAGING))
        if "agent_meta/run_01" in rel:
            entry["interpretation"] = "FAILED: overstrong norm-equality assertion, preserved; see corrected run_02."
            entry["source_at_run"] = "evidence/agent_meta/run_01/source_at_failure.py"
        elif "agent_native/run_01" in rel:
            entry["interpretation"] = "FAILED: overstrong norm-equality assertion, preserved; see v2/run_02."
            entry["source_at_run"] = "evidence/agent_native/audit_native_evidence.py"
        elif "90_bundle_prepare" in rel:
            entry["kind"] = "packaging_only_not_a_scientific_test"
        new.append(entry)
    p = STAGING / "evidence/agent_prior_scope"
    command = json.loads((p / "command.json").read_text())
    completion = json.loads((p / "completion.json").read_text())
    assert int((p / "exit_code.txt").read_text()) == completion["returncode"]
    new.append({"path": "evidence/agent_prior_scope/command.json", "kind": "this_review_combinatorial_reference",
                **command, **completion, "exit_code": completion["returncode"],
                "stdout": "evidence/agent_prior_scope/stdout.txt", "stderr": "evidence/agent_prior_scope/stderr.txt",
                "exit_status": "evidence/agent_prior_scope/exit_code.txt", "torch_or_bge_run": False})
    new.sort(key=lambda r: r["started_utc"])
    original = []
    for name in ("tests_first", "native_first", "native_load_fixed", "native_batch32",
                 "tests_load_fixed", "native_probe_fixed", "tests_final"):
        p = STAGING / "source/reports/documentation/20261004/group_meta" / name
        result = json.loads((p / "result.json").read_text())
        original.append({"run": name, "provided_by_user_not_executed_by_this_review": True,
                         "path": str(p.relative_to(STAGING)),
                         "status_in_original": result["status"],
                         "exit_code": int((p / "exit_status.txt").read_text()),
                         "started": (p / "started.txt").read_text().strip(),
                         "finished": (p / "finished.txt").read_text().strip(),
                         "original_sources": str((p / "source").relative_to(STAGING)),
                         "stdout": str((p / "stdout.txt").relative_to(STAGING)),
                         "stderr": str((p / "stderr.txt").relative_to(STAGING)),
                         "result": str((p / "result.json").relative_to(STAGING))})
    return {"scope": "Actual new reference commands are separate from uploaded Linux logs; neither count nor PASS proves scientific correctness.",
            "this_review_runs": new, "provided_linux_runs": original,
            "final_packaging_note": "The --pack command verifies the completed ZIP and reports its checksum outside the ZIP; it is not a reference/model run."}


def pack() -> None:
    assert (STAGING / "group_meta_review.zh.txt").is_file()
    for path in sorted((ROOT / "evidence/outputs/90_bundle_prepare").rglob("*")):
        if path.is_file():
            copy_file(path, STAGING / path.relative_to(ROOT))
    runs = index_runs()
    write_json(STAGING / "RUN_INDEX.json", runs)
    manifest = []
    for path in sorted(STAGING.rglob("*")):
        if path.is_file() and path.name != "EVIDENCE_MANIFEST.json":
            payload = path.read_bytes()
            manifest.append({"path": str(path.relative_to(STAGING)), "bytes": len(payload), "sha256": sha(payload)})
    write_json(STAGING / "EVIDENCE_MANIFEST.json", {
        "excludes_itself": True, "does_not_certify_algorithm_or_results": True,
        "file_count_excluding_manifest": len(manifest),
        "payload_bytes_excluding_manifest": sum(r["bytes"] for r in manifest), "files": manifest})
    output = DELIVERABLES / "group_meta_review_evidence.zip"
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path in sorted(STAGING.rglob("*")):
            if path.is_file():
                z.write(path, str(path.relative_to(STAGING)))
    with zipfile.ZipFile(output) as z:
        assert z.testzip() is None
        assert len(z.namelist()) == len(set(z.namelist())) == len(manifest) + 1
        assert z.read("input/review_original.zip") == ARCHIVE.read_bytes()
        assert z.read("group_meta_review.zh.txt") == (DELIVERABLES / "group_meta_review.zh.txt").read_bytes()
        for row in manifest:
            payload = z.read(row["path"])
            assert len(payload) == row["bytes"] and sha(payload) == row["sha256"]
        for name in z.namelist():
            if name.endswith(".json"):
                json.loads(z.read(name))
    summary = {"status": "PASS_PACKAGING_CHECK_ONLY", "output": str(output),
               "bytes": output.stat().st_size, "sha256": sha(output.read_bytes()),
               "zip_members": len(manifest) + 1, "original_files": 103,
               "original_archive_and_report_bytes_match": True, "crc_and_payload_checks": "PASS",
               "new_runs_including_packaging_prepare": len(runs["this_review_runs"]),
               "preserved_new_reference_failures": sum(r["exit_code"] != 0 for r in runs["this_review_runs"]),
               "provided_linux_runs": len(runs["provided_linux_runs"]),
               "source_changed": False, "torch_run": False}
    write_json(DELIVERABLES / "package_check.json", summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument("--prepare", action="store_true")
    modes.add_argument("--pack", action="store_true")
    args = parser.parse_args()
    prepare() if args.prepare else pack()
