#!/usr/bin/env python3
"""Independent archive integrity, safe extraction and complete byte inventory."""
import hashlib, importlib.util, json, pathlib, platform, stat, sys, zipfile

ROOT=pathlib.Path(__file__).resolve().parents[2]
ARCHIVE=ROOT.parent/'upload'/'review(6).zip'
DEST=ROOT/'source'
OUTPUT=ROOT/'evidence'/'inputs'
DEST.mkdir(parents=True,exist_ok=True); OUTPUT.mkdir(parents=True,exist_ok=True)
blob=ARCHIVE.read_bytes()
with zipfile.ZipFile(ARCHIVE) as z:
    names=z.namelist()
    assert len(names)==len(set(names)), 'Duplicate member names'
    assert z.testzip() is None, 'CRC failure'
    inventory=[]
    for info in z.infolist():
        p=pathlib.PurePosixPath(info.filename)
        assert not p.is_absolute() and '..' not in p.parts, 'Unsafe member path'
        assert not stat.S_ISLNK(info.external_attr>>16), 'Symlink member'
        if info.is_dir(): continue
        b=z.read(info)
        target=DEST.joinpath(*p.parts)
        target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(b)
        inventory.append({'path':info.filename,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
    result={'archive_name':ARCHIVE.name,'archive_bytes':len(blob),
            'archive_sha256':hashlib.sha256(blob).hexdigest(),'member_count':len(names),
            'file_count':len(inventory),'uncompressed_bytes':sum(x['bytes'] for x in inventory),
            'duplicate_names':False,'crc_check':'PASS','inventory':inventory}
(OUTPUT/'archive_inventory.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='inventory'},ensure_ascii=False,indent=2))
for name in ['review_manifest.json','reports/documentation/20261004/group_meta/source_inventory.json','reports/documentation/20261004/group_meta/linux_inventory.json']:
    value=json.loads((DEST/name).read_text())
    print('MANIFEST_SCHEMA',name,type(value).__name__)
    print(json.dumps(value,ensure_ascii=False,indent=2)[:6000])
env={'python':sys.version,'executable':sys.executable,'platform':platform.platform(),
     'packages':{m:(str(importlib.util.find_spec(m).origin) if importlib.util.find_spec(m) else None)
                  for m in ['numpy','torch','transformers','sentence_transformers','pytest']}}
(OUTPUT/'environment.json').write_text(json.dumps(env,ensure_ascii=False,indent=2)+'\n')
print('ENVIRONMENT',json.dumps(env,ensure_ascii=False,indent=2))
