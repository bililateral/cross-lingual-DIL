"""Read-only review(8) verification, including its embedded review(7) baseline.

Usage: python verify_increment.py /path/to/review8_original.zip > result.json
Only standard-library ZIP/hash/AST/arithmetic operations; no project imports.
"""
from __future__ import annotations

import argparse
import ast
import copy
import hashlib
import importlib.util
import io
import json
import platform
from pathlib import Path
from zipfile import ZipFile


def digest(data):
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def verify(rows, read):
    failures = [r["path"] for r in rows if digest(read(r["path"])) !=
                {"bytes": r["bytes"], "sha256": r["sha256"]}]
    return {"count": len(rows), "matched": len(rows) - len(failures), "failures": failures}


def definitions(data):
    return {n.name: n for n in ast.parse(data).body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}


def dump(node):
    return ast.dump(node, include_attributes=False)


def outer_body(node):
    first = next(i for i, n in enumerate(node.body) if isinstance(n, ast.Assign) and
                 any(isinstance(t, ast.Name) and t.id == "evidence" for t in n.targets))
    last = next(i for i in range(first, len(node.body)) if isinstance(node.body[i], ast.Return))
    return ast.Module(body=node.body[first:last], type_ignores=[])


class RemoveDispatch(ast.NodeTransformer):
    def visit_Call(self, node):
        node = self.generic_visit(node)
        if (isinstance(node.func, ast.BoolOp) and isinstance(node.func.op, ast.Or)
                and isinstance(node.func.values[0], ast.Name)
                and node.func.values[0].id == "update_function"):
            node.func = node.func.values[1]
        return node


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("package", type=Path)
    args = parser.parse_args()
    payload = args.package.read_bytes()
    out = {"execution_scope": "Local standard library; no Torch/CUDA/BGE or server execution",
           "python": platform.python_version(),
           "torch_installed_in_auditor_environment": importlib.util.find_spec("torch") is not None,
           "input": digest(payload)}
    with ZipFile(io.BytesIO(payload)) as z:
        out["input"].update(members=len(z.infolist()), crc_error_member=z.testzip())
        out["identity_matches_user"] = out["input"] == {
            "bytes": 792243, "members": 96, "crc_error_member": None,
            "sha256": "aab6c2470c76a6d66985246310f0af6bb983e6527e88372778af089d83d90ca6"}
        manifest = json.loads(z.read("review_manifest.json"))
        out["manifest"] = verify(manifest, z.read)
        out["manifest"]["unlisted_members"] = sorted(set(z.namelist()) - {r["path"] for r in manifest})
        sources = json.loads(z.read("source_inventory.json"))
        out["sources"] = verify(sources, z.read)
        out["linux_final_inventory_identical"] = z.read("source_inventory.json") == z.read("linux/reports/source_inventory.json")
        with ZipFile(io.BytesIO(z.read("initial_deployment.zip"))) as initial:
            out["initial_sources"] = verify(json.loads(z.read("linux/reports/initial_source_inventory.json")), initial.read)
            out["initial_to_final_changed_sources"] = [r["path"] for r in sources if initial.read(r["path"]) != z.read(r["path"])]
            snapshots = []
            for run in ("tiny_first", "tiny_repair", "staged_first"):
                prefix = "linux/evidence/" + run + "/"
                for name in z.namelist():
                    if name.startswith(prefix) and name.endswith((".py", ".sh")):
                        basename = Path(name).name
                        source = ("tests/" if basename.startswith("test_") else "scripts/") + basename
                        expected = initial.read(source) if run == "tiny_first" else z.read(source)
                        snapshots.append({"run": run, "source": source, "matches": z.read(name) == expected})
            out["run_snapshots"] = {"count": len(snapshots), "matched": sum(x["matches"] for x in snapshots), "checks": snapshots}
        with ZipFile(io.BytesIO(z.read("returned.zip"))) as returned:
            out["returned"] = verify(json.loads(z.read("linux/returned_inventory.json")), returned.read)
            out["returned"]["members"] = len(returned.infolist())
            out["returned"]["expanded_matching_members"] = sum(returned.read(n) == z.read("linux/" + n) for n in returned.namelist())
        with ZipFile(io.BytesIO(z.read("prior/reviewed_gpu_input.zip"))) as prior:
            out["embedded_prior"] = {**digest(z.read("prior/reviewed_gpu_input.zip")), "members": len(prior.infolist())}
            old = definitions(prior.read("scripts/step28_group_meta.py"))
            new = definitions(z.read("scripts/step28_group_meta.py"))
            names = ("load_model", "Settings", "Episode", "lookahead", "GroupScorer", "objective", "train_stage")
            out["unchanged_ast"] = {name: dump(old[name]) == dump(new[name]) for name in names}
            out["shared_outer_update_core_ast_equal"] = dump(outer_body(old["update"])) == dump(outer_body(new["apply_gradient"]))
            old_native = definitions(prior.read("scripts/step28_group_meta_gpu_check.py"))["native"]
            new_native = copy.deepcopy(definitions(z.read("scripts/step28_group_meta_gpu_check.py"))["native"])
            assert new_native.args.args[-1].arg == "update_function"
            new_native.args.args.pop()
            new_native.args.defaults.pop()
            normalized_native = RemoveDispatch().visit(new_native)
            out["gpu_native_only_explicit_dispatch_change"] = dump(old_native) == dump(normalized_native)
            prior_seconds = sum(int(prior.read(n)) for n in prior.namelist() if n.endswith("/seconds.txt") and "/evidence/" in n)
        attempts = []
        for run in ("tiny_first", "tiny_repair", "staged_first"):
            prefix = "linux/evidence/" + run + "/"
            r = json.loads(z.read(prefix + "result.json"))
            attempts.append({"run": run, "charged_seconds": int(z.read(prefix + "seconds.txt")),
                             "wrapper_exit": int(z.read(prefix + "exit_status.txt")),
                             "result_status": r["status"], "tests": r.get("tests"), "error_type": r.get("error_type")})
        out["attempts"] = attempts
        current_seconds = sum(r["charged_seconds"] for r in attempts)
        out["budget"] = {"prior_seconds": prior_seconds, "current_seconds": current_seconds,
                         "cumulative_seconds": prior_seconds + current_seconds,
                         "arithmetic_remaining_seconds": 3600 - prior_seconds - current_seconds,
                         "further_execution_authorized": False}
        phases = [json.loads(line) for line in z.read("linux/evidence/staged_first/stdout.txt").decode().splitlines() if line.startswith("{")]
        out["native_phase_order"] = [p["phase"] for p in phases]
        r = json.loads(z.read("linux/evidence/staged_first/result.json"))
        out["native_resources"] = {"hvp_0_start_allocated_bytes": phases[-1]["allocated_bytes"],
                                   "last_interval_peak_allocated_bytes": r["last_interval_peak_allocated_bytes"],
                                   "last_interval_peak_reserved_bytes": r["last_interval_peak_reserved_bytes"],
                                   "peak_rss_kib": r["peak_rss_kib"]}
    out["mechanical_checks_pass"] = all((
        out["identity_matches_user"], not out["manifest"]["failures"], not out["sources"]["failures"],
        out["linux_final_inventory_identical"], not out["initial_sources"]["failures"],
        out["run_snapshots"]["matched"] == out["run_snapshots"]["count"],
        not out["returned"]["failures"], out["returned"]["expanded_matching_members"] == out["returned"]["members"],
        all(out["unchanged_ast"].values()), out["shared_outer_update_core_ast_equal"],
        out["gpu_native_only_explicit_dispatch_change"]))
    out["mechanical_pass_is_not_scientific_or_resource_admission"] = True
    print(json.dumps(out, indent=2, ensure_ascii=False))
    return 0 if out["mechanical_checks_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
