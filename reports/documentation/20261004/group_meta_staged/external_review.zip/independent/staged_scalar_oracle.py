"""Independent scalar oracle of review(8)'s existing test; no Torch/BGE/CUDA."""
import json, math, platform
from pathlib import Path

x, y, beta, ax, ay = .3, -.2, .7, .03, .11
z = x*y
s, c = math.sin(z), math.cos(z)
r = s-.8
t = x+2*y-1
fx, fy = c*y, c*x
gs = [r*fx + .2*t, r*fy + .4*t]
h_f = [[-s*y*y, c-s*x*y], [c-s*x*y, -s*x*x]]
h_gn = [[fx*fx+.2, fx*fy+.4], [fx*fy+.4, fy*fy+.8]]
h = [[h_gn[i][j] + r*h_f[i][j] for j in range(2)] for i in range(2)]
phi = [x-ax*gs[0], y-ay*gs[1]]
a, b = phi
v = [a+b+.4 + .6*(a*b+.9)*b, a+b+.4 + .6*(a*b+.9)*a]
u = [ax*v[0], ay*v[1]]
def matvec(m, v):
    return [sum(row[j]*v[j] for j in range(2)) for row in m]
hu = matvec(h, u)
true = [gs[i]+beta*(v[i]-hu[i]) for i in range(2)]
def objective(a, b):
    s, c = math.sin(a*b), math.cos(a*b)
    common = (s-.8)*c
    gx = common*b+.2*(a+2*b-1)
    gy = common*a+.4*(a+2*b-1)
    fastx, fasty = a-ax*gx, b-ay*gy
    return .5*(s-.8)**2+.1*(a+2*b-1)**2+beta*(.5*(fastx+fasty+.4)**2+.3*(fastx*fasty+.9)**2)
eps=1e-6
fd=[(objective(x+eps, y)-objective(x-eps, y))/(2*eps), (objective(x, y+eps)-objective(x, y-eps))/(2*eps)]
hv = matvec(h,v)
gn = matvec(h_gn,u)
mutants = {
    'drop_hessian': [gs[i]+beta*v[i] for i in range(2)],
    'apply_A_after_H': [gs[i]+beta*(v[i]-[ax,ay][i]*hv[i]) for i in range(2)],
    'drop_cross_parameter_H': [gs[i]+beta*(v[i]-h[i][i]*u[i]) for i in range(2)],
    'MSE_Gauss_Newton_only': [gs[i]+beta*(v[i]-gn[i]) for i in range(2)],
}
result={
    'scope':'Independent closed-form analytic arithmetic for the shipped scalar fixture only; did not execute project Torch code, BGE, CUDA or server.',
    'python':platform.python_version(),
    'point':[x,y], 'beta':beta, 'rates':[ax,ay],
    'support_gradient':gs, 'support_hessian':h, 'fast_point':phi,
    'query_gradient_at_fast':v, 'exact_gradient':true, 'central_difference':fd,
    'central_difference_max_abs_error':max(abs(a-b) for a,b in zip(true,fd)),
    'mutants':{k:{'gradient':g,'max_abs_error_vs_exact':max(abs(a-b) for a,b in zip(g,true)),
                      'detected_by_fixture_places_8': any(abs(a-b)>5e-9 for a,b in zip(g,fd))}
               for k,g in mutants.items()},
    'notes':['Finite difference matches existing handwritten scalar objective; no new optimization route.',
             'Mutation vectors are independent arithmetic, not executed mutated project programs.',
             'None/zero/Adam semantics cannot be executed locally without Torch; assessed from code and supplied raw Linux tests.']
}
assert result['central_difference_max_abs_error'] < 5e-9
assert all(r['detected_by_fixture_places_8'] for r in result['mutants'].values())
print(json.dumps(result, indent=2, ensure_ascii=False))
