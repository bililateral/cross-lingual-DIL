"""Read-only review(8) identity, manifest, snapshot, and attempt accounting check.

Runs only Python standard library locally. Does not import project/Torch code,
connect to a server, or run a GPU/model/training attempt.
"""
from __future__ import annotations

from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
from datetime import datetime
import difflib
import io
import json

ROOT = Path('/workspace/scratch/b650966d75ab')
PACKAGE = ROOT / 'upload/review(8).zip'
BASE = ROOT / 'review8_extracted'
OUT = ROOT / 'audit8_work/agents'


def digest(data):
    return {'bytes': len(data), 'sha256': sha256(data).hexdigest()}


def verify_entries(entries, get_bytes):
    observations = []
    for entry in entries:
        actual = digest(get_bytes(entry['path']))
        observations.append({'path': entry['path'], **actual,
                             'matches': all(actual[k] == entry[k] for k in actual)})
    return {'count': len(entries), 'matched': sum(x['matches'] for x in observations),
            'all_match': all(x['matches'] for x in observations), 'entries': observations}


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    data = PACKAGE.read_bytes()
    with ZipFile(io.BytesIO(data)) as z:
        identity = {**digest(data), 'members': len(z.infolist()),
                    'crc_error_member': z.testzip()}
        identity['matches_user_identity'] = (
            identity['bytes'] == 792243 and identity['members'] == 96 and
            identity['sha256'] == 'aab6c2470c76a6d66985246310f0af6bb983e6527e88372778af089d83d90ca6')
        manifest = json.loads(z.read('review_manifest.json'))
        review_check = verify_entries(manifest, z.read)
        review_check['unlisted_members'] = sorted(set(z.namelist()) -
                                                   {e['path'] for e in manifest})
        extracted = {name: digest((BASE / name).read_bytes()) == digest(z.read(name))
                     for name in z.namelist()}
    source = json.loads((BASE / 'source_inventory.json').read_text())
    source_check = verify_entries(source, lambda p: (BASE / p).read_bytes())
    linux_sources = json.loads((BASE / 'linux/reports/source_inventory.json').read_text())
    final_inventories_equal = linux_sources == source
    initial_inventory = json.loads((BASE / 'linux/reports/initial_source_inventory.json').read_text())
    with ZipFile(BASE / 'initial_deployment.zip') as iz:
        initial_check = verify_entries(initial_inventory, iz.read)
        initial_check['members'] = len(iz.infolist())
        initial_check['crc_error_member'] = iz.testzip()
        initial_check['archive_inventory_matches_returned_initial_inventory'] = (
            json.loads(iz.read('reports/source_inventory.json')) == initial_inventory)
        initial_check['authorization_matches_current'] = (
            iz.read('reports/authorization.json') == (BASE / 'authorization.json').read_bytes())
        changes = []
        differences = []
        for entry in source:
            path = entry['path']
            before, after = iz.read(path), (BASE / path).read_bytes()
            if before != after:
                changes.append({'path': path, 'initial': digest(before), 'final': digest(after)})
                differences.extend(difflib.unified_diff(
                    before.decode().splitlines(True), after.decode().splitlines(True),
                    fromfile='initial_deployment/' + path, tofile='final/' + path))
        (OUT / 'initial_to_final_sources.diff').write_text(''.join(differences))
        snapshots = []
        for run in ['tiny_first', 'tiny_repair', 'staged_first']:
            for p in sorted((BASE / 'linux/evidence' / run).iterdir()):
                if p.suffix not in {'.py', '.sh'}:
                    continue
                rel = ('tests/' if p.name.startswith('test_') else 'scripts/') + p.name
                expected = iz.read(rel) if run == 'tiny_first' else (BASE / rel).read_bytes()
                snapshots.append({'run': run, 'path': rel,
                                  'reference': 'initial_deployment.zip' if run == 'tiny_first' else 'current_source',
                                  'matches': p.read_bytes() == expected, **digest(p.read_bytes())})
    returned_inventory = json.loads((BASE / 'linux/returned_inventory.json').read_text())
    with ZipFile(BASE / 'returned.zip') as rz:
        returned_check = verify_entries(returned_inventory, rz.read)
        returned_check.update(members=len(rz.infolist()), crc_error_member=rz.testzip(),
                              unlisted_members=sorted(set(rz.namelist()) -
                                  {e['path'] for e in returned_inventory}),
                              inventory_identical=rz.read('returned_inventory.json') ==
                                  (BASE / 'linux/returned_inventory.json').read_bytes())
        returned_extracted = {name: rz.read(name) == (BASE / 'linux' / name).read_bytes()
                              for name in rz.namelist()}
    old_path = BASE / 'prior/reviewed_gpu_input.zip'
    with ZipFile(old_path) as oz:
        prior_identity = {**digest(old_path.read_bytes()), 'members': len(oz.infolist())}
        prior_accounting = []
        for name in sorted(oz.namelist()):
            if name.endswith('/seconds.txt') and '/evidence/' in name:
                prior_accounting.append({'path': name, 'seconds': int(oz.read(name))})
        prior_snippets = []
        for name in sorted(oz.namelist()):
            if '/direct_first/' in name and Path(name).name in {'result.json', 'stdout.txt', 'stderr.txt'}:
                prior_snippets.append({'path': name, 'text': oz.read(name).decode()})
    (OUT / 'prior_direct_failure_excerpt.json').write_text(
        json.dumps(prior_snippets, ensure_ascii=False, indent=2))
    attempts = []
    prior_spent = sum(r['seconds'] for r in prior_accounting)
    cumulative = prior_spent
    for run in ['tiny_first', 'tiny_repair', 'staged_first']:
        d = BASE / 'linux/evidence' / run
        result = json.loads((d / 'result.json').read_text())
        start, finish = [(d / name).read_text().strip() for name in ['started.txt', 'finished.txt']]
        charged = int((d / 'seconds.txt').read_text())
        resources = dict(x.split('=') for x in (d / 'resources.txt').read_text().split())
        remaining = int(resources['remaining_seconds'])
        attempts.append({
            'run': run, 'mode': (d / 'mode.txt').read_text().strip(),
            'started': start, 'finished': finish,
            'displayed_wall_seconds': (datetime.fromisoformat(finish) - datetime.fromisoformat(start)).total_seconds(),
            'charged_wrapper_seconds': charged, 'result_internal_seconds': result['seconds'],
            'remaining_before': remaining, 'remaining_correct': remaining == 3600-cumulative,
            'exit_status': int((d / 'exit_status.txt').read_text()),
            'result_status': result['status'], 'error_type': result.get('error_type'),
            'tests': result.get('tests'), 'budget_stop_record_exists': (d / 'budget_stop.txt').exists(),
            'peak_rss_kib': result['peak_rss_kib'],
            'peak_rss_gib': result['peak_rss_kib'] / 2**20,
            'last_interval_peak_allocated_bytes': result['last_interval_peak_allocated_bytes'],
            'last_interval_peak_allocated_gib': result['last_interval_peak_allocated_bytes'] / 2**30,
            'last_interval_peak_reserved_bytes': result['last_interval_peak_reserved_bytes'],
            'last_interval_peak_reserved_gib': result['last_interval_peak_reserved_bytes'] / 2**30,
            'resources': {k:int(v) for k,v in resources.items()},
        })
        cumulative += charged
    phases = []
    for line in (BASE / 'linux/evidence/staged_first/stdout.txt').read_text().splitlines():
        if line.startswith('{'):
            obs = json.loads(line)
            obs['allocated_gib'] = obs['allocated_bytes'] / 2**30
            obs['reserved_gib'] = obs['reserved_bytes'] / 2**30
            phases.append(obs)
    result = {
        'execution_scope': 'Local Python standard library only; no CUDA/Torch/BGE import or server connection.',
        'input_identity': identity,
        'review_manifest': review_check,
        'extracted_matches_archive': {'matched':sum(extracted.values()), 'count':len(extracted), 'all_match':all(extracted.values())},
        'current_sources': source_check,
        'current_and_linux_source_inventories_identical': final_inventories_equal,
        'initial_deployment': initial_check,
        'initial_to_final_changed_sources': changes,
        'run_source_snapshots': {'count':len(snapshots), 'matched':sum(x['matches'] for x in snapshots), 'entries':snapshots},
        'returned_archive': returned_check,
        'returned_expansion': {'count':len(returned_extracted), 'matched':sum(returned_extracted.values()),
                               'all_match':all(returned_extracted.values())},
        'prior_identity': prior_identity, 'prior_accounting': prior_accounting,
        'attempts': attempts, 'native_phases': phases,
        'budget': {'prior_seconds':prior_spent, 'current_seconds':cumulative-prior_spent,
                   'cumulative_seconds':cumulative, 'arithmetic_remaining_seconds':3600-cumulative,
                   'remaining_is_not_authorization':True},
    }
    (OUT / 'resource_provenance_check.json').write_text(json.dumps(result, ensure_ascii=False, indent=2))
    compact = {k:v for k,v in result.items() if k in {'input_identity','extracted_matches_archive',
              'current_and_linux_source_inventories_identical','initial_to_final_changed_sources',
              'returned_expansion','prior_identity','prior_accounting','attempts','native_phases','budget'}}
    for key in ['review_manifest','current_sources','initial_deployment','run_source_snapshots','returned_archive']:
        compact[key] = {k:v for k,v in result[key].items() if k != 'entries'}
    print(json.dumps(compact, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
