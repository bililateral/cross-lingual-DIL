# 严禁当作正式结果

本目录由网页CPU独立参考程序产生。所有“new”“logit_quarter”分数、相关性标签、微型模型权重、微型缓存正文及六端点门中的fake模型身份都是手写或合成夹具，不是本次正式LOGIT0.25训练结果，也不是原BGE模型/缓存。

统计参考中45套被钉住的既有小型指标/计数按收到的字节复用；只有 `quarter_minus_seq` 可作为既有观察复算。另18套新分数是手写输入。任何文件中涉及 `logit_quarter_minus_quarter` 或 `logit_quarter_minus_seq` 的数值都只验证实现，不可写入科研结果表，不可据此宣称有效或无效。

路径参考实际运行的是微型编码器288步，不是BGE288步；完整六点门主要使用显式fake身份夹具。阅读 `REVIEW.zh.md` 与各results.json的scope。
