"""Archive the completed review and verify every packaged byte against its manifest."""
from pathlib import Path
import hashlib, json, zipfile, datetime
B=Path('/mnt/data/er_weight_audit')
Z=Path('/mnt/data/er_weight_external_audit_20261001.zip')
excluded={'EVIDENCE_MANIFEST.json','SHA256SUMS.txt'}
files=sorted(p for p in B.rglob('*') if p.is_file() and p.name not in excluded)
rows=[]
for p in files:
 raw=p.read_bytes();rows.append({'path':p.relative_to(B).as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
manifest={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'purpose':'ER history-weight independent contract/implementation audit; no new formal results',
 'excluded_self_files':sorted(excluded),'file_count':len(rows),'total_bytes':sum(r['bytes'] for r in rows),'files':rows}
mp=B/'EVIDENCE_MANIFEST.json';mp.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
lines=[f"{r['sha256']}  {r['path']}" for r in rows]
lines.append(f"{hashlib.sha256(mp.read_bytes()).hexdigest()}  EVIDENCE_MANIFEST.json")
(B/'SHA256SUMS.txt').write_text('\n'.join(lines)+'\n')
with zipfile.ZipFile(Z,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(B.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(B).as_posix())
with zipfile.ZipFile(Z) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(rows)+2
 for r in rows:
  raw=z.read(r['path']);assert len(raw)==r['bytes'] and hashlib.sha256(raw).hexdigest()==r['sha256'],r['path']
 assert z.read('EVIDENCE_MANIFEST.json')==mp.read_bytes()
receipt={'file':str(Z),'bytes':Z.stat().st_size,'sha256':hashlib.sha256(Z.read_bytes()).hexdigest(),
 'members':len(rows)+2,'manifest_files':len(rows),'uncompressed_manifested_bytes':sum(r['bytes'] for r in rows),
 'archive_crc_ok':True,'all_manifested_packaged_bytes_verified':True}
Path('/mnt/data/er_weight_external_audit_20261001.receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(receipt,ensure_ascii=False,indent=2))
