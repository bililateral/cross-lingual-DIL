"""Reviewer reference: scalar losses/analytic edge derivatives, no project objective oracle."""
import itertools, math, json, hashlib, copy
from pathlib import Path
import numpy as np
import torch
import step28_er_weight as m

BASE=Path('/mnt/data/er_weight_audit'); EVIDENCE=BASE/'evidence'
PAIRS=list(itertools.combinations(range(28),2))
OWN=[i for i,n in enumerate([3]*4+[2]*8) for _ in range(n)]
LABELS=tuple(int(OWN[i]==OWN[j]) for i,j in PAIRS)

def group(uid='handmade',shift=0):
    # Every title/description and binary relation here is invented, not a formal asset.
    return m.data.Group(uid,tuple(f'{uid}_a{i:02}' for i in range(28)),
       tuple(tuple((f'{uid}_{i}_{j}',f'审查手写商品{i%7}_{j+shift}',f'独立手写描述{OWN[i]}_{i}_{j}_{shift}') for j in range(2+i%2)) for i in range(28)),LABELS)

class Encoder(torch.nn.Module):
    def __init__(self):
        super().__init__();self.embedding=torch.nn.Embedding(48,4);self.dropout=torch.nn.Dropout(.25)
    def tokenizer(self,texts,**kw):
        return {'input_ids':torch.tensor([[x%48 for x in hashlib.sha256(t.encode()).digest()[:6]] for t in texts])}
    def forward(self,x):
        return {'sentence_embedding':self.dropout(self.embedding(x['input_ids'])).mean(1)}

def setup(count=288):
    torch.manual_seed(1701); model=m.core.build_model(Encoder(),16,9)
    c=m.config(m.contract());c['input']['encoder_bf16']=False
    opt=m.core.make_optimizer(model,c)
    # One real handmade warm update, explicitly rebased counter; never a 288-step claim.
    m.parent.update(model,opt,group('warm',3),None,None,c,'seq',1,1,1,2)
    for v in opt.state.values():v['step'].fill_(count)
    return model,opt,c

def clone(model,opt,c):
    other=copy.deepcopy(model); oo=m.core.make_optimizer(other,c);oo.load_state_dict(copy.deepcopy(opt.state_dict()));return other,oo

def sigmoid(x):
    return math.exp(-math.log1p(math.exp(-x))) if x>=0 else math.exp(x)/(1+math.exp(x))

def softplus(x):
    # PyTorch's finite threshold=20 branch is part of the inherited implemented hard term.
    return x if x>20 else math.log1p(math.exp(x))

def scalar_reference(values,labels=LABELS):
    z=np.asarray(values,dtype=np.float64);y=np.asarray(labels)
    grad={'bce':np.array([(sigmoid(float(a))-int(b))/378 for a,b in zip(z,y)]),
          'rank':np.zeros(378),'hard':np.zeros(378)}
    bce=sum(max(a,0)-int(b)*a+math.log1p(math.exp(-abs(a))) for a,b in zip(z,y))/378
    rank=hard=0.
    for q in range(28):
        es=[(e,j if i==q else i) for e,(i,j) in enumerate(PAIRS) if q in (i,j)]
        pos=[e for e,_ in es if y[e]]; neg=[(e,j) for e,j in es if not y[e]]
        neg=sorted(neg,key=lambda p:(-z[p[0]],p[1]))[:5]
        mx=max(z[e] for e,_ in es); denominator=sum(math.exp(z[e]-mx) for e,_ in es)
        rank+=(mx+math.log(denominator)-sum(z[e] for e in pos)/len(pos))/28
        for e,_ in es:grad['rank'][e]+=math.exp(z[e]-mx)/denominator/28
        for e in pos:grad['rank'][e]-=1/(28*len(pos))
        for p in pos:
            for n,_ in neg:
                x=float(z[n]-z[p]);hard+=softplus(x)/(28*len(pos)*5)
                g=(1. if x>20 else sigmoid(x))/(28*len(pos)*5)
                grad['hard'][n]+=g;grad['hard'][p]-=g
    losses={'bce':float(bce),'rank':float(rank),'hard':float(hard),'total':float(bce+rank+.5*hard)}
    grad['total']=grad['bce']+grad['rank']+.5*grad['hard']
    return losses,grad

def manual_adam(model,opt,grads,rates,clip):
    params=list(model.parameters());norm=math.sqrt(sum(float((g.double()**2).sum()) for g in grads))
    coefficient=min(1.,clip/(norm+1e-6))
    by_id={id(p):g.detach().double().numpy()*coefficient for p,g in zip(params,grads)}
    expected={};states={}
    for gp,lr in zip(opt.param_groups,rates):
        b1,b2=gp['betas']
        for p in gp['params']:
            st=opt.state[p];g=by_id[id(p)];t=int(st['step'])+1
            mm=b1*st['exp_avg'].double().numpy()+(1-b1)*g
            vv=b2*st['exp_avg_sq'].double().numpy()+(1-b2)*(g*g)
            estimate=p.detach().double().numpy()*(1-lr*gp['weight_decay'])-lr*(mm/(1-b1**t))/(np.sqrt(vv/(1-b2**t))+gp['eps'])
            expected[id(p)]=estimate;states[id(p)]=(mm,vv,t)
    return expected,states,norm,coefficient

def write(name,value):
    (EVIDENCE/name).write_text(json.dumps(value,ensure_ascii=False,indent=2))
