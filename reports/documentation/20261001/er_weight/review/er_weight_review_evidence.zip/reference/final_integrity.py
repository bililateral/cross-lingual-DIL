"""Final read-only original-byte check and baseline resource evidence; no formal assets."""
import ast, hashlib, json, platform, sys, zipfile
from pathlib import Path
import step28_er_weight as method
B=Path('/mnt/data/er_weight_audit'); S=B/'submission'; Z=Path('/mnt/data/er_weight_review.zip')
def sha(b): return hashlib.sha256(b).hexdigest()
def record(p):
 b=p.read_bytes(); return {'path':str(p.relative_to(S)), 'bytes':len(b), 'sha256':sha(b)}
with zipfile.ZipFile(Z) as z:
 assert z.testzip() is None
 comparisons=[]
 for info in z.infolist():
  if info.is_dir(): continue
  p=S/info.filename; raw=z.read(info.filename)
  assert p.read_bytes()==raw, info.filename
  comparisons.append({'path':info.filename,'bytes':len(raw),'sha256':sha(raw),'unchanged':True})
inv=json.loads((S/'source_inventory.json').read_text())
for row in inv['files']:
 r=record(S/row['path'])
 assert r['bytes']==row['bytes'] and r['sha256']==row['sha256'],row['path']
assert len(inv['files'])==226
freeze=json.loads((S/'reports/documentation/20261001/er_weight/freeze.json').read_text())
assert freeze['source_files']==method.sources() and len(method.sources())==28
ast_files=[]
for r in method.sources():
 if r['path'].endswith('.py'):
  ast.parse((S/r['path']).read_text(encoding='utf-8-sig'),filename=r['path'],feature_version=(3,10));ast_files.append(r['path'])
p=method.contract(); ref=method.baseline(p,S/p['baseline']['local_small_job']); times=[]
for o in method.ORDERS:
 for st in (2,3):
  name=f'{o}_er_stage{st}';rec=ref['manifest']['training'][name]
  source=method.data.verify(ref['job']/'run'/rec['path'],rec)
  log=json.loads(source.read_text());times.append({'point':name,'training_seconds':log['training_seconds'],'source':rec})
result={'original_archive':{'bytes':Z.stat().st_size,'sha256':sha(Z.read_bytes()),'zip_crc_all_ok':True},
 'source_inventory_file':record(S/'source_inventory.json'),'freeze_file':record(S/'reports/documentation/20261001/er_weight/freeze.json'),
 'zip_payload_comparisons':comparisons,'all_227_submission_files_still_exact_original':True,
 'inventory_226_payloads_verified':True,'freeze_28_current_equals_original':True,'python_310_grammar_checks':ast_files,
 'old_er_stage_timing_sources':times,'old_6_training_seconds':sum(r['training_seconds'] for r in times),
 'two_times_old_training_hours':2*sum(r['training_seconds'] for r in times)/3600,
 'timing_scope':'Recorded old GPU stages only; not a new workload runtime guarantee or a future-time promise',
 'native_project_models_or_caches_opened':False,'formal_text_or_label_read':False}
(B/'evidence/integrity_final.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in result.items() if k not in ('zip_payload_comparisons','python_310_grammar_checks','old_er_stage_timing_sources')},ensure_ascii=False,indent=2))
print('python_310_grammar_files',len(ast_files))
