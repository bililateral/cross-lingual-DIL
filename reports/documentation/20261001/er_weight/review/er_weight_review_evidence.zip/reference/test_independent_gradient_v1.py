import unittest,copy,tempfile
from pathlib import Path
from unittest import mock
import numpy as np
import torch
import independent_core as ref
from independent_core import m
import step28_er_weight_run as run

class IndependentGradients(unittest.TestCase):
    @classmethod
    def setUpClass(cls):torch.set_num_threads(1);torch.use_deterministic_algorithms(True)

    def test_analytic_edge_loss_derivatives(self):
        rng=np.random.default_rng(981);cases={'mixed':rng.normal(0,1,378),'ties':np.zeros(378),'extreme':np.linspace(-35,35,378)};rows=[]
        for name,z in cases.items():
            p=torch.tensor(z,dtype=torch.float64,requires_grad=True);y=torch.tensor(ref.LABELS,dtype=torch.float64)
            terms=m.parent.ranking.objectives(p,y,.5);losses,grads=ref.scalar_reference(z)
            for k,v in terms.items():
                got=torch.autograd.grad(v,p,retain_graph=True)[0].numpy();err=float(np.max(np.abs(got-grads[k])));le=abs(float(v.detach())-losses[k])
                self.assertLess(err,2e-14);self.assertLess(le,1e-12)
                rows.append({'case':name,'term':k,'loss_actual':float(v.detach()),'loss_reference':losses[k],'loss_error':le,'gradient_max_error':err})
        ref.write('independent_edge_derivatives.json',rows)

    def test_production_update_vjp_manual_clip_adam(self):
        original,oo,c=ref.setup();current=ref.group('current',1);history=ref.group('history',2);evidence=[];forwards=[]
        for weight in (1.,.5,.25):
            model,opt=ref.clone(original,oo,c);params=list(model.parameters());components={};losses={};captured=[]
            model.train()
            for role,grp,seed in [('current',current,901),('history',history,902)]:
                torch.manual_seed(seed);z=m.base.logits(model,grp,c,'split_rank');ls,gs=ref.scalar_reference(z.detach().numpy());losses[role]=ls;captured.append(z.detach().numpy().copy())
                components[role]=torch.autograd.grad(z,params,torch.tensor(gs['total'],dtype=z.dtype))
            forwards.append(captured)
            combined=[a+weight*b for a,b in zip(components['current'],components['history'])]
            expected,states,norm,coefficient=ref.manual_adam(model,opt,combined,(m.parent.stage_lr(1),.001),c['optimizer']['clip_norm'])
            old_params=[p.detach().clone() for p in params]
            with mock.patch.object(torch.nn.utils,'clip_grad_norm_',wraps=torch.nn.utils.clip_grad_norm_) as clip, mock.patch.object(opt,'step',wraps=opt.step) as step, mock.patch.object(opt,'zero_grad',wraps=opt.zero_grad) as zero:
                row=m.update(model,opt,current,history,c,weight,2,1,901,902,observe=True)
                self.assertEqual((clip.call_count,step.call_count,zero.call_count),(1,1,1))
            pe=max(float(np.max(np.abs(p.detach().numpy()-expected[id(p)]))) for p in params)
            ge=max(float(np.max(np.abs(p.grad.numpy()-g.numpy()*coefficient))) for p,g in zip(params,combined))
            me=max(float(np.max(np.abs(opt.state[p]['exp_avg'].numpy()-states[id(p)][0]))) for p in params)
            ve=max(float(np.max(np.abs(opt.state[p]['exp_avg_sq'].numpy()-states[id(p)][1]))) for p in params)
            self.assertLess(pe,5e-7);self.assertLess(ge,3e-7);self.assertLess(me,3e-8);self.assertLess(ve,3e-9)
            self.assertAlmostEqual(row['gradient_norm'],norm,delta=3e-7)
            for role in ('current','history'):
                for term in ('bce','rank','hard','total'):self.assertAlmostEqual(row[role+'_'+term],losses[role][term],delta=3e-6)
            self.assertAlmostEqual(row['total'],losses['current']['total']+weight*losses['history']['total'],delta=4e-6)
            module_norms={}
            nenc=len(list(model.encoder.parameters()))
            for role in ('current','history'):
                module_norms[role]={part:sum(float(g.double().square().sum()) for g in xs)**.5 for part,xs in [('encoder',components[role][:nenc]),('head',components[role][nenc:])]}
                self.assertTrue(all(x>0 for x in module_norms[role].values()))
            if weight==1.:
                old,op=ref.clone(original,oo,c);m.parent.update(old,op,current,history,None,c,'er',2,1,901,902)
                self.assertEqual(m.core.state_digest(model.state_dict()),m.core.state_digest(old.state_dict()))
                self.assertEqual(m.core.state_digest(opt.state_dict()),m.core.state_digest(op.state_dict()))
            evidence.append({'lambda':weight,'current_terms':losses['current'],'history_terms':losses['history'],'actual_total':row['total'],'parameter_max_error':pe,'postclip_gradient_max_error':ge,'adam_m_max_error':me,'adam_v_max_error':ve,'manual_combined_norm':norm,'actual_combined_norm':row['gradient_norm'],'clip_factor':coefficient,'clip_calls':1,'adam_calls':1,'adam_step':m.parent.adam_step(opt),'unweighted_component_norms':module_norms})
        for a in forwards[1:]:
            for x,y in zip(a,forwards[0]):np.testing.assert_array_equal(x,y)
        ref.write('independent_gradient_adam.json',evidence)

    def test_full_restore_missing_corrupt_and_next_update(self):
        model,opt,c=ref.setup();initial_rng=run.rng_state();initial_m=m.core.state_digest(model.state_dict());initial_o=m.core.state_digest(opt.state_dict())
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);p=root/'first.pt';rec=m.core.save_state(p,model,opt,{'completed_updates':288,'rng':initial_rng,'fixture':'one handmade warm update then 1->288 counter'})
            point={'full_checkpoint':rec,'model_state_sha256':initial_m}
            with mock.patch.object(m.base,'load_model',side_effect=lambda *a,**kw:ref.setup()[0]):
                a,b=m.prior.restore_branch(root,point,c)
            self.assertEqual(initial_m,m.core.state_digest(a.state_dict()));self.assertEqual(initial_o,m.core.state_digest(b.state_dict()));self.assertEqual(initial_rng,run.rng_state())
            for weight in (.5,.25):
                x,xx=ref.clone(model,opt,c);y,yy=ref.clone(a,b,c)
                for z,o in ((x,xx),(y,yy)):m.update(z,o,ref.group('new',4),ref.group('old',6),c,weight,2,1,121,122)
                self.assertEqual(m.core.state_digest(x.state_dict()),m.core.state_digest(y.state_dict()));self.assertEqual(m.core.state_digest(xx.state_dict()),m.core.state_digest(yy.state_dict()))
            payload=p.read_bytes();p.write_bytes(payload[:-1]+bytes([payload[-1]^1]))
            with mock.patch.object(m.base,'load_model',side_effect=lambda *a,**kw:ref.setup()[0]):
                with self.assertRaises(ValueError):m.prior.restore_branch(root,point,c)
            p.unlink()
            with mock.patch.object(m.base,'load_model',side_effect=lambda *a,**kw:ref.setup()[0]):
                with self.assertRaises(FileNotFoundError):m.prior.restore_branch(root,point,c)
        ref.write('independent_restore.json',{'model_adam_rng_exact':True,'next_lambda_half_and_quarter_updates_exact':True,'corrupt_stopped':True,'missing_stopped':True,'actual_model':'handmade tiny only','warm_updates':1,'counter_fixture':'1->288'})

    def test_stage_end_moments_and_head(self):
        model,opt,c=ref.setup(575);en=m.core.state_digest(model.encoder.state_dict());he=m.core.state_digest(model.head.state_dict());before=m.core.state_digest(opt.state_dict())
        row=m.update(model,opt,ref.group('a'),ref.group('b',5),c,.25,2,288,81,82,observe=True)
        self.assertEqual(en,m.core.state_digest(model.encoder.state_dict()));self.assertNotEqual(he,m.core.state_digest(model.head.state_dict()));self.assertNotEqual(before,m.core.state_digest(opt.state_dict()));self.assertEqual(row['adam_step'],576)
        ref.write('independent_last_step.json',row)

if __name__=='__main__':unittest.main(verbosity=2)
