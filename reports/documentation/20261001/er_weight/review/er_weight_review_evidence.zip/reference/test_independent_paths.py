"""Handwritten data only; original public IDs/logs used solely to check pairing."""
import copy,hashlib,json,random,tempfile,time,unittest
from pathlib import Path
from unittest import mock
from dataclasses import replace
import numpy as np
import torch
import independent_core as ref
from independent_core import m
import step28_er_weight_run as runner
import test_step28_er_weight_contracts as fixtures

def seed(*parts):
    encoded=(json.dumps(list(parts),ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
    return int.from_bytes(hashlib.sha256(encoded).digest()[:8],'big')%(2**63-1)

def baseline():
    p=m.contract();return m.baseline(p,m.data.ROOT/p['baseline']['local_small_job'])

def fitting(b,d):return [ref.group(r['group_uid'],i%3) for i,r in enumerate(b['partition']['fit']) if r['domain']==d]

def memory(b,order):
    mem=m.parent.Memory(order,m.parent.contract()['memory_seed'],False,{'a':1.,'b':0.})
    mem.retain(fitting(b,order[0]),1,None);return mem

class Budget:
    def __init__(self):self.check_calls=0;self.started=time.monotonic()
    def check(self,reserve=0):self.check_calls+=1
    def state(self):return {'handmade_check_calls':self.check_calls,'elapsed_seconds':time.monotonic()-self.started}

class IndependentPaths(unittest.TestCase):
    @classmethod
    def setUpClass(cls):torch.set_num_threads(1);torch.use_deterministic_algorithms(True)

    def test_three_order_reservoir_schedule_and_dropout_reconstruction(self):
        b=baseline();p=m.parent.contract();rows=[]
        for order in m.ORDERS:
            ids=[];seen=0;rng=random.Random(seed(p['memory_seed'],order,'retention'))
            for d in order[:2]:
                for gid in sorted(g.uid for g in fitting(b,d)):
                    seen+=1
                    if len(ids)<6:ids.append(gid)
                    else:
                        index=rng.randrange(seen)
                        if index<6:ids[index]=gid
                stage=2 if seen==48 else 3
                expected=b['manifest']['memories'][order+'_er_after1' if stage==2 else order+'_er_stage2']['members'];self.assertEqual(ids,expected)
                log=runner.old_training(b,order,stage)
                draw=random.Random(seed(p['memory_seed'],order,stage,'history_draws'));history=[ids[draw.randrange(6)] for _ in range(288)];self.assertEqual(history,log['history_ids'])
                schedule_rng=random.Random(seed(p['schedule_seed'],order,stage,'current'));current=[]
                for _ in range(6):
                    items=sorted(g.uid for g in fitting(b,order[stage-1]));schedule_rng.shuffle(items);current.extend(items)
                self.assertEqual(current,log['current_ids']);self.assertEqual(seed(p['schedule_seed'],order,stage,'current'),log['current_dropout_stream'])
                dropout_current=[seed(log['current_dropout_stream'],i,'dropout') for i in range(288)]
                dropout_history=[seed(p['memory_seed'],order,stage,i,'history_dropout') for i in range(288)]
                for i in range(288):
                    self.assertEqual(dropout_current[i],m.data.seed_for(log['current_dropout_stream'],i,'dropout'))
                    self.assertEqual(dropout_history[i],m.data.seed_for(p['memory_seed'],order,stage,i,'history_dropout'))
                rows.append({'order':order,'stage':stage,'members':ids.copy(),'seen':seen,'current_ids':current,'history_ids':history,'current_dropout_seeds':dropout_current,'history_dropout_seeds':dropout_history,'pairing_exact':True})
        ref.write('independent_paired_schedules.json',rows)

    def test_real_1152_tiny_continuation_updates_and_four_checkpoints(self):
        b=baseline();order='ABC';root=Path(tempfile.mkdtemp(prefix='tiny_paths_',dir=ref.EVIDENCE));original,oo,c=ref.setup();start=m.core.state_digest(original.state_dict());initial_memory=memory(b,order).to_bytes();results=[]
        for arm,weight in m.ARMS.items():
            out=root/arm;out.mkdir()
            for directory in ('updates','work','models','scores','maps','points','memory'):(out/directory).mkdir()
            model,opt=ref.clone(original,oo,c);mem=m.parent.Memory.from_bytes(initial_memory);budget=Budget();self.assertEqual(m.core.state_digest(model.state_dict()),start)
            valid=[replace(ref.group(r['group_uid'],i%4),labels=None) for i,r in enumerate(b['partition']['development'])]
            for stage in (2,3):
                current=fitting(b,order[stage-1]);cal=[ref.group(r['group_uid'],i%2) for i,r in enumerate(b['partition']['calibration']) if r['domain']==order[stage-1]]
                flags=[];actual_logits=m.base.logits
                def forward(model,group,*a,**kw):
                    flags.append((model.training,model.encoder.training,model.head.training))
                    return actual_logits(model,group,*a,**kw)
                with mock.patch.object(m.base,'logits',side_effect=forward):
                    log=runner.train_stage(model,opt,current,mem,c,order,stage,arm,out,runner.old_training(b,order,stage),budget)
                self.assertEqual(len(flags),576);self.assertTrue(all(all(row) for row in flags))
                before_rng=runner.rng_state();name=m.point_name(order,arm,stage)
                point=runner.checkpoint(out,name,model,opt,c,order,stage,cal,valid,mem.first_map,budget,weight)
                self.assertEqual(before_rng,runner.rng_state());self.assertFalse(model.training);self.assertFalse((out/point['full_checkpoint']['path']).exists());self.assertTrue((out/point['model']['path']).exists())
                self.assertEqual(m.parent.adam_step(opt),stage*288);self.assertEqual(len(point['scores']),4);self.assertEqual(point['history_weight'],weight)
                mem.auxiliary=point['learner_auxiliary']
                if stage==2:
                    mem.retain(current,2,None);self.assertEqual(mem.summary()['members'],b['manifest']['memories'][order+'_er_stage2']['members'])
                    rec=m.prior.save_memory(out,name,mem);reloaded=m.parent.Memory.from_bytes((out/rec['file']['path']).read_bytes());self.assertEqual(reloaded.to_bytes(),mem.to_bytes());mem=reloaded
                results.append({'arm':arm,'stage':stage,'actual_handmade_updates':288,'actual_training_forwards':len(flags),'model_train_encoder_train_head_train':True,'adam_step':m.parent.adam_step(opt),'first_logical_count':(stage-1)*288,'score_arrays':4,'rng_restore_exact':True,'temporary_full_checkpoint_deleted':True,'inference_model_retained':True,'mapping_fit_status':m.data.read_json(out/point['mapping']['path'])['status'],'training_seconds':log['training_seconds'],'memory_serialized_bytes':mem.summary()['serialized_bytes'],'root':str(out.relative_to(ref.BASE))})
        ref.write('independent_tiny_paths.json',{'actual_continuation_updates':sum(r['actual_handmade_updates'] for r in results),'actual_training_forwards':sum(r['actual_training_forwards'] for r in results),'initial_warm_updates':1,'initial_counter_fixture':'1->288 once before cloning both arms','native_bge_updates':0,'formal_updates':0,'scope':'one order ABC, two coefficients, two stages; all texts and binary labels invented; public IDs only for pairing','stages':results})

    def test_blind_gate_rejects_each_model_and_score_file_corruption(self):
        with tempfile.TemporaryDirectory() as td:
            root,manifest,reference=fixtures.gate_fixture(Path(td));out=runner.blind_gate(root,manifest,reference);self.assertEqual(len(out),12);files=[]
            for name in m.expected_points():
                point=m.data.read_json(root/manifest['points'][name]['path']);files.append((name,'model',point['model']))
                files.extend((name,role,rec) for role,rec in point['scores'].items())
            records=[]
            for name,role,rec in files:
                path=root/rec['path'];original=path.read_bytes();path.write_bytes(original[:-1]+bytes([original[-1]^1]))
                try:
                    with self.assertRaises(ValueError):runner.blind_gate(root,manifest,reference)
                finally:path.write_bytes(original)
                records.append({'point':name,'role':role,'corruption_rejected':True})
            self.assertEqual(len(files),60);self.assertEqual(len(runner.blind_gate(root,manifest,reference)),12)
            ref.write('independent_blind_corruptions.json',{'fake_weight_identity_files':12,'score_arrays':48,'rejected':len(records),'records':records,'scope':'handmade file-identity fixtures, NOT actual native weights'})

    def test_parse_attempt_is_recorded_before_loader_and_no_retry(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);m.data.write_json(root/'access.json',{'train':0,'valid':0,'heldout':0,'owners':0});called=[]
            for role,key in (('train','train'),('development','valid')):
                def loader(*a):
                    self.assertEqual(m.data.read_json(root/'access.json')[key],1);called.append(role);raise RuntimeError('HANDMADE_LOADER_FAILURE')
                with self.assertRaises(RuntimeError):m.prior.parse_once(root,[],{},role,loader=loader)
                with self.assertRaises(ValueError):m.prior.parse_once(root,[],{},role,loader=loader)
            for prohibited in ('test','heldout','owners'):
                with self.assertRaises(ValueError):m.prior.parse_once(root,[],{},prohibited,loader=lambda *a:self.fail('prohibited loader'))
            self.assertEqual(len(called),2);access=m.data.read_json(root/'access.json');self.assertEqual(access,{'train':1,'valid':1,'heldout':0,'owners':0});ref.write('independent_once_ledger.json',{'simulated_attempts':access,'loader_calls':called,'all_labels_handmade':True,'repeat_refused':True})

    def test_unpaired_history_stops_before_any_update(self):
        b=baseline();log=copy.deepcopy(runner.old_training(b,'ABC',2));log['history_ids'][0]='WRONG_ID';mem=memory(b,'ABC');model,opt,c=ref.setup()
        with tempfile.TemporaryDirectory() as td, mock.patch.object(m,'update',side_effect=AssertionError('No update is permitted after mismatch')) as f:
            with self.assertRaises(ValueError):runner.train_stage(model,opt,fitting(b,'B'),mem,c,'ABC',2,'half',Path(td),log,Budget())
            self.assertEqual(f.call_count,0)
        ref.write('independent_pairing_stop.json',{'mismatched_history_rejected':True,'weighted_update_calls':0})

if __name__=='__main__':unittest.main(verbosity=2)
