"""Independent endpoint definitions, frequency-count bootstrap, 23 guards and saved-only recovery."""
import copy,hashlib,json,math,tempfile,unittest
from pathlib import Path
from unittest import mock
import numpy as np
import independent_core as ref
from independent_core import m
import step28_er_weight_run as runner
import step28_er_weight_evaluate as ev
prev=ev.previous

# Independent column classification, not previous.RANK_COLUMNS.
RANK_NAMES=['average_precision','trapezoidal_pr_auc','roc_auc','recall_at_fpr_1pct','map','mrr','recall_at_1','recall_at_3','recall_at_5','recall_at_10','ndcg_at_1','ndcg_at_3','ndcg_at_5','ndcg_at_10']
PROB_LOSSES=['brier','log_loss']
ENDPOINTS=['O','N','Z','F_first','F','G','final_all']

def per_path_definitions(R):
    """R[t][j] is arrival-j population at stage-t, already averaged/sampled within its actual domain."""
    return {'O':(R[3][1]+R[3][2])/2,
            'N':(R[2][2]+R[3][3])/2,'Z':R[3][3],
            'F_first':R[1][1]-R[3][1],
            'F':((R[1][1]-R[3][1])+(R[2][2]-R[3][2]))/2,
            'G':((R[2][2]-R[1][2])+(R[3][3]-R[2][3]))/2,
            'final_all':(R[3][1]+R[3][2]+R[3][3])/3}

def reference_endpoint(new,old,domains,arm,role,frequencies):
    per_order={}; boot_order={};mcols=list(m.metrics.COLUMNS)
    for order in m.ORDERS:
        R={};B={}
        for stage in (1,2,3):
            name=order+'_shared' if stage==1 else f'{order}_{arm}_stage{stage}'
            entry=old[name] if stage==1 or arm in ('seq','er') else new[name]
            if role=='primary':
                v=np.column_stack([entry['raw' if k in RANK_NAMES else 'stage-cal'][:,j] for j,k in enumerate(mcols)])
            else:v=entry[role]
            R[stage]={};B[stage]={}
            for arrival,domain in enumerate(order,1):
                rows=np.flatnonzero(np.array(domains)==domain);vdom=v[rows]
                R[stage][arrival]=np.sum(vdom,axis=0)/20
                B[stage][arrival]=(frequencies['ABC'.index(domain)]@vdom)/20
        P=per_path_definitions(R);Q=per_path_definitions(B)
        for endpoint in ('F_first','F','G'):
            P[endpoint]=P[endpoint].copy();Q[endpoint]=Q[endpoint].copy()
            for col in PROB_LOSSES:
                P[endpoint][mcols.index(col)]*=-1;Q[endpoint][:,mcols.index(col)]*=-1
        per_order[order]=P;boot_order[order]=Q
    return {e:{'mean':sum(per_order[o][e] for o in m.ORDERS)/3,
               'per_order':np.array([per_order[o][e] for o in m.ORDERS]),
               'boot':sum(boot_order[o][e] for o in m.ORDERS)/3} for e in ENDPOINTS}

def manual_interval(boot):
    sorted_=np.sort(boot,axis=0);out=[]
    for q in (.025,.975):
        index=(len(boot)-1)*q;lo=int(math.floor(index));frac=index-lo
        out.append(sorted_[lo]*(1-frac)+sorted_[lo+1]*frac)
    return np.array(out)

def independent_guards(delta,raw):
    def mean(e,k):return delta[e][k]['mean']
    cs={'old_map_improves':mean('O','map')>0,'old_map_interval_above_zero':delta['O']['map']['conditional_95pct_interval'][0]>0,'old_recall5_improves':mean('O','recall_at_5')>0,'new_map_non_decrease':mean('N','map')>=0,'new_recall5_non_decrease':mean('N','recall_at_5')>=0}
    for e in ('O','N'):
        for k in ('average_precision','roc_auc'):cs[f'{e}_{k}_non_degradation']=mean(e,k)>=0
        for k in ('brier','log_loss'):
            cs[f'{e}_{k}_non_degradation']=mean(e,k)<=0
            cs[f'{e}_{k}_against_raw_reference']=raw[e][k]['mean']<=0
    for k in ('map','recall_at_5','average_precision','roc_auc'):cs[f'Z_{k}_non_degradation']=mean('Z',k)>=0
    for k in ('brier','log_loss'):cs[f'Z_{k}_non_degradation']=mean('Z',k)<=0
    return cs

def synth_from_old(old):
    out={}
    # Deliberately non-constant and different across rows, domains, stages, roles and candidates.
    for oi,o in enumerate(m.ORDERS):
        for ai,arm in enumerate(m.ARMS):
            for s in (2,3):
                orig=old[f'{o}_er_stage{s}'];entry={}
                pattern=(np.sin(np.arange(60)[:,None]*.31+np.arange(22)[None,:]*.17+oi*.43+s*.51)+.13)*(0.003+ai*.002)
                for role_i,role in enumerate(m.ROLES):
                    v=orig[role].copy()+pattern
                    for k in PROB_LOSSES:v[:,m.metrics.COLUMNS.index(k)]+=role_i*.004
                    entry[role]=v
                for role in ('stage-cal','first-cal'):
                    for k in RANK_NAMES:entry[role][:,m.metrics.COLUMNS.index(k)]=entry['raw'][:,m.metrics.COLUMNS.index(k)]
                out[f'{o}_{arm}_stage{s}']=entry
    return out

class IndependentStatistics(unittest.TestCase):
    def test_endpoints_all_metrics_and_actual_5000_paired_intervals(self):
        policy=m.contract();b=m.baseline(policy,m.data.ROOT/policy['baseline']['local_small_job'])
        names=[n for o in m.ORDERS for n in [o+'_shared',*(f'{o}_{a}_stage{s}' for a in ('seq','er') for s in (2,3))]]
        old,_=ev.read_points(b['job']/'evaluation',b['collected'],names);domains=b['collected']['domains'];new=synth_from_old(old)
        before=m.core.state_digest(old);new_before=m.core.state_digest(new);methods=m.parent.METHODS
        actual=ev.evaluate_matrices(new,old,domains)
        self.assertEqual(before,m.core.state_digest(old));self.assertEqual(new_before,m.core.state_digest(new));self.assertEqual(methods,m.parent.METHODS)
        draws=np.random.Generator(np.random.PCG64(20260930)).integers(0,20,size=(5000,3,20));np.testing.assert_array_equal(draws,prev.bootstrap_draws())
        frequencies=[np.array([np.bincount(row,minlength=20) for row in draws[:,d]],dtype=np.float64) for d in range(3)]
        references={};checks=0;pointmax=ordermax=intervalmax=0.;records=[]
        for arm in ('seq','er','half','quarter'):
            references[arm]={}
            for role in (*m.ROLES,'primary'):
                rr=reference_endpoint(new,old,domains,arm,role,frequencies);references[arm][role]=rr
                for endpoint in ENDPOINTS:
                    ints=manual_interval(rr[endpoint]['boot'])
                    for j,k in enumerate(m.metrics.COLUMNS):
                        a=actual['endpoints'][arm][role][endpoint][k];r=rr[endpoint]
                        pe=abs(a['mean']-r['mean'][j]);oe=np.max(np.abs(np.array([a['per_order'][o] for o in m.ORDERS])-r['per_order'][:,j]));ie=np.max(np.abs(a['conditional_95pct_interval']-ints[:,j]))
                        self.assertLess(max(pe,oe,ie),3e-14);pointmax=max(pointmax,float(pe));ordermax=max(ordermax,float(oe));intervalmax=max(intervalmax,float(ie));checks+=1
        compars=[];compmax=0.;compmetrics=0
        for arm in m.ARMS:
            for base in ('er','seq'):
                label=arm+'_minus_'+base;a=actual['comparisons'][label]
                for e in ENDPOINTS:
                    x=references[arm]['primary'][e];y=references[base]['primary'][e];q=manual_interval(x['boot']-y['boot'])
                    for j,k in enumerate(m.metrics.COLUMNS):
                        row=a['primary'][e][k];err=max(abs(row['mean']-(x['mean'][j]-y['mean'][j])),float(np.max(np.abs(row['conditional_95pct_interval']-q[:,j]))));self.assertLess(err,3e-14);compmax=max(compmax,err);compmetrics+=1
                for e in ('O','N'):
                    x=references[arm]['primary'][e];y=references[base]['raw'][e];q=manual_interval(x['boot']-y['boot'])
                    for j,k in enumerate(m.metrics.COLUMNS):
                        row=a['against_raw_reference'][e][k];err=max(abs(row['mean']-(x['mean'][j]-y['mean'][j])),float(np.max(np.abs(row['conditional_95pct_interval']-q[:,j]))));self.assertLess(err,3e-14);compmax=max(compmax,err);compmetrics+=1
                guards=independent_guards(a['primary'],a['against_raw_reference']);self.assertEqual(guards,a['interpretation']['checks']);self.assertEqual(len(guards),23)
                compars.append({'comparison':label,'checks':guards,'purpose':'synthetic perturbations of saved metrics for arithmetic only, NOT new experiment results'})
        ref.write('independent_statistics.json',{'endpoint_metric_cases':checks,'point_max_difference':pointmax,'per_order_max_difference':ordermax,'interval_max_difference':intervalmax,'comparison_metric_cases':compmetrics,'comparison_max_difference':compmax,'draws_shape':list(draws.shape),'bootstrap_aggregation':'explicit per-domain frequency matrices then direct per-path endpoint formulas; linear quantile via sorted order statistics','paired_draws_exact':True,'input_arrays_and_parent_globals_unchanged':True,'comparison_checks':compars,'selection_fixture_only':actual['selection']})

    def test_each_original_guard_and_selection_boundaries(self):
        def value(v):return {'mean':v,'per_order':dict.fromkeys(m.ORDERS,v),'conditional_95pct_interval':[v-.001,v+.001]}
        delta={e:{k:value(-.1 if k in PROB_LOSSES else .1) for k in m.metrics.COLUMNS} for e in ENDPOINTS}
        raw={e:{k:value(-.2) for k in PROB_LOSSES} for e in ('O','N')}
        self.assertTrue(prev.comparison_checks(delta,raw)['pilot_observed_checks_pass'])
        cases=[]
        for name in independent_guards(delta,raw):
            d=copy.deepcopy(delta);r=copy.deepcopy(raw)
            if name=='old_map_interval_above_zero':d['O']['map']['conditional_95pct_interval'][0]=0
            elif name=='old_map_improves':d['O']['map']['mean']=0
            elif name=='old_recall5_improves':d['O']['recall_at_5']['mean']=0
            elif name=='new_map_non_decrease':d['N']['map']['mean']=-1e-30
            elif name=='new_recall5_non_decrease':d['N']['recall_at_5']['mean']=-1e-30
            else:
                endpoint=name[0];suffix='_against_raw_reference' if name.endswith('_against_raw_reference') else '_non_degradation';key=name[2:-len(suffix)];(r if suffix=='_against_raw_reference' else d)[endpoint][key]['mean']=1e-30 if key in PROB_LOSSES else -1e-30
            got=prev.comparison_checks(d,r);self.assertEqual(got['failed'],[name]);self.assertEqual(got['checks'],independent_guards(d,r));cases.append({'individually_failed':name,'actual_failed':got['failed']})
        E={a:{'primary':{'O':{'map':{'mean':.4},'recall_at_5':{'mean':.5}}}} for a in m.ARMS}
        C={a+'_minus_er':{'interpretation':{'pilot_observed_checks_pass':False}} for a in m.ARMS}
        selections=[]
        def check(expected):
            got=ev.select_configuration(E,C);self.assertEqual(got['selected'],expected);selections.append(copy.deepcopy(got))
        check('er');C['half_minus_er']['interpretation']['pilot_observed_checks_pass']=True;check('half')
        E['quarter']['primary']['O']['map']['mean']=.9;check('half')
        C['quarter_minus_er']['interpretation']['pilot_observed_checks_pass']=True;check('quarter')
        E['quarter']['primary']['O']['map']['mean']=.4;check('half')
        E['quarter']['primary']['O']['recall_at_5']['mean']=np.nextafter(.5,1.);check('quarter')
        E['half']['primary']['O']['map']['mean']=np.nextafter(.4,1.);check('half')
        C['half_minus_er']['interpretation']['pilot_observed_checks_pass']=False;check('quarter')
        C['quarter_minus_er']['interpretation']['pilot_observed_checks_pass']=False;check('er')
        ref.write('independent_23_and_selection.json',{'single_guard_failure_cases':cases,'selection_cases':selections})

    def test_collect_then_statistics_failure_and_saved_only_recovery(self):
        policy=m.contract();job=m.data.ROOT/policy['baseline']['local_small_job'];b=m.baseline(policy,job);partition=b['partition'];groups=[ref.group(r['group_uid'],i%3) for i,r in enumerate(partition['development'])]
        rng=np.random.default_rng(12);scores={}
        for i,name in enumerate(m.expected_points()):
            raw=rng.normal(size=(60,378)).astype(np.float32)
            scores[name]={'raw':raw,'stage-cal':raw.astype(np.float64)*.6-1.4,'first-cal':raw.astype(np.float64)*.7-.9}
        root=ref.EVIDENCE/'saved_only_fixture';self.assertFalse(root.exists());before={str(p.relative_to(job)):hashlib.sha256(p.read_bytes()).hexdigest() for p in job.rglob('*') if p.is_file()}
        col=runner.collect(root,scores,groups,partition,m.sources());self.assertEqual(col['status'],'ALL_36_ER_WEIGHT_MATRICES_SAVED_BEFORE_COMPARISONS');self.assertEqual(sum(len(v) for v in col['points'].values()),36);self.assertFalse((root/'evaluation.json').exists())
        del groups,scores
        with mock.patch.object(ev,'evaluate_matrices',side_effect=RuntimeError('REVIEWER_INJECTED_STATISTICS_FAILURE_AFTER_FULL_COLLECTION')):
            try:ev.finalize(root,job/'evaluation')
            except RuntimeError as e:(ref.EVIDENCE/'injected_statistics_failure.txt').write_text(str(e)+'\n')
            else:self.fail('injected failure did not occur')
        with mock.patch.object(m.prior,'parse_once',side_effect=AssertionError('Never reparse labels')),mock.patch.object(m.base.public,'public_inputs',side_effect=AssertionError('Never read formal inputs')),mock.patch.object(m.base,'load_model',side_effect=AssertionError('Never load model')):
            result=ev.finalize(root,job/'evaluation')
            original=(root/'evaluation.json').read_bytes();again=ev.finalize(root,job/'evaluation');self.assertEqual(original,(root/'evaluation.json').read_bytes());self.assertEqual(result,again)
        after={str(p.relative_to(job)):hashlib.sha256(p.read_bytes()).hexdigest() for p in job.rglob('*') if p.is_file()};self.assertEqual(before,after)
        reused=m.data.read_json(root/'reference/collected.json');self.assertEqual(len(reused['points']),15)
        ref.write('independent_saved_recovery.json',{'collected_new_sets':36,'reused_sets':45,'injected_failure_caught':True,'saved_only_recovery_pass':True,'second_finalize_byte_identical':True,'baseline_all_small_files_unchanged':len(before),'formal_label_text_or_model_calls':0,'fixture_note':'all new scores and group labels are handwritten synthetic; output is NOT new ER performance','selection_synthetic_only':result['selection']})

if __name__=='__main__':unittest.main(verbosity=2)
