"""Create audit ledgers from retained raw logs; never invent a missing exit receipt."""
import json, re, platform, hashlib
from pathlib import Path
B=Path('/mnt/data/er_weight_audit'); L=B/'logs'; E=B/'evidence'
def write(path,obj): path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
retry=json.loads((L/'13_independent_paths_receipt_retry.command.json').read_text())
incident={'name':'12_independent_paths_v1','command':retry['command'],'cwd':retry['cwd'],
 'environment_overrides':retry['environment_overrides'],
 'started_utc':None,'process_returncode':None,
 'receipt_status':'OUTER_TOOL_TIMEOUT; child raw unittest transcript reached OK',
 'raw_unittest_summary':{'run':5,'pass':5,'assertion_fail':0,'error':0,'skip':0,'seconds':28.322},
 'original_outer_message':'Command failed because it timed out.',
 'reason_returncode_unknown':'run_logged.py writes command JSON only after child exits; no original command JSON was produced. Do not infer a numeric process exit code.',
 'first_run_artifacts':'evidence/tiny_paths_n1p8unt2',
 'remedy':'Rerun same unchanged reference using a fresh handwritten fixture directory; 13 has independently recorded exit code 0.',
 'scope':'Audit harness receipt problem, not a reproduced project failure.'}
write(L/'12_independent_paths_v1.incident.json',incident)
names=['02_submitted_tests_initial','08_independent_gradient_v1','09_independent_statistics_v1','10_independent_statistics_v2','11_independent_gradient_expanded','12_independent_paths_v1','13_independent_paths_receipt_retry']
rows=[]
for n in names:
 text=(L/(n+'.stderr.txt')).read_text()
 tests=[]
 for line in text.splitlines():
  match=re.match(r'^(test_\w+) \((.+)\) \.\.\. (ok|ERROR|FAIL|skipped.*)$',line)
  if match:
   status={'ok':'PASS','ERROR':'ERROR','FAIL':'FAIL'}.get(match[3],'SKIP')
   tests.append({'test':match[1],'runtime_identifier':match[2],'status':status})
 totals={s:sum(t['status']==s for t in tests) for s in ('PASS','FAIL','ERROR','SKIP')}
 cmd=L/(n+'.command.json')
 rec=json.loads(cmd.read_text()) if cmd.exists() else {'returncode':None}
 rows.append({'attempt':n,'returncode':rec['returncode'],'tests_run':len(tests),**totals,'cases':tests,
 'stdout':str((L/(n+'.stdout.txt')).relative_to(B)),'stderr':str((L/(n+'.stderr.txt')).relative_to(B)),
 'command_or_incident':str((cmd if cmd.exists() else L/(n+'.incident.json')).relative_to(B))})
final_names=['02_submitted_tests_initial','10_independent_statistics_v2','11_independent_gradient_expanded','13_independent_paths_receipt_retry']
final=[r for r in rows if r['attempt'] in final_names]
assert sum(r['PASS'] for r in final)==29
assert all(r['FAIL']==r['ERROR']==r['SKIP']==0 and r['returncode']==0 for r in final)
changes=[
 {'id':'REF-01','category':'reviewer_reference_reporting_error_corrected','first_attempt':'03_integrity_and_baseline',
  'description':'v1 reported 13500 comparisons by multiplying five proposed columns, but fpr/accuracy are not matrix columns and were skipped: only 8100 comparisons actually ran. All actual comparisons passed.',
  'minimal_correction':'Use the six actual classification columns and increment an executed-comparison counter. Final 16200 exact comparisons, maximum difference 0.',
  'retained':['reference/integrity_and_baseline_v1.py','reference/integrity_count_correction.diff','evidence/integrity_and_baseline_v1.json','logs/03_integrity_and_baseline.stdout.txt','logs/07_integrity_count_correction.stdout.txt'],
  'submission_changed':False},
 {'id':'REF-02','category':'reviewer_reference_error_corrected','first_attempt':'09_independent_statistics_v1',
  'description':'Reviewer called tensor/state JSON digest on NumPy matrices. TypeError before endpoint comparison; no scientific assertion failed. Saved-only and selection tests already passed.',
  'minimal_correction':'Dedicated array digest includes names, roles, shape, dtype and bytes; use a fresh output fixture directory to preserve previous output.',
  'retained':['reference/test_independent_statistics_v1.py','reference/statistics_v1_to_v2.diff','logs/09_independent_statistics_v1.stderr.txt','logs/10_independent_statistics_v2.stderr.txt'],
  'submission_changed':False},
 {'id':'REF-03','category':'reviewer_harness_receipt_limitation','first_attempt':'12_independent_paths_v1',
  'description':'Raw child transcript 5/5 OK and four 288-update stage artifacts persisted; outer tool timeout prevented an exit-code receipt.',
  'minimal_correction':'Unchanged reference repeated, retaining both directories; attempt 13 exit 0. Do not count duplicate execution as additional independent experiments.',
  'retained':['logs/12_independent_paths_v1.incident.json','logs/12_independent_paths_v1.stdout.txt','logs/12_independent_paths_v1.stderr.txt','logs/13_independent_paths_receipt_retry.command.json'],
  'submission_changed':False}
]
write(E/'reviewer_revision_history.json',changes)
summary={'scope':'Handwritten fixtures and supplied small historical records only; no new ER result claims',
 'final_unique_cases':{'submitted':16,'reviewer_independent':13,'total':29,'PASS':29,'FAIL':0,'ERROR':0,'SKIP':0},
 'recorded_test_execution_events_including_repeats':{s:sum(r[s] for r in rows) for s in ('PASS','FAIL','ERROR','SKIP')},
 'attempts':rows,'changes_and_incidents':changes,
 'full_tiny_continuation_per_run':{'updates':1152,'training_forwards':2304,'order':'ABC','coefficients':[0.5,0.25],'stages':[2,3],'warm_actual_updates':1,'counter_fixture':'1->288 before branching'},
 'full_tiny_continuation_two_executed_runs':{'updates':2304,'training_forwards':4608,'scope':'Duplicate execution for receipt verification, not independent seeds or formal experiment'},
 'not_run_not_counted_as_unittest_skips':[
  {'item':'Project Linux native BGE CPU check','status':'NOT_RUN_BY_REQUEST','required_actual_updates':4,'actual_updates':0},
  {'item':'Formal train/valid label parsing','status':'NOT_RUN_BY_REQUEST','train':0,'valid':0},
  {'item':'Formal CUDA/BF16 continuation','status':'NOT_RUN_BY_REQUEST','actual_updates':0},
  {'item':'Original native model/checkpoint/cache fresh SHA verification','status':'PENDING_PROJECT_LINUX_ASSETS'},
  {'item':'Two project Bash scripts execution','status':'NOT_RUN_BY_REQUEST','syntax_only':'PASS'},
  {'item':'test/owners reading','status':'PROHIBITED_NOT_ATTEMPTED'}],
 'model_identity':{'self_label':'GPT-6 Astra Pro','independently_verifiable_backend_identifier':None,'requested_GPT_6_Pro_not_independently_authenticated':True}}
write(B/'TEST_RESULTS.json',summary)
# Index actual recorded commands; the timeout incident is separate, with unknown receipt fields.
index=[]
for p in sorted(L.glob('*.command.json')):
 r=json.loads(p.read_text()); r['record_file']=str(p.relative_to(B));index.append(r)
write(B/'COMMANDS.json',{'recorded_commands':index,'unrecorded_exit_incident':'logs/12_independent_paths_v1.incident.json',
 'scope':'Runtime verification commands have raw stdout/stderr. Initial ZIP inspection and interactive source-reading commands were not instrumented by run_logged.py; source content and final byte-verification evidence are retained. No reconstructed text is presented as an original stdout stream.'})
# Explicitly label generated fixtures that resemble scientific results.
for d in E.iterdir():
 if d.is_dir():
  (d/'README_HANDMADE_NOT_FORMAL.zh.md').write_text('# 仅供审查的手写夹具\n\n本目录为网页审查生成的手写文本、手写标签、微型模型或人为分数/指标扰动，不是新ER正式实验结果。公共群ID仅用于与既有日志配对；没有读取正式商品文本、标签CSV或原生模型/缓存。evaluation.json中的选择与胜负不可用于研究结论。\n',encoding='utf-8')
print(json.dumps(summary['final_unique_cases'],ensure_ascii=False))
print('Execution events including repeated attempts:',summary['recorded_test_execution_events_including_repeats'])
print('No production source changed; native/formal update count 0.')
