from pathlib import Path
import hashlib,json,math
import numpy as np
import step28_er_weight as m
import step28_er_weight_evaluate as ev
B=Path('/mnt/data/er_weight_audit');S=B/'submission'; p=m.contract()
inv=json.loads((S/'source_inventory.json').read_text());rows=[]
for r in inv['files']:
 b=(S/r['path']).read_bytes(); x={'path':r['path'],'expected_bytes':r['bytes'],'actual_bytes':len(b),'expected_sha256':r['sha256'],'actual_sha256':hashlib.sha256(b).hexdigest()}; x['pass']=x['expected_bytes']==x['actual_bytes'] and x['expected_sha256']==x['actual_sha256']; rows.append(x)
assert all(x['pass'] for x in rows)
assert inv['file_count']==len(rows) and inv['total_source_bytes']==sum(x['actual_bytes'] for x in rows)
fr=json.loads((S/'reports/documentation/20261001/er_weight/freeze.json').read_text());assert fr['source_files']==m.sources()
r=m.baseline(p,S/p['baseline']['local_small_job']);old=r['collected'];root=r['job']/'evaluation'
assert r['manifest']['source_files']==m.prior.sources();assert len(m.prior.sources())==18
names=[n for o in m.ORDERS for n in [o+'_shared',*(f'{o}_{a}_stage{st}' for a in ('seq','er') for st in (2,3))]]
arrays,counts=ev.read_points(root,old,names); rr=[]; numerical_checks=0; max_count_difference=0.
for name in names:
 for role, recs in old['points'][name].items():
  pointrec=r['manifest']['points'][name];point=m.data.read_json(m.data.verify(r['job']/'run'/pointrec['path'],pointrec))
  for kind,rec in recs.items():
   f=m.data.verify(root/rec['path'],rec);rr.append({'point':name,'role':role,'kind':kind,**rec,'verified':True})
  assert point['name']==name
  mat=arrays[name][role]; cs=counts[name][role]
  for ix,c in enumerate(cs):
   tp,fp,fn,tn=(c[k] for k in ('tp','fp','fn','tn'))
   precision=tp/(tp+fp) if tp+fp else 0.;recall=tp/20;specificity=tn/358
   denominator=math.sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn))
   expected={'precision':precision,'recall':recall,'f1':2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0.,'specificity':specificity,'balanced_accuracy':(recall+specificity)/2,'mcc':(tp*tn-fp*fn)/denominator if denominator else 0.}
   for metric,value in expected.items():
    difference=abs(mat[ix,m.metrics.COLUMNS.index(metric)]-value)
    assert difference<2e-15,(name,role,ix,metric,difference)
    numerical_checks+=1;max_count_difference=max(max_count_difference,difference)

report={'source_inventory':{'count':len(rows),'bytes':sum(x['actual_bytes'] for x in rows),'rows':rows},'freeze_count':len(fr['source_files']),'old_sources_equal_original_manifest':18,'new_sources':10,'baseline_pinned_records':5,'reused_metric_count_sets':len(names)*3,'reused_files':rr,'matrix_shape':[60,22],'matrix_dtype':'float64','group_count':len(old['group_ids']),'unique_group_count':len(set(old['group_ids'])),'domain_counts':{d:old['domains'].count(d) for d in 'ABC'},'column_names':old['metric_columns'],'confusion_recalculation_checks':numerical_checks,'maximum_confusion_difference':max_count_difference,'formal_text_label_model_cache_access':False}
(B/'evidence/integrity_and_baseline.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in report.items() if k not in ['source_inventory','reused_files']},ensure_ascii=False,indent=2))
print('ALL_226_PAYLOADS_28_FREEZE_18_OLD_45_METRIC_COUNT_SETS_VERIFIED')
