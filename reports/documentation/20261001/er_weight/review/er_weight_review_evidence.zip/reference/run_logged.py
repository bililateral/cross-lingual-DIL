import datetime,json,os,pathlib,subprocess,sys,time
BASE=pathlib.Path('/mnt/data/er_weight_audit')
name=sys.argv[1];cmd=sys.argv[2:];cwd=BASE/'submission'
env=os.environ.copy();env.update(PYTHONPATH=f'{cwd}/scripts:{cwd}/tests:{BASE}/reference',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
t=time.monotonic();rec={'name':name,'command':cmd,'cwd':str(cwd),'environment_overrides':{k:env[k] for k in ['PYTHONPATH','OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','PYTHONDONTWRITEBYTECODE','HF_HUB_OFFLINE','TRANSFORMERS_OFFLINE']},'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
with open(BASE/'logs'/f'{name}.stdout.txt','w') as out,open(BASE/'logs'/f'{name}.stderr.txt','w') as err:
 p=subprocess.run(cmd,cwd=cwd,env=env,stdout=out,stderr=err)
rec.update(returncode=p.returncode,elapsed_seconds=time.monotonic()-t)
(BASE/'logs'/f'{name}.command.json').write_text(json.dumps(rec,ensure_ascii=False,indent=2))
print(json.dumps(rec,ensure_ascii=False));print('--- STDOUT ---');print((BASE/'logs'/f'{name}.stdout.txt').read_text());print('--- STDERR ---');print((BASE/'logs'/f'{name}.stderr.txt').read_text());sys.exit(p.returncode)
