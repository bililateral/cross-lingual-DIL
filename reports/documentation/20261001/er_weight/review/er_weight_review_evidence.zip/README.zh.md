# ER历史权重实现外审证据包

请先阅读`REVIEW.zh.md`，再核对`TEST_RESULTS.json`、`COMMANDS.json`和`logs/`。本包审查的是用户2026-10-01提交的冻结合同/实现，不是新ER正式结果。

## 文件分区

`input/er_weight_review.zip`是收到的原件，`submission/`为其原字节解压副本；原件及原18份科学来源均未改动。

`reference/`为独立标量/解析导数/手算AdamW、端点/配对bootstrap、供给/恢复等核对代码及前后版本。`evidence/`包含逐值比较、旧45套矩阵/计数的核验、实际微型模型checkpoint、完整原始手写更新日志和保存后统计恢复产物。`logs/`保存核心验证的原始stdout/stderr和命令记录。

所有新模型、群正文、标签、分数、指标和选择均为审查手写夹具；不是正式BGE，不是新增λ的实证结果。部分fixture使用公开group_uid以重建旧日程，但不读取对应正式正文/标签。不要从fixture的evaluation.json抽取胜负或selected作为论文结果。

## 运行结果及已知记录限制

最终29个不同测试全部通过，提交16项首次通过。计入重跑的执行事件为40 PASS、1 ERROR、0 FAIL、0 SKIP；ERROR是审查参考NumPy哈希接口误用，已修正参考并保留v1/traceback/diff。

初次清单参考的数值核对计数曾错误地报告13500，而实际做8100次；修订后对6个真实列做16200次，最大差异0。所有旧记录保留。

日志12原始stderr已到5/5 OK，外层命令回执超时，进程退出码未知；没有伪造command.json。日志13为相同源码的新夹具重复执行，退出码0。两轮微型1152步路径的产物均保留，不计为两个独立科研实验。

核心执行命令有双流日志；初始浏览和交互式源码阅读并非全都通过日志包装器，不伪称完整录制了每条浏览命令。详见`COMMANDS.json`的scope。

## 本次环境及复算

已实际使用Python3.13.5 / Torch2.10.0+cpu / NumPy2.3.5 / SciPy1.17.0 / scikit-learn1.8.0。未安装依赖、未加载或下载项目BGE。项目Linux原生环境与此不同，另有明确待核验内容。

参考脚本保留实际运行时的绝对根目录`/mnt/data/er_weight_audit`，便于对应原始traceback。下面是本次实际用法的复算示例，不是要求运行项目正式代码：

```bash
cd /mnt/data/er_weight_audit/submission
export PYTHONPATH="$PWD/scripts:$PWD/tests:/mnt/data/er_weight_audit/reference"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
python -m unittest test_step28_er_weight_contracts -v
python ../reference/test_independent_gradient.py
python ../reference/test_independent_statistics.py
python ../reference/test_independent_paths.py
```

复算应在本证据包的另一个工作副本里进行；程序会产生新的夹具/JSON，不能直接覆盖这份归档来隐藏原始输出。重定位时仅需在审查工作副本的reference脚本中替换`/mnt/data/er_weight_audit`根路径并相应设置PYTHONPATH；不得改动submission原冻结来源。旧参考v1用于阅读错误及差异，不纳入最终成功复算。

没有提供或执行正式训练启动命令作为此次网页测试的一部分。原两个Bash只做`bash -n`，两个Python入口只做`--help`。原生核验和正式运行是否启动，应按原用户授权及报告第9节在项目Linux落实，不从手写fixture生成“原生PASS”或正式授权。

## 大小与SHA

`EVIDENCE_MANIFEST.json`列出包内所有实质文件的相对路径、大小、SHA-256；不自包含清单本身及`SHA256SUMS.txt`。后者另列文件与manifest的SHA，避免循环自哈希。原提交ZIP的SHA为：

`f59b5a88d5ade07a2909108e7f0b711f9f06160f4dd937a626bb20dc108b3ad0`

原提交的226载荷合计4,493,793字节；ZIP本身1,725,753字节。外层交付证据ZIP的SHA/大小在聊天最终回复中提供。
