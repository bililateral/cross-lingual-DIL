## 11 月 19 日的并发依据与独立预算

这张六方法表首次统一执行。原五方法的上限为 3，10 月 23 日 16:28 同时记录到 ER、Logit、SEQ 三个进程及实际更新。原 L²R／ER+GCR 同样最多 3，10 月 31 日 11:54 的观测同时记录到 CAB 的三条 L²R。FOREVER 的三个 ABC 进程在 0.03 秒内启动且均持续超过 9,500 秒，九条成功回执在槽 0、1、2 各三条。八配置消融的首更回执也记录了三个活跃 worker。[五方法现场](../../20261023/continual_implementation/formal_observation.json) · [L²R／GCR 现场](../../20261031/comparison_continue/observation.json) · [FOREVER 逐任务账](../../../seller_alias_continual/20261103/forever_result/campaign/training_complete.json) · [消融首更](../../20261107/h_ablation_start/first_updates.json)

建议新批次最多 3 个训练 worker，一槽一条完整轨迹、一个 CPU 核。按已绑定的 GPU、RAM 和磁盘承诺逐槽准入，够一路先跑一路。生成、盲评、分析依次各用一路。中文原生历史门中，trial3 每槽预留并监测整 PID 10.25 GiB、allocator 9.25 GiB。拟沿此上界安排本批，每槽 RSS 64 GiB、RAM 准入 72 GiB，自有父子进程合计 196 GiB，整批输出 320 GiB，非模型文件 8 GiB，保留共享空盘 64 GiB，每活跃槽另预留 8 GiB 写盘。三路显存预留合计 30.75 GiB，能否同时开足须看开训时其他作业的实际及尚未体现的占用。此前 714 MiB 的微型 CUDA 核验仅用于接线。[trial3 原门](../../../seller_alias_continual/20261107/history_result/source_receipts/history_state/formal_gate.json) · [原消融门](../../20261107/h_ablation_start/formal_gate.json)

| 方法 | 历史九条成功训练累计（任务小时） | 拟定每次完整尝试上限（小时） |
|---|---:|---:|
| H_full（trial3） | 31.18 | 6 |
| ER 0.1 | 28.81 | 5 |
| Logit 0.1 | 29.54 | 5 |
| L²R | 299.63 | 46 |
| ER+GCR | 36.36 | 6 |
| FOREVER | 24.43 | 4 |

未舍入合计约 **449.95 个成功训练任务小时**。ER 与 Logit 从五方法原账按成功任务身份各取九条。L²R 成功单条最大 36.747 小时，历史 L²R／GCR 整批另有 64.739012 小时既往训练费用。旧失败与旧成功均留在各自原账。这里用它们为新批估时。[五方法原账](../../20261024/continual_retry/formal/budget.json) · [L²R／GCR 成本](../../../seller_alias_continual/20261101/comparison_result/report.zh.txt) · [FOREVER 成本](../../../seller_alias_continual/20261103/forever_result/report.zh.txt) · [trial3 九复验](../../../seller_alias_continual/20261107/history_result/report.zh.md)

拟定总帽 **720 小时**，分为训练 **700 h**、确认评分与本批既有 GPU 核验 **10 h**、生成 **1 h**、分析 **1 h**、控制／CPU 核验／其他辅助 **8 h**。生成、正式评分、分析各只运行一次，单次上限依次为 45 分钟、8 小时、45 分钟。本批既有 CUDA 短测计 47 秒，CPU 核验和失败按已有回执继承，正式门记录已用值。调度账的 `gpu` 对应确认桶，`auxiliary` 对应控制与辅助桶。54 次首跑的单条上限之和为 648 小时，即使首跑全按上限计，训练桶仍有 52 小时，够再预留一次 L²R 的 46 小时和一次 H 的 6 小时。重试时仍要扣除已结及在跑预留，多次重试取决于实际余量。[此前 CPU 账](cpu.json) · [GPU 账](gpu.json) · [本次 CPU 账](dispatch_review/cpu.json)

按训练入口实际领取顺序，将各方法历史成功均时排入三个空槽，训练约 163 小时。若只有两槽，约 237 小时。另参考八配置串行确认约 5.11 小时。故三路可持续时整批约 7 天，两路约 10 天，均假定历史单条速度可比、无失败和额外排队。正式账按各任务从启动到释放的时间逐条相加。[原确认费用](../../20261116/h_ablation_result/result/report.zh.md)

## 局部 OOM 与一次具名重试

同一个原控制器处理 54 个方法／顺序／seed 身份。首次局部 CUDA OOM 保留进程身份、日志、访问、失败回执及耗时，该槽退出。健康槽继续领取本批其他轨迹。恢复命令 `step28_history_benchmark.py request-oom --gate <本批正式门> --id <轨迹身份> --attempt 1` 只登记指定首败，重复登记幂等。只有原 PID 已退出、显存进程表已释放、共同资源及扣除在跑预留后的预算都够，才在原槽从固定初态启动 `attempt-2`。暂时资源不足时请求保留；已无在途任务可释放额度仍不足时，停止派发。重复 OOM 对同一轨迹不再产生第三次尝试；如还有普通待派任务，可对第二次失败登记容量恢复，重新使用该槽。

其他局部技术失败或超时停止新派，已在跑的健康任务按原控制器收尾。遇共享磁盘、共同来源／端点验收失败或控制器中断，停止受影响的自有进程并计费。只有 54 个不同身份的成功端点集齐全才接续下游；若成功来自第二次尝试，按同身份、同槽位、已释放的首败回执及成功文件摘要交接。评分与分析没有 OOM 重试。中文独立部署调用 VendorLink 的同一套领取、释放、恢复请求与获胜尝试选择代码，中文方法、顺序、指标及批次目录由中文入口提供。[实际调度接线](../../../../scripts/step28_history_benchmark_dispatch.py) · [VendorLink 原补充](../vendorlink_market_training/proposal.zh.md#已确认的-oom-恢复与一次重试) · [增量合审入口](dispatch_review/questions.zh.md)
