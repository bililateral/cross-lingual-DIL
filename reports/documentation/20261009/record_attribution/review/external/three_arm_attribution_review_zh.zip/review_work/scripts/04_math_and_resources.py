"""Independent NumPy reference for the new R0/S contrast and exact workload accounting.

This is a mathematical check, not execution of Torch autograd or BGE. The group
constructor is taken unchanged from the supplied handwritten fixture by AST.
"""
import ast
import itertools
import json
from pathlib import Path
import sys
import time
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
INPUT=ROOT/'input'
OUT=ROOT/'evidence'
sys.dont_write_bytecode=True
sys.path.insert(0,str(INPUT/'source/scripts'))
import step28_record_replay as record

def fixture():
    path=INPUT/'source/tests/test_step28_record_replay.py'
    tree=ast.parse(path.read_text())
    node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='handmade_group')
    module=ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[]))
    ns={'itertools':itertools,'method':record}
    exec(compile(module,str(path),'exec'),ns)
    return ns['handmade_group']('ablation')

def explicit_pool(slots):
    pairs=list(itertools.combinations(range(len(slots)),2))
    lookup={p:i for i,p in enumerate(pairs)}
    q=np.zeros((378,len(pairs)),np.float64)
    for row,(a,b) in enumerate(itertools.combinations(range(28),2)):
        left,right=np.flatnonzero(slots==a),np.flatnonzero(slots==b)
        for i in left:
            for j in right:
                q[row,lookup[tuple(sorted((int(i),int(j))) )]]=1/(len(left)*len(right))
    return q

def B(scores,y):
    """Literal 378-edge BCE + 28-query rank + 0.5 known top-five hard; analytic gradient."""
    edge=list(itertools.combinations(range(28),2))
    lookup={p:k for k,p in enumerate(edge)}
    value=float(np.mean(np.logaddexp(0,scores)-y*scores))
    grad=(1/(1+np.exp(-scores))-y)/378
    for query in range(28):
        candidates=[j for j in range(28) if j!=query]
        ix=np.array([lookup[tuple(sorted((query,j)))] for j in candidates])
        s,truth=scores[ix],y[ix].astype(bool)
        ex=np.exp(s-s.max()); probs=ex/ex.sum()
        value+=(s.max()+np.log(ex.sum())-s[truth].mean())/28
        grad[ix]+=probs/28
        grad[ix[truth]]-=1/(28*truth.sum())
        positive=ix[truth]
        negative=ix[~truth]
        chosen=negative[np.argsort(-scores[negative],kind='stable')[:5]]
        weight=.5/(28*len(positive)*5)
        for p in positive:
            diff=scores[chosen]-scores[p]
            value+=weight*np.logaddexp(0,diff).sum()
            derivative=weight/(1+np.exp(-diff))
            grad[chosen]+=derivative
            grad[p]-=derivative.sum()
    return value,grad

def main():
    started=time.monotonic()
    group=fixture()
    slots0,slots1=record.assignment(group),record.assignment(group,17)
    q0,q1=explicit_pool(slots0),explicit_pool(slots1)
    y=np.array(group.labels,dtype=np.float64)
    rng=np.random.default_rng(718)
    t=np.linspace(-1,2,1540)+rng.normal(0,.03,1540)
    target=np.linspace(.7,-.2,1540)
    def loss(table,arm,history):
        b0,g0=B(q0@table,y)
        b1,g1=B(q1@table,y)
        supervised=b0 if arm=='R0' else (b0+b1)/2
        grad=q0.T@g0 if arm=='R0' else (q0.T@g0+q1.T@g1)/2
        if not history:
            return supervised,grad
        error=q0@(table-target)
        return .1*supervised+.5*np.mean(error**2), .1*grad+q0.T@error/378
    math={}
    for history in [False,True]:
        coefficient=.05 if history else .5
        r,gr=loss(t,'R0',history)
        s,gs=loss(t,'S',history)
        b0,g0=B(q0@t,y);b1,g1=B(q1@t,y)
        expected=coefficient*(q1.T@g1-q0.T@g0)
        error=float(np.max(np.abs(gs-gr-expected)))
        assert error<1e-15
        derivative_errors=[]
        for _ in range(8):
            direction=rng.normal(size=1540);direction/=np.linalg.norm(direction)
            h=1e-5
            for arm,grad in [('R0',gr),('S',gs)]:
                finite=(loss(t+h*direction,arm,history)[0]-loss(t-h*direction,arm,history)[0])/(2*h)
                derivative_errors.append(abs(finite-grad@direction))
        assert max(derivative_errors)<1e-8
        assert float(np.max(np.abs(expected)))>1e-5
        math['history' if history else 'current']={
            'R0_objective':r,'S_objective':s,'S_minus_R0':s-r,
            'expected_loss_difference':coefficient*(b1-b0),
            'gradient_identity_max_error':error,
            'finite_difference_directional_checks':len(derivative_errors),
            'finite_difference_max_error':max(derivative_errors),
            'missing_regroup_term_gradient_discrepancy':float(np.max(np.abs(expected)))}
    # Keep actual field-call counts separate from estimated wallclock and storage.
    counts={}
    for arm in ['LOGIT0.1','R0','S']:
        first=3; later=6; stages=9; epochs=stages*6
        diagnostic=first*6*(48+60)+later*6*(48+6+60)
        extra=later*6*6 if arm!='LOGIT0.1' else 0
        initial=60 if arm in ['R0','LOGIT0.1'] else 0
        counts[arm]={'updates':stages*288,'gradient_groups':first*288+later*576,
          'stage_states':stages,'epoch_diagnostics':epochs,
          'diagnostic_A0_forward_groups':diagnostic,'extra_teacher_error_forward_groups':extra,
          'checkpoint_forward_and_restore_groups':stages*2*(12+60),
          'new_teacher_forward_upper_bound':3*2*6,'blind_initial_forward_groups':initial,
          'pure_forward_total':diagnostic+extra+stages*144+36+initial,
          'fit_cache_metric_group_calls':first*6*48+later*6*54}
    assert [counts[a]['pure_forward_total'] for a in ['R0','S','LOGIT0.1']]==[7656,7596,7440]
    totals={k:sum(v[k] for v in counts.values()) for k in counts['R0']}
    assert (totals['updates'],totals['gradient_groups'],totals['stage_states'],totals['epoch_diagnostics'])==(7776,12960,27,162)
    metric_count=totals['fit_cache_metric_group_calls']+162*60+27*3*60+2*60
    old=json.loads((INPUT/'background/FIVE_ARM_native.json').read_text())['native']['architectures']
    measurements={'LOGIT0.1':old['LOGIT0.1'],'R0':old['record'],'S':old['record']}
    train_seconds=sum(4320*m['paired_update_seconds']/2+9*max(0,m['first_current_allocation_seconds']-m['paired_update_seconds']/2) for m in measurements.values())
    forward_seconds=sum(counts[a]['pure_forward_total']*max(m['source_seconds'],m['worst_eval_group_seconds']) for a,m in measurements.items())
    saved=18144*max(m['save_two_groups_seconds'] for m in measurements.values())/2
    total_seconds=1.25*(train_seconds+forward_seconds+3600+saved)
    sizes=[m['parameter_bytes'] for m in measurements.values()]
    storage=int(1.1*(9*sum(sizes)+3*max(sizes)+2*2**30))
    # The first review attempt asserted the four-decimal planning figure in
    # new/implementation.zh.txt. It failed: the delivered native formula with
    # the disclosed old measurements yields a slightly different value.
    # Preserve this discrepancy as a result, not a native qualification test.
    stated_planning_hours=44.2764
    assert round(storage/2**30,4)==42.3082
    output={'status':'PASS','R0_S_independent_math':math,
       'fixture':'Unmodified package handmade_group(ablation), two records per account; fixed synthetic tables.',
       'native_claim':False,'autograd_or_Adam_executed':False,
       'per_arm_counts':counts,'totals':totals,'all_CPU_metric_group_calls':metric_count,
       'calibration_fits':27,'full_state_saves':27,'inference_saves':27,
       'full_restores':27,'inference_restores':27,
       'native_planned_actual_updates':9,'native_planned_gradient_groups':15,
       'historical_measurement_projection_only':{'train_seconds':train_seconds,'pure_forward_seconds':forward_seconds,
          'small_save_proxy_seconds':saved,'other_work_assumed_seconds':3600,'total_seconds':total_seconds,
          'hours':total_seconds/3600,'stated_planning_hours':stated_planning_hours,
          'planning_discrepancy_seconds':total_seconds-stated_planning_hours*3600,
          'planning_discrepancy_exceeds_four_decimal_rounding':abs(total_seconds/3600-stated_planning_hours)>.00005,
          'output_bytes':storage,'output_GiB':storage/2**30,
          'time_margin_to_48_hours':48-total_seconds/3600,'storage_margin_to_48_GiB':48-storage/2**30,
          'record_measurement_was_old_arm':'C_plus','is_new_native_qualification':False},
       'scope':'Handwritten mathematical/source-count checks and arithmetic on already-open historical measurements.',
       'elapsed_seconds':time.monotonic()-started}
    (OUT/'04_math_and_resources.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(output,ensure_ascii=False,indent=2))

if __name__=='__main__':
    main()
