"""Package the review, original bytes, executed scripts, outputs and failure records."""
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

ROOT=Path(__file__).resolve().parents[1]
DELIVERY=ROOT.parent/'deliverables'

def digest(path):
    raw=path.read_bytes()
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}

def main():
    quality=json.loads((ROOT/'evidence/05_scope_and_quality.json').read_text())
    assert quality['status']=='PASS' and quality['all_frozen_members_byte_identical']
    assert quality['report_bytes']==(ROOT/'report.zh.txt').stat().st_size
    DELIVERY.mkdir(exist_ok=True)
    report=DELIVERY/'three_arm_attribution_review_zh.txt'
    shutil.copyfile(ROOT/'report.zh.txt',report)
    body=report.read_text(encoding='utf-8')
    for expected in ['SCIENTIFIC_BLOCKER','REPRODUCIBILITY_DEFECT','OUT_OF_SCOPE_OVERDESIGN',
                     'GPT-6 Astra Pro','44.2796561020','11.721967','九、实际证据、失败、错误和跳过记录']:
        assert expected in body,expected
    for name in [f'{i:02d}' for i in range(7)]:
        assert len(list((ROOT/'scripts').glob(name+'_*.py')))==1,name
    original=ROOT.parent/'upload/review_input(10).zip'
    assert digest(original)=={'bytes':306794,'sha256':'5efc5023ac1e4e06c8ff0ff6b8ed22bcc0d04da942cd724c669b8fd7c2b37d78'}
    receipt={'status':'PASS_CONTENT_SELECTION','report_full_text':True,'original_zip_preserved':True,
             'input_payloads_preserved':69,'contains_failed_reviewer_script_and_stderr':True,
             'contains_read_scope_and_execution_ledger':True,
             'native_or_formal_execution':False,
             'post_build_checks':'The script verifies ZIP CRC, every selected member byte and all manifest hashes before printing PASS.'}
    (ROOT/'evidence/06_build_delivery.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    files={'three_arm_attribution_review_zh.txt':report,
           'README.zh.txt':ROOT/'README.zh.txt',
           'review_work/report.zh.txt':ROOT/'report.zh.txt',
           'upload/review_input(10).zip':original}
    for directory in ['input','scripts','evidence']:
        for path in sorted((ROOT/directory).rglob('*')):
            if path.is_file() and '__pycache__' not in path.parts and path.suffix!='.pyc':
                files['review_work/'+path.relative_to(ROOT).as_posix()]=path
    manifest={'description':'Every delivered file except this manifest, including the unchanged original input archive.',
              'files':[{'path':name,**digest(path)} for name,path in sorted(files.items())]}
    archive=DELIVERY/'three_arm_attribution_review_zh.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,path in sorted(files.items()):
            z.write(path,name)
        z.writestr('delivery_manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert len(z.infolist())==len(files)+1
        assert len(set(z.namelist()))==len(z.namelist())
        for name,path in files.items():
            assert z.read(name)==path.read_bytes(),name
        for entry in manifest['files']:
            data=z.read(entry['path'])
            assert len(data)==entry['bytes']
            assert hashlib.sha256(data).hexdigest()==entry['sha256']
        members=len(z.infolist())
    result={'status':'PASS','report':{'path':str(report),**digest(report)},
            'zip':{'path':str(archive),**digest(archive),'members':members},
            'zip_crc_pass':True,'all_manifest_entries_verified':True,'input_original_unchanged':True}
    # A build receipt is an intermediate, not a file claiming to be inside its own ZIP.
    (DELIVERY/'build_receipt.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':
    main()
