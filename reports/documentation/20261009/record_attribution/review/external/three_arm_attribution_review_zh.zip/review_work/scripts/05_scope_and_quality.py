"""Build the honest read-scope and execution ledger; verify every frozen input byte."""
import csv
import hashlib
import json
from pathlib import Path
import platform
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'evidence'
ARCHIVE = ROOT.parent/'upload/review_input(10).zip'

def write(name, value):
    (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def intervals(lines):
    runs=[]
    for n in sorted(lines):
        if not runs or n>runs[-1][1]+1:
            runs.append([n,n])
        else:
            runs[-1][1]=n
    return ','.join(str(a) if a==b else f'{a}-{b}' for a,b in runs)

def main():
    events=[json.loads(s) for s in (OUT/'read_events.jsonl').read_text().splitlines()]
    automatic={}
    for e in events:
        automatic.setdefault(e['path'],set()).update(range(e['start'],e['end']+1))
    first_manual={
        'new/implementation.zh.txt', 'new/authorization.json',
        'source/docs/SELLER_ALIAS_RECORD_ATTRIBUTION.zh.md'}
    mechanical_notes={
        'package_manifest.json':'全部条目大小与 SHA 机械核对；不是叙述性全文阅读',
        'new/return_manifest.json':'全部 16 返回载荷机械核对',
        'new/cpu/attempt01/sources.json':'全部来源逐路径对照 attempt02；精确反算唯一变动文件',
        'background/ORIGINAL_CS_record_replay.py':'全文 AST 定义对比；objective 差异语义复核，其余对应当前源码',
        'background/FIVE_ARM_native.json':'完整 JSON 解析，来源身份机械核对；实际架构、资源、耗时字段阅读与复算',
        'background/NUMERICS_GPU.json':'完整 JSON 解析；实际设置、模型、fixture 和逐字节结果字段阅读，来源列表不另作语义审查',
        'background/USER_BRIEF.zh.txt':'仅身份核对；未作全文语义审查，不取代当前授权'}
    identity=json.loads((OUT/'00_input_identity.json').read_text())
    rows=[]
    with zipfile.ZipFile(ARCHIVE) as z:
        assert z.testzip() is None
        assert len(z.infolist())==69
        for m in sorted(identity['members'],key=lambda m:m['path']):
            path=m['path']; data=(ROOT/'input'/path).read_bytes()
            assert data==z.read(path),path
            assert hashlib.sha256(data).hexdigest()==m['sha256'],path
            total=len(data.splitlines())
            reviewed=automatic.get(path,set()).copy()
            note=''
            if path in first_manual:
                reviewed.update(range(1,total+1))
                note='最初按用户指定顺序直接全文读取；在辅助读日志创建前，单独回溯登记，未伪造时间戳'
            if reviewed:
                mode='全文阅读' if len(reviewed)==total else '相关函数或章节定点阅读'
                if path in mechanical_notes:
                    note=mechanical_notes[path]
            else:
                mode='机械核对或字段阅读' if path in mechanical_notes else '仅身份核对'
                note=mechanical_notes.get(path,'未作语义审查')
            rows.append({'path':path,'bytes':len(data),'sha256':m['sha256'],
                         'total_lines':total,'semantic_read_ranges':intervals(reviewed),
                         'mode':mode,'note':note,'frozen_bytes_unchanged':True})
    assert len(rows)==69
    assert len([r for r in rows if r['path'].startswith('source/')])==29
    notes=[
        '所有 69 成员已与原 ZIP 逐字节比较。',
        '全文阅读是本轮相关文件的阅读范围，不能外推为所有历史问题重新审查。',
        '读取日志记录请求与保存范围；过长输出中的所需内容另行定点补读；日志不是语义审查的独立证明。',
        '29 来源全部身份核对，旧依赖只对实际调用路径定点审查。',
        '最初三份合同材料的阅读单独标记；未伪造自动读取事件。']
    write('reading_scope.json',{'notes':notes,'files':rows})
    with (OUT/'reading_scope.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    write('reviewer_read_error.json',{
        'status':'RECOVERED_READ_PATH_ERROR','kind':'Reviewer file extension typo',
        'command':'python review_work/scripts/01_read_sources.py current/AI_RESEARCH_HANDOFF.zh.md:79:105 background/BGE_CONTINUAL.zh.md:17:76 background/BGE_CONTINUAL.zh.md:104:136 background/FIVE_ARM_IMPLEMENTATION_REVIEW.zh.md:1:39 background/FIVE_ARM_run.py:95:209 background/FIVE_ARM_run.py:527:552',
        'exit_code':1,'tool_wall_seconds':0.000031684,
        'error_tail_transcribed_from_actual_tool':"FileNotFoundError: [Errno 2] No such file or directory: '/workspace/scratch/b99fa28d04ff/review_work/input/background/FIVE_ARM_IMPLEMENTATION_REVIEW.zh.md'",
        'effect':'The current handoff and BGE ranges before the error were read; subsequent arguments were not executed in that call.',
        'recovery':'Used actual .zh.txt extension and read remaining ranges successfully in a later call.',
        'project_failure':False,'input_changed':False})
    runs=[
        {'script':'00_prepare.py','status':'PASS','scope':'ZIP identity/extraction','elapsed_seconds':None,'elapsed_note':'Not separately recorded by this script'},
        {'script':'01_read_sources.py','status':'READING_HELPER_WITH_ONE_RECOVERED_PATH_ERROR','scope':'See read_events.jsonl and reviewer_read_error.json'},
    ]
    for script,output in [('02_identity_and_reuse.py','02_identity_and_reuse.json'),
                           ('03_handwritten_statistics.py','03_handwritten_statistics.json')]:
        result=json.loads((OUT/output).read_text())
        runs.append({'script':script,'status':result['status'],'internal_elapsed_seconds':result['elapsed_seconds'],
                     'output':output,'new_native_or_formal_qualification':False})
    runs.append({'script':'04_math_and_resources.py','attempt':1,'status':'FAIL_ASSERTION',
                 'tool_wall_seconds':.253221514,'version':'04_attempt01/04_math_and_resources.py',
                 'stderr':'04_attempt01/stderr.txt','reason':'Reviewer asserted exact equality to the planning prose; preserved discrepancy instead on retry.'})
    result=json.loads((OUT/'04_math_and_resources.json').read_text())
    runs.append({'script':'04_math_and_resources.py','attempt':2,'status':result['status'],
                 'internal_elapsed_seconds':result['elapsed_seconds'],'tool_wall_seconds':.308119528,
                 'output':'04_math_and_resources.json','new_native_or_formal_qualification':False})
    write('execution_ledger.json',{
        'environment':{'python':sys.version,'platform':platform.platform(),'project_linux_py310':False},
        'scientific_checks':runs,
        'delivery_utilities':['05_scope_and_quality.py','06_build_delivery.py'],
        'skips':[
            {'operation':'Full Torch unittest/TinyEncoder/autograd','reason':'Torch is unavailable here; source-bound project CPU receipts reviewed, not rerun.'},
            {'operation':'Full new run/verify import and entry execution','reason':'Torch and psutil absent; only explicitly named unchanged pure functions extracted for handwritten statistics.'},
            {'operation':'BGE/CUDA/native qualification/formal training','reason':'Not executed in this review; remain project-native prerequisites.'},
            {'operation':'Server/formal data/Memory objects/weights/test/owners','reason':'No access attempted or requested; outside this package review.'},
            {'operation':'Dependency installation/web browsing/new conversations/subagents','reason':'Not used.'}],
        'project_CPU_receipt':{'outer_seconds':28.73,'conservative_seconds':30,'remaining_seconds':270,'modified_by_reviewer':False},
        'classification':{'SCIENTIFIC_BLOCKER':0,'blocking_current_REPRODUCIBILITY_DEFECT':0,
                          'nonblocking_planning_reproducibility_issue':['RD-P1'],
                          'historical_R1':'Preserved; root cause not isolated by current work.'}})
    quality={'status':'PASS','archive_sha256':hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),
             'archive_bytes':ARCHIVE.stat().st_size,'all_frozen_members_byte_identical':True,
             'members':len(rows),'source_members':29,'read_scope_files_written':2,
             'script_outputs_verified':True,'report_bytes':(ROOT/'report.zh.txt').stat().st_size}
    for name in ['02_identity_and_reuse.json','03_handwritten_statistics.json','04_math_and_resources.json']:
        assert json.loads((OUT/name).read_text())['status']=='PASS'
    assert quality['archive_sha256']=='5efc5023ac1e4e06c8ff0ff6b8ed22bcc0d04da942cd724c669b8fd7c2b37d78'
    write('05_scope_and_quality.json',quality)
    print(json.dumps(quality,ensure_ascii=False,indent=2))

if __name__=='__main__':
    main()
