"""Read-only identity, exact delta and coverage checks on the supplied review package."""
import ast
import difflib
import hashlib
import importlib.util
import json
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / 'input'
OUT = ROOT / 'evidence'

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def read(name):
    return json.loads((INPUT / name).read_text(encoding='utf-8-sig'))

def by_path(rows):
    assert len({r['path'] for r in rows}) == len(rows)
    return {r['path']: {k:r[k] for k in ('path','bytes','sha256')} for r in rows}

def verify_rows(rows, prefix=''):
    for r in rows:
        b = (INPUT / prefix / r['path']).read_bytes()
        assert len(b) == r['bytes'], r['path']
        assert digest(b) == r['sha256'], r['path']

def definitions(text):
    tree = ast.parse(text)
    return {n.name: ast.dump(n, include_attributes=False) for n in tree.body
            if isinstance(n, (ast.FunctionDef, ast.ClassDef))}

def main():
    tick = time.monotonic()
    manifest = read('package_manifest.json')
    assert len(manifest) == 68
    verify_rows(manifest)
    actual = {p.relative_to(INPUT).as_posix() for p in INPUT.rglob('*') if p.is_file()}
    assert actual == set(by_path(manifest)) | {'package_manifest.json'}
    source = read('new/sources.json')
    assert len(source) == 29
    verify_rows(source, 'source')
    cpu1 = read('new/cpu/attempt01/result.json')
    cpu2 = read('new/cpu/attempt02/result.json')
    assert by_path(source) == by_path(cpu2['source_files'])
    assert by_path(read('new/cpu/attempt01/sources.json')) == by_path(cpu1['source_files'])
    differences = [k for k in by_path(source) if by_path(source)[k] != by_path(cpu1['source_files'])[k]]
    assert differences == ['scripts/step28_record_attribution_verify.py']
    verifier = (INPUT/'source/scripts/step28_record_attribution_verify.py').read_bytes()
    line = b'    args.output = args.output.resolve()\n'
    assert verifier.count(line) == 1
    inferred_old = verifier.replace(line, b'', 1)
    old_rec = by_path(cpu1['source_files'])[differences[0]]
    assert len(inferred_old) == old_rec['bytes'] and digest(inferred_old) == old_rec['sha256']
    returned = read('new/return_manifest.json')
    verify_rows(returned, 'new')
    assert len(returned) == 16 and sum(r['bytes'] for r in returned) == 20293
    old = (INPUT/'background/ORIGINAL_CS_record_replay.py').read_text()
    new = (INPUT/'source/scripts/step28_record_replay.py').read_text()
    old_defs, new_defs = definitions(old), definitions(new)
    assert old_defs.keys() == new_defs.keys()
    changed = [n for n in old_defs if old_defs[n] != new_defs[n]]
    assert changed == ['objective']
    delta = ''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),
                         fromfile='background/ORIGINAL_CS_record_replay.py',
                         tofile='source/scripts/step28_record_replay.py'))
    (OUT/'02_record_objective_delta.diff').write_text(delta,encoding='utf-8')
    # Reconstruct the exact static step28 import closure, including function-local imports.
    seeds = {'scripts/step28_record_attribution_run.py', 'scripts/step28_record_attribution_verify.py',
             'scripts/step28_replay_diagnostics.py','tests/test_step28_record_attribution.py'}
    queue, paths = list(seeds), set(seeds)
    while queue:
        name = queue.pop()
        for node in ast.walk(ast.parse((INPUT/'source'/name).read_text())):
            imports = [x.name for x in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) else []
            for mod in imports:
                if mod and mod.startswith('step28_'):
                    child = 'scripts/'+mod+'.py'
                    if child not in paths:
                        paths.add(child)
                        queue.append(child)
    paths |= {'schema/'+n for n in ['step28_record_attribution_policy.json','step28_record_replay_policy.json',
                      'step28_bge_continual_policy.json','step28_alias_ranking_policy.json','step28_chinese_base_policy.json']}
    paths |= {'docs/SELLER_ALIAS_RECORD_ATTRIBUTION.zh.md','scripts/run_step28_record_attribution_linux_20261009.sh',
              'tests/test_step28_record_replay.py'}
    assert paths == set(by_path(source))
    old_native = read('background/FIVE_ARM_native.json')
    old_source = by_path(old_native['source_files'])
    shared = [p for p in by_path(source) if p in old_source and by_path(source)[p] == old_source[p]]
    diagnostics_name = 'scripts/step28_replay_diagnostics.py'
    assert diagnostics_name in shared
    result = {
       'status':'PASS', 'package_payloads_verified':68, 'current_sources_verified':29,
       'exact_step28_import_closure_matches':True,
       'cpu_attempt02_sources_match_by_path':True,
       'source_list_order_identical':source == cpu2['source_files'],
       'source_list_order_note':'Lists differ in ordering only; compare identities by exact path.',
       'cpu_attempt01_changed_source':differences,
       'attempt01_reverse_one_line_matches_original_hash':True,
       'reverse_delta_note':'In-memory reversal only; no original source overwritten and no earlier file claimed received.',
       'returned_payloads_verified':16,'returned_bytes':20293,
       'old_CS_identical_AST_definitions':[n for n in old_defs if n not in changed],
       'old_CS_changed_definition':changed,
       'unchanged_files_also_bound_in_old_native':shared,
       'old_diagnostics_exact_byte_reuse':True,
       'cpu_wall_seconds':[3.63,25.10], 'cpu_wall_sum':3.63+25.10,
       'cpu_conservative_consumed':30,'cpu_remaining':270,
       'web_dependency_availability':{m:importlib.util.find_spec(m) is not None for m in ['numpy','torch','psutil']},
       'elapsed_seconds':time.monotonic()-tick,
       'scope':'Static/source/receipt verification in ChatGPT scratch; not new project CPU or GPU qualification.'}
    (OUT/'02_identity_and_reuse.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))
    print(delta)

if __name__ == '__main__':
    main()
