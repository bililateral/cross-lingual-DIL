"""Print exact numbered source ranges and retain the actual read transcript."""
import datetime
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / 'input'
EVIDENCE = ROOT / 'evidence'

def read_spec(spec):
    parts = spec.split(':')
    path = parts[0]
    raw = (INPUT / path).read_bytes()
    lines = raw.decode('utf-8-sig').splitlines()
    start = int(parts[1]) if len(parts) > 1 and parts[1] else 1
    end = int(parts[2]) if len(parts) > 2 and parts[2] else len(lines)
    end = min(end, len(lines))
    output = '\nFILE ' + path + '\n' + '\n'.join(f'{i:5d}: {lines[i-1]}' for i in range(start, end+1)) + '\n'
    event = dict(path=path, start=start, end=end, total_lines=len(lines),
                 bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                 timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat())
    with (EVIDENCE / 'read_events.jsonl').open('a', encoding='utf-8') as f:
        f.write(json.dumps(event, ensure_ascii=False)+'\n')
    with (EVIDENCE / 'source_read_transcript.txt').open('a', encoding='utf-8') as f:
        f.write(output)
    print(output, end='')

if __name__ == '__main__':
    EVIDENCE.mkdir(exist_ok=True)
    for spec in sys.argv[1:]:
        read_spec(spec)
