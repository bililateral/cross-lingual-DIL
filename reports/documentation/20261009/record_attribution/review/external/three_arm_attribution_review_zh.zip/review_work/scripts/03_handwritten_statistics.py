"""Execute unchanged pure collection/statistics functions on explicitly handwritten scores.

Torch/psutil are absent here. Only the named pure functions are AST-extracted from
the submitted files; their bodies are not changed. No formal entry point, model,
data loader, checkpoint, GPU, or resource check is executed or simulated as passed.
"""
import ast
import hashlib
import itertools
import json
from pathlib import Path
import sys
import time
from types import SimpleNamespace
from typing import Any, Callable

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT/'input/source'
OUT = ROOT/'evidence'
sys.dont_write_bytecode = True
sys.path.insert(0, str(INPUT/'scripts'))
import step28_record_replay as record
import step28_bge_continual_evaluate as evaluation
import step28_bge_continual_run as previous
import step28_replay_diagnostics as diag

EXTRACTED = []

def extract(filename, names, namespace):
    path = INPUT/'scripts'/filename
    raw = path.read_bytes()
    tree = ast.parse(raw.decode('utf-8'))
    selected = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in names]
    assert {n.name for n in selected} == set(names)
    future = ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0)
    module = ast.fix_missing_locations(ast.Module(body=[future]+selected,type_ignores=[]))
    exec(compile(module,str(path),'exec'),namespace)
    EXTRACTED.append({'file':filename,'sha256':hashlib.sha256(raw).hexdigest(),
                      'functions':{n.name:[n.lineno,n.end_lineno] for n in selected}})
    return SimpleNamespace(**{n:namespace[n] for n in names})

def handwritten_group(uid):
    owner = [i for i,n in enumerate([3]*4+[2]*8) for _ in range(n)]
    labels = tuple(int(owner[i] == owner[j]) for i,j in itertools.combinations(range(28),2))
    g = record.data.Group(uid, tuple(f'{uid}_s{i:02}' for i in range(28)),
         tuple(tuple((f'{uid}_r{i:02}_{j}',f'手写标题{i}_{j}',f'手写描述{i}_{j}') for j in range(2)) for i in range(28)), labels)
    g.validate()
    return g

def main():
    started = time.monotonic()
    ns = dict(np=np, ast=ast, Path=Path, Any=Any, Callable=Callable, record=record,
              data=record.data, base=record.base, core=record.core, parent=record.parent,
              evaluation=evaluation, previous=previous,
              POLICY=INPUT/'schema/step28_record_attribution_policy.json', ARMS=('LOGIT0.1','R0','S'))
    ns['old'] = extract('step28_record_replay_run.py',['read_roles','fields'],dict(ns))
    run = extract('step28_record_attribution_run.py',
                  ['policy','sources','point_name','specifications','collect','map_interpretation','finalize'],ns)
    labelled = [handwritten_group(f'hand_{d}{i:02}') for d in 'ABC' for i in range(20)]
    domains = [d for d in 'ABC' for _ in range(20)]
    partition = {'development':[{'group_uid':g.uid,'domain':d} for g,d in zip(labelled,domains)]}
    y = np.asarray([g.labels for g in labelled], dtype=np.uint8)
    rng = np.random.default_rng(9052)
    # Fixed synthetic scores, deliberately different by arm, stage, order and actual domain.
    noise = rng.normal(0,1.1,(60,378))
    signed = 2*y.astype(np.float64)-1
    scores = {}
    for name,(order,arm,stage) in run.specifications().items():
        oi, ai = record.parent.ORDERS.index(order), ('LOGIT0.1','R0','S').index(arm)
        strength = np.array([.18*stage+.03*oi+.07*ai+.014*(i%20)+.025*order.index(d)
                            +(.09 if arm=='R0' and d==order[0] else 0.)
                            -(.11 if arm=='S' and d==order[stage-1] else 0.)
                            for i,d in enumerate(domains)])
        raw = (noise+strength[:,None]*signed-.4).astype(np.float32)
        scores[name] = {'raw':raw,'stage-cal':raw.astype(np.float64)*1.3+.15,
                        'first-cal':raw.astype(np.float64)*.8-.22}
    initial = {'record':(noise-.05).astype(np.float32), 'LOGIT0.1':(noise-.25).astype(np.float32)}
    dest = OUT/'03_handwritten_collection'
    assert not dest.exists(), 'No overwrite of an earlier reviewer run'
    col = run.collect(dest,scores,labelled,partition,initial)
    result = run.finalize(dest)
    assert len(col['points']) == 27 and len(col['initial']) == 2 and len(col['metric_columns']) == 22
    assert set(result['comparisons']) == {'R0-LOGIT0.1','S-R0','S-LOGIT0.1'}
    assert all('pass' not in c for c in result['comparisons'].values())
    matrices = {name:{role:np.load(dest/r['matrix']['path'],allow_pickle=False)
                     for role,r in roles.items()} for name,roles in col['points'].items()}
    rank_cols = [col['metric_columns'].index(n) for n in (*record.parent.metrics.CURVE_KEYS,*record.parent.metrics.RETRIEVAL_KEYS)]
    draws = np.random.Generator(np.random.PCG64(20260930)).integers(0,20,(5000,3,20))
    # Independent direct indexing of actual domains; no endpoint_fields/summarize_field calls.
    def values(arm,order,stage,domain,role):
        m = matrices[run.point_name(order,arm,stage)]
        if role == 'primary':
            a = m['stage-cal'].copy()
            a[:,rank_cols] = m['raw'][:,rank_cols]
        else:
            a = m[role]
        return a[np.asarray(domains)==domain]
    def direct(arm,endpoint,role):
        point_rows, boots = [], np.zeros((5000,22))
        for order in record.parent.ORDERS:
            terms = [(3,order[0]),(3,order[1])] if endpoint=='O' else [(2,order[1]),(3,order[2])]
            point_rows.append(sum(values(arm,order,s,d,role).mean(0)/2 for s,d in terms))
            for s,d in terms:
                a = values(arm,order,s,d,role)
                boots += a[draws[:, 'ABC'.index(d)]].mean(1)/6
        return np.stack(point_rows), boots
    max_error = 0.
    checked = 0
    comparisons = [('R0','LOGIT0.1'),('S','R0'),('S','LOGIT0.1')]
    for a,b in comparisons:
        for role in (*record.parent.ROLES,'primary'):
            for ep in ('O','N'):
                av,ab = direct(a,ep,role)
                bv,bb = direct(b,ep,role)
                rows, boot = av-bv, ab-bb
                interval = np.quantile(boot,[.025,.975],axis=0,method='linear')
                for k,column in enumerate(col['metric_columns']):
                    actual = result['comparisons'][a+'-'+b]['delta'][role][ep][column]
                    expected = np.r_[rows.mean(0)[k], rows[:,k], interval[:,k]]
                    observed = np.r_[actual['mean'],[actual['per_order'][o] for o in record.parent.ORDERS],actual['conditional_95pct_interval']]
                    max_error = max(max_error,float(np.max(np.abs(expected-observed))))
                    np.testing.assert_allclose(observed,expected,rtol=0,atol=2e-14)
                    checked += len(expected)
    # Explicit permutation exposes an incorrectly paired alternative.
    a0 = values('R0','ABC',3,'A','raw')[:,col['metric_columns'].index('map')]
    b0 = values('LOGIT0.1','ABC',3,'A','raw')[:,col['metric_columns'].index('map')]
    proper = (a0-b0)[draws[:,0]].mean(1)
    wrong = (a0-b0[::-1])[draws[:,0]].mean(1)
    pairing_detection = float(np.max(np.abs(proper-wrong)))
    assert pairing_detection > 1e-3
    interval_cases=[]
    for lo,hi,expected in [(0.01,.03,'正向证据'),(-.03,-.01,'负向证据'),(-.01,.02,'方向未确定'),(0.,.03,'方向未确定'),(-.03,0.,'方向未确定')]:
        actual=run.map_interpretation({ep:{'map':{'conditional_95pct_interval':[lo,hi]}} for ep in ['O','N']})
        assert actual == {'O':expected,'N':expected}
        interval_cases.append({'interval':[lo,hi],'actual':actual})
    # Small nonconstant diagnostic example checks paired epochs, independent populations and sign.
    rr=np.random.default_rng(516)
    train=np.tile([.45,.48,.55],(6,48,1))+rr.normal(0,.012,(1,48,3))+np.arange(6)[:,None,None]*[.026,.028,-.02]
    valid=np.tile([.44,.47,.56],(6,20,1))+rr.normal(0,.011,(1,20,3))+np.arange(6)[:,None,None]*[-.01,-.012,.016]
    diagnostic=diag.curve_comparison(train,valid,621)
    r=np.random.Generator(np.random.PCG64(621))
    td,vd=r.integers(48,size=(5000,48)),r.integers(20,size=(5000,20))
    bootstrap=np.stack([(train[e][td].mean(1)-valid[e][vd].mean(1))*[1,1,-1] for e in range(6)])
    independent=np.quantile(bootstrap[-1]-bootstrap[0],[.025,.975],axis=0).T
    diagnostic_error=float(np.max(np.abs(independent-np.asarray(diagnostic['epoch1_to_6_gap_widening']['conditional_95pct_interval']))))
    assert diagnostic_error < 1e-14
    assert diag.curve_comparison(train[:,:0],valid,621)['status']=='NOT_APPLICABLE_NO_SURVIVING_GROUPS'
    output={'status':'PASS','environment':{'python':sys.version,'numpy':np.__version__},
            'extracted_unmodified_functions':EXTRACTED,'handwritten_stage_role_sets':81,'handwritten_initial_sets':2,
            'actual_saved_metric_shape':[60,22],'primary_endpoint_comparison_scalars_checked':checked,
            'maximum_difference_from_independent_O_N_reference':max_error,
            'wrong_group_pairing_example_maximum_bootstrap_difference':pairing_detection,
            'map_interval_cases':interval_cases,'diagnostic_independent_interval_max_error':diagnostic_error,
            'diagnostic_interpretation':diagnostic['interpretation'],'no_total_pass_added':True,
            'scope':'Pure submitted functions with handwritten scores and labels; no Torch, training, native or formal data work.',
            'elapsed_seconds':time.monotonic()-started}
    (OUT/'03_handwritten_statistics.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(output,ensure_ascii=False,indent=2))

if __name__=='__main__':
    main()
