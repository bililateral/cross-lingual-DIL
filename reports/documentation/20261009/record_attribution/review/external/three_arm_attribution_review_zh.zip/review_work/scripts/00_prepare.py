import hashlib
import json
import platform
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ARCHIVE = ROOT.parent / 'upload' / 'review_input(10).zip'
DEST = ROOT / 'input'
EXPECTED = '5efc5023ac1e4e06c8ff0ff6b8ed22bcc0d04da942cd724c669b8fd7c2b37d78'

def main():
    raw = ARCHIVE.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    with zipfile.ZipFile(ARCHIVE) as z:
        entries = z.infolist()
        assert len(raw) == 306794, len(raw)
        assert digest == EXPECTED, digest
        assert len(entries) == 69, len(entries)
        assert len({e.filename for e in entries}) == len(entries)
        for e in entries:
            target = (DEST / e.filename).resolve()
            assert target.is_relative_to(DEST.resolve()), e.filename
        assert z.testzip() is None
        z.extractall(DEST)
        result = {
            'archive_name': ARCHIVE.name,
            'bytes': len(raw), 'sha256': digest, 'member_count': len(entries),
            'identity_match': True, 'zip_crc_pass': True,
            'environment': {'python': sys.version, 'platform': platform.platform(),
                            'scope': 'ChatGPT scratch CPU; not project Linux py310; no server connection'},
            'members': [dict(path=e.filename, bytes=e.file_size,
                            sha256=hashlib.sha256(z.read(e)).hexdigest()) for e in entries if not e.is_dir()]
        }
    (ROOT / 'evidence').mkdir(parents=True, exist_ok=True)
    (ROOT / 'evidence' / '00_input_identity.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k != 'members'}, ensure_ascii=False, indent=2))
    for m in result['members']:
        print(f"{m['bytes']:8d}  {m['path']}")

if __name__ == '__main__':
    main()
