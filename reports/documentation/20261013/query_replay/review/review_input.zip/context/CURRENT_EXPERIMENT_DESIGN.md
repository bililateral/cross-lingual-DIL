# 当前实验设计入口

本页只索引合同，执行状态与授权补充见[当前交接](AI_RESEARCH_HANDOFF.zh.md)。合同记录该轮形成时的设定；其中“待批准”“保留权重”等措辞须结合后续明确决定解释，科学公式、访问、预算和原判据不追改。

用户2026-10-13最新明确围绕共同原账号来源带来的可能捷径，继续形成以完整S为对照的具体改进。[C_q静态方案](../reports/documentation/20261013/query_replay/proposal.zh.txt)给出逐自然查询排除来源的候选分配、原监督的有向行运算及跨来源组成响应保持；它是待审任务化增量候选，不是执行合同或已建立效果。[S定位主审](../reports/documentation/20261013/s_contribution/review/primary_disposition.zh.txt)继续作为前提，完整S不削弱；当前不开新训练、不恢复旧C诊断，具体状态见[当前交接](AI_RESEARCH_HANDOFF.zh.md)。

已结束的[C_cf合同](SELLER_ALIAS_CROSSFIT_RETENTION.zh.md)固定完整S／C_cf／C_perm、s0 A→B于10月12日19:53:39正常完成；[结果](../reports/seller_alias_continual/20261013/crossfit_retention_result/report.zh.txt)未建立C_cf相对完整S的排序提升，也未建立对一次可行错配的优势。[独立主审](../reports/seller_alias_continual/20261013/crossfit_retention_result/review/primary_disposition.zh.txt)已关闭，补齐训练—valid差距及原判据解释，无当前科学／复现阻断。冻结原稿、实施审查、资格及失败账保持；已批准运行范围不转成新候选许可。

| 合同 | 研究内容及角色 |
|---|---|
| [自然查询锚定的历史重放C_q](../reports/documentation/20261013/query_replay/proposal.zh.txt) | 当前具体静态方案。只改变候选的历史分支：每个自然查询分别排除自己的所有记录，重组其余同控候选；保留原A0／0.5D0与当前S，额外响应保持可精确化为加权MSE。明确K2正例无新增变化、候选自然性及近邻限制；S／Q／C_q／账号内bootstrap四臂是未执行的最小证伪提议。新包审查、独立处置及未来执行许可分开，不转用旧合同。 |
| [完整S贡献定位与机制缺口](../reports/documentation/20261013/s_contribution/report.zh.txt) | 当前静态研究报告，不是执行合同。核对实际S、归因实验和直接近邻；判断基础系统价值与独立创新是否充分，明确自然账号内部结构与同控重组的待研究问题。不新增训练、数据读取或旧C诊断，当前审查状态见交接 |
| [C_cf执行合同](SELLER_ALIAS_CROSSFIT_RETENTION.zh.md) | 已结束固定实验的执行依据。完整S／C_cf／C_perm、A→B、1440更新／2304梯度群呈现；CPU300秒、原生600秒、正式16小时／16GiB，标签各一次及统一盲门。原生失败及一次补核例外、完整结果审查与权重清理按交接和回执解释，旧静态稿中的待批准草案不恢复成当前阻断，也不重授训练权限 |
| [C折外支持的历史排序间隔保持](../reports/documentation/20261011/retention_design/crossfit.zh.txt) | 静态外审／[独立主审补正](../reports/documentation/20261011/retention_design/crossfit_review/primary_disposition.zh.txt)已完成，按有限增量策略推荐继续准备。完整群折外来源与全域来源共同支持的单边正负间隔，替换候选自己的D0，完整S不变。S／C_cf／可行错配C_perm能比较系统替换及原赋值相对本次错配，不能证明折外信息的独立必要性；已知cross-fitting／排序KD构件不冒称首创。拟议A→B、1,440更新／2,304梯度群呈现；新目标接线、Memory诊断、A/B评价、共享A和完整预算投影待落实，访问与12小时／16GiB等未获具体批准。尚未实现／运行或建立效果；[完整回收状态](../reports/documentation/20261011/retention_design/crossfit_review/submission.json) |
| [C跨账号条件配对保持候选](../reports/documentation/20261011/retention_design/matching.zh.txt) | 静态外审／[独立主审及补正](../reports/documentation/20261011/retention_design/matching_review/primary_disposition.zh.txt)已完成，本版本不推荐进入实现或四臂训练；数学主体成立，但结构化KD及U-centering已有、任务信息选择和独立贡献不足，效果未知。原稿保留，单合格视图9维、二阶式、反例及完整S更新边界以主审补正为准；不是新实验负结果，完整S仍为对照，旧C单独诊断不恢复 |
| [C联合排序响应收缩保持方案](../reports/documentation/20261011/retention_design/contraction.zh.txt) | 静态外审／[独立主审与补正](../reports/documentation/20261011/retention_design/review/primary_disposition.zh.txt)已完成，本版本不推荐实施；有限数学成立，但弱OT适配的任务信息依据与实质贡献不足，效果未知。四臂仅为未执行的固定策略比较；原稿保留，低维软约束、子包粒度、归因及文献勘误以主审为准。不是执行合同，未关闭整个C研究，完整S仍为主要内部对照 |
| [C保持约束局部更新诊断](../reports/documentation/20261011/retention_design/diagnostic.zh.txt) | 曾获准的完整S单路径及四条件撤回干预；仅完成手写CPU首轮。按用户最新条件及主执行者判断停止继续推进；原范围、源码与证据保留，不自动启动GPU／正式流程。处置见第10节及交接顶部 |
| [记录结构与重组监督三臂归因](SELLER_ALIAS_RECORD_ATTRIBUTION.zh.md) | LOGIT0.1／R0／S分别判读O/N MAP收益与代价，无新总通过门。三臂独立训练首阶段，保留共同过拟合诊断；原时间上限已有[明确补充](../reports/documentation/20261009/record_attribution/qualification/authorization_72h.json)，有效预算、资格与执行状态只看当前交接及对应回执 |
| [五臂改进与共同过拟合诊断](SELLER_ALIAS_REPLAY_IMPROVEMENT.zh.md) | 已结束并完成结果外审／主审；C_plus本固定配置负结果、原继续条件false，LOGIT历史复现缺陷R1及比较边界保留。用户已明确撤下两端候选／五臂活动实现，保留原C/S、LOGIT、通用诊断、冻结方案和证据；[关闭记录](../reports/maintenance/20261009/replay_improvement_closure/closure.zh.txt)，实际状态见当前交接 |
| [记录作用表与同控重组 C/S](SELLER_ALIAS_RECORD_REPLAY_PILOT.zh.md) | 已结束的开发实验；记录对头、同架构 C/S 对照及保存 LOGIT0.1 比较。训练、保存结果独立核验、结果外审及主审已完成；整体方案相对LOGIT有正向证据，C−S原主要条件未过，证据见交接 |
| [函数目标累计关系记忆](SELLER_ALIAS_FUNCTION_MEMORY_PILOT.zh.md) | 已结束的固定配置开发实验；[结果](SELLER_ALIAS_FUNCTION_MEMORY_RESULT.zh.md) |
| [关系目标记忆修改版](SELLER_ALIAS_RELATION_REVISION_PILOT.zh.md) | 已关闭，活动修改版已按用户决定清理；[结果](SELLER_ALIAS_RELATION_REVISION_RESULT.zh.md) |
| [关系目标记忆原版](SELLER_ALIAS_RELATION_MEMORY_PILOT.zh.md) | 已结束的固定配置开发实验；[结果](SELLER_ALIAS_RELATION_MEMORY_RESULT.zh.md) |
| [群体风险重放](SELLER_ALIAS_RISK_PILOT.zh.md)与[匹配 LOGIT0.1](SELLER_ALIAS_LOGIT_LOW.zh.md) | 已完成训练及结果审查；LOGIT0.1为后续保存结果比较基线，[联合结果](SELLER_ALIAS_LOGIT_RISK_RESULT.zh.md) |
| [BGE首轮持续学习](SELLER_ALIAS_BGE_CONTINUAL.zh.md) | 已完成问题诊断及SEQ／ER1／LOGIT1；后续仅继承各自合同明确适用的数据、训练和评价设置 |
| [ER0.5／0.25](SELLER_ALIAS_ER_WEIGHT.zh.md) | 已完成有限权重比较；[结果](SELLER_ALIAS_ER_WEIGHT_RESULT.zh.md) |
| [ER0.1单点](SELLER_ALIAS_ER_LOW.zh.md) | 已完成，主比较对0.25，完整报告对SEQ；[结果](SELLER_ALIAS_ER_LOW_RESULT.zh.md) |
| [匹配LOGIT0.25](SELLER_ALIAS_LOGIT_WEIGHT.zh.md) | 已完成，主比较匹配ER0.25，另报SEQ；[结果](SELLER_ALIAS_LOGIT_WEIGHT_RESULT.zh.md) |

新方法、追加对照或种子、新计算／数据权限及独立最终留出须另定具体范围。已完成合同不自动授权重训，保存结果比较不等于仍有旧权重。常设边界见[科研纪律](RESEARCH_DISCIPLINE.zh.md)，历史设计及资源未准入的群体元学习路线见[历史入口](AI_RESEARCH_HANDOFF.zh.md#历史与证据)。
