"""Handwritten CPU evidence only; run on authorized Linux py310, never Windows."""
from __future__ import annotations

import copy
import hashlib
from pathlib import Path
import sys
import tempfile
import unittest
from unittest import mock

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'scripts'))
import step28_continual_comparison as m


class Tokenizer:
    def encode(self, text, **_):
        return [1+int(hashlib.sha256(word.encode()).hexdigest()[:8], 16) % 63 for word in text.split()]

    def __call__(self, texts, **_):
        rows = [[0, *self.encode(t)] for t in texts]
        length = max(map(len, rows))
        return {'input_ids': torch.tensor([r+[0]*(length-len(r)) for r in rows]),
                'attention_mask': torch.tensor([[1]*len(r)+[0]*(length-len(r)) for r in rows])}


class Transformer(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.embedding = torch.nn.Embedding(64, 4)

    def forward(self, features):
        z = self.embedding(features['input_ids'])
        mask = features['attention_mask'][..., None]
        cls = (z*mask).sum(1)/mask.sum(1)
        return {'token_embeddings': cls[:, None, :]}


class Encoder(torch.nn.ModuleList):
    def __init__(self):
        super().__init__([Transformer()])
        self.tokenizer = Tokenizer()

    def forward(self, features):
        raw = self[0](features)['token_embeddings'][:, 0]
        return {'sentence_embedding': torch.nn.functional.normalize(raw, dim=1)}


def group(index=0):
    uid = f'handwritten{index:03d}'
    sellers = tuple(f'{uid}.a{i:02d}' for i in range(28))
    owners = [i//2 for i in range(16)]+[8+(i-16)//3 for i in range(16, 28)]
    items = tuple(tuple((f'{seller}.r{r}', f'title {index} {i} {r}', f'description {index} {i+r}')
                        for r in range(2)) for i, seller in enumerate(sellers))
    labels = tuple(int(owners[i] == owners[j]) for i in range(28) for j in range(i+1, 28))
    return m.data.Group(uid, sellers, items, labels)


def fixture(name):
    torch.manual_seed(7)
    spec = m.Spec(name, 'ABC', 4)
    method = m.Method(spec)
    model = m.core.build_model(Encoder(), 8, 5)
    if name == 'L2R_text_fixed':
        del model.head
    c = dict(input=dict(microbatch=16, token_budget=256), comparison_spec=spec.identity(),
             optimizer=dict(encoder_lr=1e-5, head_lr=.001, encoder_weight_decay=.01,
                            head_weight_decay=0., betas=[.9, .999], eps=1e-8, foreach=False))
    optimizer = (torch.optim.AdamW(model.encoder.parameters(), lr=1e-5, foreach=False)
                 if name == 'L2R_text_fixed' else m.core.make_optimizer(model, c))
    method.bind(model, method.metadata())
    return method, model, optimizer, c


class ComparisonTests(unittest.TestCase):
    def test_omp_ridge_zero_and_small_improvement(self):
        w, _ = m.gcr.nonnegative_omp(np.array([[2.]]), np.array([3.]), ['a'])
        self.assertAlmostEqual(w['a'], 6/4.5)
        d = np.array([[1., -1., 1., -1., 1., -1.]])
        w, log = m.gcr.nonnegative_omp(d, d.sum(1), list('abcdef'))
        self.assertEqual(w, {})
        self.assertEqual(log['objective'], 0.)
        d = np.full((1, 6), 1e-6)
        w, log = m.gcr.nonnegative_omp(d, d.sum(1), list('abcdef'))
        self.assertTrue(w)
        self.assertEqual(len(log['expansions']), 6)
        self.assertGreater(sum(w.values()), 0.)
        # One atom points away from the target, exercising an active zero bound.
        w, _ = m.gcr.nonnegative_omp(np.array([[1., -1.], [0., 1.]]), np.array([1., 0.]), ['a', 'b'])
        self.assertAlmostEqual(w['a'], 2/3)
        self.assertNotIn('b', w)

    def test_omp_keeps_tiny_first_step(self):
        d = np.array([[2., 1., 1., 2., 1., 1.], [1e6, -1e6, 0., 1e6, -1e6, 0.]])
        w, log = m.gcr.nonnegative_omp(d, d.sum(1), list('abcdef'))
        self.assertTrue(w)
        self.assertGreaterEqual(len(log['expansions']), 2)
        self.assertLess(log['objective'], 64/3)

    def test_pss_sign_and_fixed_reference_isd(self):
        q, p = np.array([1., 0.]), np.array([2., 0.])
        candidates = np.array([[1., 1.], [3., 1.], [2., -1.]])
        # Self is included: each first/second item has ISD 2/3, third has 4/3.
        np.testing.assert_allclose(m.l2r.priority(q, p, candidates), [.8+.2*2/3, -.8+.2*2/3, .2*4/3])
        with self.assertRaises(ValueError):
            m.l2r.priority(np.zeros(2), p, candidates)

    def test_gcr_full_head_gradient_and_absolute_replay_weight(self):
        _, model, _, c = fixture('ER_GCR_group_fixed')
        g = group()
        actual = m.gcr.head_gradient(model, g, c)
        z = m.five.record.record_vectors(model, g, c)
        table = m.five.record.pair_table(model, z)
        objective, _ = m.gcr.supervised(table, g)
        expected = torch.autograd.grad(.5*objective, list(model.head.parameters()))
        reference = torch.cat([x.flatten() for x in expected]).detach().numpy()
        np.testing.assert_allclose(actual, reference, rtol=2e-5, atol=2e-7)
        model.zero_grad(set_to_none=True)
        m.gcr.backward(model, g, c, 17, .5)
        first = {n: p.grad.clone() for n, p in model.named_parameters()}
        self.assertGreater(float(first['encoder.0.embedding.weight'].norm()), 0.)
        model.zero_grad(set_to_none=True)
        m.gcr.backward(model, g, c, 17, 1.)
        for n, p in model.named_parameters():
            torch.testing.assert_close(p.grad, 2*first[n], rtol=2e-5, atol=2e-7)

    def test_gcr_real_update_admission_and_roundtrip(self):
        method, model, optimizer, c = fixture('ER_GCR_group_fixed')
        current = [group(i) for i in range(48)]
        memory = method.memory()
        stage = method.stage(1, current, memory, model)
        before = copy.deepcopy(model.state_dict())
        first = method.update(model, optimizer, stage, current[0], c, 1)
        self.assertNotIn('replay', first)
        self.assertEqual(stage.entered, {current[0].uid})
        self.assertTrue(any(not torch.equal(v, before[k]) for k, v in model.state_dict().items()))
        payload, transient = memory.to_bytes(), stage.transient()
        restored_memory = method.memory_from(payload)
        restored_stage = method.stage(1, current, restored_memory, model)
        restored_stage.restore_transient(transient)
        self.assertEqual(stage.draw(), restored_stage.draw())
        stage.after_update(current[0])
        self.assertEqual(len(stage.entered), 1)

    def test_l2r_multi_positive_real_update_and_false_negative_mask(self):
        method, model, optimizer, c = fixture('L2R_text_fixed')
        current = [group(i) for i in range(48)]
        memory = method.memory()
        stage = method.stage(1, current, memory, model)
        rows = stage.current[current[0].uid]
        queries = [(q, [p for p in rows if p.uid != q.uid and m.l2r.same_identity(q, p)]) for q in rows]
        loss, log = stage.block(model, c, queries, 1, 'current', lambda: None)
        self.assertEqual(log['positive_items'], 40)
        self.assertEqual(log['queries'], 28)
        by_id = stage.index.by_id
        for item in log['selections']:
            q = by_id[item['query']]
            self.assertTrue(all(uid == item['positive'] or not m.l2r.same_identity(q, by_id[uid])
                                for uid in item['denominator']))
        loss.backward()
        self.assertGreater(float(model.encoder[0].embedding.weight.grad.norm()), 0.)
        before = model.encoder[0].embedding.weight.detach().clone()
        result = method.update(model, optimizer, stage, current[0], c, 1)
        self.assertEqual(result['current']['positive_items'], 40)
        self.assertFalse(torch.equal(before, model.encoder[0].embedding.weight))
        self.assertEqual(method.score(model, current[:1], c).shape, (1, 378))
        # The scorer really uses raw CLS rather than normalized sentence output.
        z = m.l2r.encode(model, rows, c)
        i, j = torch.triu_indices(28, 28, 1)
        np.testing.assert_allclose(method.score(model, current[:1], c)[0],
                                   (z[i]*z[j]).sum(1).detach().numpy(), atol=1e-6)
        stage.retain(model, c)
        restored = method.memory_from(memory.to_bytes())
        self.assertEqual(restored.to_bytes(), memory.to_bytes())
        self.assertLessEqual(restored.summary()['slots'], 168)


if __name__ == '__main__':
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    unittest.main()
