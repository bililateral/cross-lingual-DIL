"""Affected actual entries on handwritten data; executed only by Linux py310."""
import copy
import hashlib
import os
from pathlib import Path
import random
import tempfile
import unittest
from unittest import mock

import numpy as np
import torch

import step28_continual_five as m
import step28_continual_five_run as run
import step28_continual_five_control as ctl
from test_step28_record_replay import handmade_group, TinyEncoder
from test_step28_optuna import reference


def fixture(name, order="CAB", seed=4, step=624):
    spec = m.Spec(name, order, seed)
    method, c = m.Method(spec), m.config(spec)
    torch.manual_seed(41)
    model = m.core.build_model(TinyEncoder(), 8 if spec.is_record else 16, 5)
    m.checkpoint_encoder(model.encoder)
    method.bind(model, method.metadata())
    optimizer = m.core.make_optimizer(model, c)
    # Explicit handwritten Adam state; not a completed training trajectory.
    for p in model.parameters():
        optimizer.state[p] = dict(step=torch.tensor(float(step)), exp_avg=torch.zeros_like(p), exp_avg_sq=torch.zeros_like(p))
    return spec, method, c, model, optimizer


def original_objective(scores, group):
    from test_step28_positive_ranking import independent_loss, independent_rank, LOOKUP
    original = []
    for q in range(28):
        ids = [LOOKUP[tuple(sorted((q, j)))] for j in range(28) if j != q]
        pos = [k for k in ids if group.labels[k]]
        original.append(torch.logsumexp(scores[ids], 0)-scores[pos].mean())
    return independent_loss(scores, group)-independent_rank(scores, group.labels)+torch.stack(original).mean()


class FiveTests(unittest.TestCase):
    def evidence(self, name, row):
        m.data.write_json(Path(os.environ["FIVE_TEST_ROOT"])/(name+".json"), row)

    def test_actual_five_updates_and_omission_controls(self):
        current, history = handmade_group("current"), handmade_group("history")
        evidence = {}
        for name in m.METHODS:
            spec, method, c, model, optimizer = fixture(name)
            direct = copy.deepcopy(model)
            self.assertIs(direct.encoder._five_original_forward.__self__, direct.encoder)
            direct.encoder._five_outer_checkpoint = False
            other = m.core.make_optimizer(direct, c)
            other.load_state_dict(copy.deepcopy(optimizer.state_dict()))
            target = np.sin(np.arange(1540 if spec.is_record else 378)/7).astype(np.float32)*3
            if name in ("SEQ_ref", "ER0.1_ref"):
                target = None
            h = None if name == "SEQ_ref" else history
            row = method.update(model, optimizer, current, h, target, c, 3, 49)
            direct.train()
            other.zero_grad(set_to_none=True)
            omission_gradients = []
            for role, group, teacher in (("current", current, None), ("history", h, target)):
                if group is None:
                    continue
                torch.manual_seed(m.data.seed_for(spec.roots["schedule"], spec.order, 3, 49, role, "dropout"))
                if spec.is_record:
                    z = m.record.record_vectors(direct, group, c)
                    i, j = torch.triu_indices(len(z), len(z), 1)
                    table = direct.head(torch.cat(((z[i]-z[j]).abs(), z[i]*z[j]), 1)).flatten()
                    regroup = m.data.seed_for(spec.roots["schedule"], spec.order, 3, 49, role, group.uid, "regroup")
                    objective = reference(table, group, regroup, spec, teacher)
                    if teacher is not None:
                        mutant = .1*reference(table, group, regroup, spec, None)
                        real_grad, = torch.autograd.grad(objective, table, retain_graph=True)
                        wrong_grad, = torch.autograd.grad(mutant, table, retain_graph=True)
                        self.assertGreater(float((real_grad-wrong_grad).abs().max()), 1e-7)
                else:
                    scores = m.base.logits(direct, group, c, "split_rank")
                    supervised = original_objective(scores, group)
                    objective = supervised if role == "current" else .1*supervised
                    if teacher is not None:
                        objective = objective+.5*(scores-torch.from_numpy(teacher)).square().mean()
                    if role == "history":
                        real_grad, = torch.autograd.grad(objective, scores, retain_graph=True)
                        without_teacher, = torch.autograd.grad(.1*supervised, scores, retain_graph=True)
                        self.assertGreater(float(real_grad.abs().max()), 1e-7)
                        omission_gradients.append(float(real_grad.abs().max()))
                        if teacher is not None:
                            self.assertGreater(float((real_grad-without_teacher).abs().max()), 1e-7)
                            wrongly_scaled, = torch.autograd.grad(.1*(supervised+.5*(scores-torch.from_numpy(teacher)).square().mean()), scores, retain_graph=True)
                            self.assertGreater(float((real_grad-wrongly_scaled).abs().max()), 1e-7)
                objective.backward()
            errors = []
            # The actual path has clipped once; compare its complete pre-step effect
            # against independently assembled current/history gradients and Adam.
            torch.nn.utils.clip_grad_norm_(direct.parameters(), 1.)
            for group, rate in zip(other.param_groups, spec.rates(49)):
                group["lr"] = rate
            other.step()
            for p, q in zip(model.parameters(), direct.parameters()):
                torch.testing.assert_close(p, q, atol=3e-6, rtol=3e-5)
                for field in ("step", "exp_avg", "exp_avg_sq"):
                    torch.testing.assert_close(optimizer.state[p][field], other.state[q][field], atol=3e-6, rtol=3e-5)
                errors.append(float((p-q).detach().abs().max()))
            self.assertEqual(m.parent.adam_step(optimizer), 625)
            self.assertEqual((row["encoder_lr"], row["head_lr"]), spec.rates(49))
            with self.assertRaises(ValueError):
                method.update(model, optimizer, current, h, target, c, 3, 49)
            evidence[name] = dict(max_parameter_error=max(errors), actual_adam_step=625,
                                  omitted_history_or_teacher_detected=name != "SEQ_ref", roots=spec.roots)
        self.evidence("actual_five_updates", evidence)

    def test_three_stage_memory_orders_seeds_and_birth_targets(self):
        first = [handmade_group(f"first_{i:02}") for i in range(48)]
        second = [handmade_group(f"second_{i:02}") for i in range(48)]
        evidence = []
        for order, seed in (("ABC", 4), ("BCA", 5), ("CAB", 6)):
            summaries = []
            for name in m.METHODS[1:]:
                spec, method, c, model, _ = fixture(name, order, seed)
                memory = method.new_memory(dict(a=1., b=0.))
                length = 1540 if spec.is_record else 378
                def birth(group):
                    return np.full(length, 1. if group.uid.startswith("first") else 2., np.float32)
                with mock.patch.object(m.record, "reference", side_effect=lambda mod, g, config, check: birth(g)), \
                     mock.patch.object(method, "score", side_effect=lambda mod, gs, config, check: np.stack([birth(g) for g in gs])):
                    method.retain(memory, model, first, c, 1, dict(first=dict(a=1., b=0.)))
                    memory.begin_stage(2)
                    for _ in range(288):
                        memory.draw()
                    method.retain(memory, model, second, c, 2, dict(first=dict(a=1., b=0.)))
                memory.begin_stage(3)
                payload = memory.to_bytes()
                restored = method.memory_from(payload)
                allowed = set(memory.summary()["members"])
                observed = []
                for _ in range(8):
                    g, target = memory.draw()
                    rg, rt = restored.draw()
                    self.assertEqual(g.uid, rg.uid)
                    self.assertIn(g.uid, allowed)
                    if target is not None:
                        np.testing.assert_array_equal(target, birth(g))
                        np.testing.assert_array_equal(target, rt)
                    observed.append(g.uid)
                self.assertEqual(memory.to_bytes(), restored.to_bytes())
                with self.assertRaises(ValueError):
                    m.Method(m.Spec(name, order, 5 if seed != 5 else 4)).memory_from(payload)
                summaries.append((allowed, observed))
                evidence.append(dict(spec=spec.identity(), members=sorted(allowed), draws=observed, bytes=len(payload)))
            self.assertTrue(all(row == summaries[0] for row in summaries))
            spec = m.Spec("S_tuned", order, seed)
            seq, _ = m.parent.schedule(second, m.config(spec), order, 3)
            expected = m.data.schedule(second, 6, m.data.seed_for(spec.roots["schedule"], order, 3, "current"))
            self.assertEqual([g.uid for g in seq], [g.uid for g in expected])
        self.evidence("memory_stage3", evidence)

    def test_real_restore_next_update_and_budget(self):
        out = Path(os.environ["FIVE_TEST_ROOT"])
        spec, method, c, model, optimizer = fixture("H_pos_tuned")
        current, history = handmade_group("current"), handmade_group("history")
        target = np.sin(np.arange(1540)).astype(np.float32)
        metadata = {**method.metadata(), "rng": m.diag.rng_state(), "modes": [v.training for v in model.modules()]}
        with tempfile.TemporaryDirectory(dir=out) as temporary:
            root = Path(temporary)
            budget = run.Budget(root, __import__("time").monotonic()+60, tail=1)
            full = run.save(root/"full.pt", model, optimizer, metadata, budget)
            first = method.update(model, optimizer, current, history, target, c, 3, 49)
            digest = m.core.state_digest(dict(model=model.state_dict(), optimizer=optimizer.state_dict()))
            method.restore(root/"full.pt", full, model, optimizer)
            second = method.update(model, optimizer, current, history, target, c, 3, 49)
            self.assertEqual(first, second)
            self.assertEqual(digest, m.core.state_digest(dict(model=model.state_dict(), optimizer=optimizer.state_dict())))
            with m.diag.neutral(model):
                before = method.score(model, [current], c)
            inference = run.save(root/"infer.pt", model, None, metadata, budget)
            method.restore(root/"infer.pt", inference, model, None)
            with m.diag.neutral(model):
                np.testing.assert_array_equal(before, method.score(model, [current], c))
        now = [0.]
        ledger = ctl.Ledger(clock=lambda: now[0])
        for i in range(3):
            ledger.reserve(str(i), "training", 100.)
        now[0] = 40.
        self.assertEqual(ledger.available("training"), ctl.LIMITS["training"]-300)
        ledger.settle("1", success=True)
        self.assertEqual(ledger.available("training"), ctl.LIMITS["training"]-240)
        ledger.used["training"] = ctl.LIMITS["training"]-300
        with self.assertRaises(ValueError):
            ledger.reserve("over", "training", 60, remaining_projection=41)
        now[0] = 101.
        with self.assertRaises(RuntimeError):
            ledger.settle("0", success=True)
        self.assertEqual(ledger.completed[-1]["actual_seconds"], 101)
        self.assertTrue(ledger.failed)
        with mock.patch.object(run.time, "monotonic", return_value=100.):
            with self.assertRaises(TimeoutError):
                run.Budget(out, 101., 2.).check()
        self.evidence("restore_budget", dict(actual_next_update_bitwise_equal=True, inference_equal=True,
            same_absolute_child_deadline=True, active_elapsed_not_double_counted=True, actual_overrun_not_clipped=True))

    def test_exact_complete_id_gate(self):
        rows = []
        for spec in m.specifications():
            rows.append(dict(status=run.COMPLETE, spec=spec.identity(), source_files=[], updates=864,
                gradient_group_presentations=864 if spec.name == "SEQ_ref" else 1440,
                access=dict(train=1, valid=0, heldout=0, owners=0, worker_train_reads=1),
                training={str(i): {} for i in (1, 2, 3)}, points={str(i): dict(continual_spec=spec.identity(), adam_step=i*288,
                    full_restore_verified=True, inference_restore_verified=True, development_ids=list(range(60)),
                    calibration_ids=list(range(12)), scores={k: {} for k in ("calibration", "raw", "full-calibration", "full-raw",
                        "inference-calibration", "inference-raw", "stage-cal", "first-cal")}) for i in (1, 2, 3)}))
        random.Random(19).shuffle(rows)
        ctl.joint_opening(rows, [])
        for mutant in (rows[:-1], rows[:-1]+[rows[0]]):
            with self.assertRaises(ValueError):
                ctl.joint_opening(mutant, [])
        broken = copy.deepcopy(rows)
        broken[0]["points"]["3"]["full_restore_verified"] = False
        with self.assertRaises(ValueError):
            ctl.joint_opening(broken, [])
        broken = copy.deepcopy(rows)
        broken[0]["access"]["valid"] = 1
        with self.assertRaises(ValueError):
            ctl.joint_opening(broken, [])
        self.evidence("complete_ids", dict(exact_45_unordered=True, duplicate_missing_bad_restore_and_early_open_rejected=True))
