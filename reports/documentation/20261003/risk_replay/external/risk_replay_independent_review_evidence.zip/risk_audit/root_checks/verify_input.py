"""Independent byte/ZIP inventory audit; never writes to received attachment."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
ARCHIVE = ROOT.parent / 'upload' / 'review(3).zip'
INPUT = ROOT / 'input'
expected = {'bytes': 193561, 'members': 51, 'sha256':
            '562b01b536a0bd43bee1366a0be09381d603d0770bbd8855ae027f26707fd61e'}
b = ARCHIVE.read_bytes()
with zipfile.ZipFile(ARCHIVE) as z:
    actual = {'bytes': len(b), 'members': len(z.infolist()),
              'sha256': hashlib.sha256(b).hexdigest()}
    assert actual == expected, (actual, expected)
    assert z.testzip() is None
    assert len(set(z.namelist())) == len(z.namelist())
    for name in z.namelist():
        assert (INPUT / name).read_bytes() == z.read(name)
    print('ARCHIVE_IDENTITY_AND_EXTRACTED_BYTES', json.dumps(actual))
    members = set(z.namelist())
for inv, base in [
    ('review_inventory.json', INPUT),
    ('reports/documentation/20261003/risk_replay/source_inventory.json', INPUT),
    ('reports/documentation/20261003/risk_replay/evidence_inventory.json',
     INPUT / 'reports/documentation/20261003/risk_replay/evidence')]:
    records = json.loads((INPUT / inv).read_text())
    assert len({r['path'] for r in records}) == len(records)
    for row in records:
        contents = (base / row['path']).read_bytes()
        assert len(contents) == row['bytes'], row['path']
        assert hashlib.sha256(contents).hexdigest() == row['sha256'], row['path']
    if inv == 'review_inventory.json':
        assert {r['path'] for r in records} | {inv} == members
    print('INVENTORY_PASS', inv, len(records))
print('PASS: archive 51 members, review 50, source 21, evidence 17; no omissions.')
