"""Execute the mechanism reference and preserve complete process evidence."""
import json
import os
from pathlib import Path
import subprocess
import sys

out = Path(__file__).resolve().parent
root = out.parent
env = os.environ.copy()
env["PYTHONPATH"] = str(root / "torch_runtime")
env["CUDA_VISIBLE_DEVICES"] = ""
command = [sys.executable, str(out / "mechanism_reference.py")]
(out / "command.json").write_text(json.dumps({"argv": command, "PYTHONPATH": env["PYTHONPATH"], "CUDA_VISIBLE_DEVICES": ""}, indent=2) + "\n")
with (out / "stdout.txt").open("w") as stdout, (out / "stderr.txt").open("w") as stderr:
    completed = subprocess.run(command, stdout=stdout, stderr=stderr, env=env, cwd=root, check=False)
(out / "exit_code.txt").write_text(str(completed.returncode) + "\n")
print(json.dumps({"exit_code": completed.returncode, "stdout": str(out / "stdout.txt"), "stderr": str(out / "stderr.txt")}))
sys.exit(completed.returncode)
