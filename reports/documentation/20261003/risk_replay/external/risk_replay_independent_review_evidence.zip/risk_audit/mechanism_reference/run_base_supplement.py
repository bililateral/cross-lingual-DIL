"""Preserve separate stdout/stderr/exit evidence without replacing earlier runs."""
import json
import os
from pathlib import Path
import subprocess
import sys

out = Path(__file__).resolve().parent
env = os.environ.copy()
env["PYTHONPATH"] = str(out.parent / "torch_runtime")
env["CUDA_VISIBLE_DEVICES"] = ""
command = [sys.executable, str(out / "base_loss_supplement.py")]
(out / "base_supplement.command.json").write_text(json.dumps({"argv": command, "PYTHONPATH": env["PYTHONPATH"], "CUDA_VISIBLE_DEVICES": ""}, indent=2) + "\n")
with (out / "base_supplement.stdout.txt").open("w") as stdout, (out / "base_supplement.stderr.txt").open("w") as stderr:
    completed = subprocess.run(command, stdout=stdout, stderr=stderr, env=env, cwd=out.parent, check=False)
(out / "base_supplement.exit_code.txt").write_text(str(completed.returncode) + "\n")
print(json.dumps({"exit_code": completed.returncode, "stdout": str(out / "base_supplement.stdout.txt"), "stderr": str(out / "base_supplement.stderr.txt")}))
sys.exit(completed.returncode)
