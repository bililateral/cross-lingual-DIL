"""Portable audit recorder; inherit a Torch Python env or RISK_AUDIT_TORCH_PATH.

Usage: python run_recorded.py RUN_DIR PYTHON oracle.py --output DATA_DIR
No original or prior result is overwritten. All child stdout/stderr are captured.
"""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

destination = Path(sys.argv[1]).resolve()
command = sys.argv[2:]
if not command:
    raise SystemExit('Expected RUN_DIR followed by a command')
destination.mkdir(parents=True, exist_ok=False)
started = time.monotonic()
env = dict(os.environ)
if env.get('RISK_AUDIT_TORCH_PATH'):
    env['PYTHONPATH'] = os.pathsep.join(filter(None, [env['RISK_AUDIT_TORCH_PATH'], env.get('PYTHONPATH')]))
env.update(CUDA_VISIBLE_DEVICES='', PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1',
           MKL_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1')
keys = ('PYTHONPATH', 'RISK_AUDIT_INPUT', 'RISK_AUDIT_TORCH_PATH', 'CUDA_VISIBLE_DEVICES',
        'PYTHONDONTWRITEBYTECODE', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS')
(destination/'command.json').write_text(json.dumps({'command': command, 'cwd': os.getcwd(),
    'environment': {k: env[k] for k in keys if k in env}}, indent=2))
with (destination/'stdout.txt').open('wb') as out, (destination/'stderr.txt').open('wb') as err:
    p = subprocess.run(command, stdout=out, stderr=err, env=env)
(destination/'exit_code.txt').write_text(str(p.returncode)+'\n')
(destination/'execution.json').write_text(json.dumps({'exit_code': p.returncode, 'seconds': time.monotonic()-started,
    'stdout_sha256': hashlib.sha256((destination/'stdout.txt').read_bytes()).hexdigest(),
    'stderr_sha256': hashlib.sha256((destination/'stderr.txt').read_bytes()).hexdigest()}, indent=2))
print(json.dumps({'directory': str(destination), 'exit_code': p.returncode, 'seconds': time.monotonic()-started}), flush=True)
print((destination/'stdout.txt').read_text(), flush=True)
print((destination/'stderr.txt').read_text(), file=sys.stderr, flush=True)
sys.exit(p.returncode)
