"""Run an audit command and retain exact stdout/stderr/exit/metadata; no overwrites."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

destination = Path(sys.argv[1])
command = sys.argv[2:]
destination.mkdir(parents=True, exist_ok=False)
started = time.monotonic()
env = dict(os.environ)
env['PYTHONPATH'] = '/workspace/scratch/ae1bf546d06e/risk_audit/torch_runtime'
env['CUDA_VISIBLE_DEVICES'] = ''
env['PYTHONDONTWRITEBYTECODE'] = '1'
env['OMP_NUM_THREADS'] = '1'
env['MKL_NUM_THREADS'] = '1'
env['OPENBLAS_NUM_THREADS'] = '1'
(destination / 'command.json').write_text(json.dumps({'command': command, 'cwd': os.getcwd(),
    'environment': {key: env[key] for key in ('PYTHONPATH', 'CUDA_VISIBLE_DEVICES', 'PYTHONDONTWRITEBYTECODE',
                                             'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS')}}, indent=2))
with (destination / 'stdout.txt').open('wb') as out, (destination / 'stderr.txt').open('wb') as err:
    p = subprocess.run(command, stdout=out, stderr=err, env=env)
(destination / 'exit_code.txt').write_text(str(p.returncode) + '\n')
(destination / 'execution.json').write_text(json.dumps({'exit_code': p.returncode, 'seconds': time.monotonic()-started,
    'stdout_sha256': hashlib.sha256((destination/'stdout.txt').read_bytes()).hexdigest(),
    'stderr_sha256': hashlib.sha256((destination/'stderr.txt').read_bytes()).hexdigest()}, indent=2))
print(json.dumps({'directory': str(destination), 'exit_code': p.returncode, 'seconds': time.monotonic()-started}), flush=True)
print((destination / 'stdout.txt').read_text(), flush=True)
print((destination / 'stderr.txt').read_text(), file=sys.stderr, flush=True)
sys.exit(p.returncode)
