"""Export the independently generated Tiny update fixture, never source data."""
from pathlib import Path
import importlib.util
import json
import torch

root = Path('/workspace/scratch/ae1bf546d06e/risk_audit/reference')
spec = importlib.util.spec_from_file_location('fixture_oracle', root/'oracle_v3/oracle.py')
oracle = importlib.util.module_from_spec(spec); spec.loader.exec_module(oracle)
torch.set_num_threads(1); torch.use_deterministic_algorithms(True)
destination = root/'fixture_inputs'
destination.mkdir(exist_ok=False)
model, optimizer, c, old, current, reference = oracle.prepared()
result = {'scope': 'Handwritten Tiny CPU only; one actual warm update then Adam counter 1->288',
          'config': c, 'current': current.payload(), 'history': old.payload(), 'reference': reference,
          'history_weight': .23, 'retention_weight': .71,
          'current_seed': 815, 'history_seed': 927,
          'stage_first': {'uids': [f'phase1_{k:02d}' for k in range(48)], 'shifts': [k+1 for k in range(48)]},
          'stage_second': {'uids': [f'phase2_{k:02d}' for k in range(48)], 'shifts': [k+100 for k in range(48)]},
          'text_generator': 'oracle_v3/oracle.py: group()'}
(destination/'handwritten_inputs.json').write_text(json.dumps(result, ensure_ascii=False, indent=2))
receipt = oracle.production.core.save_state(destination/'tiny_fixture_initial_counter288.pt', model, optimizer,
                                           {'handwritten_probe_only': True, 'actual_warm_updates': 1, 'counter': 288})
(destination/'checkpoint_receipt.json').write_text(json.dumps(receipt, indent=2))
print(json.dumps({'saved': str(destination), 'model': receipt, 'formal_data_access': False}, indent=2))
