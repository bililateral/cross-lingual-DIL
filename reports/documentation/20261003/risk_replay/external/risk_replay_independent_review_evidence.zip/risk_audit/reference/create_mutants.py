"""Create immutable single-defect mutation copies, leaving the supplied code intact."""
from pathlib import Path
import hashlib
import json

root = Path('/workspace/scratch/ae1bf546d06e/risk_audit/reference')
original = Path('/workspace/scratch/ae1bf546d06e/risk_audit/input/scripts/step28_risk_replay.py')
source = original.read_text()
specs = {
 'delete_retention': ('objective = objective + retention_weight * penalties.mean()',
                      'objective = objective + 0.0 * penalties.mean()'),
 'detach_retention': ('objective = objective + retention_weight * penalties.mean()',
                      'objective = objective + retention_weight * penalties.detach().mean()'),
 'multiply_gamma_by_lambda': ('objective = objective + retention_weight * penalties.mean()',
                             'objective = objective + history_weight * retention_weight * penalties.mean()'),
 'swap_weights': ('objective = objective + retention_weight * penalties.mean()',
                  'objective = retention_weight * terms["total"] + history_weight * penalties.mean()'),
 'omit_channel_mean': ('objective = objective + retention_weight * penalties.mean()',
                       'objective = objective + retention_weight * penalties.sum()'),
 'stage_gamma_zero': ('history_weight=history_weight, retention_weight=retention_weight, check=check))',
                      'history_weight=history_weight, retention_weight=0.0, check=check))'),
 'cross_stratum_mix': ('ordered = torch.sort(risks[counts == degree], dim=0, stable=True).values\n        target = torch.tensor(reference[str(degree)], dtype=risks.dtype, device=risks.device)',
                       'ordered = torch.sort(risks, dim=0, stable=True).values\n        target = torch.sort(torch.tensor(reference["1"] + reference["2"], dtype=risks.dtype, device=risks.device), dim=0, stable=True).values\n        if degree == 2:\n            continue'),
 'retained_score_row_reverse': ('for group, row in zip(newcomers, values, strict=True):',
                                'for group, row in zip(newcomers, values[::-1], strict=True):'),
}
manifest = {}
for name, (old, new) in specs.items():
    if source.count(old) != 1:
        raise ValueError((name, source.count(old)))
    directory = root / 'mutants' / name
    directory.mkdir(parents=True, exist_ok=False)
    modified = source.replace(old, new)
    (directory / 'step28_risk_replay.py').write_text(modified)
    manifest[name] = {'original_sha256': hashlib.sha256(source.encode()).hexdigest(),
                      'mutated_sha256': hashlib.sha256(modified.encode()).hexdigest(),
                      'removed': old, 'inserted': new}
    (directory / 'mutation.json').write_text(json.dumps(manifest[name], indent=2))
(root / 'mutants' / 'manifest.json').write_text(json.dumps(manifest, indent=2))
print(json.dumps({'created': list(manifest)}, indent=2))
