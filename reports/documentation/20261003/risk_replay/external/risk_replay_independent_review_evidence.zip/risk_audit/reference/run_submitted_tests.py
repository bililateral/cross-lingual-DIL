"""Run the exact submitted 7 tests against original or a declared mutation copy."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import unittest
import torch

p = argparse.ArgumentParser()
p.add_argument('--module', type=Path)
a = p.parse_args()
root = Path('/workspace/scratch/ae1bf546d06e/risk_audit/input')
sys.path[:0] = [str(root / 'tests'), str(root / 'scripts')]
if a.module:
    spec = importlib.util.spec_from_file_location('step28_risk_replay', a.module)
    module = importlib.util.module_from_spec(spec)
    sys.modules['step28_risk_replay'] = module
    spec.loader.exec_module(module)
else:
    import step28_risk_replay as module
torch.set_num_threads(1)
torch.use_deterministic_algorithms(True)
print(json.dumps({'torch': torch.__version__, 'module': module.__file__,
                  'sha256': hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest(),
                  'test_source': str(root/'tests/test_step28_risk_replay.py'),
                  'scope': 'exact submitted Tiny suite; no BGE/model/formal data'}, indent=2), flush=True)
import test_step28_risk_replay as tests
result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(tests))
print(json.dumps({'run': result.testsRun, 'errors': len(result.errors),
                  'failures': len(result.failures), 'success': result.wasSuccessful()}), flush=True)
sys.exit(0 if result.wasSuccessful() else 1)
