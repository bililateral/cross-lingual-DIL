"""Package immutable original input plus the actually executed independent audit.

No training, remote data access, or attachment rewrite occurs here.
The manifest and CRC checks establish artifact integrity only.
"""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = ROOT.parent
ORIGINAL = WORKSPACE / 'upload/review(3).zip'
OUT = ROOT / 'deliverables/risk_replay_independent_review_evidence.zip'
EXPECTED = '562b01b536a0bd43bee1366a0be09381d603d0770bbd8855ae027f26707fd61e'

if OUT.exists():
    raise SystemExit('Refusing to replace an existing evidence bundle')

payloads = {}
def add(path, name=None):
    path = Path(path)
    key = name or path.relative_to(WORKSPACE).as_posix()
    if key in payloads:
        raise ValueError('duplicate bundle member: '+key)
    payloads[key] = path.read_bytes()

raw = ORIGINAL.read_bytes()
assert len(raw) == 193561 and hashlib.sha256(raw).hexdigest() == EXPECTED
with zipfile.ZipFile(ORIGINAL) as source:
    assert len(source.infolist()) == 51 and source.testzip() is None
    for name in source.namelist():
        assert (ROOT/'input'/name).read_bytes() == source.read(name), name
        add(ROOT/'input'/name)
add(ORIGINAL)

for folder in ['reference', 'mechanism_reference', 'mechanism_reference_root_repeat', 'root_checks', 'package']:
    for path in sorted((ROOT/folder).rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc':
            add(path)
for name in ['input_identity.json', 'inventory_verification.json']:
    add(ROOT/name)
for path in sorted(ROOT.glob('agent_*.txt')):
    add(path)
for name in ['risk_replay_review.zh.pdf', 'report.zh.txt', 'verdict.json', 'risk_replay_review.zh.build.json']:
    add(ROOT/'deliverables'/name)
add(ROOT/'report_builder/build_report.py')
add(ROOT/'pdf_qa/visual_check.json')
add(ROOT/'package/README.zh.txt', 'README.zh.txt')

manifest = {
    'schema_version': 1,
    'description_zh': '完整交付的逐文件身份清单；不作为计算正确性证据。MANIFEST.json本身不自引用。',
    'original_zip_sha256': EXPECTED,
    'payload_members': len(payloads),
    'files': [dict(path=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
              for name, data in sorted(payloads.items())],
}
payloads['MANIFEST.json'] = (json.dumps(manifest, ensure_ascii=False, indent=2)+'\n').encode()
with zipfile.ZipFile(OUT, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in sorted(payloads.items()):
        entry = zipfile.ZipInfo(name, date_time=(2026,10,3,0,0,0))
        entry.compress_type = zipfile.ZIP_DEFLATED
        entry.external_attr = 0o100644 << 16
        z.writestr(entry, data, compresslevel=9)
with zipfile.ZipFile(OUT) as z:
    assert z.testzip() is None
    assert len(z.namelist()) == len(set(z.namelist())) == len(payloads)
    for name,data in payloads.items():
        assert z.read(name) == data, name
assert ORIGINAL.read_bytes() == raw
receipt = {
    'filename': OUT.name,
    'bytes': OUT.stat().st_size,
    'members': len(payloads),
    'sha256': hashlib.sha256(OUT.read_bytes()).hexdigest(),
    'all_payloads_reopened_and_equal': True,
    'crc_bad_member': None,
    'original_zip_unchanged': True,
}
(ROOT/'deliverables/bundle_receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2)+'\n')
print(json.dumps(receipt, ensure_ascii=False, indent=2))
