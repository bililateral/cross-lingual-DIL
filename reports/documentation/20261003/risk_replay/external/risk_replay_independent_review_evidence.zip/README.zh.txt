群体风险分布保持重放：独立科研方法与实现外审证据包
审查日期：2026-10-03 UTC

一、先读什么

1. risk_audit/deliverables/risk_replay_review.zh.pdf：12页完整中文审查报告。
2. risk_audit/deliverables/report.zh.txt：同一报告的UTF-8纯文本，便于搜索与引用。
3. risk_audit/deliverables/verdict.json：机器裁决；分开记录科学主张、当前实现、证据覆盖缺口和后续范围。
4. risk_audit/reference/portable_v4/README.zh.md：最终可移植独立参考的环境与运行命令。

本包的总裁决以最终报告与verdict.json为准。agent_*.txt保存分工审查笔记，不代替最终整合裁决。原附件中的说明和原Linux日志是被审证据，不是此次独立执行产生的日志。

二、原附件没有被改写

upload/review(3).zip是收到的完整原ZIP，逐字节保留：
字节数：193561
成员数：51
SHA-256：562b01b536a0bd43bee1366a0be09381d603d0770bbd8855ae027f26707fd61e

risk_audit/input/仅包含该ZIP原有51个成员的逐字节副本；不含导入过程产生的__pycache__。root_checks/保存原始ZIP及三份inventory的独立校验源码、完整输出与退出0。
在解压根目录可运行：

python risk_audit/root_checks/verify_input.py

MANIFEST.json列出本交付包所有其他成员的路径、大小和SHA-256；它不递归包含自身摘要。交付ZIP的独立摘要见包外下载说明。哈希与CRC仅用于核对文件身份，不作为科学或计算正确性的证据。

三、实际独立执行结果

最终源码：risk_audit/reference/portable_v4/oracle.py
最终实跑：risk_audit/reference/portable_v4/root_run/
最终数据：risk_audit/reference/portable_v4/root_data/
退出码：0；六个检查组全部通过；完整stderr确实为空。

独立标量/NumPy另行实现三风险、分层单向惩罚、378条边的解析导数、BCE/rank/hard导数以及clip/AdamW参考。真实Torch仅执行被审文本→表示→对称分数图，并承接独立logit导数传播到Tiny参数。真实stage使用各群不同手写文本，执行288次更新，核对非默认λ=.23、γ=.71、抽样、reference、seed、缓存与恢复。

root_data/包括完整结果、手写输入、独立梯度数组、阶段逐步日志、手写缓存与纯Tiny模型/Adam状态。所有Tiny状态只来自手写夹具，不是BGE或正式模型权重。

四、完整失败版本与变异

reference/oracle_v1/：本方依赖缺sympy的失败版本，退出1，源码和完整输出保留。
reference/oracle_v2/：本方ER等价夹具给旧接口不支持的λ=.23，退出1，源码和完整输出保留。
reference/oracle_v3/：修正上述ER夹具为λ=.1，主更新与阶段仍使用.23/.71，全部通过，退出0。
reference/portable_v4/：只改输入根路径的可移植版本，根审查者已完整实跑，退出0；没有修改数学或断言。
reference/environment_v1/：最初无Torch的环境失败以及官方CPU依赖安装的完整命令/输出/退出码。

reference/mutants/保留八个故意引入单缺陷的完整生产源码副本、变更说明和实际运行的stdout/stderr/退出码：删除保持项、detach保持项、γ再乘λ、互换λ与γ、遗漏三通道平均、跨m层混合、stage强制γ=0、新参考分数行逆序。八个均被独立参考拒绝，退出1是预期检出。

reference/reference_summary.json包含全部八项。mutants/batch_result.json只包含同批运行的七项，stage变异另有完整独立目录和总汇，不要把批次清单误当总清单。

submitted_original_run/中原七项测试7/7通过；submitted_stage_gamma_zero_run/与submitted_score_row_reverse_run/中，两个错误版本仍通过原七项。它们是已证实的原测试覆盖缺口。当前生产代码的相应路径正确，本方参考也通过；本次没有修补或覆盖原测试文件。

五、反例与机制核验

mechanism_reference/保存独立手写反例的源码、完整输入、完整stdout/stderr、退出码，以及完整历史base/hard目标的补充核验。
mechanism_reference_root_repeat/保存根审查者对主反例源码的实际重复执行及原样输入；退出0。

有效378对称logit反例证明：逐查询三类代理风险均不恶化、D=0且保持梯度为0，仍可使MAP下降和固定阈值FPR翻倍。个体好坏交换也有有效logit例。联合风险例明确只是风险空间代数构造，不假称已经由某个BGE参数实现。

六、复跑方法与边界

解压后进入risk_audit/，按reference/portable_v4/README.zh.md准备Python 3.12、NumPy 2.3.5和Torch 2.7.1+cpu等依赖。依赖wheel和整个Python环境未打包；安装命令及当时版本均保留。

从risk_audit/运行，输出目录必须是新的：

python reference/portable_v4/run_recorded.py reference/portable_v4/my_run python reference/portable_v4/oracle.py --output reference/portable_v4/my_data

普通虚拟环境无需额外环境变量；若Torch通过pip --target安装，可设置RISK_AUDIT_TORCH_PATH。若原附件解压目录另置，可设置RISK_AUDIT_INPUT指向包含scripts/和schema/的目录。不要指向正式数据。

v1/v2/v3及各原始日志保留当时绝对路径，未为“可移植”而改写历史失败证据。v4是供独立重放的入口。给出已有结果不是建议覆盖它们。

Adam计数1→288、缩放参考风险以及较低clip=.08均明确为手写人工激活探针；不能当作真实来源阶段训练成果。288次是后续Tiny真实更新。本次没有重新运行BGE、访问正式数据或启动GPU训练，没有接入正式六端点评价。

七、辅助排版材料

report_builder/build_report.py为报告PDF排版源码；其环境依赖与科学参考分开。它可从本地PyMuPDF提取中文字体，不含外部模型或数据。PDF已经嵌入字体并完成页面检查。pdf_qa/visual_check.json记录检查和渲染器边界；中间PNG、重复布局PDF及依赖环境属于可重现临时材料，未占用交付包。

八、身份与结论限制

会话配置标签是GPT-6 Astra Pro，未取得独立可认证的后台模型/路由ID，不能认证为用户指定的网页GPT 6 Pro。源码、日志和数值可供外部重审；模型自述不是身份认证。

当前裁决支持收窄的候选机制与CPU实现检查，不证明旧分布未见身份的收益，不认定已成立的方法创新，也不产生正式实验授权。
