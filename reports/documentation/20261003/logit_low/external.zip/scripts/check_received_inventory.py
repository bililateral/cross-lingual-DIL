#!/usr/bin/env python3
"""Independently check the received archive and its two declared inventories.

Only supplied review-package bytes are read. No project data or models are used.
"""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--archive", type=Path, required=True)
    ap.add_argument("--root", type=Path, required=True)
    ap.add_argument("--result", type=Path, required=True)
    args = ap.parse_args()
    raw = args.archive.read_bytes()
    expected_sha = "576a07d9b7ec1387fcdc889e848db79808abcfc02655f5c85466fd893419e66e"
    report = {"archive": {"bytes": len(raw), "sha256": digest(raw)}}
    errors = []
    with zipfile.ZipFile(args.archive) as archive:
        names = archive.namelist()
        report["archive"].update(members=len(names), duplicates=len(names)-len(set(names)), crc_bad=archive.testzip())
        if len(raw) != 3573700 or digest(raw) != expected_sha or len(names) != 413:
            errors.append("uploaded archive identity differs")
        extracted_errors = []
        for name in names:
            p = args.root / name
            if not p.is_file() or p.read_bytes() != archive.read(name):
                extracted_errors.append(name)
        report["extracted_vs_archive"] = {"checked": len(names), "mismatches": extracted_errors}
        errors.extend(extracted_errors)
    prefix = "reports/documentation/20261003/logit_low/"
    for filename in ["source_inventory.json", "review_inventory.json"]:
        rows = json.loads((args.root / prefix / filename).read_text())
        bad = []
        for row in rows:
            p = args.root / row["path"]
            if not p.is_file():
                bad.append({"path": row["path"], "reason": "missing"})
                continue
            data = p.read_bytes()
            if len(data) != row["bytes"] or digest(data) != row["sha256"]:
                bad.append({"path": row["path"], "expected": row,
                            "actual": {"bytes": len(data), "sha256": digest(data)}})
        declared = [r["path"] for r in rows]
        inventory_report = {"entries": len(rows), "duplicates": len(declared)-len(set(declared)), "mismatches": bad}
        if filename == "review_inventory.json":
            inventory_report["unlisted_members"] = sorted(set(names)-set(declared))
            inventory_report["listed_but_not_archived"] = sorted(set(declared)-set(names))
            # The manifest cannot include its own hash without a fixed point.
            expected_unlisted = [prefix+filename]
            if inventory_report["unlisted_members"] != expected_unlisted:
                errors.append("review inventory membership mismatch")
        report[filename] = inventory_report
        errors.extend(bad)
    report["ok"] = not errors
    report["errors"] = errors
    args.result.write_text(json.dumps(report, ensure_ascii=False, indent=2)+"\n")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
