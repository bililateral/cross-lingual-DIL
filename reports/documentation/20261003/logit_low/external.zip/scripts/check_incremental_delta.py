#!/usr/bin/env python3
"""Reverse the supplied seven-file diff and bind it to frozen LOGIT0.25 hashes.

This is a package-provenance and static function-identity check, not training.
The input tree is never modified. The recovered preimage is retained for review.
"""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import re


def sha(data):
    return hashlib.sha256(data).hexdigest()


def reverse_section(current, section):
    lines = current.decode("utf-8").splitlines(keepends=True)
    out, cursor, hunk_count = [], 0, 0
    i = 0
    while i < len(section):
        match = re.match(r"@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@", section[i])
        if not match:
            i += 1
            continue
        old_start, old_count, new_start, new_count = [int(v) if v is not None else 1 for v in match.groups()]
        position = new_start - 1
        assert position >= cursor, (position, cursor)
        out.extend(lines[cursor:position])
        cursor = position
        seen_old = seen_new = 0
        i += 1
        while i < len(section) and not section[i].startswith("@@ "):
            row = section[i]
            if row.startswith("\\ No newline"):
                raise AssertionError("Unexpected no-newline marker; do not silently normalize it")
            if not row or row[0] not in " +-":
                raise AssertionError(("Unexpected hunk row", row))
            prefix, text = row[0], row[1:]
            if prefix in " +":
                assert cursor < len(lines) and lines[cursor] == text, (cursor+1, text, lines[cursor] if cursor < len(lines) else None)
                cursor += 1
                seen_new += 1
            if prefix in " -":
                out.append(text)
                seen_old += 1
            i += 1
        assert (seen_old, seen_new) == (old_count, new_count), (seen_old, seen_new, old_count, new_count)
        hunk_count += 1
    out.extend(lines[cursor:])
    return "".join(out).encode("utf-8"), hunk_count


def functions(data):
    text = data.decode("utf-8")
    return {node.name: ast.get_source_segment(text, node) for node in ast.parse(text).body
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=False)
    root = args.root
    patch = (root / "reports/documentation/20261003/logit_low/implementation.diff").read_bytes().decode("utf-8")
    sections = {}
    key = None
    for line in patch.splitlines(keepends=True):
        if line.startswith("diff --git "):
            key = line.split()[3][2:]
            sections[key] = []
        elif key is not None:
            sections[key].append(line)
    old = json.loads((root / "reports/seller_alias_continual/20261003/logit_weight_result/job/execution.json").read_text())
    frozen = {row["path"]: row for row in old["source_files"]}
    current_inventory = json.loads((root / "reports/documentation/20261003/logit_low/source_inventory.json").read_text())
    current = {row["path"]: row for row in current_inventory}
    results = []
    equal_functions = {}
    for name, section in sections.items():
        new_bytes = (root / name).read_bytes()
        previous, hunks = reverse_section(new_bytes, section)
        destination = args.out / "reconstructed_logit025_sources" / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(previous)
        record = {"path": name, "bytes": len(previous), "sha256": sha(previous)}
        assert record == frozen[name], (record, frozen[name])
        results.append({**record, "hunks_reversed": hunks, "matches_frozen_logit025": True})
        if name.endswith(".py"):
            before, after = functions(previous), functions(new_bytes)
            equal_functions[name] = {function: before[function] == after[function] for function in before.keys() & after.keys()}
    unchanged = []
    for name, row in frozen.items():
        if name not in sections:
            assert current[name] == row, name
            unchanged.append(name)
    new_files = sorted(set(current)-set(frozen))
    assert len(results) == 7 and len(unchanged) == 27 and len(new_files) == 3
    assert equal_functions["scripts/step28_er_weight.py"]["update"]
    for name in ["train_stage", "checkpoint", "train", "blind_gate", "collect", "execute"]:
        assert equal_functions["scripts/step28_er_weight_run.py"][name], name
    report = {"scope": "static diff reversal, frozen-byte provenance, and exact function-source identity",
              "previous_source_count": len(frozen), "current_source_count": len(current),
              "changed_sources_recovered": results, "unchanged_sources": unchanged,
              "added_sources": new_files, "function_source_equality": equal_functions,
              "update_function_unchanged": True, "formal_training_executed": False, "ok": True}
    (args.out / "result.json").write_text(json.dumps(report, ensure_ascii=False, indent=2)+"\n")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
