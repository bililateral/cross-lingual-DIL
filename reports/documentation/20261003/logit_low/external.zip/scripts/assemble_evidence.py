#!/usr/bin/env python3
"""Assemble this completed review; no scientific code or remote service is run."""
import argparse
from datetime import datetime, timezone
import hashlib
from html import escape
from pathlib import Path
import re
import shutil
import zipfile
import json


def sha(data):
    return hashlib.sha256(data).hexdigest()


def inline(text):
    text = escape(text)
    text = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", text)
    return re.sub(r"`([^`]+)`", r"<code>\1</code>", text)


def html_report(text):
    lines = text.splitlines()
    blocks, contents = [], []
    i = 0
    while i < len(lines):
        line = lines[i]
        if not line.strip():
            i += 1
            continue
        heading = re.match(r"^(#{1,6}) (.*)$", line)
        if heading:
            level, title = len(heading.group(1)), heading.group(2)
            anchor = "section_"+str(len(blocks))
            if level == 2:
                contents.append((anchor, title))
            blocks.append(f'<h{level} id="{anchor}">{inline(title)}</h{level}>')
            i += 1
        elif line.startswith("|"):
            rows = []
            while i < len(lines) and lines[i].startswith("|"):
                cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                if not all(re.fullmatch(r":?-{3,}:?", c) for c in cells):
                    rows.append(cells)
                i += 1
            head = "".join("<th>"+inline(c)+"</th>" for c in rows[0])
            body = "".join("<tr>"+"".join("<td>"+inline(c)+"</td>" for c in row)+"</tr>" for row in rows[1:])
            blocks.append('<div class="table-wrap"><table><thead><tr>'+head+'</tr></thead><tbody>'+body+'</tbody></table></div>')
        elif line.startswith("    "):
            code = []
            while i < len(lines) and (lines[i].startswith("    ") or not lines[i].strip()):
                code.append(lines[i][4:] if lines[i].startswith("    ") else "")
                i += 1
            blocks.append("<pre><code>"+escape("\n".join(code).rstrip())+"</code></pre>")
        elif re.match(r"^\d+\. ", line):
            items = []
            while i < len(lines) and re.match(r"^\d+\. ", lines[i]):
                items.append("<li>"+inline(re.sub(r"^\d+\. ", "", lines[i]))+"</li>")
                i += 1
            blocks.append("<ol>"+"".join(items)+"</ol>")
        else:
            paragraph = [line]
            i += 1
            while i < len(lines) and lines[i].strip() and not lines[i].startswith(("#", "|", "    ")) and not re.match(r"^\d+\. ", lines[i]):
                paragraph.append(lines[i])
                i += 1
            blocks.append("<p>"+inline("\n".join(paragraph))+"</p>")
    toc = '<nav aria-label="目录"><h2>目录</h2><ol>'+"".join(f'<li><a href="#{a}">{escape(t)}</a></li>' for a,t in contents)+"</ol></nav>"
    css = """body{margin:0;background:#f1f5f9;color:#172b3a;font-family:system-ui,'Noto Sans CJK SC','Microsoft YaHei',sans-serif;font-size:16px;line-height:1.85}main{max-width:1100px;margin:32px auto;padding:44px 54px;background:white;box-shadow:0 4px 28px #10253512;border-top:7px solid #0e7490}h1{font-size:30px;line-height:1.4;margin:0 0 24px}h2{font-size:23px;margin-top:38px;padding-bottom:9px;border-bottom:2px solid #d8e7eb}h3{font-size:19px;margin-top:26px}p{margin:16px 0}strong{color:#104f63}.table-wrap{overflow-x:auto;margin:20px 0}table{width:100%;border-collapse:collapse;font-size:14px;line-height:1.7}th,td{border:1px solid #dbe4e8;padding:9px 12px;vertical-align:top;overflow-wrap:anywhere}th{background:#edf6f8;text-align:left}tr:nth-child(even){background:#fafcfd}pre{padding:18px;background:#f3f6f8;border-left:4px solid #0e7490;white-space:pre-wrap;overflow-wrap:anywhere;font-size:14px}code{font-family:ui-monospace,Consolas,monospace}nav{padding:12px 24px;background:#f6fafb;border:1px solid #d6e5e9;margin-bottom:28px}nav h2{font-size:18px;margin:0;border:0}nav ol{margin:6px 0;columns:2;column-gap:30px}nav li{break-inside:avoid;font-size:14px}a{color:#11697c;text-decoration:none}a:hover{text-decoration:underline}footer{margin-top:44px;font-size:13px;color:#516779;border-top:1px solid #dce6e9;padding-top:18px}@media(max-width:700px){main{margin:0;padding:24px 18px}nav ol{columns:1}h1{font-size:26px}}@media print{body{background:white}main{margin:0;padding:0;box-shadow:none;border-top:0}nav{display:none}h2,h3{break-after:avoid}tr{break-inside:avoid}a{color:inherit}}"""
    return '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>LOGIT0.1 独立科研外审</title><style>'+css+'</style></head><body><main>'+blocks[0]+toc+"\n".join(blocks[1:])+'<footer>完整原始依据与可复核源码见同包 input_snapshot、scripts、evidence 和 agents；本报告不包含 LOGIT0.1 正式效果结果。</footer></main></body></html>\n'


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--review-root", type=Path, required=True)
    ap.add_argument("--input-archive", type=Path, required=True)
    ap.add_argument("--bundle-root", type=Path, required=True)
    ap.add_argument("--zip", type=Path, required=True)
    ap.add_argument("--receipt", type=Path, required=True)
    a = ap.parse_args()
    assert not a.bundle_root.exists() and not a.zip.exists(), "Use a new delivery path"
    text = (a.review_root/"LOGIT01_REVIEW.zh.txt").read_text()
    (a.review_root/"LOGIT01_REVIEW.zh.html").write_text(html_report(text))
    verdict = {"review_date":"2026-10-03", "timezone":"Asia/Shanghai", "stage":"contract_implementation_native_evidence_incremental_review",
               "verdict":"PASS_WITH_EXPLICIT_SCOPE_LIMITS", "scientific_blockers":[], "unresolved_project_reproducibility_defects":[],
               "approved_candidate_scope":{"candidate":"logit_tenth", "history_supervision_weight":0.1, "independent_raw_logit_mse_weight":0.5,
                   "primary_comparator":"tenth", "fixed_other_comparators":["logit_quarter","seq"], "new_updates":1728,"new_metric_count_sets":18,"reused_metric_count_sets":63,"seed":"s0","orders":["ABC","BCA","CAB"]},
               "reviewer_execution":{"dependency_installs":0,"project_server_connections":0,"formal_text_label_model_reads":0,"formal_training_runs":0,"torch_bge_runs":0,
                   "gradient_reference":"NumPy six-parameter fixture executing extracted update control statements",
                   "flow_reference":"Production control functions with 1728 explicit update spy calls; zero optimizer updates",
                   "evaluation_reference":"Production finalize with 18 explicitly non-research ER0.1-rekeyed candidate sets plus 63 frozen reused sets"},
               "submitted_native_evidence":{"contract_tests_recorded":31,"native_updates_recorded":4,"component_gradient_probes":2,"parameter_update_probes":29,"full_gradient_arrays_supplied":False},
               "reviewer_corrections":[{"id":"R1","initial_exit":1,"issue":"ndarray-based target observation also counted handwritten labels","resolved_in":"gradient_reference_v2.py"},
                   {"id":"R2","initial_exit":0,"issue":"simulation head weight_decay initially 0.01 instead of 0","resolved_in":"gradient_reference_v3.py"},
                   {"id":"R3","initial_exit":2,"issue":"exploratory rg used two nonexistent paths","resolved_by":"subsequent correct-path reads"}],
               "model_identity":{"supplied_screenshot":"6 Pro visible","context_reported":"GPT-6 Astra Pro","independent_backend_authentication":False},
               "formal_logit01_results_exist_in_this_review":False}
    (a.review_root/"AUDIT_VERDICT.json").write_text(json.dumps(verdict,ensure_ascii=False,indent=2)+"\n")
    shutil.copytree(a.review_root,a.bundle_root,ignore=shutil.ignore_patterns("__pycache__","*.pyc"))
    (a.bundle_root/"received_input").mkdir()
    shutil.copyfile(a.input_archive,a.bundle_root/"received_input/review.zip")
    with zipfile.ZipFile(a.input_archive) as original:
        for name in original.namelist():
            q=a.bundle_root/"input_snapshot"/name
            q.parent.mkdir(parents=True,exist_ok=True)
            q.write_bytes(original.read(name))
    paths=sorted(q for q in a.bundle_root.rglob("*") if q.is_file())
    listing="完整路径索引；MANIFEST.json 另存各载荷大小/SHA。FILE_LIST.txt 的大小见 MANIFEST.json；MANIFEST.json 不自哈希。\n\n"+"\n".join(sorted([f"{q.relative_to(a.bundle_root).as_posix()}\t{q.stat().st_size} bytes" for q in paths]+["FILE_LIST.txt\t本索引；大小和SHA见MANIFEST.json", "MANIFEST.json\t完整载荷清单；不自哈希"]))+"\n"
    (a.bundle_root/"FILE_LIST.txt").write_text(listing)
    rows=[]
    for q in sorted(p for p in a.bundle_root.rglob("*") if p.is_file()):
        raw=q.read_bytes();rows.append({"path":q.relative_to(a.bundle_root).as_posix(),"bytes":len(raw),"sha256":sha(raw)})
    (a.bundle_root/"MANIFEST.json").write_text(json.dumps({"schema_version":1,"scope":"All bundle payload files except this manifest itself","files":rows},ensure_ascii=False,indent=2)+"\n")
    a.zip.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(a.zip,"w",zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for q in sorted(p for p in a.bundle_root.rglob("*") if p.is_file()):
            archive.write(q,q.relative_to(a.bundle_root).as_posix())
    with zipfile.ZipFile(a.zip) as archive:
        assert archive.testzip() is None
        manifest=json.loads(archive.read("MANIFEST.json"))
        expected={r["path"] for r in manifest["files"]}|{"MANIFEST.json"}
        assert set(archive.namelist())==expected
        assert len(archive.namelist())==len(expected)
        for row in manifest["files"]:
            raw=archive.read(row["path"])
            assert len(raw)==row["bytes"] and sha(raw)==row["sha256"],row["path"]
        with zipfile.ZipFile(a.input_archive) as original:
            for name in original.namelist():
                assert archive.read("input_snapshot/"+name)==original.read(name)
        assert archive.read("received_input/review.zip")==a.input_archive.read_bytes()
        members=len(archive.namelist())
    raw=a.zip.read_bytes()
    receipt={"completed_utc":datetime.now(timezone.utc).isoformat(),"zip_path":str(a.zip),"bytes":len(raw),"sha256":sha(raw),
             "members":members,"manifest_payloads":len(rows),"zip_crc_ok":True,"manifest_all_payloads_match":True,
             "input_snapshot_members":413,"input_snapshot_matches_received_zip":True,"original_zip_preserved_exactly":True,
             "review_html":str(a.bundle_root/"LOGIT01_REVIEW.zh.html"),"scientific_code_executed_by_packager":False}
    a.receipt.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+"\n")
    print(json.dumps(receipt,ensure_ascii=False,indent=2))


if __name__=="__main__":
    main()
