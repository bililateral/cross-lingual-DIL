LOGIT0.1 独立科研外审证据包
============================

先读 LOGIT01_REVIEW.zh.html（排版版）或 LOGIT01_REVIEW.zh.txt（同内容文本版）。
最终结论：本轮合同、实现及 Linux 增量证据外审通过；未确认项目级 SCIENTIFIC_BLOCKER 或未关闭的 REPRODUCIBILITY_DEFECT。没有认证 LOGIT0.1 正式效果。

目录：

  received_input/review.zip     收到的原 ZIP，完整保留用户给出的大小和 SHA。
  input_snapshot/              原 ZIP 全部 413 个载荷，逐字节一致。
  scripts/                    本次主审的独立清单/增量逆向核查与交付组装源码。
  evidence/                   原附件身份、逐成员列表、实际命令、stdout/stderr/退出码、逆向恢复的旧源码。
  agents/gradient/            最终 v3 NumPy/AST 梯度参考、手写输入、故意错误变体、v1/v2 及全部修订。
  agents/flow/                生产控制流/内存/访问账本参考，1728 次明确 spy 调用；真实优化器更新 0。
  agents/native/              Linux 原证据的标准库独立复算；没有重跑原生 BGE。
  agents/reference/           生产 finalize 实际运行与独立统计，18 夹具＋63 冻结复用。
  AUDIT_VERDICT.json          机器可读结论与边界。
  FILE_LIST.txt               可读载荷索引。
  MANIFEST.json               全部载荷的字节数和 SHA-256，清单不自哈希。

必须注意：

  1. SYNTHETIC_NOT_LOGIT01_RESULTS 下的数据是 ER0.1 复制到候选槽位的接入夹具，不是 LOGIT0.1 正式结果。
  2. gradient/results03 是六参数 NumPy 夹具；没有生产 Torch/BGE/AdamW 执行。
  3. flow 的 1728 次是显式 spy 调用，不是训练；其占位日志不能作为梯度证据。
  4. 原项目的 31 项测试和 4 次 BGE 手写更新属于 input_snapshot 中被审的 Linux 原记录。
  5. 本次没有安装科研依赖、连接项目 Linux、读取正式文本/标签/模型或启动正式训练。
  6. 所有失败版本和原始 stderr 保留。原生 FutureWarning 保留。核心程序的绝对路径命令均是当时实际记录。

可以直接阅读各 command.json 与原输出；报告第 12 节列出使用当前目录相对路径的复核入口。
重新运行时请使用新输出目录，以保留本包中的原始证据。无需为了本次审查替审查者补运行；本轮必要运行已完成。

任何根清单与子清单的范围差异，以根 MANIFEST.json 为准。子清单按其生成时点保留，不为交付追改旧记录。
