# LOGIT0.1 增量外审：损失、真实梯度接入和目标生命周期

本分项先完整阅读本轮 `reports/documentation/20261003/logit_low/request.zh.md`、`docs/SELLER_ALIAS_LOGIT_LOW.zh.md`，并完整读取直接历史 `reports/documentation/20261002/logit_weight/review/external/REVIEW.zh.md` 的 513 行。以下项目路径相对于收到的源码根目录；自有证据相对于本目录。输入文件没有修改。

## 1. 分项裁决

**在本分项实际覆盖范围内，未发现 LOGIT0.1 损失/梯度接入、一次联合更新或历史目标生命周期的 SCIENTIFIC_BLOCKER，也未确认需要修改项目源码的 REPRODUCIBILITY_DEFECT。** 0.1 作用于完整历史监督，0.5 原始 logit MSE 在其外独立加权，并实际进入历史 backward；不只是日志字段变成了 0.1/0.5。

该判断有四层依据：生产源码因果链；历史已完成的 PyTorch 独立数值/微型续训证据；本轮提交方原生 BGE 两臂组件梯度证据的源码和原输出；本轮审查者实际执行的 NumPy 独立参考和错误注入。四层证据的能力不同，不能合并写成“本轮审查者实际重跑了 BGE/PyTorch”。

主审已独立逆向应用本轮七文件 diff，恢复旧文件逐份大小/SHA 与 LOGIT0.25 execution.source_files 相符；`update`、`native`、`train_stage`、`checkpoint`、`train`、`blind_gate`、`collect`、`execute` 函数文本均未改变。可引用主审证据 `evidence/delta_attempt01/result.json`。本分项不重复该核验，也不以“不变”代替对实际操作的审读。

## 2. 精确目标及梯度路径

本轮展开目标为：

```text
L = BCE_current + Rank_current + 0.5 Hard_current
  + 0.1 BCE_history + 0.1 Rank_history + 0.05 Hard_history
  + 0.5 mean_378((raw_history_logit - saved_eval_target)^2)
```

历史 Hard 的有效系数是 0.05，MSE 的有效系数是 0.5。没有除以 1.1，没有把 MSE 再乘 0.1，也没有只缩放历史 BCE。

|计算环节|实际源码位置|判断|
|---|---|---|
|完整 BCE/Rank|`scripts/step28_chinese_base.py:165–191`|378 个无向配对平均 BCE；28 个查询分别对 27 候选做 logsumexp 减正例 logit 均值，再按查询平均。标签完整关系结构检查保留。|
|已知 top5 负例 Hard|`scripts/step28_alias_ranking.py:89–129`|仅选择已知负例；按 detach 分数确定索引，被选中的 live 分数参与 softplus 差的梯度；完整 total 是 BCE+Rank+0.5Hard。|
|系数和 target 前置校验|`scripts/step28_er_weight.py:219–228`|0.1 是允许值；reference 必须为长度 378 的有限 float32 NumPy 数组，presence 与独立 0.5 相匹配。|
|实际当前/历史前向|同文件 `:237–242`|当前与历史分别设配对 seed，各调用一次 `base.logits`，返回值实际用于完整监督。|
|完整历史监督乘 0.1|同文件 `:243–244`|历史 objective 为 `coefficient * terms["total"]`；后面的反向使用这个 objective。|
|独立 MSE 进入历史图|同文件 `:245–250`|同一个历史 predicted 减保存 target，square 后 mean，独立乘 logit_weight 加到 objective，再执行 backward；无额外一次历史群 forward。|
|target 无梯度|同文件 `:246`；`scripts/step28_bge_continual.py:150–169`|由 NumPy 缓存新建 tensor，未启用 requires_grad；缓存保存和 draw 都 copy，目标不是活的教师参数图。|
|一次累加/裁剪/更新|`scripts/step28_er_weight.py:232–233,250,264–269`|只在开始清梯度；当前 backward 和历史组合 backward 累加；循环后一次全局 clip、一次 optimizer.step，并核对 Adam 只前进一步。|
|正式参数实际传递|`scripts/step28_er_weight_run.py:59–69`|memory.draw 返回的真实 target，policy 的 arms[arm]=0.1 和 loss.logit_mse=0.5 都传入实际 update；不是只给 checkpoint 或日志。|
|真实优化器构造|`scripts/step28_continual_population.py:32–40`|使用 PyTorch AdamW，两参数组；encoder decay=0.01、head decay=0（policy）；本轮不改变。|

“两次 forward”针对群级 `base.logits` 接口；不声称 BGE 内部没有微批计算或 activation checkpoint 重算。

## 3. 保存目标的生命周期

共同首域原始代码在 `scripts/step28_bge_continual_run.py:426–438` 先完成共享模型/Adam/RNG/首映射，再在同一共享模型状态生成 LOGIT 首域缓存。新分支 `scripts/step28_er_weight_run.py:219–245` 从原 shared 完整状态和原 `logit_after1` 缓存恢复，并回放全部 60 群首域盲分数，随后恢复 RNG；没有从 ER0.1 或 LOGIT0.25 第二/第三域端点续训。

第二域末 `scripts/step28_er_weight_run.py:249–277` 完成当前分支训练和 checkpoint 后才执行本分支 `reference_score`。`scripts/step28_bge_continual.py:130–154` 先完成 reservoir 保留，只对最后留下且不在此前 targets 集合中的新增群 score；存活旧目标直接保留，淘汰群目标删除；新目标记 origin=2。draw 返回目标副本。`scripts/step28_chinese_base.py:223–229` 的 score 实际调用 eval 和 inference_mode，因此是阶段末 eval 的 raw logit，不经过 stage-cal 或 first-cal。

当前源码及已审历史的微型真实恢复证据支持此生命周期。**本轮审查者没有读取或重算原生首域正式模型、正式缓存向量或未来 LOGIT0.1 正式第二域目标。** 此处未验证范围由用户明确限制，不应被转换成要求提前访问私有资产或扩大实验的阻断。

student 使用 train dropout，target 来源为 eval。因此 MSE 包含输出均值偏离及 dropout 方差作用；不能解释为纯确定性函数保持。合同已明确承认这一点。

## 4. 本轮提交方 Linux 原生证据：实际能支持什么

已读取 `reports/seller_alias_continual/20261003/logit_low_execution/20261003_150000/cpu/` 下原 stdout、stderr、audit、tenth、logit_tenth。stdout 对两臂分别记录 native_start/native_end；stderr 为 31 个 unittest 的逐项 ok、`Ran 31 tests in 32.110s`、`OK`，并含两次同源 `get_sentence_embedding_dimension` FutureWarning。warning 不应隐去，也不应误称运行失败。

真正的梯度证据在 `scripts/step28_er_weight_check.py:48–79,178–194`：

1. LOGIT 臂用同一预热后模型对手写旧群 eval 打分，保存为 target；重置历史 train seed=108，单独对 **0.5 MSE** 调用 `torch.autograd.grad`，取得 encoder 第一层 query.weight 与 head 隐藏层 weight 两个组件的期望梯度。
2. 对实际 `method.update` 注册两个参数的 gradient hook；current/history 各 backward 一次，所以每个探针有两个贡献，而非只观察最后总梯度。
3. 两臂初始模型、预热后模型、Adam 状态、current/history logits 必须配对；当前梯度逐元素完全相等；历史梯度逐元素核对 `g_LOGIT_history = g_ER0.1_history + g_0.5MSE`。

|原生组件探针|ER0.1 历史梯度范数|独立 0.5 MSE 梯度范数|LOGIT0.1 历史组合范数|保存的最大等式残差|
|---|---:|---:|---:|---:|
|encoder 第一层 query.weight|0.0005840433295816183|0.00008615575643489137|0.0005063213175162673|1.000444171950221e-11|
|head 隐藏层 weight|0.008052303455770016|0.001860779826529324|0.006408629938960075|2.764863893389702e-10|

这些范数自身不是梯度分解证明；有意义的是其前述实际 hook/autograd 路径和逐元素比较。也不能从组合范数下降推导遗忘改善或实验效果。

原生更新观察共 29 个参数探针：24 层 query.weight、词嵌入 weight、head 两个 Linear 的 weight/bias。它们报告梯度有限非零且参数改变。未用 pooler 的两个参数允许 grad=None。**逐层参数变动观察不等于对所有参数分别验证了 MSE 梯度分解；分解只覆盖上述两个组件。**

原生实际优化器更新是两臂各一次 warm 加一次 weighted，共四次。每臂 warm 之后把 Adam counter 从 1 显式改为 288 是计数夹具；没有原生连续 288 次预热的证据。31 个测试里另有 tiny 模型的 288 步日志，不应与四次 BGE 原生更新混同。

提交的小证据只保存组件梯度范数、摘要与最大残差，没有保存完整梯度数组，因此本轮无法仅从原包独立复算原生逐元素残差。用户已允许复用既有证据，本分项将此列为证据边界，不要求新增巨量梯度或再次读取模型。

## 5. 审查者实际运行的增量独立参考

本网页当前环境 NumPy=2.3.5，`find_spec("torch")` 返回不存在；没有安装依赖。实际程序为 `gradient_reference_v3.py`，结果见 `results03/result.json`。运行的真实 argv、开始/结束 UTC、完整 stdout、stderr、exit code 在 `run03/`；退出 0。

### 5.1 运行方式与证据能力

程序 AST 提取提交的 `update` 函数，只删除局部 `import torch`，其余控制语句执行。依赖明确替换为一个六参数 affine-logit 手写夹具和仅支持该函数所需运算的 NumPy 一阶值；没有注册或安装假 torch 模块。原始提取结果与四个错误变体源码均保留。

完整基础损失通过手写边遍历计算，另写解析 logit 导数作为夹具导数；期望参数梯度再走 **直接标量完整目标的中央有限差分**，避免用被测系数组合生成期望答案。当前/历史两个 affine design、bias、六参数、378 targets 以及纯手写关系标签完整保存为 `handwritten_fixture.npz`。

**这实际运行了生产 update 的系数组合、调用顺序和反向入口控制；生产 `base.logits`、生产 `ranking.objectives`、PyTorch autograd、真实 AdamW 和 BGE 均未运行。** 对这些未变底层数值链，复用历史 LOGIT0.25 外审第 4 节真实 PyTorch VJP/手算 AdamW 证据，再结合本轮提交方原生证据。不能把本轮 NumPy 模拟参数误差写成“生产 AdamW 误差”。

### 5.2 三个关键场景

|场景|提取函数记录总目标|独立标量总目标|最大裁剪前梯度误差|裁剪因子|模拟 AdamW 参数最大误差|
|---|---:|---:|---:|---:|---:|
|不触发裁剪、阶段第 1 步|5.279426343984742|5.279426343984742|1.4089385214077765e-10|1|2.4327762027098743e-13|
|主动裁剪、阶段第 1 步|5.279426343984742|5.279426343984742|1.4089385214077765e-10|0.024164886300415172|2.914335439641036e-15|
|阶段第 288 步|5.279426343984742|5.279426343984742|1.4089385214077765e-10|1|3.212985433265203e-13|

每个场景实际观察的调用序列均为 train→zero_grad→current forward→backward→history forward→backward→clip→optimizer_step；两个 seed 依次为 107/108，target 为常量。末步 encoder LR=0、head LR=0.001、计数到 576。计数及 Adam moments 是明确夹具，不是执行了 575 次此前更新。

### 5.3 专门检出“日志正确、梯度错误”

在提取函数的副本中修改实际 objective、完全保留日志公式。四个变体的日志 total 都仍是正确的 5.279426343984742，但独立梯度参考实际全部拒绝：

|手写错误注入|相对正确完整梯度最大误差|
|---|---:|
|MSE 只写日志，不进入 objective|0.0657321043201084|
|MSE 再误乘历史 0.1|0.059158893891112396|
|历史仅使用 BCE，漏 Rank/Hard|0.02051590240131851|
|历史实际用 0.25，日志继续写 0.1|0.033700483183394137|

这四个错误的差异远大于真实路径有限差分误差，直接回答用户要求的伪实现风险。它们是本审查的预期错误注入，不是项目出现四个缺陷。

### 5.4 原生手写分数独立复算

程序另读取已开放的两臂 378 current/history logits，使用纯手写 4 个三节点团、8 个二节点团构造其手写标签，逐边独立复算基础目标和 MSE。没有读取正式 labels 或 owners 文件。

|量|独立复算|
|---|---:|
|current BCE/Rank/Hard/total|0.6633192276984118 / 3.2916884789974716 / 0.6929290613008465 / 4.301472237346307|
|history BCE/Rank/Hard/total|0.66336845059292 / 3.292110873997936 / 0.6933351772194258 / 4.302146913200569|
|LOGIT 原始 MSE|0.0001965899888976513|
|ER0.1 总目标|4.731686928666363|
|LOGIT0.1 总目标|4.731785223660812|
|ER0.1 总目标与原记录差|5.046201767555658e-08|
|LOGIT0.1 总目标与原记录差|5.045596829234e-08|

两臂 current/history logits 和前三个状态摘要均相同。原生梯度数组缺席，所以这里复算的是实际保存 logits 对应的标量目标，不冒称用 NumPy 重现了原生 BGE 梯度。

## 6. 所有失败和修订

|版本/记录|实际退出码|说明|
|---|---:|---|
|`gradient_reference_v1.py` / `run01`|1|审查者 target 观测夹具用 ndarray 类型识别目标，而两份手写标签也是 ndarray，误计为三个 target；实际失败源、原 stderr 和输入均保留。|
|`gradient_reference_v2.py` / `run02`|0|仅改为 `value is target` 身份观测；损失/梯度和生产 update 未变。|
|`gradient_reference_v3.py` / `run03`|0|后续交叉读取生产 optimizer 发现 v2 模拟两组均 decay=0.01。v3 将模拟组 decay 匹配为 encoder=0.01/head=0，同时更正手算对应值。v2 成功证据保留；此修订不影响梯度/调用结论。|

细节见 `revision_01.zh.md`、`revision_02.zh.md`。上述属于审查者夹具的问题和校对，项目源码没有修改。每个命令独立保存原始流；没有把 v1 静态或失败状态写成成功。

复跑最终参考：

```bash
python gradient_reference_v3.py --source /path/to/input_snapshot --out /path/to/new_results
```

只需要现有 Python/NumPy；输出目录必须新建，防止覆盖已有失败证据。对应本次真实绝对路径命令不作改写，完整见 `run03/command.json`。

## 7. 分类与最小处置

|类别|本分项结论|处置|
|---|---|---|
|SCIENTIFIC_BLOCKER|未发现已确认的项目级问题|本分项不要求改生产源码，不新增候选或成功线。|
|REPRODUCIBILITY_DEFECT（被审项目）|本分项未确认尚待修复缺陷|依照总外审对入口/对照/评价的综合结论处理。|
|审查者参考修订|v1 target 计数错误已修；v2 模拟 head decay 校对已修|保留原版、失败/成功流和修订；最终采用 v3。|
|未验证范围|本轮审查者未运行 PyTorch/BGE/CUDA/BF16；未重算原生全梯度；未访问正式数据/权重；LOGIT0.1 无正式结果|如实限制结论，保留既定正式执行/结果外审流程；不因禁止范围未执行而追加阻断。|
|OUT_OF_SCOPE_OVERDESIGN|新增泛化恢复系统、完整全参数梯度归档框架、更多候选/种子、事后改成功线|不要求、不实现；不能以此推迟已授权单点。|

原生四次手写更新可支持“系数和 MSE 接入在当前 native 路径的必要核验已完成”；无法证明未来 1728 次正式训练、六端点、18 新结果有效或 LOGIT0.1 效果优于任一对照。正式效果只能在对应结果产生并经过独立结果审查后判断。
