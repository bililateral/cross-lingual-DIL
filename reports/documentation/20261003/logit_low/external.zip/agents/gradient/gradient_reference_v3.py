"""Independent LOGIT0.1 incremental reference; NumPy only, no Torch/BGE execution.

Usage: python gradient_reference_v3.py --source /path/to/input_snapshot --out new_dir

Executes the submitted update function's unchanged control statements using a
six-parameter affine-logit fixture and explicit first-order values. The sole AST
adaptation removes its local `import torch`; dependencies are named fixture
objects, never installed or registered as a fake torch module. Production base
forward, production ranking objectives, PyTorch autograd/AdamW and BGE are NOT run.
Expected parameter gradients come from scalar-objective central differences.
Separately re-evaluates the submitted Linux handwritten native scores in NumPy.
"""
from __future__ import annotations

import argparse
import ast
import copy
import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
from types import SimpleNamespace

import numpy as np

PAIRS = list(itertools.combinations(range(28), 2))
# Handwritten clique structure. This is not a read of any formal owners/labels.
COMPONENTS = np.repeat(np.arange(12), [3] * 4 + [2] * 8)
Y = np.array([COMPONENTS[i] == COMPONENTS[j] for i, j in PAIRS], dtype=float)
QUERIES = []
for q in range(28):
    incidence = [(e, j if q == i else i) for e, (i, j) in enumerate(PAIRS) if q in (i, j)]
    QUERIES.append(incidence)


def scalar_loss(z: np.ndarray) -> dict:
    """Direct edge enumeration; independent of production objective functions."""
    bce = sum(np.logaddexp(0.0, v) - y * v for v, y in zip(z, Y)) / len(z)
    rank_terms, hard_terms = [], []
    for incidence in QUERIES:
        ix = np.array([e for e, _ in incidence])
        pos = ix[Y[ix] == 1]
        neg = sorted((row for row in incidence if Y[row[0]] == 0),
                     key=lambda row: (-z[row[0]], row[1]))[:5]
        rank_terms.append(np.logaddexp.reduce(z[ix]) - np.mean(z[pos]))
        hard_terms.append(sum(np.logaddexp(0.0, z[e] - z[p])
                              for e, _ in neg for p in pos) / (5 * len(pos)))
    rank, hard = float(np.mean(rank_terms)), float(np.mean(hard_terms))
    return dict(bce=float(bce), rank=rank, hard=hard, total=float(bce + rank + .5 * hard))


def analytic_loss_derivatives(z: np.ndarray) -> dict:
    """Derivative route for the fixture; oracle uses scalar central differences."""
    db = (1 / (1 + np.exp(-z)) - Y) / 378
    dr, dh = np.zeros(378), np.zeros(378)
    for incidence in QUERIES:
        ix = np.array([e for e, _ in incidence]); pos = ix[Y[ix] == 1]
        logits = z[ix] - max(z[ix]); probs = np.exp(logits); probs /= probs.sum()
        dr[ix] += probs / 28; dr[pos] -= 1 / (28 * len(pos))
        neg = sorted((row for row in incidence if Y[row[0]] == 0),
                     key=lambda row: (-z[row[0]], row[1]))[:5]
        for e, _ in neg:
            for p in pos:
                d = 1 / (1 + np.exp(-(z[e] - z[p]))) / (28 * 5 * len(pos))
                dh[e] += d; dh[p] -= d
    return dict(bce=db, rank=dr, hard=dh, total=db + dr + .5 * dh)


class FirstOrder:
    """Only operations needed by this single update; not a general tensor engine."""
    def __init__(self, value, derivative=None, model=None):
        self.value = np.asarray(value, dtype=float)
        self.derivative = (np.zeros(self.value.shape + (6,)) if derivative is None
                           else np.asarray(derivative, dtype=float))
        self.model = model
        self.device = "handwritten_numpy_cpu"
        self.dtype = np.float64
        self.requires_grad = bool(np.any(self.derivative))

    def _other(self, other):
        return other if isinstance(other, FirstOrder) else FirstOrder(other)

    def __add__(self, other):
        other = self._other(other)
        return FirstOrder(self.value + other.value, self.derivative + other.derivative,
                          self.model or other.model)

    __radd__ = __add__

    def __sub__(self, other):
        return self + (-1) * self._other(other)

    def __mul__(self, other):
        other = self._other(other)
        return FirstOrder(self.value * other.value,
                          self.derivative * other.value[..., None] +
                          other.derivative * self.value[..., None], self.model or other.model)

    __rmul__ = __mul__

    def square(self):
        return self * self

    def mean(self):
        return FirstOrder(self.value.mean(), self.derivative.reshape(-1, 6).mean(0), self.model)

    def detach(self):
        return self.value.copy()

    def backward(self):
        assert self.value.shape == () and self.model is not None
        self.model.gradient += self.derivative
        self.model.contributions.append(self.derivative.copy())
        self.model.events.append("backward")


class FixtureModel:
    def __init__(self, theta):
        self.theta = theta.copy(); self.gradient = np.zeros(6)
        self.events, self.forward_names, self.seeds, self.contributions = [], [], [], []

    def train(self):
        self.events.append("train")

    def parameters(self):
        return iter([self])


class FixtureOptimizer:
    """Simulated NumPy AdamW; production optimizer is NOT executed."""
    def __init__(self, model, step):
        self.model, self.counter = model, 288 + step - 1
        self.param_groups = [{"lr": 0.}, {"lr": 0.}]
        self.m = np.linspace(-.002, .003, 6)
        self.v = np.linspace(.0001, .0006, 6)

    def zero_grad(self, set_to_none):
        assert set_to_none
        self.model.events.append("zero_grad"); self.model.gradient[:] = 0

    def step(self):
        self.model.events.append("optimizer_step"); self.counter += 1
        g = self.model.gradient
        self.m = .9 * self.m + .1 * g
        self.v = .999 * self.v + .001 * g * g
        lr = np.repeat([p["lr"] for p in self.param_groups], 3)
        decay = np.repeat([.01, 0.], 3)
        self.model.theta *= 1 - lr * decay
        self.model.theta -= lr * (self.m / (1 - .9 ** self.counter)) / (
            np.sqrt(self.v / (1 - .999 ** self.counter)) + 1e-8)


def extract_update(source: Path, mutation: str | None = None):
    path = source / "scripts/step28_er_weight.py"
    parsed = ast.parse(path.read_text())
    node = copy.deepcopy(next(n for n in parsed.body if isinstance(n, ast.FunctionDef) and n.name == "update"))
    removed = [n for n in node.body if isinstance(n, ast.Import) and [a.name for a in n.names] == ["torch"]]
    assert len(removed) == 1
    node.body = [n for n in node.body if n not in removed]
    if mutation:
        class Mutate(ast.NodeTransformer):
            count = 0
            def visit_Assign(self, item):
                text = ast.unparse(item)
                if text == "objective = objective + logit_weight * penalty" and mutation in ("omit_mse", "mse_times_history_weight"):
                    self.count += 1
                    statement = ("objective = objective" if mutation == "omit_mse" else
                                 "objective = objective + coefficient * logit_weight * penalty")
                    return ast.parse(statement).body[0]
                if (text == "objective = terms['total'] if role == 'current' else coefficient * terms['total']"
                        and mutation in ("history_bce_only", "history_quarter_logs_tenth")):
                    self.count += 1
                    statement = ("objective = terms['total'] if role == 'current' else coefficient * terms['bce']"
                                 if mutation == "history_bce_only" else
                                 "objective = terms['total'] if role == 'current' else 0.25 * terms['total']")
                    return ast.parse(statement).body[0]
                return self.generic_visit(item)
        mutator = Mutate(); node = mutator.visit(node); assert mutator.count == 1
    future = ast.ImportFrom(module="__future__", names=[ast.alias(name="annotations")], level=0)
    module = ast.fix_missing_locations(ast.Module(body=[future, node], type_ignores=[]))
    return module, ast.unparse(module)


def fixture_run(source, theta, designs, target, clip, step, mutation=None):
    model = FixtureModel(theta); optimizer = FixtureOptimizer(model, step)
    targets = []
    def tensor(value, dtype, device):
        obj = FirstOrder(np.array(value, copy=True))
        if value is target: targets.append(obj)
        return obj
    def logits(actual_model, group, config, arm, check):
        assert actual_model is model and arm == "split_rank"
        model.events.append("forward_" + group.uid); model.forward_names.append(group.uid)
        a, bias = designs[group.uid]
        return FirstOrder(a @ model.theta + bias, a, model)
    def objectives(predicted, truth, hard_weight):
        assert hard_weight == .5 and np.array_equal(truth.value, Y)
        values = scalar_loss(predicted.value); grads = analytic_loss_derivatives(predicted.value)
        return {k: FirstOrder(values[k], grads[k] @ predicted.derivative, model) for k in values}
    def clip_grad_norm_(parameters, maximum, error_if_nonfinite):
        assert list(parameters) == [model] and error_if_nonfinite
        model.events.append("clip"); model.before_clip = model.gradient.copy()
        norm = np.linalg.norm(model.gradient); assert np.isfinite(norm)
        model.gradient *= min(1., maximum / (norm + 1e-6))
        return norm
    def manual_seed(seed): model.seeds.append(seed)
    def stage_lr(s): return 1e-5 * (s / 29 if s <= 29 else (288-s) / (288-29))
    ns = dict(np=np, STEP_COLUMNS=("current_bce", "current_rank", "current_hard", "current_total",
               "history_bce", "history_rank", "history_hard", "history_total", "weighted_history_total",
               "total", "encoder_lr", "head_lr", "gradient_norm", "history_weight"),
              base=SimpleNamespace(logits=logits),
              parent=SimpleNamespace(adam_step=lambda o: o.counter, stage_lr=stage_lr,
                                     ranking=SimpleNamespace(objectives=objectives)),
              torch=SimpleNamespace(manual_seed=manual_seed, tensor=tensor, float32=np.float32,
                                     nn=SimpleNamespace(utils=SimpleNamespace(clip_grad_norm_=clip_grad_norm_))))
    module, exported = extract_update(source, mutation); exec(compile(module, "submitted_update_AST", "exec"), ns)
    current = SimpleNamespace(uid="current", labels=Y); history = SimpleNamespace(uid="history", labels=Y)
    info = ns["update"](model, optimizer, current, history, {"optimizer": {"clip_norm": clip}},
                       .1, 2, step, 107, 108, reference=target, logit_weight=.5, observe=False)
    assert model.events == ["train", "zero_grad", "forward_current", "backward", "forward_history", "backward", "clip", "optimizer_step"]
    assert model.seeds == [107, 108] and len(targets) == 1 and not targets[0].requires_grad
    return info, model, optimizer, exported


def finite_gradient(fn, theta):
    result = []
    for j in range(len(theta)):
        plus, minus = theta.copy(), theta.copy(); plus[j] += 1e-5; minus[j] -= 1e-5
        result.append((fn(plus) - fn(minus)) / 2e-5)
    return np.asarray(result)


def run(source, out):
    out.mkdir(parents=True, exist_ok=False)
    assert Y.sum() == 20
    theta = np.array([.21, -.14, .63, -.28, .37, .18])
    rng = np.random.default_rng(471392)
    designs = {name: (rng.normal(0, .35, (378, 6)), rng.normal(0, .25, 378)) for name in ("current", "history")}
    target = np.linspace(-1.4, 1.6, 378, dtype=np.float32)
    np.savez(out / "handwritten_fixture.npz", theta=theta, labels=Y, target=target,
             current_design=designs["current"][0], current_bias=designs["current"][1],
             history_design=designs["history"][0], history_bias=designs["history"][1])
    def base_part(name, t):
        a, b = designs[name]; return scalar_loss(a @ t + b)["total"]
    def mse_part(t):
        a, b = designs["history"]; return float(np.mean((a @ t + b - target) ** 2))
    fc = lambda t: base_part("current", t)
    fh = lambda t: .1 * base_part("history", t)
    fm = lambda t: .5 * mse_part(t)
    total = lambda t: fc(t) + fh(t) + fm(t)
    independent = finite_gradient(total, theta)
    separate = [finite_gradient(fn, theta) for fn in (fc, fh, fm)]
    rows = []
    for clip, step in ((1e6, 1), (.01, 1), (1e6, 288)):
        info, model, opt, extracted = fixture_run(source, theta, designs, target, clip, step)
        err = float(np.max(abs(model.before_clip - independent)))
        assert err < 1e-8, err
        assert abs(info["total"] - total(theta)) < 1e-12
        assert np.max(abs(model.contributions[0] - separate[0])) < 1e-8
        assert np.max(abs(model.contributions[1] - separate[1] - separate[2])) < 1e-8
        norm = np.linalg.norm(independent); factor = min(1., clip / (norm + 1e-6)); clipped = factor * independent
        expected_parameters = theta.copy()
        initial_m = np.linspace(-.002, .003, 6); initial_v = np.linspace(.0001, .0006, 6)
        # Scalar route independently checks fixture update order; not a Torch claim.
        for j in range(6):
            lr = info["encoder_lr"] if j < 3 else info["head_lr"]
            m = .9 * initial_m[j] + .1 * clipped[j]; v = .999 * initial_v[j] + .001 * clipped[j] ** 2
            correction = (m / (1 - .9 ** (288 + step))) / (np.sqrt(v / (1 - .999 ** (288 + step))) + 1e-8)
            decay = .01 if j < 3 else 0.
            expected_parameters[j] = theta[j] * (1 - decay * lr) - lr * correction
        parameter_error = float(np.max(abs(model.theta - expected_parameters)))
        assert parameter_error < 1e-10
        rows.append(dict(clip=clip, step=step, adam_counter=opt.counter, total=info["total"],
                         independent_total=total(theta), max_preclip_gradient_error=err,
                         clip_factor=factor, max_simulated_parameter_error=parameter_error,
                         actual_events=model.events, actual_seeds=model.seeds,
                         target_is_constant=True, current_gradient=model.contributions[0].tolist(),
                         history_gradient=model.contributions[1].tolist(),
                         production_log=info))
    (out / "submitted_update_extracted.py").write_text(extracted + "\n")
    mutations = []
    for mutation in ("omit_mse", "mse_times_history_weight", "history_bce_only", "history_quarter_logs_tenth"):
        info, model, opt, mutated = fixture_run(source, theta, designs, target, 1e6, 1, mutation)
        (out / (mutation + ".py")).write_text(mutated + "\n")
        err = float(np.max(abs(model.before_clip - independent)))
        assert err > 1e-4
        # All mutant logs still satisfy the published equation. A log-only audit cannot distinguish them.
        assert abs(info["total"] - total(theta)) < 1e-12
        mutations.append(dict(mutation=mutation, gradient_error=err, rejected_by_gradient_oracle=True,
                              correct_logged_total=info["total"], actual_gradient=model.before_clip.tolist()))
    native_root = source / "reports/seller_alias_continual/20261003/logit_low_execution/20261003_150000/cpu"
    native = {}
    for arm in ("tenth", "logit_tenth"):
        payload = json.loads((native_root / (arm + ".json")).read_text())
        computed = {role: scalar_loss(np.asarray(payload["captured_" + role + "_logits"])) for role in ("current", "history")}
        differences = {role + "_" + k: computed[role][k] - payload["weighted_update"][role + "_" + k]
                       for role in computed for k in computed[role]}
        mse = (float(np.mean((np.asarray(payload["captured_history_logits"]) -
                              np.asarray(payload["origin_eval_reference"])) ** 2)) if arm == "logit_tenth" else 0.)
        expected = computed["current"]["total"] + .1 * computed["history"]["total"] + .5 * mse
        error = expected - payload["weighted_update"]["total"]
        assert max(abs(v) for v in differences.values()) < 4e-6 and abs(error) < 6e-6
        if arm == "logit_tenth":
            assert abs(mse - payload["weighted_update"]["logit_mse"]) < 1e-6
        native[arm] = dict(independent_losses=computed, scalar_differences=differences,
                           independent_mse=mse, independent_total=expected,
                           logged_total=payload["weighted_update"]["total"], total_error=error)
    a = json.loads((native_root / "tenth.json").read_text()); b = json.loads((native_root / "logit_tenth.json").read_text())
    paired_fields = ["initial_model_state_sha256", "after_warm_model_state_sha256", "before_stage2_optimizer_sha256",
                     "captured_current_logits", "captured_history_logits"]
    assert all(a[k] == b[k] for k in paired_fields)
    result = dict(status="PASS_INCREMENTAL_NUMPY_REFERENCE", environment=dict(numpy=np.__version__,
                    torch_import_spec_present=importlib.util.find_spec("torch") is not None),
                  source_sha256=hashlib.sha256((source/"scripts/step28_er_weight.py").read_bytes()).hexdigest(),
                  scope="AST update control statements with explicit NumPy six-parameter fixture; no PyTorch/BGE, production forward or objectives executed",
                  fd_gradient=independent.tolist(), independent_components=[g.tolist() for g in separate],
                  cases=rows, detected_mutations=mutations, native_saved_handwritten_score_recomputation=native,
                  saved_native_pairing_fields_equal=paired_fields,
                  limitations=["Saved native gradient tensors are not included; only their norms/hashes and maximum residuals can be audited.",
                               "Native BGE component probes and updates were performed by the submitter; reviewer did not execute BGE.",
                               "No formal text/label/model/test/owner assets read; no formal training or project-server connection."])
    (out / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(); parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True); args = parser.parse_args()
    run(args.source.resolve(), args.out.resolve())
