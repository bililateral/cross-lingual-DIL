# 独立参考程序 v1 失败及 v2 修订

v1 实际运行退出 1，原因是审查者的目标观测夹具以 `isinstance(value, np.ndarray)` 识别 target；手写的两份标签也用 ndarray，因此把三个常量都误计为 target。生产群 labels 是 tuple，生产 reference 才是 ndarray。此失败不说明被审项目有缺陷。

v2 只将目标观测条件改为输入对象身份 `value is target`；生产提取的 update AST 和所有期望损失、梯度、参数更新均未改。v1 源码、实际命令、原 stderr、stdout、退出码及已生成手写输入完整保留。
