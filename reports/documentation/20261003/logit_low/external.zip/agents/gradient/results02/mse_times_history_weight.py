from __future__ import annotations

def update(model: Any, optimizer: Any, current: Any, history: Any, c: dict, weight: float, stage: int, step: int, current_seed: int, history_seed: int, *, reference: np.ndarray | None=None, logit_weight: float=0.0, observe: bool=False, check: Callable[[], None]=lambda: None) -> dict:
    """Two forwards; independently weighted history supervision/MSE, one clip/update."""
    if type(weight) not in (int, float) or weight not in (1.0, 0.5, 0.25, 0.1) or stage not in (2, 3) or (current is None) or (history is None) or (current.labels is None) or (history.labels is None) or (history.uid == current.uid) or (len(optimizer.param_groups) != 2) or (parent.adam_step(optimizer) != (stage - 1) * 288 + step - 1):
        raise ValueError('Unexpected ER continuation or supervision')
    if logit_weight not in (0.0, 0.5) or (reference is not None) != (logit_weight == 0.5) or (reference is not None and (not isinstance(reference, np.ndarray) or reference.shape != (378,) or reference.dtype != np.float32 or (not np.isfinite(reference).all()))):
        raise ValueError('Historical raw-logit reference or independent MSE weight differs')
    rates = (parent.stage_lr(step), 0.001)
    for group, rate in zip(optimizer.param_groups, rates, strict=True):
        group['lr'] = rate
    model.train()
    optimizer.zero_grad(set_to_none=True)
    before = {name: core.state_digest(module.state_dict()) for name, module in (('encoder', model.encoder), ('head', model.head))} if observe else {}
    result = {name: 0.0 for name in STEP_COLUMNS}
    for role, group, seed, coefficient in (('current', current, current_seed, 1.0), ('history', history, history_seed, weight)):
        torch.manual_seed(seed)
        predicted = base.logits(model, group, c, 'split_rank', check)
        truth = torch.tensor(group.labels, dtype=torch.float32, device=predicted.device)
        terms = parent.ranking.objectives(predicted, truth, 0.5)
        objective = terms['total'] if role == 'current' else coefficient * terms['total']
        if role == 'history' and reference is not None:
            target = torch.tensor(reference, dtype=predicted.dtype, device=predicted.device)
            penalty = (predicted - target).square().mean()
            objective = objective + coefficient * logit_weight * penalty
            result.update(logit_mse=float(penalty.detach()), logit_weight=logit_weight)
        objective.backward()
        result.update({role + '_' + key: float(value.detach()) for key, value in terms.items()})
        del predicted, truth, terms, objective
    result['weighted_history_total'] = weight * result['history_total']
    result['total'] = result['current_total'] + result['weighted_history_total']
    if reference is not None:
        result['total'] += logit_weight * result['logit_mse']
    evidence = {}
    if observe:
        for name, module in (('encoder', model.encoder), ('head', model.head)):
            norms = [float(p.grad.float().norm()) for p in module.parameters() if p.grad is not None]
            if not norms or not np.isfinite(norms).all() or max(norms) <= 0:
                raise ValueError('No finite task gradient in ' + name)
            evidence[name] = {'finite_nonzero_combined_gradient': True}
    result['gradient_norm'] = float(torch.nn.utils.clip_grad_norm_(model.parameters(), c['optimizer']['clip_norm'], error_if_nonfinite=True))
    check()
    optimizer.step()
    if parent.adam_step(optimizer) != (stage - 1) * 288 + step:
        raise ValueError('Adam did not make exactly one update')
    if observe:
        for name, module in (('encoder', model.encoder), ('head', model.head)):
            changed = before[name] != core.state_digest(module.state_dict())
            if changed != (name == 'head' or rates[0] > 0):
                raise ValueError('Unexpected parameter update: ' + name)
            evidence[name]['parameters_changed'] = changed
    result.update(history_weight=weight, encoder_lr=rates[0], head_lr=rates[1], modules=evidence, stage=stage, step=step, adam_step=parent.adam_step(optimizer))
    return result
