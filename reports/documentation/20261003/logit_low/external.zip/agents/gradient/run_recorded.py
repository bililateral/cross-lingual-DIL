"""Run one argv command and preserve its exact streams and status without overwriting."""
import argparse, datetime, json, pathlib, subprocess, sys
p=argparse.ArgumentParser(); p.add_argument("--out",type=pathlib.Path,required=True); p.add_argument("command",nargs=argparse.REMAINDER); a=p.parse_args()
argv=a.command[1:] if a.command and a.command[0]=="--" else a.command
if not argv: p.error("command missing")
a.out.mkdir(parents=True, exist_ok=False)
meta={"argv":argv,"cwd":str(pathlib.Path.cwd()),"started_utc":datetime.datetime.now(datetime.timezone.utc).isoformat()}
(a.out/"command.json").write_text(json.dumps(meta,ensure_ascii=False,indent=2)+"\n")
with (a.out/"stdout.log").open("wb") as out,(a.out/"stderr.log").open("wb") as err:
    r=subprocess.run(argv,stdout=out,stderr=err)
meta.update(exit_code=r.returncode,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(a.out/"exit_code.txt").write_text(str(r.returncode)+"\n")
(a.out/"command.json").write_text(json.dumps(meta,ensure_ascii=False,indent=2)+"\n")
print(json.dumps(meta,ensure_ascii=False)); print((a.out/"stdout.log").read_text()); print((a.out/"stderr.log").read_text(),file=sys.stderr)
sys.exit(r.returncode)
