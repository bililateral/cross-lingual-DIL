# 独立参考程序 v2 后校对及 v3 修订

v2 已真实退出0。随后交叉读取生产 make_optimizer（scripts/step28_continual_population.py:32—40）确认 encoder weight_decay=0.01、head weight_decay=0。v2 夹具的 NumPy 模拟 AdamW 对两组都用了0.01；这不影响生产 update 的真实语句、系数、梯度、调用次数及错误变体检出，但其“模拟参数更新”数值不应被理解为按正式优化器超参演示。

v3 仅把夹具的两组衰减设为[0.01,0]，同时修正独立标量手算对应值；不改生产项目。v2 初版成功日志及源码保留，v3 独立记录重新运行。所有版本均未执行 PyTorch/BGE 或生产 make_optimizer；这里始终是明确的 NumPy 模拟。
