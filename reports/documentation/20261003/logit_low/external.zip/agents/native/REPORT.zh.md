# LOGIT0.1 Linux 增量核验：独立证据审查分报告

## 判断与边界

在本分工范围内，**未发现应归类为 SCIENTIFIC_BLOCKER 或 REPRODUCIBILITY_DEFECT 的具体缺陷**。提交证据能够支持“在同一初始模型和同一手写预热状态下，ER0.1 与 LOGIT0.1 各实际执行一次原生 BGE 预热更新和一次加权更新；LOGIT 相比 ER 的历史分量在两个参数探针上增加独立的 0.5 MSE 梯度”。这个判断来自命令与入口、源码语义、原始运行记录、保存的 378 维 logit 数组和独立标量复算的交叉核查，不以 PASS 标签或测试数量替代。

网页环境实际执行的是附带标准库脚本 `verify_native_evidence.py`，没有重新执行项目 Linux 的原生 BGE 核验，也没有导入 Torch、NumPy 或项目模块。本次核查不构成正式 LOGIT0.1 训练或结果审查。源码中的原生梯度数组未保存到包内，所以逐元素梯度等式仍属于提交运行时执行的断言证据，不能写成网页环境重算过真实 BGE 梯度。

## 1. 命令、源码与原始证据一致性

证据根目录为 `reports/seller_alias_continual/20261003/logit_low_execution/20261003_150000/`。独立重新计算文件字节数及 SHA-256 后确认：

- `reports/documentation/20261003/logit_low/source_inventory.json` 的 37 项来源与 `deployment.json` 以及 `cpu/audit.json#/source_files` 按路径完全一致；本包内对应文件均匹配。
- `cpu_inventory.json` 的 10 项覆盖 `cpu/` 目录全部文件，共 70,909 字节，各项均匹配；不能只靠 `cpu_return_check.json` 的布尔量确认这一点。
- `cpu_execution.json` 启动命令为 `taskset -c 47 ... reports/cpu logit_low`；`cpu/resource_usage.log` 实際计时命令包含 `scripts/step28_er_weight_check.py --study logit_low`，输出地址位于新的 `20261003_150000/workspace/reports/cpu/`。
- `scripts/run_step28_er_check_linux_20261001.sh:3` 将工作目录切到脚本所属 workspace 的根目录；第 19—23 行限制 GPU 可见性、离线模型读取和 CPU 线程；第 26—34 行记录计时、原 stdout/stderr、退出码及结束时间。没有将更早的 CPU 路径误当本轮运行路径。
- `scripts/step28_er_weight_check.py:171—175` 从本轮 policy 的 `evaluation.matched_er` 与 `arms` 生成原生配对臂，实际为 `tenth`、`logit_tenth`。`cpu/stdout.log` 的原生 start/end 事件与此一致。通用 `PASS_LOGIT_WEIGHT_HANDMADE_CPU` 标签沿用 `step28_er_weight.py:64—65` 的名称，并不自行标识 0.25；具体本轮身份由新来源、命令和两个 arm 字段共同确认。

实际原日志的时长与退出状态如下：

| 项目 | 原证据 |
|---|---:|
| 包装开始 | 2026-10-03 15:01:51 +08:00 |
| 包装结束 | 2026-10-03 15:08:54 +08:00 |
| 秒级时间戳差 | 423 秒 |
| `/usr/bin/time` 墙钟时长 | 7:02.92 |
| 程序内计时 | 421.01334596285596 秒 |
| CPU affinity | [47] |
| 原生进程最大 RSS | 10,363,364 KiB |
| `exit_status.txt` 与 `/usr/bin/time` | 均为 0 |

`cpu/stderr.log` 包含两条 `get_sentence_embedding_dimension` 更名的 FutureWarning，未被隐藏；它们不是此次运行失败。RSS 与 256 MiB 的**输出证据预算**不是同一个量，不能将约 9.88 GiB 的 RSS 误报为证据预算超限。

## 2. “31 项测试”和“4 次原生更新”分别覆盖什么

独立使用 AST 提取 `tests/test_step28_er_weight_contracts.py` 的 `test_*` 方法，与原始 stderr 中 31 条测试身份逐项相符；日志均为 `ok`，原 runner 汇总是 `Ran 31 tests in 32.110s`，没有失败、错误或跳过。三个测试类分别覆盖权重基础、LOGIT、LOGIT0.1 接入，不能将这 31 项解释成 31 次原生 BGE 实验。

`cpu/stdout.log` 中先出现两组每 24 步递增至 288 的进度，均带 `handmade_fixture: true`。它们对应：

- `tests/test_step28_er_weight_contracts.py:613—653`：实际 Tiny 模型的 LOGIT0.1 阶段二 288 次 `runner.train_stage` 调用，并检查 checkpoint、供给与旧 target 不刷新；
- 同文件 `433—456`：实际 Tiny 模型的 ER0.1 阶段二 288 次调用。

随后才出现 `tenth`、`logit_tenth` 两臂的原生 start/end。原生源码 `step28_er_weight_check.py:27—40,72—74,108—109` 每臂加载 BGE、执行一次真实预热更新、将已有 Adam 的 step 计数从 1 手写改成 288，再执行一次加权更新至 289。因此：

- “4 次原生更新”是两臂各两次，符合合同；
- Adam moments 来自一次真实预热；并非真实训练了 288 步的 moments；
- 这四次更新不独立证明真实首域 288 步后的全部恢复和后续长程训练；这一限制已由源码、JSON 的 `counter_fixture` 和合同明确承认。

## 3. 同初态、同随机流与真实调用

从 `cpu/tenth.json` 与 `cpu/logit_tenth.json` 独立核对的精确相等项包括：初始模型摘要、预热后模型摘要、加权更新前 Adam 摘要、完整 `warm_update` 对象、当前群全部 378 个 logits、历史群全部 378 个 logits。加权更新后的模型与 Adam 摘要则不同。

代码如何使这个对照成立：

- `step28_chinese_base.py:110—131` 固定初始化种子，从本地 BGE 加载，在 CPU 建立头部；
- `step28_er_weight_check.py:34` 对两臂使用同一预热群及种子；
- 额外 MSE 参考前向在第 53—65 行执行，此时尚未注册生产更新的 forward/parameter hooks；它用 eval 生成 target，再用 train 与种子 108 形成独立 penalty 梯度；
- 真正的 `method.update` 在第 72—74 行调用，仍显式使用当前种子 107、历史种子 108。额外参考计算未执行 optimizer step，也没有污染这两个显式重设的随机流；
- 第 67—79 行 hooks 要求两个实际前向和每个参数探针的两个分量反向；第 178—181 行比较两个 arm 的状态和完整 logits。CPU 原证据记录符合这些约束。

生产更新 `step28_er_weight.py:237—250` 对当前群与历史群分别调用实际 `base.logits`；历史损失先对完整 `terms['total']` 乘 `weight`，随后在同一历史图上相加 `logit_weight * penalty`，再反向。第 264—269 行统一 clip 并只执行一次 AdamW step。该调用链与仅修改配置或累计日志的实现有本质区别。

## 4. 用捕获 logits 独立复算完整标量目标

独立脚本没有调用项目 `scalar_losses` 或 `ranking.objectives`。它在标准库中手写了 28 账号、4 个三成员关系组与 8 个二成员关系组的合成拓扑，按 378 个无序对算 BCE，按每个 query 的 27 个候选算 logsumexp 与正例平均，再按负例分数及索引排序取 top 5 算 pairwise softplus。此处标签全部从已公开手写夹具规则重新构造，未读正式标签。

从二臂保存的相同当前/历史 raw logits 得到：

| 手写参考分项 | 当前群 | 历史群 |
|---|---:|---:|
| BCE | 0.6633192276984118 | 0.6633684505929200 |
| query rank | 3.291688478997471 | 3.292110873997935 |
| top-5 hard（未乘 0.5） | 0.6929290613008466 | 0.6933351772194258 |
| 完整 `BCE + rank + 0.5 hard` | 4.301472237346308 | 4.302146913200568 |

从 `logit_tenth.json#/captured_history_logits` 与 `#/origin_eval_reference` 逐对复算原始 logit MSE 为 `0.0001965899888976513`。因此独立得到：

| 目标 | 网页标准库独立复算 | 原生产 float32 运算导出的日志 |
|---|---:|---:|
| ER0.1 | 4.731686928666364 | 4.7316868782043455 |
| LOGIT0.1 | 4.731785223660813 | 4.731785173204844 |
| LOGIT 增加的 `0.5 MSE` | 0.00009829499444882565 | 0.00009829500049818307 |

完整目标的差异约 `5.05e-8`，与原生 float32 数值精度相符。MSE 没有乘 0.1，也没有除以 1.1。独立脚本同时验证保存的 `independent_objectives` 分项；最大差异在浮点舍入量级。

## 5. 两个梯度探针是否能识别伪实现

原生比较在 `step28_er_weight_check.py:184—194` 直接执行张量级比较：当前分量要求 `rtol=0, atol=0`；历史分量要求 `LOGIT = ER + 独立 0.5 MSE 梯度`，使用 `rtol=2e-5, atol=2e-8`。保存结果为：

| 参数探针 | 独立 `0.5 MSE` 梯度 L2 范数 | 历史逐元素等式最大差 |
|---|---:|---:|
| 编码器第一层 query weight | 8.615575643489137e-5 | 1.000444171950221e-11 |
| 头部隐藏层 weight | 0.001860779826529324 | 2.764863893389702e-10 |

原生前向 target 由 eval 输出创建为常量 Tensor；`autograd.grad` 在两个探针上要求有限非零，见第 53—64 行。原生生产更新的 `.backward` 实际贡献通过 parameter hooks 捕获，不能由一条“模型发生变化”日志替代。二臂当前分量的范数及摘要均完全相同，历史分量摘要不同；加权更新后参数与 optimizer 状态也不同。

额外做了一个无需原生梯度数组的敏感性上界检查，回答“这些 tolerance 是否大到漏掉 MSE 也能通过”。根据 `step28_continual_population.py:21` 和冻结配置，头部隐藏层 weight 有 `128 × (2 × 4096) = 1,048,576` 个元素。若逐元素误差满足原 assertion，则由范数三角不等式：

`||差||₂ ≤ atol × √N + rtol × ||参考||₂`。

将所存头部范数和最大残差代入，允许通过的误差 L2 上界约为 `2.0608178261220455e-5`。若真实历史图漏掉 0.5 MSE，但日志照常写出它，差向量范数应为 `0.001860779826529324`；若误再乘 0.1，差为 `0.0016747018438763917`。两者都远大于该上界。因此，在所保存的原生数值与执行源码成立的前提下，**这项头部探针断言确实可以检出“只记日志却不施加 MSE”和“误把 MSE 再乘 0.1”**。这不是重新运行的原生张量实验，分报告和机器结果都明确标明了它是基于原证据的数学敏感性判断。

### 仍然存在的覆盖界限

1. 二探针对比独立拆出了 MSE 梯度，但 ER 与 LOGIT 的完整监督部分共用 `ranking.objectives`。附带 `tests/test_step28_er_weight_contracts.py:47` 的 `independent_update` 也使用该函数；它独立组合梯度/clip/Adam，但不独立推导每个基础项的导数。标量 `scalar_losses` 对监督值的独立验证也不能自动变成监督导数验证。未变监督函数可沿用既有审查，并结合实际源码或本次其他数学分工的独立导数核验；不能只靠这 31 项声称所有监督导数都已独立验证。
2. 全部 24 层 query weight、词 embedding、四个 head 参数共 29 个探针均记录了有限非零梯度和参数变化；仅两项 pooler 参数没有梯度。这个证据支持各层被更新，**不等于所有 BGE 参数逐元素的 MSE 增量均已比较**。
3. 原生梯度完整数组未入包，网页环境可以复算 logit 标量，不能从摘要逆推出或复算所有参数梯度。要求新增保存全部原生梯度或重跑 BGE 会超过本轮明确范围，也不是本分工发现的阻断项。

## 6. 数据访问声明能支持到哪里

`step28_er_weight_check.py:155—157` 在整个测试与原生调用块外层，用异常替代正式 `public_inputs`、`attach_labels` 与 `Archive`。实际训练数据由 `tests/test_step28_bge_continual_contracts.py:24—32` 的手写群构造；供给/对照测试使用已开放小结果或临时夹具。原生代码的模型加载只指向批准的本地预训练 BGE；本包中的模型信息只是路径、元数据与哈希。

上述证据与原始运行日志支持“沿所审入口没有消费正式文本/标签、没有使用 GPU、没有保留原生核验权重”的有限声明。没有 OS 级全部文件访问审计，所以不把 `formal_inputs=false` 等字段本身解释为独立证明。此处没有具体异常需要扩张权限、连接项目 Linux 或搭建文件访问审计系统。

## 7. 本次实际独立运行与文件

实际命令（源目录可替换为下载 ZIP 中的 `input_snapshot`）：

```bash
python -B independent_review/agents/native/run_verify.py --source-root input_review --run-dir independent_review/agents/native/run_01
```

`run_01/command.json` 保存了展开后的 Python 可执行文件绝对路径、argv、工作目录、UTC 起止时间和 0 退出码；`stdout.log`、`stderr.log` 为 subprocess 的原始字节输出；`exit_status.txt` 为原退出码；`result.json` 为独立复算、输入清单及具体断言结果。本次该独立脚本首次运行成功，没有失败运行或代码修订需要隐藏。31 项项目测试及 4 次原生更新属于附件原记录，本次实际执行范围如上。

### 分类结论

- **SCIENTIFIC_BLOCKER：未发现本分工内具体问题。** 原始计算、调用、对照配对和新增 MSE 梯度探针互相支持。
- **REPRODUCIBILITY_DEFECT：未发现本分工内具体问题。** 可运行入口、冻结源码、原始 stdout/stderr/exit 与必要小数组齐备；独立网页复算源码及记录随本报告保存。
- **未验证范围：** 原生全参数增量、真实首域长程恢复、正式 LOGIT0.1 数据/GPU/1728 更新、未来结果、所有 OS 级读取及后端模型认证。未验证不等于已发现错误。
- **OUT_OF_SCOPE_OVERDESIGN：** 追加原生 288 步、导出全部 BGE 梯度/权重、重新取正式标签、连接远程项目主机、通用审计框架，均不作为本轮放行的新增条件。
