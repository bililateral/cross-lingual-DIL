#!/usr/bin/env python3
"""Capture the actual independent command, raw stdout/stderr, and exit status."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import platform
import shlex
import subprocess
import sys
import time

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--source-root", type=Path, required=True)
parser.add_argument("--run-dir", type=Path, required=True)
args = parser.parse_args()
run_dir = args.run_dir.resolve()
run_dir.mkdir(parents=True, exist_ok=False)
command = [sys.executable, "-B", str(Path(__file__).resolve().with_name("verify_native_evidence.py")),
           "--source-root", str(args.source_root.resolve()), "--output", str(run_dir / "result.json")]
started = datetime.now(timezone.utc).isoformat()
tick = time.perf_counter()
with (run_dir / "stdout.log").open("wb") as out, (run_dir / "stderr.log").open("wb") as err:
    completed = subprocess.run(command, stdout=out, stderr=err, check=False)
record = {"argv": command, "shell_display": shlex.join(command), "cwd": str(Path.cwd()),
          "started_utc": started, "finished_utc": datetime.now(timezone.utc).isoformat(),
          "seconds": time.perf_counter() - tick, "exit_code": completed.returncode,
          "python": sys.version, "platform": platform.platform()}
(run_dir / "command.json").write_text(json.dumps(record, indent=2) + "\n")
(run_dir / "exit_status.txt").write_text(str(completed.returncode) + "\n")
print(json.dumps(record, indent=2))
print((run_dir / "stdout.log").read_text(), end="")
if completed.returncode:
    print((run_dir / "stderr.log").read_text(), end="", file=sys.stderr)
sys.exit(completed.returncode)
