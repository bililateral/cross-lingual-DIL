#!/usr/bin/env python3
"""Independent standard-library recomputation of the submitted native CPU evidence.

This program never imports project modules or scientific libraries and never reads
formal data, model weights, or remote assets. It verifies saved evidence only.
Run with --source-root pointing to the extracted review package.
"""
from __future__ import annotations

import argparse
import ast
from datetime import datetime
import hashlib
import itertools
import json
import math
from pathlib import Path
import re
import sys


EVIDENCE = Path("reports/seller_alias_continual/20261003/logit_low_execution/20261003_150000")
checks: list[dict] = []
reads: dict[str, dict] = {}


def require(condition: bool, name: str, details=None) -> None:
    checks.append({"name": name, "passed": bool(condition), "details": details})
    if not condition:
        raise AssertionError(name + ": " + repr(details))


def read_bytes(root: Path, relative: Path | str) -> bytes:
    path = root / relative
    payload = path.read_bytes()
    reads[Path(relative).as_posix()] = {
        "path": Path(relative).as_posix(), "bytes": len(payload),
        "sha256": hashlib.sha256(payload).hexdigest(),
    }
    return payload


def read_json(root: Path, relative: Path | str):
    return json.loads(read_bytes(root, relative))


def by_path(rows: list[dict]) -> dict[str, dict]:
    require(len(rows) == len({r["path"] for r in rows}), "inventory_paths_are_unique")
    return {r["path"]: r for r in rows}


def verify_records(root: Path, base: Path, rows: list[dict], name: str) -> dict:
    records = by_path(rows)
    for relative, entry in records.items():
        payload = read_bytes(root, base / relative)
        require(len(payload) == entry["bytes"], name + ":size:" + relative)
        require(hashlib.sha256(payload).hexdigest() == entry["sha256"],
                name + ":sha256:" + relative)
    return {"files": len(rows), "bytes": sum(r["bytes"] for r in rows)}


def softplus(value: float) -> float:
    return max(value, 0.0) + math.log1p(math.exp(-abs(value)))


def handmade_labels() -> tuple[list[tuple[int, int]], list[int]]:
    # Explicitly handmade identity groups: four groups of three and eight of two.
    identity = [k for k, count in enumerate([3] * 4 + [2] * 8) for _ in range(count)]
    pairs = list(itertools.combinations(range(28), 2))
    labels = [int(identity[i] == identity[j]) for i, j in pairs]
    require(len(pairs) == 378 and sum(labels) == 20, "handmade_topology_378_pairs_20_positive")
    return pairs, labels


def losses(values: list[float]) -> dict:
    require(len(values) == 378 and all(math.isfinite(v) for v in values), "captured_finite_378_logits")
    pairs, labels = handmade_labels()
    bce = math.fsum(softplus(s) - y * s for s, y in zip(values, labels)) / len(pairs)
    ranks, hards = [], []
    for query in range(28):
        candidates = [(index, j if i == query else i)
                      for index, (i, j) in enumerate(pairs) if query == i or query == j]
        positive = [index for index, _ in candidates if labels[index]]
        negatives = sorted(((-values[index], other, index)
                            for index, other in candidates if not labels[index]))[:5]
        center = max(values[index] for index, _ in candidates)
        rank = center + math.log(math.fsum(math.exp(values[index] - center)
                                         for index, _ in candidates))
        ranks.append(rank - math.fsum(values[index] for index in positive) / len(positive))
        hards.append(math.fsum(softplus(values[negative] - values[pos])
                               for _, _, negative in negatives for pos in positive)
                     / (len(negatives) * len(positive)))
    rank, hard = math.fsum(ranks) / 28, math.fsum(hards) / 28
    return {"bce": bce, "rank": rank, "hard": hard, "total": bce + rank + 0.5 * hard}


def main(root: Path) -> dict:
    current = read_json(root, "reports/documentation/20261003/logit_low/source_inventory.json")
    deployment = read_json(root, EVIDENCE / "deployment.json")
    execution = read_json(root, EVIDENCE / "cpu_execution.json")
    returned = read_json(root, EVIDENCE / "cpu_return_check.json")
    inventory = read_json(root, EVIDENCE / "cpu_inventory.json")
    audit = read_json(root, EVIDENCE / "cpu/audit.json")
    policy = read_json(root, "schema/step28_logit_low_policy.json")
    base_policy = read_json(root, "schema/step28_chinese_base_policy.json")
    contracts = read_json(root, EVIDENCE / "cpu/contracts.json")

    source_totals = verify_records(root, Path(), current, "current_sources")
    require(len(current) == 37, "37_current_source_records")
    require(by_path(current) == by_path(deployment["sources"]) == by_path(audit["source_files"]),
            "source_inventory_deployment_audit_identity")
    evidence_totals = verify_records(root, EVIDENCE / "cpu", inventory, "returned_cpu_evidence")
    require(evidence_totals == {"files": 10, "bytes": 70909}, "10_cpu_files_70909_bytes")
    require(returned["cpu_files"] == 10 and returned["cpu_bytes"] == 70909 and
            returned["all_cpu_size_sha256_match"] and returned["all_current_source_size_sha256_match"],
            "return_claim_consistent_with_independent_hashes")
    require(set(by_path(inventory)) == {p.name for p in (root / EVIDENCE / "cpu").iterdir() if p.is_file()},
            "cpu_inventory_covers_cpu_directory")

    stderr = read_bytes(root, EVIDENCE / "cpu/stderr.log").decode()
    stdout = read_bytes(root, EVIDENCE / "cpu/stdout.log").decode()
    test_module = ast.parse(read_bytes(root, "tests/test_step28_er_weight_contracts.py").decode())
    declared = {f"test_step28_er_weight_contracts.{node.name}.{f.name}"
                for node in test_module.body if isinstance(node, ast.ClassDef)
                for f in node.body if isinstance(f, ast.FunctionDef) and f.name.startswith("test_")}
    executed = re.findall(r"^(test_\w+) \((test_step28_er_weight_contracts\.\w+)\) \.\.\. (\w+)$", stderr, re.M)
    executed_names = {f"{cls}.{name}" for name, cls, _ in executed}
    require(len(declared) == len(executed) == 31 and executed_names == declared,
            "31_logged_tests_match_31_actual_test_definitions")
    require(all(status == "ok" for _, _, status in executed), "all_31_logged_tests_ok")
    require(contracts == audit["contracts"] == {"passed": 31, "failed": 0, "skipped": 0},
            "test_summary_consistency")
    require("Ran 31 tests in 32.110s" in stderr and "\nOK\n" in stderr,
            "test_runner_raw_summary")

    wrapper = read_bytes(root, "scripts/run_step28_er_check_linux_20261001.sh").decode()
    resource = read_bytes(root, EVIDENCE / "cpu/resource_usage.log").decode()
    native_source = read_bytes(root, "scripts/step28_er_weight_check.py").decode()
    exit_status = int(read_bytes(root, EVIDENCE / "cpu/exit_status.txt"))
    require(exit_status == 0 and "Exit status: 0" in resource, "raw_process_exit_zero")
    expected_inner = "timeout --signal=TERM --kill-after=30s 1h python -u -B scripts/step28_er_weight_check.py --study logit_low --out " + execution["workspace"] + "/reports/cpu/audit.json"
    require(expected_inner in resource, "timed_command_matches_new_workspace_and_study")
    require("reports/cpu logit_low" in execution["command"] and
            "taskset -c 47" in execution["command"] and
            audit["environment"]["cpu_affinity"] == [47], "launch_command_cpu_study_consistency")
    require('export CUDA_VISIBLE_DEVICES=\'\'' in wrapper and
            'export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1' in wrapper and
            'export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1' in wrapper,
            "wrapper_static_cpu_offline_limits_present")
    require('mock.patch.object(method.base.public, "public_inputs"' in native_source and
            'mock.patch.object(method.base.public, "attach_labels"' in native_source and
            'mock.patch.object(method.data, "Archive"' in native_source,
            "native_entry_static_guards_formal_public_inputs_labels_archive")
    require(not execution["formal_training_started"] and not audit["formal_inputs"] and
            not audit["formal_labels"] and audit["formal_updates"] == 0 and
            not audit["gpu"] and audit["retained_native_weights"] == 0,
            "declared_nonformal_scope_consistency")
    start = datetime.fromisoformat(read_bytes(root, EVIDENCE / "cpu/started.txt").decode().strip())
    end = datetime.fromisoformat(read_bytes(root, EVIDENCE / "cpu/finished.txt").decode().strip())
    elapsed = (end - start).total_seconds()
    require(execution["observed_start"] == start.isoformat() and 0 < audit["seconds"] <= elapsed < 3600,
            "program_and_wrapper_time_consistency", {"wrapper_seconds": elapsed, "program_seconds": audit["seconds"]})
    require("Maximum resident set size (kbytes): " + str(audit["max_rss_kib"]) in resource,
            "resource_rss_consistency")

    events = [json.loads(line) for line in stdout.splitlines() if line.strip()]
    handmade_events = [e for e in events if e.get("event") == "updates"]
    native_events = [e for e in events if e.get("event") in ("native_start", "native_end")]
    require(len(handmade_events) == 24 and all(e.get("handmade_fixture") for e in handmade_events),
            "24_progress_records_explicitly_handmade")
    for arm in ("tenth", "logit_tenth"):
        require([e["stage_updates"] for e in handmade_events if e["arm"] == arm] == list(range(24, 289, 24)),
                "tiny_stage_progress_24_through_288:" + arm)
    require([(e["event"], e["arm"]) for e in native_events] ==
            [("native_start", "tenth"), ("native_end", "tenth"),
             ("native_start", "logit_tenth"), ("native_end", "logit_tenth")],
            "raw_native_events_identify_exact_two_arms")
    require(events[-1]["native_updates_actually_executed"] == audit["native_updates_actually_executed"] == 4,
            "four_native_updates_recorded_separately_from_tiny_stages")

    records = {arm: read_json(root, EVIDENCE / "cpu" / f"{arm}.json") for arm in ("tenth", "logit_tenth")}
    paired_fields = ["initial_model_state_sha256", "after_warm_model_state_sha256", "before_stage2_optimizer_sha256",
                     "captured_current_logits", "captured_history_logits", "warm_update"]
    for field in paired_fields:
        require(records["tenth"][field] == records["logit_tenth"][field], "paired_exact_saved_field:" + field)
    for field in ("after_model_state_sha256", "after_optimizer_sha256"):
        require(records["tenth"][field] != records["logit_tenth"][field], "final_states_differ:" + field)

    independently_recomputed = {}
    for arm, row in records.items():
        require(row["arm"] == arm and row["history_weight"] == 0.1 and row["native_updates_actually_executed"] == 2,
                "native_arm_weight_update_count:" + arm)
        require(row["warm_update"]["adam_step"] == 1 and row["weighted_update"]["adam_step"] == 289 and
                "1->288" in row["counter_fixture"], "one_warm_one_weighted_counter_fixture:" + arm)
        expected = {role: losses(row["captured_" + role + "_logits"]) for role in ("current", "history")}
        scalar_error, recorded_error = {}, {}
        for role in ("current", "history"):
            scalar_error[role], recorded_error[role] = {}, {}
            for term, value in expected[role].items():
                scalar_error[role][term] = abs(value - row["independent_objectives"][role][term])
                recorded_error[role][term] = abs(value - row["weighted_update"][role + "_" + term])
                require(scalar_error[role][term] < 1e-12, "saved_scalar_reference_recomputed:" + arm + ":" + role + ":" + term)
                require(recorded_error[role][term] < (4e-6 if term == "total" else 2e-6),
                        "production_logged_term_matches_raw_logits:" + arm + ":" + role + ":" + term)
        mse = 0.0
        if arm == "logit_tenth":
            target = row["origin_eval_reference"]
            require(len(target) == 378 and all(math.isfinite(v) for v in target), "finite_378_saved_eval_targets")
            mse = math.fsum((prediction - wanted) ** 2 for prediction, wanted in
                            zip(row["captured_history_logits"], target)) / 378
            require(abs(mse - row["independent_logit_mse"]) < 1e-15, "raw_mse_recomputed")
            require(abs(mse - row["weighted_update"]["logit_mse"]) < 1e-6 and
                    row["weighted_update"]["logit_weight"] == .5, "production_mse_mean_and_independent_coefficient")
        total = expected["current"]["total"] + .1 * expected["history"]["total"] + .5 * mse
        require(abs(total - row["independent_total"]) < 1e-12, "complete_total_independent_reference:" + arm)
        require(abs(total - row["weighted_update"]["total"]) < 6e-6, "production_total_matches_raw_logits:" + arm)
        probes = row["parameter_probes"]
        names = {p["name"] for p in probes}
        layers = {int(re.search(r"\.layer\.(\d+)\.", name).group(1)) for name in names if ".attention.self.query.weight" in name}
        require(len(probes) == len(names) == 29 and layers == set(range(24)) and row["backbone_layers"] == 24,
                "29_probes_cover_24_layer_query_weights_embedding_and_four_head_parameters:" + arm)
        require(all(p["parameters_changed"] and math.isfinite(p["gradient_norm_after_clip"]) and
                    p["gradient_norm_after_clip"] > 0 for p in probes), "positive_finite_and_changed_saved_probes:" + arm)
        require(set(row["unused_parameters"]) == {"encoder.0.model.pooler.dense.weight", "encoder.0.model.pooler.dense.bias"},
                "only_unused_pooler_recorded:" + arm)
        independently_recomputed[arm] = {"terms": expected, "mse": mse, "total": total,
                                        "saved_scalar_errors": scalar_error, "production_log_errors": recorded_error}

    for name in ("encoder_first_query", "head_hidden"):
        er = records["tenth"]["gradient_components"][name]
        logit = records["logit_tenth"]["gradient_components"][name]
        increment = records["logit_tenth"]["mse_gradient_reference"][name]
        require(er["current"] == logit["current"], "current_gradient_digest_and_norm_exact:" + name)
        require(er["weighted_history"]["sha256"] != logit["weighted_history"]["sha256"] and increment["norm"] > 0,
                "history_gradient_digest_changes_with_nonzero_independent_mse:" + name)
        comparison = audit["native_component_comparison"][name]
        require(comparison["compared_arms"] == ["tenth", "logit_tenth"] and
                comparison["history_supervision_weight"] == .1 and comparison["independent_mse_weight"] == .5 and
                comparison["maximum_history_difference"] < 2e-8,
                "saved_native_component_comparison_consistency:" + name)

    # Bound the capability of the *recorded native assertion*, not a fresh tensor comparison.
    # If every coordinate passes |d_i| <= atol + rtol|e_i|, then
    # ||d||_2 <= atol*sqrt(N) + rtol*||e||_2 (triangle inequality).
    # The head hidden weight has N=128*(2*4096) by source and frozen configuration.
    hidden_elements = base_policy["input"]["head_hidden"] * 2 * base_policy["interventions"]["split_rank"]["account_dim"]
    hidden = records["logit_tenth"]["gradient_components"]["head_hidden"]["weighted_history"]["norm"]
    max_delta = audit["native_component_comparison"]["head_hidden"]["maximum_history_difference"]
    expected_norm_upper = hidden + math.sqrt(hidden_elements) * max_delta
    possible_allclose_error_norm = 2e-8 * math.sqrt(hidden_elements) + 2e-5 * expected_norm_upper
    mse_gradient_norm = records["logit_tenth"]["mse_gradient_reference"]["head_hidden"]["norm"]
    require(mse_gradient_norm > possible_allclose_error_norm, "recorded_native_head_assertion_detects_omitted_mse")
    require(.9 * mse_gradient_norm > possible_allclose_error_norm, "recorded_native_head_assertion_detects_extra_tenth_mse_factor")
    half_mse = .5 * independently_recomputed["logit_tenth"]["mse"]
    require(half_mse > 6e-6 and .9 * half_mse > 6e-6, "native_scalar_total_tolerance_distinguishes_missing_or_extra_tenth_mse")

    archive = audit["archive"]
    require(archive["file_count"] == len(archive["files"]) == 12 and
            archive["total_size_bytes"] == sum(r["size_bytes"] for r in archive["files"]), "archive_metadata_internal_totals")
    archive_digest = hashlib.sha256(json.dumps(archive["files"], ensure_ascii=False, sort_keys=True,
                                              separators=(",", ":"), allow_nan=False).encode()).hexdigest()
    require(archive_digest == archive["content_sha256"] == base_policy["models"]["split_rank"]["content_sha256"],
            "archive_manifest_digest_matches_frozen_model_identity")
    require(policy["cpu_verification"]["maximum_evidence_bytes"] > evidence_totals["bytes"], "evidence_budget_satisfied")
    return {
        "status": "PASS_SAVED_NATIVE_EVIDENCE_RECOMPUTATION",
        "source_root": str(root), "runtime": {"python": sys.version, "scientific_imports": []},
        "sources": source_totals, "cpu_evidence": evidence_totals,
        "native_execution": {"wrapper_seconds": elapsed, "program_seconds": audit["seconds"],
                             "raw_exit": exit_status, "max_rss_kib": audit["max_rss_kib"],
                             "native_updates": 4, "logged_tests": len(executed)},
        "declared_and_logged_tests": sorted(declared),
        "warnings": [line for line in stderr.splitlines() if "FutureWarning:" in line],
        "recomputed": independently_recomputed,
        "native_assertion_sensitivity_bound": {
            "scope": "A mathematical bound from saved norms and source-defined head dimension; not a new native gradient run",
            "head_parameter_elements": hidden_elements, "per_element_rtol": 2e-5, "per_element_atol": 2e-8,
            "maximum_possible_passed_error_l2": possible_allclose_error_norm,
            "omitted_half_mse_gradient_error_l2": mse_gradient_norm,
            "extra_tenth_multiplier_error_l2": .9 * mse_gradient_norm,
            "missing_mse_scalar_gap": half_mse, "extra_tenth_mse_scalar_gap": .9 * half_mse,
        },
        "limitations": [
            "The raw native gradient tensors and weights are absent; their norms/digests and logged elementwise comparisons were checked for consistency, not recomputed.",
            "This is an independent saved-logit scalar recomputation, not a fresh BGE execution or 31-test rerun.",
            "Static public input/label/archive guards and saved declarations do not constitute an operating-system-level proof of every file access.",
            "The 288-step progress records are explicitly Tiny-model handwritten tests; native evidence covers one warm and one weighted update per arm.",
            "No native full-stage continuity, CUDA/BF16 behavior, formal-data execution, future scores, or model backend attestation is claimed.",
        ],
        "checks": checks,
        "input_inventory": [reads[key] for key in sorted(reads)],
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = main(args.source_root.resolve())
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
    print(json.dumps({"status": result["status"], "checks_passed": len(checks),
                      "native_execution": result["native_execution"],
                      "recomputed_totals": {arm: r["total"] for arm, r in result["recomputed"].items()},
                      "native_assertion_sensitivity_bound": result["native_assertion_sensitivity_bound"]},
                     ensure_ascii=False, indent=2))
