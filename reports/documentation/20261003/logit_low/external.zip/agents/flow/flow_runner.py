#!/usr/bin/env python3
"""Run an audit command and preserve its exact arguments and original streams."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-root', type=Path, required=True)
parser.add_argument('run_id')
parser.add_argument('command', nargs=argparse.REMAINDER)
args = parser.parse_args()
ROOT = args.source_root.resolve()
run_id, cmd = args.run_id, args.command
dest = BASE / 'runs' / run_id
dest.mkdir(parents=True, exist_ok=False)
(dest / 'command.json').write_text(json.dumps({'argv': cmd, 'cwd': str(ROOT)}, ensure_ascii=False, indent=2) + '\n')
t0 = time.time()
proc = subprocess.run(cmd, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
(dest / 'stdout.txt').write_bytes(proc.stdout)
(dest / 'stderr.txt').write_bytes(proc.stderr)
(dest / 'exit.json').write_text(json.dumps({'returncode': proc.returncode, 'elapsed_seconds': time.time()-t0}, indent=2) + '\n')
sys.stdout.buffer.write(proc.stdout)
sys.stderr.buffer.write(proc.stderr)
print('\nAUDIT_RETURN_CODE=' + str(proc.returncode), flush=True)
sys.exit(proc.returncode)
