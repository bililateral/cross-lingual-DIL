# LOGIT0.1增量流程独立核查

## 结论

在本分工实际审读与有限手写核验范围内，**未确认新增的项目 SCIENTIFIC_BLOCKER 或 REPRODUCIBILITY_DEFECT**。`logit_low`能到达实际续训函数、原LOGIT首域记忆和评价参数；没有发现退回ER0.25、漏用原始logit target、自动重新训练首域或新增读取正式标签的分支。本分工不负责损失导数和63套真实对照数值的最终核验，它们须与并行审查结果合并判断。

本次网页环境有NumPy，没有Torch、Transformers和SentenceTransformers。本分工没有安装依赖、加载BGE、执行数值优化器、读取正式文本/标签/模型/私有资产或连接项目Linux。所报告的1728次是**实际生产train_stage向显式更新spy传参的1728次调用**；不是1728次训练。spy的计数器、日志和占位返回值均不能用来证明梯度、Adam更新或正式效果。真实梯度只能由本轮另外的独立梯度分析及包内原生证据支持。

## 1. 已核对的范围和复用依据

先完整读取本轮request、合同及implementation.diff，然后读实际`step28_er_weight_run.py`、新增policy、method入口、Memory/Supply、首域恢复、访问账本及finalize。直接复用`20261002/logit_weight/review/report.zh.md`和相应外审中已关闭的恢复/记忆/盲门/保存后恢复证据，及`20261002/er_low/review/report.zh.md`、`20261003/result_review/report.zh.md`的处置。

主审独立反向diff结果见`independent_review/evidence/delta_attempt01/result.json`：旧34来源中27份未改，7份修改逆向恢复后精确匹配旧LOGIT0.25冻结记录，另新增3份；`train_stage/checkpoint/train/blind_gate/collect/execute`函数文本全部未变，仅`main`加入study枚举。该结果支持复用未变闭环，不把历史PASS当作当前新增接入正确的替代品。

## 2. study、policy、来源及CLI确实接入

`scripts/step28_er_weight.py:30–50`允许`logit_low`，使用独立policy及SHA常量，arm固定为`logit_tenth:0.1`。policy固定`memory_arm=logit`、MSE=0.5和主比较`tenth`。`with_logits:60–61`、`step_columns:68–69`以及`expected_points:109–111`由该policy导出六新端点和LOGIT字段。

`scripts/step28_er_weight_run.py:530–547`将CLI的`--study logit_low`传给execute；finalize分支重新读取相同policy，将原共同首域baseline及policy传给统计。手写参考实际调用`main()`并仅将末端execute/finalize替换为spy，两个分支的参数均正确。这证明CLI转发；未执行正式execute或正式统计。

两个Linux包装脚本均在第3行以脚本自身目录定位workspace；正式包装第11–14行把logit_low归入12小时，第32–36行转发study/audit/authorization。CPU包装第8–10、28–30行相应接入。两份`bash -n`实际退出0；本次没有执行项目Conda激活或Linux包装的真实作业命令。

实际运行`sources(p)`得到37条，按唯一路径/大小/SHA与source_inventory、deployment和本轮CPU audit全部相同；运行列表与CPU audit的列表顺序也完全一致。source_inventory和deployment排序与Python排序不同，因此直接列表相等为False不构成身份不匹配。未改被审源文件来统一排序。

当前包中没有新的`freeze.json`。实现并不依赖这个文件名：policy的SHA已经钉住；source_inventory、deployment、CPU audit记录当前37来源；正式`execute:458–473`要求授权及CPU receipt的source_files等于实时来源；`train:287–288`、`execute:515–516`、`finalize:125–130`继续核对。**没有新freeze.json本身不是阻断缺陷。** 尚未生成的正式授权/执行来源记录和真实资源状态仍未被预先认证。

## 3. 首域恢复、训练供给与target生命周期

`train:191–239`明确选`memory_arm=logit`；新train标签解析前核验原共享完整checkpoint和首域缓存文件身份。`prior.restore_branch:230–240`实际加载该完整state，恢复模型、优化器和RNG，要求Adam288及模型摘要一致。恢复后`train:222–235`回放全部60群首域盲分数，并检查缓存with_logits、顺序、seen=48、draw状态、首映射、与原ER成员匹配、target起源均为阶段1。该路径不是从任一对照末端续训。

`ContinuationSupply.resume:201–209`只把阶段推进到2；`Supply.current:85–100`只返回当阶段48拟合和12校准群。手写参考对三顺序实际运行供应器，均拒绝旧阶段、跳到阶段3和重复阶段2，按2、3返回对应实际域。这里shared标记为明确占位，没有模型恢复证据含义。

`train_stage:64–69`向实际更新函数传`p['arms'][arm]`、当前及历史分别固定的dropout种子、`reference=target`和`p['loss']['logit_mse']`。独立手写群用Python Random自行展开当前六轮日程和历史draws，对三顺序×两阶段共1728次spy调用逐一检查：arm权重0.1、MSE系数0.5、当前/历史群ID、两套种子、完整float32 378项target及预算回调均匹配；target与保存向量不共享可变内存。梯度及更新实现未在此被运行。

`Memory.retain:130–154`先按Algorithm R选成员，仅删除淘汰target，再为newcomers生成新target；`draw:164–169`返回副本。`train:255–277`阶段2结束时调用本路径当前模型，核对旧存活target哈希不变，并把当前阶段2模型摘要作为来源。实际`base.score:223–229`调用eval和inference_mode，检查float32 378项。

手写参考实际执行这份生产Memory代码和序列化，在三顺序阶段转换验证：新target请求恰等于新入群集合，旧存活值逐字节不变，first_map不变，起源只为1或2，to_bytes/from_bytes回环一致。这证明手写输入下的状态生命周期；没有本次真实BGE评分。

## 4. 六端点盲门、18新结果和统计恢复

`checkpoint:100–178`要求完整阶段、12当前域校准和60群valid盲评分，保存并实际恢复完整model/Adam/RNG，逐值回放校准/valid分数，再保存推理状态及校准映射。每终点4份分数：12群校准raw、60群valid raw/stage-cal/first-cal，所以六终点是24数组；指标角色只有后三类，所以18套新指标/计数。不能把这两个计数混淆。

`blind_gate:294–422`检查六点和训练/记忆/初态集合、1728更新/3456群、首域起点、真实文件摘要、缓存内容及target起源、全部更新日程、完整损失日志分解、4个观察步、模型/校准记录和24份有限数组。该门的算术日志核对不能单独证明真实计算已生效，因此必须与更新实现和原生分量梯度证据结合。本分工复用已关闭的39类门错误注入证据，没有把它们说成本次重新执行。

`execute:505–511`顺序明确为全部训练→blind_gate→写before_valid→一次development解析→collect。`collect:425–451`先核对六点和群ID，为六点各三个角色保存矩阵及count，最后才写完整collected。新增63套对照接入在`finalize:145–173`，复制保存小矩阵/count后才统计；对照数值身份由并行审查独立负责。

正式CLI只有execute和finalize，没有训练resume。`execute:476–478`拒绝已有run/evaluation/access的作业；错误写`FAILED_NO_AUTOMATIC_RETRY`后抛出，不自动重训。`prior.parse_once:76–87`先记账再调用loader。本次实际手写loader故意抛错，train与development各记一次；再次尝试在loader前被拒绝，test/heldout/owners也在loader前拒绝。均为手写回调，正式访问次数为0。

`finalize:123–132`要求完整collected和所有矩阵/计数及当前来源一致。后续恢复仍需要既有钉住参考元数据及小型结果文件；它没有加载对照模型或调用标签入口。已有历史外审对“完整保存后统计失败→仅保存结果恢复→重复输出字节一致”进行了实测，本轮核心收集/写一次机制未变，应复用而不搭建额外恢复框架。

## 5. 实际执行、失败保留与可复现入口

主要新参考：

```bash
python flow_reference.py --source-root /path/to/input_snapshot --out /path/to/new_flow_output
```

实际执行保留于`runs/012_control_flow_reference/`，原stdout、空stderr、退出0、命令参数及耗时俱在；生成手写输入规格、1728条spy调用、三顺序memory摘要、访问账及result。两个bash语法检查见runs/013及014，退出0。查询/读文件命令同样保留command.json/stdout.txt/stderr.txt/exit.json。

唯一非零进程退出是`runs/005_dependencies_history`的探索性rg：错误地查询不存在的`scripts/step28_bge_ranking.py`及`reports/documentation/20261003/result_review`，退出2；原stderr保留。后续006/007/009使用实际的`step28_alias_ranking.py`和`seller_alias_continual/.../result_review`。这是审查者路径查询错误，不是项目运行失败，也未据此修改项目。

原日志封装v1保留为flow_runner_v1.py；之后v2只增加显式`--source-root`以便交付复现。既有command.json保留当时绝对路径，不改写历史命令。参考源码flow_reference.py本来即接受`--source-root/--out`，没有失败修订版本。

## 6. 分类与实际边界

|分类|结论|
|---|---|
|SCIENTIFIC_BLOCKER|本流程分工未确认新增项；不能替代其他分工的梯度和真实对照审查。|
|项目REPRODUCIBILITY_DEFECT|未确认新增未决项。inventory排序不同不是来源变化，无freeze.json也不是实现缺口。|
|审查自身错误|一次rg错误路径，退出2，原流保留，按正确路径后续读取。|
|未验证|本次真实模型首域恢复、CUDA/BF16、原生288步连续运行、六正式终点、正式参数更新、正式资源及新结果；均未宣称已完成。|
|未来建议|按已批准正式路径保存并核对真实六终点与访问账；不是新增实验/成功线或审批。|
|OUT_OF_SCOPE_OVERDESIGN|新增候选/种子/标签权限、重跑未变全部旧测试、新教师/恢复框架、增加freeze文件名门或通用系统加固，均非本轮必要修订。|

