#!/usr/bin/env python3
"""LOGIT0.1 control-flow audit using only stdlib, NumPy, and handwritten data.

This is NOT a training or gradient test. train_stage's update callable is
replaced with an explicit spy; a local empty torch import object is supplied
only because train_stage imports torch even on its CPU control path. No torch
package is installed, no model is loaded, and no numerical optimizer runs.
Actual production contract/CLI/Memory/Supply/parse_once code is exercised.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import itertools
import json
from pathlib import Path
import random
import sys
from types import SimpleNamespace
from unittest import mock

import numpy as np


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def seed(number, *parts):
    raw = (json.dumps([number, *parts], ensure_ascii=False, sort_keys=True,
                      separators=(',', ':'), allow_nan=False) + '\n').encode()
    return int.from_bytes(hashlib.sha256(raw).digest()[:8], 'big') % (2**63 - 1)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    source, out = args.source_root.resolve(), args.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(source / 'scripts'))
    import step28_er_weight as method
    import step28_er_weight_run as runner
    parent, prior, data = method.parent, method.prior, method.data
    p = method.contract('logit_low')
    old_p = parent.contract()
    results = {
        'scope': 'Pure control flow, handwritten groups and call spies; not a gradient/native training test',
        'formal_inputs_read': 0, 'formal_label_parses': 0,
        'models_loaded': 0, 'actual_optimizer_updates': 0,
        'source_root': str(source), 'checks': {},
    }
    expected_names = [f'{order}_logit_tenth_stage{stage}' for order in ('ABC', 'BCA', 'CAB') for stage in (2, 3)]
    assert method.expected_points(p) == expected_names
    assert p['arms'] == {'logit_tenth': .1} and p['loss']['logit_mse'] == .5
    assert method.with_logits(p) and p['memory_arm'] == 'logit'
    assert p['evaluation']['comparison_pairs'] == [
        ['logit_tenth', 'tenth'], ['logit_tenth', 'logit_quarter'], ['logit_tenth', 'seq']]

    actual_sources = method.sources(p)
    by_path = lambda rows: {r['path']: (r['bytes'], r['sha256']) for r in rows}
    inventory = data.read_json(source / 'reports/documentation/20261003/logit_low/source_inventory.json')
    cpu_dir = source / 'reports/seller_alias_continual/20261003/logit_low_execution/20261003_150000'
    deployment = data.read_json(cpu_dir / 'deployment.json')['sources']
    audit_sources = data.read_json(cpu_dir / 'cpu/audit.json')['source_files']
    for rows in (actual_sources, inventory, deployment, audit_sources):
        assert len(rows) == len(by_path(rows)) == 37
        assert by_path(rows) == by_path(actual_sources)
    assert actual_sources == audit_sources
    results['checks']['source_identity'] = {
        'unique_sources': 37, 'inventory_deployment_audit_match_by_path_size_sha': True,
        'runtime_and_cpu_audit_list_order_matches': True,
        'inventory_list_order_same': inventory == actual_sources,
        'freeze_json_present': (source / 'reports/documentation/20261003/logit_low/freeze.json').exists(),
        'policy_sha256': method.policy_sha256(p),
    }

    # Exercise the actual argparse/main dispatch, while the terminal action is a spy.
    argv = ['step28_er_weight_run.py', 'execute', '--out', str(out / 'not_a_job'),
            '--audit', str(out / 'not_an_audit.json'), '--authorization', str(out / 'not_an_authorization.json'),
            '--study', 'logit_low']
    with mock.patch.object(sys, 'argv', argv), mock.patch.object(runner, 'execute', return_value={'status': 'SPY_ONLY_NO_EXECUTION'}) as called:
        runner.main()
        assert called.call_args.args == ((out / 'not_a_job').resolve(), (out / 'not_an_audit.json').resolve(),
                                         (out / 'not_an_authorization.json').resolve(), 'logit_low')
    argv = ['step28_er_weight_run.py', 'finalize', '--out', str(out / 'not_a_collection'), '--study', 'logit_low']
    with mock.patch.object(sys, 'argv', argv), mock.patch.object(runner.evaluation, 'finalize', return_value={'status': 'SPY_ONLY_NO_STATISTICS'}) as called:
        runner.main()
        assert called.call_args.args[0] == (out / 'not_a_collection').resolve()
        assert called.call_args.args[1] == source / p['baseline']['linux_job'] / 'evaluation'
        assert called.call_args.args[2] == p
    results['checks']['cli'] = {'execute_study_forwarded': True, 'finalize_policy_and_baseline_forwarded': True,
                               'terminal_calls_were_spies': True}

    # Each account has >=1 positive; four triples and eight pairs give 20 positive edges.
    owners = [i // 3 if i < 12 else 4 + (i - 12) // 2 for i in range(28)]
    labels = tuple(int(owners[a] == owners[b]) for a, b in itertools.combinations(range(28), 2))
    assert len(labels) == 378 and sum(labels) == 20

    def group(uid):
        sellers = tuple(f'{uid}_seller_{i:02}' for i in range(28))
        items = tuple(tuple((f'{uid}_item_{i:02}_{j}', f'handmade title {i} {j}', f'handmade description {i} {j}')
                            for j in range(2)) for i in range(28))
        value = data.Group(uid, sellers, items, labels)
        value.validate()
        return value

    fit = {d: [group(f'fixture_fit_{d}_{i:02}') for i in range(48)] for d in 'ABC'}
    cal = {d: [group(f'fixture_cal_{d}_{i:02}') for i in range(12)] for d in 'ABC'}
    save(out / 'handwritten_input_spec.json', {
        'fixture_only': True, 'source': 'Generated in this script; not project data',
        'accounts': 28, 'items_per_account': 2, 'pair_labels': list(labels),
        'fit_group_ids': {d: [g.uid for g in fit[d]] for d in 'ABC'},
        'calibration_group_ids': {d: [g.uid for g in cal[d]] for d in 'ABC'},
    })

    # Real dispatch guards never return first-domain fit after the resumed first point.
    groups = {'fit': sum((fit[d] for d in 'ABC'), []), 'calibration': sum((cal[d] for d in 'ABC'), [])}
    partition = {role: [{'group_uid': g.uid, 'domain': d} for d in 'ABC' for g in collection[d]]
                 for role, collection in (('fit', fit), ('calibration', cal))}
    supply_results = []
    for order in ('ABC', 'BCA', 'CAB'):
        supplier = method.ContinuationSupply(groups, partition)
        name = order + '_logit_tenth'
        shared = {'order': order, 'stage': 1, 'completed_updates': 288,
                  'full_model_adam_and_rng_restore_verified': True,
                  'model_state_sha256': 'HANDWRITTEN_CONTROL_FLOW_PLACEHOLDER'}
        supplier.resume(name, order, shared)
        rejects = []
        for bad_stage in (1, 3):
            try:
                supplier.current(name, order, bad_stage)
            except ValueError as error:
                rejects.append(str(error))
            else:
                raise AssertionError('Accepted old/future domain before stage 2')
        a, b = supplier.current(name, order, 2)
        assert a == fit[order[1]] and b == cal[order[1]]
        try:
            supplier.current(name, order, 2)
        except ValueError as error:
            rejects.append(str(error))
        else:
            raise AssertionError('Accepted duplicate stage 2')
        a, b = supplier.current(name, order, 3)
        assert a == fit[order[2]] and b == cal[order[2]]
        supply_results.append({'order': order, 'stages_served': [2, 3], 'rejected_requests': rejects})
    results['checks']['continuation_supply'] = supply_results

    # A local import placeholder plus an explicit update spy tests parameter transmission.
    # NO backward, clip, tensor operation or optimizer step happens in this section.
    spy_calls, lifecycle = [], []
    fake_torch_import = SimpleNamespace()
    class CpuModelMarker:
        def parameters(self):
            yield SimpleNamespace(is_cuda=False)
    class BudgetSpy:
        def __init__(self): self.calls = 0
        def check(self): self.calls += 1
        def state(self): return {'fixture_only': True, 'budget_callback_calls': self.calls}

    for order in ('ABC', 'BCA', 'CAB'):
        memory = parent.Memory(order, old_p['memory_seed'], True, {'a': 1., 'b': 0.})
        scored = []
        def target_source(rows, stage):
            scored.append({'stage': stage, 'group_ids': [g.uid for g in rows]})
            return np.stack([np.linspace(stage + .001 * int(g.uid[-2:]), stage + .5, 378, dtype=np.float32) for g in rows])
        memory.retain(fit[order[0]], 1, lambda rows: target_source(rows, 1))
        payload = memory.to_bytes()
        memory = parent.Memory.from_bytes(payload)
        assert memory.to_bytes() == payload
        initial_refs = {uid: v.copy() for uid, v in memory.references.items()}
        initial_map = copy.deepcopy(memory.first_map)
        marker, optimizer, budget = CpuModelMarker(), SimpleNamespace(state={'fixture_parameter': {'step': 288}}), BudgetSpy()
        root = out / ('dispatch_' + order)
        (root / 'updates').mkdir(parents=True)
        for stage in (2, 3):
            stream = seed(old_p['schedule_seed'], order, stage, 'current')
            rng = random.Random(stream)
            current_ids = []
            for _ in range(6):
                ids = sorted(g.uid for g in fit[order[stage - 1]])
                rng.shuffle(ids)
                current_ids.extend(ids)
            rng = random.Random(seed(old_p['memory_seed'], order, stage, 'history_draws'))
            members = [g.uid for g in memory.reservoir.groups]
            history_ids = [members[rng.randrange(len(members))] for _ in range(288)]
            stage_refs = {uid: x.copy() for uid, x in memory.references.items()}
            reference_log = {'current_ids': current_ids, 'history_ids': history_ids,
                             'memory_after_training': {'members': members}}
            stage_start = len(spy_calls)
            def update_spy(model, opt, current, history, config, weight, actual_stage, step,
                            current_seed, history_seed, *, reference, logit_weight, observe, check):
                index = step - 1
                assert model is marker and opt is optimizer and weight == .1
                assert actual_stage == stage and current.uid == current_ids[index] and history.uid == history_ids[index]
                assert current_seed == seed(stream, index, 'dropout')
                assert history_seed == seed(old_p['memory_seed'], order, stage, index, 'history_dropout')
                assert logit_weight == .5 and reference.dtype == np.float32 and reference.shape == (378,)
                assert np.array_equal(reference, stage_refs[history.uid])
                assert not np.shares_memory(reference, memory.references[history.uid])
                assert observe == (step in (1, 29, 30, 288))
                assert check == budget.check
                check()
                opt.state['fixture_parameter']['step'] += 1  # Counter fixture, NOT optimizer execution.
                row = dict.fromkeys(method.step_columns(p), 0.)
                row.update(history_weight=weight, logit_weight=logit_weight, modules={})
                spy_calls.append({'order': order, 'stage': stage, 'step': step, 'current_uid': current.uid,
                                  'history_uid': history.uid, 'history_weight': weight, 'logit_weight': logit_weight,
                                  'current_seed': current_seed, 'history_seed': history_seed,
                                  'target_sha256': hashlib.sha256(reference.tobytes()).hexdigest()})
                return row
            with mock.patch.dict(sys.modules, {'torch': fake_torch_import}), mock.patch.object(method, 'update', side_effect=update_spy):
                row = runner.train_stage(marker, optimizer, fit[order[stage - 1]], memory, {}, order, stage,
                                         'logit_tenth', root, reference_log, budget, p)
            assert len(spy_calls) - stage_start == 288
            assert row['name'] == f'{order}_logit_tenth_stage{stage}' and row['history_weight'] == .1
            assert row['history_ids'] == history_ids and row['current_ids'] == current_ids
            if stage == 2:
                before = memory.summary()
                memory.retain(fit[order[1]], 2, lambda rows: target_source(rows, 2))
                after = memory.summary()
                newcomers = set(after['references']) - set(before['references'])
                requested = set(scored[-1]['group_ids']) if scored[-1]['stage'] == 2 else set()
                assert requested == newcomers
                for uid in set(initial_refs) & set(memory.references):
                    assert np.array_equal(initial_refs[uid], memory.references[uid])
                assert set(memory.reference_origins.values()) <= {1, 2}
                assert memory.first_map == initial_map
                restored = parent.Memory.from_bytes(memory.to_bytes())
                assert restored.to_bytes() == memory.to_bytes()
                lifecycle.append({'order': order, 'before': before, 'after': after,
                                  'scoring_requests': copy.deepcopy(scored), 'old_survivors_byte_identical': True,
                                  'roundtrip_byte_identical': True})
        assert budget.calls == 576 and parent.adam_step(optimizer) == 864
    assert len(spy_calls) == 1728
    save(out / 'dispatch_spy_calls.json', spy_calls)
    save(out / 'memory_lifecycle.json', lifecycle)
    results['checks']['train_stage_dispatch'] = {'mocked_update_calls': len(spy_calls), 'stages': expected_names,
                                               'paired_ids_seeds_and_target_forwarding_verified': True,
                                               'actual_optimizer_updates': 0, 'torch_placeholder_scope': 'CPU import only; update is a spy'}

    # Actual parse_once behavior with an explicitly handwritten failing callback.
    access_root = out / 'access_failure_fixture'
    access_root.mkdir()
    access = {'train': 0, 'valid': 0, 'heldout': 0, 'owners': 0}
    data.write_json(access_root / 'access.json', access)
    callback_calls, parse_events = [], []
    def failing_handwritten_loader(groups, config, split):
        callback_calls.append(split)
        snapshot = data.read_json(access_root / 'access.json')
        assert snapshot['train' if split == 'train' else 'valid'] == 1
        raise OSError('Deliberate handwritten loader failure; no label file is opened')
    for split in ('train', 'development'):
        try:
            prior.parse_once(access_root, [], {}, split, loader=failing_handwritten_loader)
        except OSError as error:
            parse_events.append({'split': split, 'first_attempt': str(error)})
        else:
            raise AssertionError('Missing deliberate loader failure')
        try:
            prior.parse_once(access_root, [], {}, split, loader=failing_handwritten_loader)
        except ValueError as error:
            parse_events.append({'split': split, 'second_attempt_rejected': str(error)})
        else:
            raise AssertionError('Unexpected parse retry')
    for split in ('test', 'heldout', 'owners'):
        try:
            prior.parse_once(access_root, [], {}, split, loader=failing_handwritten_loader)
        except ValueError as error:
            parse_events.append({'split': split, 'forbidden_split_rejected': str(error)})
        else:
            raise AssertionError('Forbidden split accepted')
    assert callback_calls == ['train', 'development']
    assert data.read_json(access_root / 'access.json') == {'train': 1, 'valid': 1, 'heldout': 0, 'owners': 0}
    results['checks']['parse_once'] = {'events': parse_events, 'handwritten_callback_calls': callback_calls,
                                     'attempt_recorded_before_callback': True, 'formal_label_parses': 0}
    results['status'] = 'PASS_LIMITED_CONTROL_FLOW_REFERENCE'
    save(out / 'result.json', results)
    print(json.dumps(results, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
