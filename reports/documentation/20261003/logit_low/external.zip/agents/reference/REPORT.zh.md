# LOGIT0.1：对照来源及评价接入独立增量审查

## 本分工裁定

在本分工实际审读及运行范围内，**未发现新增 SCIENTIFIC_BLOCKER 或需要修改冻结生产代码的 REPRODUCIBILITY_DEFECT**。新 study 的实际评价路径能够引用正确的 ER0.1、LOGIT0.25 和 SEQ，保留共同首域，读取 63 套指定旧指标/计数，并产生三组各 23 项比较。这里判定的是接入与计算路径；**尚无 LOGIT0.1 正式训练结果，本分工未给 LOGIT0.1 作效果裁定**。

本分工没有安装科研依赖、连接项目 Linux、读取正式文本/标签/模型/私有资产或进行训练。网页实际运行使用 Python 3.12.14、NumPy 2.3.5；实际命令、脚本快照、原 stdout/stderr、退出码与结果均在本目录 `runs/attempt_01/`。本分工属于主审同一会话的协作，不代表另一独立模型后端或新增科研重复试验。

## 1. 固定对照及来源实际对应

下列路径均相对于收到的原包根目录。

| 比较角色 | 实际输入来源 | 使用集合 | 独立核验结果 |
|---|---|---:|---|
| SEQ 及共同首域 | `reports/seller_alias_continual/20261001/bge_continual_result/returned/job/` | 3 个首域×3 角色＋3 顺序×2 后续阶段×3 角色＝27 套 | 读取原 `shared` 与 `seq` 端点，不读取原 `er` 或 `logit` 后续端点作为此次对照 |
| 匹配 ER0.1 | `reports/seller_alias_continual/20261003/er_low_result/job/` | `ABC/BCA/CAB_tenth_stage2/3`，18 套 | policy 摘要为 `201c7a76…`；端点臂名为 `tenth`，没有误用 ER0.25 |
| 固定 LOGIT0.25 | `reports/seller_alias_continual/20261003/logit_weight_result/job/` | `ABC/BCA/CAB_logit_quarter_stage2/3`，18 套 | policy 摘要为 `2aaf4172…`；端点臂名为 `logit_quarter`，没有误用旧 LOGIT1 |

新 policy 的 `comparison_pairs`、`matched_er`、`primary_comparison` 逐一与合同一致：`logit_tenth_minus_tenth` 为主比较，另报 `logit_tenth_minus_logit_quarter`、`logit_tenth_minus_seq`。`baseline_methods` 仅为 `seq`；`continuation_references` 明确两条已完成续训路径。见 `schema/step28_logit_low_policy.json:87–102,135–218`，以及 `docs/SELLER_ALIAS_LOGIT_LOW.zh.md` 第 1–2 节。

本分工独立逐项核对三份来源各自的五份小记录：execution、manifest、partition、collected、evaluation 的字节数和 SHA 均与新 policy 冻结记录一致。原 SEQ 为 18 份来源、ER0.1 为 31 份、LOGIT0.25 为 34 份；各自 execution/manifest/collected/evaluation 内 source_files 完全一致。**没有拿旧 ER0.1 或 LOGIT0.25 的源码摘要与本轮后继实现逐字节比对来错误认定复用失效。** 复用冻结来源能否逐字节还原由主审的变更分析另行覆盖。

两份续训结果的 partition 与原共同划分完全相同；60 个 valid 群 ID 顺序一致，实际 A/B/C 各 20 群，22 列指标及三个输出角色一致。环境记录均为 Python 3.10.19、Torch 2.9.1+cu130、CUDA 13.0、RTX 5090。以上环境是**包内记录相符**，不称作本网页重新检查过原机器。

生产对应语义位于 `scripts/step28_er_weight.py:165–185`：先核对 pinned 小记录，再核对完成状态、policy、1728/3456 预算计数、准确端点名称、原 baseline_records、完整 partition、各自来源列表与群/域/列及环境。它不只检查 `logit_low` 字符串是否存在。

## 2. 共同首域：实际核对哪些内容

在三份原 `*_shared` point 小记录与两个续训 manifest 的 `restored_starts` 间，独立比对六个起点记录的以下字段：

- `full_checkpoint` 的 path/bytes/SHA/state 摘要完全一致；没有改为 ER0.1 或 LOGIT0.25 的阶段二/三终点。
- `model_state_sha256`、`adam_step=288`、`first_map` 与原首域一致。
- `first_scores_replayed_exactly=true` 与旧已关闭的原生恢复证据相接。
- ER0.1 使用原 ER 首缓存，LOGIT0.25 使用原 LOGIT 首缓存；成员列表相同。LOGIT 的首目标摘要和 `reference_origins` 与原 LOGIT 首缓存记录一致，来源阶段全为 1。

对应生产检查位于 `scripts/step28_er_weight.py:186–195`。本分工额外直接核对 manifest 内存摘要中的成员/目标来源，详见本分工 `runs/attempt_01/output/reference_identity.json` 的 `start_record_checks` 及输入记录。

**这是共同起点身份的保存证据核验，不是本网页载入 model/Adam/RNG/target 载荷重演。** 首域全状态恢复、60 群盲分数回放、原供给/dropout 流的真实执行沿用未改历史实现及结果外审证据；新 LOGIT0.1 将来是否实际通过其恢复门，仍要看正式执行记录。本分工没有据 `first_scores_replayed_exactly` 一个布尔值单独下科学结论。

## 3. 63 套开放小结果：不仅清单匹配

实际载入 63 个 `float64 (60,22)` 指标矩阵及其 63 份计数 JSON；所有值有限。每个角色的计数均为 60 群，TP/FN 总数 20、FP/TN 总数 358；独立由整数计数计算 precision、recall、F1、specificity、balanced accuracy、MCC，共 22,680 个逐群派生标量，与矩阵对应列最大绝对差 **0**。三个角色的曲线/检索列与 raw 逐位一致。

这能检验计数派生量、结构及使用结果的身份，**不能替代正式标签级 AP/MAP/Brier 重算，也没有推断具体哪条边为真阳性**。正式标签级性质继续采用已关闭历史审查及本报告明确的证据边界。

使用集合为 21 个 point×3 个 role＝63 套。每套 matrix 与 counts 两个文件，共 126 个实际复用载荷，均按指定原 `collected.json` 记录进行哈希校验；结果清单和每套精确源路径在 `reference_identity.json` 的 `reused_matrix_count_records`。

## 4. 实际运行新增评价路径与独立参考

### 4.1 明确非研究的候选夹具

本分工创建 `SYNTHETIC_NOT_LOGIT01_RESULTS/`：将**已开放 ER0.1 的 18 套小结果按对应顺序/阶段复制到 `logit_tenth` 候选槽位**。目录 README、输入映射及独立参考均说明这不是 LOGIT0.1 训练观察。这样有一个明确预期：候选对 ER0.1 的全部主角色差值必须精确为 0，而与 LOGIT0.25/SEQ 的结果不同，能识别误取对手、臂名或阶段的错误。

在真实提交源码上，实际调用 `contract("logit_low")`、`baseline()` 及 `finalize()`；后者走完整收集校验、旧结果读取、reference 保存、三组比较及输出流程。未替换生产统计函数，未让假的模型或第三方依赖冒充真实科研组件。

实际完成：

- 18 套候选夹具＋63 套冻结复用；reference 下 126 个复制载荷重新逐项匹配原描述符。
- 输出恰为三个固定 comparison key，各 23 项；不存在 ER0.25/LOGIT1 对照。
- LOGIT 的结果走 `method_checks`，没有生成配置自动替换的 `selection`。
- 候选等于 ER0.1 的全部七端点/22 指标主角色均值、三顺序均值和区间差精确为 0。

实际生产路径见 `scripts/step28_er_weight_evaluate.py:118–174`。其中 `133–150` 分别加载 SEQ/shared 与两个 continuation reference，`151–173` 按原载荷保存准确复用集合。对应参数化 endpoint view 位于 `31–48`，比较臂与匹配对手位于 `54–75`。新 `primary_comparison` 字段不是唯一证据；真正的 `matched_er` 已在实际结果分支使用，三组差值也真的按指定臂计算。

### 4.2 独立计算的来源与结果

另写 NumPy 参考，**不调用项目 endpoint_fields、summarize_field 或 comparison_checks**。独立实现按每个顺序的 `R(stage,arrival)` 明确写 O/N/Z/F_first/F/G/final_all，按实际 A/B/C 群对齐；先把重复顺序内同一实际群的贡献折合，再以固定 PCG64 seed=20260930 的 5000 次域内整群样本频数计算。线性分位数由排序数组的两个相邻位置手写插值。Brier/log_loss 在遗忘/收益端点的方向单独处理，原 23 项没有引入性能容差。

| 核验项 | 实际结果 |
|---|---:|
| 绝对端点数值：4 臂×4 角色×7 端点×22 指标×6 数值（均值、三顺序、两区间端点） | 14,784 个数值；最大绝对差 `4.440892098500626e-16` |
| 三组夹具比较＋两组既有对 SEQ：每组七主端点及 O/N raw 参照诊断 | 5,940 个数值；最大绝对差 `2.220446049250313e-16` |
| 三组夹具原判据 | 69 个布尔值逐项一致 |
| 既有 ER0.1−SEQ | 10/23，原判定保持 |
| 既有 LOGIT0.25−SEQ | 16/23，原判定保持 |

数值容差只用于复算一致性，不进入 23 项性能判定。14,784/5,940 等是比较的标量数，不是独立样本量、额外实验数或判定正确的充分条件。

## 5. 历史证据如何复用

本分工完整阅读了 `reports/seller_alias_continual/20261003/result_review/external/REVIEW.zh.md`（含附录）及 `report.zh.md`。复用内容有：冻结 ER0.1 与 LOGIT0.25 真实来源及共起点对应；原生更新和恢复、样本供给/随机流、阶段二目标生成不刷新；原七端点/22 指标/23 项定义；之前独立数值复算与主审对历史有效性、失败修订和边界的处置。

特别保留历史结论的条件：ER0.1 与 LOGIT0.25 对 SEQ 分别为 10/23、16/23，不能写成全部保护成功；旧 ER0.25−SEQ 的有效负结果不被本轮换对手覆盖；单 s0 三顺序不等于三种子；已开发 valid 的条件区间不覆盖重训、校准估计或开发选择不确定性；跨零区间不证明非劣效。

原历史外审明确未重演正式 model/Adam/RNG/target 载荷、未重建标签级指标，并记录部分旧逐步日志未随其包提供。本轮没有用引用旧外审的方式抹去这些限制，也不要求重开已关闭范围。没有发现需进一步追溯旧结果的具体矛盾。

## 6. 分类及后续边界

| 分类 | 本分工结论 |
|---|---|
| SCIENTIFIC_BLOCKER | 未发现由本轮对照接入/评价参数化引入的科学阻断。 |
| REPRODUCIBILITY_DEFECT | 未发现影响 63 套保存结果引用与新 study 评价输出的必须修订项目缺陷。 |
| 未验证范围 | LOGIT0.1 的正式训练、六原生终点、真实 18 套结果均尚未发生；原生 model/Adam/RNG/cache 载荷及正式标签没有在网页读取；本次夹具成功不得写成正式结果或模型恢复实物认证。 |
| OUT_OF_SCOPE_OVERDESIGN | 为此接入添加候选/种子、重开正式标签/模型、复审全部历史、修改 23 项成功线、扩展教师/缓存系统、通用重放框架，均不作为本轮完成条件。 |

本分工只有一次实际参考程序运行，退出 0，原 stderr 为空；没有被删除或隐去的运行失败。源代码在 `reference_audit.py`，本次实际运行快照在 `runs/attempt_01/reference_audit.py`。准备过程的静态审读不算科研实际运行。

## 7. 实际命令与可复放入口

本次实际顶层命令为：

```bash
python /workspace/scratch/2936f771c193/independent_review/agents/reference/run_logged.py --input-root /workspace/scratch/2936f771c193/input_review --attempt attempt_01
```

实际子进程使用 `/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python`；完整 argv、cwd、线程环境、UTC 起止及 2.886603294 秒耗时均在 `runs/attempt_01/command.json`。`stdout.log`、`stderr.log`、`exit_code.txt` 是原始运行输出。未以摘要替代这些原件。

解包后可以把 `--input-root` 指向主审交付中的 `input_snapshot/`，并使用新的 `--attempt` 名称；也可直接运行 `reference_audit.py --input-root <源码根> --output-root <新目录>`。程序不会覆盖已有运行目录。重放需要现有 Python 和 NumPy，无新增安装动作。

主要结果在 `runs/attempt_01/output/summary.json`、`reference_identity.json`、`input_records.json`、`fixture_input_mapping.json` 和 `independent_fixture_reference.json`。所有夹具产物集中在显式命名的非研究目录，以避免误作为 LOGIT0.1 正式结果。
