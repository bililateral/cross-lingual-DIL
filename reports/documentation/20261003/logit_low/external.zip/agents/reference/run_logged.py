"""Run one review program and preserve its exact command, source, streams, exit."""
from __future__ import annotations
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ap = argparse.ArgumentParser()
ap.add_argument("--input-root", type=Path, required=True)
ap.add_argument("--attempt", required=True)
args = ap.parse_args()
here = Path(__file__).resolve().parent
attempt = here / "runs" / args.attempt
attempt.mkdir(parents=True, exist_ok=False)
source = here / "reference_audit.py"
shutil.copyfile(source, attempt / "reference_audit.py")
argv = [sys.executable, str(source), "--input-root", str(args.input_root.resolve()),
        "--output-root", str(attempt / "output")]
env = os.environ.copy()
changes = {k: "1" for k in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
                            "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "PYTHONDONTWRITEBYTECODE")}
env.update(changes)
record = {"argv": argv, "cwd": str(here), "environment_overrides": changes,
          "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
          "started_utc": dt.datetime.now(dt.timezone.utc).isoformat()}
(attempt / "command.json").write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n")
start = time.monotonic()
with (attempt / "stdout.log").open("wb") as stdout, (attempt / "stderr.log").open("wb") as stderr:
    result = subprocess.run(argv, cwd=here, env=env, stdout=stdout, stderr=stderr, check=False)
record.update(exit_code=result.returncode, elapsed_seconds=time.monotonic() - start,
              finished_utc=dt.datetime.now(dt.timezone.utc).isoformat())
(attempt / "command.json").write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n")
(attempt / "exit_code.txt").write_text(str(result.returncode) + "\n")
print(json.dumps(record, ensure_ascii=False, indent=2), flush=True)
print("--- Raw stdout ---", flush=True)
print((attempt / "stdout.log").read_text(), end="", flush=True)
print("--- Raw stderr ---", flush=True)
print((attempt / "stderr.log").read_text(), end="", flush=True)
sys.exit(result.returncode)
