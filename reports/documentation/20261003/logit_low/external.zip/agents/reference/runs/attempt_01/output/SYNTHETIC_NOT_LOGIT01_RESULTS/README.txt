NON-RESEARCH FIXTURE. Candidate slots copy ER0.1 matrices/counts under logit_tenth names. This does not represent trained LOGIT0.1.
