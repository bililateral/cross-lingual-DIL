"""Independent reference identity/statistics + actual LOGIT0.1 finalize fixture.

No model, formal text, labels, private assets or scientific installs are used.
Fixture candidate matrices are ER0.1 copies under new names.  They are explicitly
NOT observations of LOGIT0.1; they exercise 18 new-slot + 63 reused-slot routing.
Independent reference calculations never call project endpoint/statistic/check
functions.  Project finalize is called separately as the system under review.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import json
import math
from pathlib import Path
import platform
import shutil
import sys
import time
import numpy as np

ORDERS = ("ABC", "BCA", "CAB")
ROLES = ("raw", "stage-cal", "first-cal")
ENDPOINTS = ("O", "N", "Z", "F_first", "F", "G", "final_all")
METRICS = ("average_precision", "trapezoidal_pr_auc", "roc_auc", "recall_at_fpr_1pct",
           "brier", "log_loss", "precision", "recall", "f1", "specificity",
           "balanced_accuracy", "mcc", "map", "mrr", "recall_at_1", "recall_at_3",
           "recall_at_5", "recall_at_10", "ndcg_at_1", "ndcg_at_3", "ndcg_at_5", "ndcg_at_10")
RANK_INDICES = [0, 1, 2, 3] + list(range(12, 22))
INPUTS: dict[str, dict] = {}

def canonical(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False) + "\n").encode()

def desc(path: Path, relative: Path) -> dict:
    payload = path.read_bytes()
    return {"path": path.relative_to(relative).as_posix(), "bytes": len(payload),
            "sha256": hashlib.sha256(payload).hexdigest()}

def load(path: Path):
    payload = path.read_bytes()
    INPUTS[str(path)] = {"bytes": len(payload), "sha256": hashlib.sha256(payload).hexdigest()}
    return json.loads(payload)

def verify(path: Path, record: dict) -> None:
    actual = desc(path, path.parent)
    assert actual["bytes"] == record["bytes"], (str(path), "bytes")
    assert actual["sha256"] == record["sha256"], (str(path), "sha256")
    INPUTS[str(path)] = {k: actual[k] for k in ("bytes", "sha256")}

def confusion(row: dict) -> dict:
    tp, fp, fn, tn = [row[k] for k in ("tp", "fp", "fn", "tn")]
    assert all(type(x) is int and x >= 0 for x in (tp, fp, fn, tn))
    assert tp + fn == 20 and fp + tn == 358
    precision = tp / (tp + fp) if tp + fp else 0.
    recall = tp / 20
    specificity = tn / 358
    denom = math.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
    return {"precision": precision, "recall": recall, "f1": 2 * tp / (2 * tp + fp + fn),
            "specificity": specificity, "balanced_accuracy": (recall + specificity) / 2,
            "mcc": (tp * tn - fp * fn) / denom if denom else 0.}

def read_points(job: Path, collection: dict, names: list[str], records: list[dict]):
    result = {}
    max_error = 0.
    for name in names:
        point = collection["points"][name]
        assert set(point) == set(ROLES)
        result[name] = {}
        for role in ROLES:
            mr, cr = point[role]["matrix"], point[role]["counts"]
            mp, cp = job / "evaluation" / mr["path"], job / "evaluation" / cr["path"]
            verify(mp, mr)
            verify(cp, cr)
            arr = np.load(mp, allow_pickle=False)
            counts = load(cp)
            assert arr.shape == (60, 22) and arr.dtype == np.float64 and np.isfinite(arr).all()
            assert len(counts) == 60
            for row, counted in zip(arr, counts, strict=True):
                for metric, value in confusion(counted).items():
                    max_error = max(max_error, abs(float(row[METRICS.index(metric)]) - value))
            result[name][role] = arr
            records.append({"point": name, "role": role, "matrix": str(mp), "matrix_record": mr,
                            "counts": str(cp), "counts_record": cr})
        for role in ("stage-cal", "first-cal"):
            assert np.array_equal(result[name][role][:, RANK_INDICES], result[name]["raw"][:, RANK_INDICES])
    assert max_error <= 1e-15, max_error
    return result, max_error

def independent_fields(arrays: dict, domains: list[str], arm: str, role: str) -> dict:
    # Explicit R_{stage,arrival} domain fields, summed after order averaging.
    # Shape: order, actual domain, 20 within-domain groups, 22 columns.
    fields = {e: np.zeros((3, 3, 20, 22)) for e in ENDPOINTS}
    for oi, order in enumerate(ORDERS):
        r = {}
        for stage in (1, 2, 3):
            point = order + "_shared" if stage == 1 else f"{order}_{arm}_stage{stage}"
            mat = arrays[point]["stage-cal" if role == "primary" else role].copy()
            if role == "primary":
                mat[:, RANK_INDICES] = arrays[point]["raw"][:, RANK_INDICES]
            for arrival, actual in enumerate(order, 1):
                full = np.zeros((3, 20, 22))
                full["ABC".index(actual)] = mat[[i for i, d in enumerate(domains) if d == actual]]
                r[stage, arrival] = full
        vals = {
            "O": (r[3, 1] + r[3, 2]) / 2,
            "N": (r[2, 2] + r[3, 3]) / 2,
            "Z": r[3, 3],
            "F_first": r[1, 1] - r[3, 1],
            "F": ((r[1, 1] - r[3, 1]) + (r[2, 2] - r[3, 2])) / 2,
            "G": ((r[2, 2] - r[1, 2]) + (r[3, 3] - r[2, 3])) / 2,
            "final_all": (r[3, 1] + r[3, 2] + r[3, 3]) / 3,
        }
        for ep, value in vals.items():
            if ep in ("F_first", "F", "G"):
                value[..., [4, 5]] *= -1
            fields[ep][oi] = value
    return fields

def linear_quantile(ordered: np.ndarray, q: float) -> np.ndarray:
    index = (len(ordered) - 1) * q
    lo, hi = math.floor(index), math.ceil(index)
    return ordered[lo] * (hi - index) + ordered[hi] * (index - lo) if hi != lo else ordered[lo]

def summarize(fields: np.ndarray, draw_counts: np.ndarray) -> dict:
    per_order = fields.sum(axis=1).mean(axis=1)
    # Fold repeated-order appearances of the same actual group BEFORE bootstrap.
    mean_by_domain = fields.mean(axis=0)
    sample = sum((draw_counts[d] @ mean_by_domain[d]) / 20 for d in range(3))
    ordered = np.sort(sample, axis=0)
    lo, hi = linear_quantile(ordered, .025), linear_quantile(ordered, .975)
    point = mean_by_domain.sum(axis=0).mean(axis=0)
    return {name: {"mean": float(point[k]), "per_order": dict(zip(ORDERS, per_order[:, k].tolist())),
                   "conditional_95pct_interval": [float(lo[k]), float(hi[k])]}
            for k, name in enumerate(METRICS)}

def checks(delta: dict, raw: dict) -> dict:
    o, n, z = delta["O"], delta["N"], delta["Z"]
    result = {"old_map_improves": o["map"]["mean"] > 0,
              "old_map_interval_above_zero": o["map"]["conditional_95pct_interval"][0] > 0,
              "old_recall5_improves": o["recall_at_5"]["mean"] > 0,
              "new_map_non_decrease": n["map"]["mean"] >= 0,
              "new_recall5_non_decrease": n["recall_at_5"]["mean"] >= 0}
    guards = {"average_precision": 1, "roc_auc": 1, "brier": -1, "log_loss": -1}
    for ep in ("O", "N"):
        for name, sign in guards.items():
            result[f"{ep}_{name}_non_degradation"] = sign * delta[ep][name]["mean"] >= 0
        for name in ("brier", "log_loss"):
            result[f"{ep}_{name}_against_raw_reference"] = raw[ep][name]["mean"] <= 0
    for name, sign in {"map": 1, "recall_at_5": 1, **guards}.items():
        result[f"Z_{name}_non_degradation"] = sign * z[name]["mean"] >= 0
    assert len(result) == 23
    return result

def compare_numeric(a, b, path="") -> tuple[float, int]:
    if isinstance(a, dict):
        assert set(a) == set(b), (path, set(a) ^ set(b))
        results = [compare_numeric(a[k], b[k], path + "/" + k) for k in a]
        return max((x for x, n in results), default=0.), sum(n for x, n in results)
    if isinstance(a, list):
        assert len(a) == len(b), path
        results = [compare_numeric(x, y, path + f"/{i}") for i, (x, y) in enumerate(zip(a, b, strict=True))]
        return max((x for x, n in results), default=0.), sum(n for x, n in results)
    assert isinstance(a, (int, float)) and not isinstance(a, bool), path
    diff = abs(float(a) - float(b))
    assert diff < 3e-14, (path, a, b, diff)
    return diff, 1

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input-root", type=Path, required=True)
    ap.add_argument("--output-root", type=Path, required=True)
    args = ap.parse_args()
    root, out = args.input_root.resolve(), args.output_root.resolve()
    out.mkdir(parents=True, exist_ok=False)
    p = load(root / "schema/step28_logit_low_policy.json")
    assert p["arms"] == {"logit_tenth": .1}
    pairs = [["logit_tenth", x] for x in ("tenth", "logit_quarter", "seq")]
    assert p["evaluation"]["comparison_pairs"] == pairs
    assert p["evaluation"]["matched_er"] == "tenth"
    assert p["evaluation"]["primary_comparison"] == "logit_tenth_minus_tenth"
    assert p["baseline_methods"] == ["seq"] and p["reference_arms"] == {"tenth": .1, "logit_quarter": .25}
    assert "weight_reference" not in p
    specs = {"seq": p["baseline"], **p["continuation_references"]}
    jobs, saved = {}, {}
    for arm, spec in specs.items():
        jobs[arm] = root / spec["local_small_job"]
        saved[arm] = {}
        for name, rec in spec["records"].items():
            verify(jobs[arm] / name, rec)
            saved[arm][name] = load(jobs[arm] / name)
        sources = saved[arm]["run/manifest.json"]["source_files"]
        assert len(sources) == {"seq": 18, "tenth": 31, "logit_quarter": 34}[arm]
        for name in ("execution.json", "evaluation/collected.json", "evaluation/evaluation.json"):
            assert saved[arm][name]["source_files"] == sources
        for key, value in p["baseline"]["environment"].items():
            assert saved[arm]["execution.json"][key] == value
    bman = saved["seq"]["run/manifest.json"]
    bcol = saved["seq"]["evaluation/collected.json"]
    partition = saved["seq"]["run/partition.json"]
    domains = bcol["domains"]
    assert list(METRICS) == bcol["metric_columns"]
    assert len(domains) == 60 and all(domains.count(d) == 20 for d in "ABC")
    assert len(set(bcol["group_ids"])) == 60
    assert bcol["group_ids"] == [r["group_uid"] for r in partition["development"]]
    assert domains == [r["domain"] for r in partition["development"]]
    starts = []
    for arm in ("tenth", "logit_quarter"):
        spec, files = specs[arm], saved[arm]
        man, col = files["run/manifest.json"], files["evaluation/collected.json"]
        assert files["run/partition.json"] == partition
        assert man["baseline_records"] == p["baseline"]["records"]
        assert man["physical_updates"] == 1728 and man["gradient_group_presentations"] == 3456
        assert man["status"] == f"COMPLETE_1728_{spec['evidence_tag']}_UPDATES_VALID_BLIND"
        assert col["status"] == f"ALL_18_{spec['evidence_tag']}_MATRICES_SAVED_BEFORE_COMPARISONS"
        assert files["evaluation/evaluation.json"]["status"] == f"COMPLETE_{spec['evidence_tag']}_DEVELOPMENT_COMPARISON"
        for name in ("run/manifest.json", "evaluation/collected.json", "evaluation/evaluation.json"):
            assert files[name]["policy_sha256"] == spec["policy_sha256"]
        for key in ("group_ids", "domains", "metric_columns"):
            assert col[key] == bcol[key]
        expected = {f"{o}_{arm}_stage{s}" for o in ORDERS for s in (2, 3)}
        assert set(man["points"]) == set(col["points"]) == expected
        for order in ORDERS:
            rec = bman["points"][order + "_shared"]
            verify(jobs["seq"] / "run" / rec["path"], rec)
            shared = load(jobs["seq"] / "run" / rec["path"])
            start = man["restored_starts"][order + "_" + arm]
            memory = bman["memories"][order + "_" + spec["memory_arm"] + "_after1"]
            assert start["full_checkpoint"] == shared["full_checkpoint"]
            assert start["model_state_sha256"] == shared["model_state_sha256"]
            assert start["first_map"] == shared["first_map_parameters"]
            assert start["memory_source"] == memory["file"]
            assert start["adam_step"] == 288 and start["first_scores_replayed_exactly"] is True
            assert start["memory_summary"]["members"] == memory["members"]
            if arm == "logit_quarter":
                assert start["memory_summary"]["references"] == memory["references"]
                assert start["memory_summary"]["reference_origins"] == memory["reference_origins"]
                assert set(memory["reference_origins"].values()) == {1}
            starts.append({"arm": arm, "order": order, "full_checkpoint": start["full_checkpoint"],
                           "model_state_sha256": start["model_state_sha256"], "adam_step": start["adam_step"],
                           "first_map": start["first_map"], "memory_source": start["memory_source"],
                           "scope": "Small records agree; no payload checkpoint/cache/RNG read"})
    records, old = [], {}
    count_errors = {}
    for arm in specs:
        names = [n for order in ORDERS for n in ([order + "_shared"] if arm == "seq" else [])
                 + [f"{order}_{arm}_stage{s}" for s in (2, 3)]]
        arrays, error = read_points(jobs[arm], saved[arm]["evaluation/collected.json"], names, records)
        assert not (set(old) & set(arrays))
        old.update(arrays)
        count_errors[arm] = error
    assert len(records) == 63 and len(old) == 21
    assert not any(n.startswith(f"{o}_{bad}_stage") for n in old for o in ORDERS for bad in ("er", "quarter", "logit"))
    structure = {"reused_sets": 63, "seq_sets": 27, "er01_sets": 18, "logit025_sets": 18,
                 "source_record_counts": {arm: len(saved[arm]["run/manifest.json"]["source_files"]) for arm in specs},
                 "start_record_checks": starts, "confusion_max_abs_errors": count_errors,
                 "reused_matrix_count_records": records, "research_dependency_installations": 0}
    (out / "reference_identity.json").write_bytes(canonical(structure))
    print("Independent frozen-reference verification: 27 SEQ + 18 ER0.1 + 18 LOGIT0.25 = 63 sets; all file records match.", flush=True)
    print("Each continuation agrees with its own execution/manifest/collected/evaluation source lists (31/34); all three first starts match original records.", flush=True)

    # Import the immutable submitted code only after independent input inspection.
    sys.path.insert(0, str(root / "scripts"))
    import step28_er_weight as method
    import step28_er_weight_evaluate as project_eval
    assert method.contract("logit_low") == p
    assert len(method.sources(p)) == 37
    project_baseline = method.baseline(p, jobs["seq"], continuation_jobs={a: jobs[a] for a in ("tenth", "logit_quarter")})
    assert set(project_baseline["continuation_references"]) == {"tenth", "logit_quarter"}
    print("Submitted baseline() and logit_low contract ran on local allowed small records; no mismatch.", flush=True)

    # Generate an explicit non-research candidate: identical ER0.1 saved numbers,
    # but with distinct LOGIT0.1 fixture point names so all routing is exercised.
    fixture = out / "SYNTHETIC_NOT_LOGIT01_RESULTS"
    fixture.mkdir()
    (fixture / "README.txt").write_text("NON-RESEARCH FIXTURE. Candidate slots copy ER0.1 matrices/counts under logit_tenth names. This does not represent trained LOGIT0.1.\n")
    candidate_collection = {"status": "ALL_18_LOGIT_WEIGHT_MATRICES_SAVED_BEFORE_COMPARISONS",
        "policy_sha256": method.policy_sha256(p), "source_files": method.sources(p), "metric_columns": list(METRICS),
        "domains": domains, "group_ids": bcol["group_ids"], "points": {}}
    mapping = []
    all_arrays = dict(old)
    for order in ORDERS:
        for stage in (2, 3):
            original, candidate = f"{order}_tenth_stage{stage}", f"{order}_logit_tenth_stage{stage}"
            all_arrays[candidate] = copy.deepcopy(old[original])
            candidate_collection["points"][candidate] = {}
            for role in ROLES:
                candidate_collection["points"][candidate][role] = {}
                for kind in ("matrix", "counts"):
                    rec = saved["tenth"]["evaluation/collected.json"]["points"][original][role][kind]
                    suffix = ".npy" if kind == "matrix" else "_counts.json"
                    target = fixture / f"{candidate}_{role}{suffix}"
                    source = jobs["tenth"] / "evaluation" / rec["path"]
                    shutil.copyfile(source, target)
                    candidate_collection["points"][candidate][role][kind] = desc(target, fixture)
                    mapping.append({"fixture_path": target.name, "source": str(source), "kind": kind})
    (fixture / "collected.json").write_bytes(canonical(candidate_collection))
    (out / "fixture_input_mapping.json").write_bytes(canonical(mapping))
    result = project_eval.finalize(fixture, jobs["seq"] / "evaluation", p,
                                  continuation_jobs={a: jobs[a] for a in ("tenth", "logit_quarter")})
    assert result["new_metric_count_sets"] == 18 and result["reused_metric_count_sets"] == 63
    assert set(result["comparisons"]) == {a + "_minus_" + b for a, b in pairs}
    assert "selection" not in result
    reused = load(fixture / "reference/collected.json")
    assert reused["status"] == "REUSED_63_FROZEN_METRIC_COUNT_SETS"
    assert set(reused["points"]) == set(old)
    copied_files = 0
    for point, roles in reused["points"].items():
        for role, kinds in roles.items():
            for kind, rec in kinds.items():
                verify(fixture / "reference" / rec["path"], rec)
                copied_files += 1
    assert copied_files == 126
    print("Submitted finalize() actually completed: 18 candidate fixture sets + 63 exact reused sets; three fixed comparisons, no model selection.", flush=True)

    # Separate numerical reference: frequency counts + explicit R formulas and
    # independent sorted interpolation instead of project statistic functions.
    draws = np.random.Generator(np.random.PCG64(20260930)).integers(0, 20, size=(5000, 3, 20))
    assert np.array_equal(np.load(fixture / "bootstrap_draws.npy", allow_pickle=False), draws)
    draw_counts = np.stack([np.eye(20, dtype=np.int64)[draws[:, d]].sum(axis=1) for d in range(3)])
    fields = {arm: {role: independent_fields(all_arrays, domains, arm, role) for role in (*ROLES, "primary")}
              for arm in ("seq", "tenth", "logit_quarter", "logit_tenth")}
    independent_endpoints = {arm: {role: {ep: summarize(f[ep], draw_counts) for ep in ENDPOINTS}
                                  for role, f in roles.items()} for arm, roles in fields.items()}
    end_error, end_numbers = compare_numeric(independent_endpoints, result["endpoints"])
    independent_comparisons = {}
    comparison_error, comparison_numbers = 0., 0
    for arm, opponent in pairs:
        key = arm + "_minus_" + opponent
        delta = {ep: summarize(fields[arm]["primary"][ep] - fields[opponent]["primary"][ep], draw_counts) for ep in ENDPOINTS}
        raw = {ep: summarize(fields[arm]["primary"][ep] - fields[opponent]["raw"][ep], draw_counts) for ep in ("O", "N")}
        expected_checks = checks(delta, raw)
        assert expected_checks == result["comparisons"][key]["interpretation"]["checks"]
        for expected, actual in ((delta, result["comparisons"][key]["primary"]),
                                 (raw, result["comparisons"][key]["against_raw_reference"])):
            error, number = compare_numeric(expected, actual)
            comparison_error, comparison_numbers = max(error, comparison_error), comparison_numbers + number
        independent_comparisons[key] = {"primary": delta, "against_raw_reference": raw, "checks": expected_checks}
    # Candidate identical to ER0.1: every primary difference must be exactly zero,
    # including all 7 endpoints, all 22 metrics and all three order means.
    zero_comparison = independent_comparisons["logit_tenth_minus_tenth"]["primary"]
    assert all(v["mean"] == 0. and v["conditional_95pct_interval"] == [0., 0.]
               and all(x == 0. for x in v["per_order"].values()) for e in zero_comparison.values() for v in e.values())
    # Existing comparisons may also be independently checked without opening
    # labels or generating any new scientific result.
    old_check_counts = {}
    for arm, key in (("tenth", "tenth_minus_seq"), ("logit_quarter", "logit_quarter_minus_seq")):
        published = saved[arm]["evaluation/evaluation.json"]["comparisons"][key]
        delta = {ep: summarize(fields[arm]["primary"][ep] - fields["seq"]["primary"][ep], draw_counts) for ep in ENDPOINTS}
        raw = {ep: summarize(fields[arm]["primary"][ep] - fields["seq"]["raw"][ep], draw_counts) for ep in ("O", "N")}
        own_checks = checks(delta, raw)
        assert own_checks == published["interpretation"]["checks"]
        for actual, expected in ((delta, published["primary"]), (raw, published["against_raw_reference"])):
            error, number = compare_numeric(actual, expected)
            comparison_error, comparison_numbers = max(error, comparison_error), comparison_numbers + number
        old_check_counts[key] = sum(own_checks.values())
    assert old_check_counts == {"tenth_minus_seq": 10, "logit_quarter_minus_seq": 16}
    (out / "independent_fixture_reference.json").write_bytes(canonical({
        "scope": "Non-research ER0.1-copy candidate fixture; NOT LOGIT0.1 formal results",
        "endpoints": independent_endpoints, "comparisons": independent_comparisons}))
    summary = {"status": "PASS_WITH_EXPLICIT_NON_RESEARCH_FIXTURE", "python": sys.version,
        "numpy": np.__version__, "platform": platform.platform(),
        "reused_sets": 63, "fixture_candidate_sets": 18, "fixture_comparison_groups": 3,
        "checks_per_group": 23, "independent_endpoint_numbers": end_numbers,
        "independent_comparison_numbers_including_two_existing_comparisons": comparison_numbers,
        "endpoint_max_abs_error": end_error, "comparison_max_abs_error": comparison_error,
        "existing_comparison_pass_counts": old_check_counts,
        "formal_training_runs": 0, "formal_label_reads": 0, "formal_model_reads": 0,
        "scientific_dependency_installs": 0,
        "verified_scope": "small records, 63 matrices/counts, first-state record identity, routing, endpoint statistics and 69 fixed checks",
        "not_verified": "formal LOGIT0.1 execution/results, model/Adam/RNG payloads, label-dependent AP/MAP recomputation"}
    (out / "summary.json").write_bytes(canonical(summary))
    (out / "input_records.json").write_bytes(canonical({str(Path(k).relative_to(root)) if Path(k).is_relative_to(root) else k: v
                                                      for k, v in INPUTS.items()}))
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)

if __name__ == "__main__":
    main()
