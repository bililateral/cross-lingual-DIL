"""Report the original absolute-bound failure from retained raw arrays."""
from pathlib import Path
import json
import numpy as np

root = Path(__file__).resolve().parent
archive = root/'incremental_v2/runner_data/runner_step_30_raw.npz'
with np.load(archive) as data:
    actual = data['actual_parameter.encoder.emb.weight']
    expected = data['expected_parameter.encoder.emb.weight']
    index = tuple(int(x) for x in np.unravel_index(np.abs(actual-expected).argmax(), actual.shape))
    av, ev = float(actual[index]), float(expected[index])
    spacing = abs(float(np.spacing(np.float32(av))))
    nearest = float(np.float32(ev))
    result = {'original_failure': 'incremental_v1/original_run/stderr.txt',
              'raw_arrays': str(archive.relative_to(root)),
              'same_error_as_v1': abs(abs(av-ev)-2.712995064158008e-7) < 1e-15,
              'parameter': 'encoder.emb.weight', 'index': list(index),
              'actual_torch_float32': av, 'numpy_float64_closed_form': ev,
              'expected_rounded_to_float32': nearest, 'parameter_absolute_scale': abs(ev),
              'absolute_error': abs(av-ev), 'relative_error': abs(av-ev)/abs(ev),
              'local_float32_ulp': spacing, 'error_in_local_float32_ulps': abs(av-ev)/spacing,
              'distance_from_nearest_rounded_reference_in_ulps': abs(av-nearest)/spacing,
              'v1_fixed_absolute_bound': 2e-7,
              'v2_atol': 2e-7, 'v2_rtol': 2*float(np.finfo(np.float32).eps),
              'v2_component_bound': 2e-7+2*float(np.finfo(np.float32).eps)*abs(ev),
              'classification': 'Auditor reference-precision gate, not a production algorithm failure.',
              'reason': 'NumPy reference evaluates the documented AdamW closed form in float64; production performs weight decay and adaptive subtraction with separate float32 roundings. The component is about magnitude 3, so a fixed bound smaller than ~one local ULP is inappropriate. Independent preclip gradient and moment criteria were unchanged.'}
assert result['same_error_as_v1']
(root/'precision_analysis.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
