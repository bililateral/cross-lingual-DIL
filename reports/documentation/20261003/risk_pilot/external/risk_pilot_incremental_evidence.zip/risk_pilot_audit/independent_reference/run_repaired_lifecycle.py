"""Run only the changed R1/R2 regression, against original or explicit mutant."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import os
import sys
import unittest

ROOT = Path(os.environ.get('RISK_PILOT_INPUT', Path(__file__).resolve().parents[1] / 'input')).resolve()
sys.path[:0] = [str(ROOT / 'scripts'), str(ROOT / 'tests')]
parser = argparse.ArgumentParser()
parser.add_argument('--module', type=Path)
args = parser.parse_args()
if args.module:
    spec = importlib.util.spec_from_file_location('step28_risk_replay', args.module.resolve())
    module = importlib.util.module_from_spec(spec)
    sys.modules['step28_risk_replay'] = module
    spec.loader.exec_module(module)
else:
    import step28_risk_replay as module
import torch
torch.set_num_threads(1)
torch.use_deterministic_algorithms(True)
assert os.environ.get('CUDA_VISIBLE_DEVICES') == ''
print(json.dumps({'scope': 'Handwritten R1/R2 lifecycle only; no BGE/formal data',
                  'torch': torch.__version__, 'module': module.__file__,
                  'sha256': hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest()}, indent=2), flush=True)
import test_step28_risk_replay as tests
suite = unittest.TestSuite([tests.RiskReplayTests('test_actual_stage_memory_lifecycle_and_restore')])
result = unittest.TextTestRunner(verbosity=2).run(suite)
print(json.dumps({'run': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors),
                  'passed': result.wasSuccessful()}), flush=True)
sys.exit(0 if result.wasSuccessful() else 1)
