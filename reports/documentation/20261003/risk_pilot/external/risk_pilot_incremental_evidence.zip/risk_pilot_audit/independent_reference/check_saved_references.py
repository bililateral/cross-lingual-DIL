"""Exercise actual reference gate on previously executed Tiny memory evidence.

No training occurs here. Stage 3 covers this reference-consistency helper only,
using one actual restored memory draw; it is not a complete stage-3 endpoint.
"""
from pathlib import Path
import copy
import hashlib
import json
import os
import sys

root = Path(__file__).resolve().parent
input_root = Path(os.environ.get('RISK_PILOT_INPUT', root.parent/'input')).resolve()
sys.path.insert(0, str(input_root/'scripts'))
import step28_risk_execution as adapter

output = root/'saved_reference_gate_data'
output.mkdir(exist_ok=False)
stage2_log_path = root/'incremental_v2/runner_data/runner/updates/ABC_risk_stage2.json'
stage2_log = json.loads(stage2_log_path.read_text())
first_payload = (root/'incremental_v1/original_data/converted_memory.json').read_bytes()
first_memory = adapter.Memory.from_bytes(first_payload)
first_summary = first_memory.summary()
for key in ('risk_references', 'risk_origins'):
    # The separately recorded converted memory uses the same deterministic Tiny
    # initialization and texts. Establish exact identities before reusing it.
    assert first_summary[key] == stage2_log['memory_after_training'][key]
start = {'memory_summary': first_summary}
payload = (root/'incremental_v2/runner_data/runner_memory_after2.json').read_bytes()
memory = adapter.Memory.from_bytes(payload)
(output/'memory_after2.json').write_bytes(payload)
summary = memory.summary()
retained = {**summary, 'file': {'path': 'memory_after2.json', 'bytes': len(payload),
                              'sha256': hashlib.sha256(payload).hexdigest()}}
adapter.verify_references(output, retained, start, stage2_log, 2)
memory.begin_stage(3)
drawn, reference = memory.draw()
stage3_log = {'memory_after_training': memory.summary(),
              'scope': 'reference-helper branch only; after one restored memory draw, not 288 stage-3 updates'}
adapter.verify_references(output, retained, start, stage3_log, 3)
passed = {'stage2_real_payload_and_training_log': True,
          'stage3_helper_after_one_draw_only': True, 'stage3_drawn_uid': drawn.uid}
failures = {}

def expect_failure(label, fn):
    try:
        fn()
    except ValueError as error:
        failures[label] = {'rejected': True, 'exception': type(error).__name__, 'message': str(error)}
        print(json.dumps({'expected_rejection': label, **failures[label]}), flush=True)
    else:
        raise AssertionError(label+' was not rejected')

bad_summary = copy.deepcopy(retained)
uid = next(iter(bad_summary['risk_origins']))
bad_summary['risk_origins'][uid] = 99
expect_failure('summary_payload_mismatch',
               lambda: adapter.verify_references(output, bad_summary, start, stage2_log, 2))

altered = adapter.Memory.from_bytes(payload)
old_uid = sorted(set(first_summary['risk_references']) & set(summary['risk_references']))[0]
values = altered.cache.auxiliary['risk_replay']['groups'][old_uid]['values']
for degree, rows in values.items():
    values[degree] = [[x+.01 for x in row] for row in rows]
bad_payload = altered.to_bytes()
(output/'old_reference_altered.json').write_bytes(bad_payload)
bad_retained = {**altered.summary(), 'file': {'path': 'old_reference_altered.json', 'bytes': len(bad_payload),
                                             'sha256': hashlib.sha256(bad_payload).hexdigest()}}
# This altered record and file are internally consistent. It must still be
# rejected by the origin-survivor constraint, not just a stale digest check.
expect_failure('old_reference_changed_stage2',
               lambda: adapter.verify_references(output, bad_retained, start, stage2_log, 2))
expect_failure('old_reference_changed_stage3',
               lambda: adapter.verify_references(output, bad_retained, start, stage3_log, 3))

inputs = {'start': start, 'retained': retained, 'stage2_training_log': stage2_log,
          'stage3_reference_helper_log': stage3_log, 'bad_summary_record': bad_summary,
          'internally_consistent_changed_reference_record': bad_retained, 'changed_old_uid': old_uid}
(output/'inputs.json').write_text(json.dumps(inputs, ensure_ascii=False, indent=2))
result = {'scope': 'Saved actual Tiny data; no new model updates', 'positive_checks': passed,
          'negative_checks': failures, 'passed': True}
(output/'results.json').write_text(json.dumps(result, ensure_ascii=False, indent=2))
print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)
