"""Independent incremental CPU checks for the formal risk-runner connection.

Reuse the prior independently checked scalar gradients/AdamW oracle; do not rerun
the old formula suite. Input is handwritten Tiny text only. The shared production
runner stage itself executes all 288 updates. No native BGE, formal data or GPU.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import random
import sys
import time
from unittest import mock

import numpy as np
import torch

ROOT = Path(os.environ.get('RISK_PILOT_INPUT', Path(__file__).resolve().parents[2] / 'input')).resolve()
os.environ['RISK_AUDIT_INPUT'] = str(ROOT)
sys.path.insert(0, str(ROOT / 'scripts'))
spec = importlib.util.spec_from_file_location('prior_independent_oracle', Path(__file__).resolve().parents[1] / 'reused_v4/oracle.py')
oracle = importlib.util.module_from_spec(spec)
spec.loader.exec_module(oracle)
risk = oracle.production
import step28_risk_execution as adapter
import step28_er_weight_run as runner
import step28_risk_study as study

OUT = None
RESULTS = {}


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False))


def emit(name, value):
    RESULTS[name] = value
    print(json.dumps({'check': name, **value}, ensure_ascii=False), flush=True)


def full_rng():
    nr = np.random.get_state()
    return {'torch': runner.rng_state(), 'python': random.getstate(),
            'numpy': (nr[0], nr[1].tolist(), nr[2], nr[3], nr[4])}


def restore_full_rng(state):
    runner.restore_rng(state['torch'])
    random.setstate(state['python'])
    n = state['numpy']
    np.random.set_state((n[0], np.array(n[1], dtype=np.uint32), n[2], n[3], n[4]))


def snapshot(model, optimizer, memory):
    return {'model': risk.core.state_digest(model.state_dict()),
            'optimizer': risk.core.state_digest(optimizer.state_dict()),
            'gradients': risk.core.state_digest({n: p.grad for n, p in model.named_parameters()}),
            'rng': full_rng(), 'training': model.training,
            'memory': hashlib.sha256(memory.to_bytes()).hexdigest()}


def new_fixture():
    model, optimizer, c, old, current, active_ref = oracle.prepared()
    first = [oracle.group(f'pilot_a_{k:02d}', k + 7) for k in range(48)]
    second = [oracle.group(f'pilot_b_{k:02d}', k + 107) for k in range(48)]
    parent = risk.parent.Memory('ABC', risk.parent.contract()['memory_seed'], False, {'a': 1., 'b': 0.})
    parent.retain(first, 1, None)
    return model, optimizer, c, first, second, parent, active_ref


def test_conversion_and_modes():
    model, optimizer, c, first, current, parent, active_ref = new_fixture()
    old_payload = parent.to_bytes()
    torch.manual_seed(18551); random.seed(27272); np.random.seed(39193)
    before_rng = full_rng()
    before_model = risk.core.state_digest(model.state_dict())
    before_optimizer = risk.core.state_digest(optimizer.state_dict())
    scored = []
    original_score = risk.parent.ranking.score
    def capture_score(m, rows, *args):
        scored.append([g.uid for g in rows])
        return original_score(m, rows, *args)
    with mock.patch.object(risk.parent.ranking, 'score', side_effect=capture_score):
        memory = adapter.Memory.from_er(old_payload, model, optimizer, c, lambda: None)
    assert scored == [[g.uid for g in parent.reservoir.groups]]
    assert full_rng() == before_rng
    assert risk.core.state_digest(model.state_dict()) == before_model
    assert risk.core.state_digest(optimizer.state_dict()) == before_optimizer
    assert parent.to_bytes() == old_payload
    max_reference_error = 0.
    refs = copy.deepcopy(memory.cache.auxiliary['risk_replay'])
    for g in memory.cache.reservoir.groups:
        scores = original_score(model, [g], c)[0]
        rs, counts = oracle.scalar_risks(scores)
        expected = oracle.reference_from_risks(rs, counts)
        for degree in ('1', '2'):
            actual = refs['groups'][g.uid]['values'][degree]
            difference = float(np.max(np.abs(np.asarray(actual) - expected[degree])))
            max_reference_error = max(max_reference_error, difference)
            oracle.assert_allclose(actual, expected[degree], atol=1e-6, label='converted per-UID reference '+g.uid)
    # Exercise the actual metadata replacement interface with phase/RNG fields.
    metadata = {'checkpoint_metadata': {'stage': 1, 'completed_updates': 288, 'rng': runner.rng_state()},
                'first_map': {'a': 1., 'b': 0.}, 'history_weight': .1, 'er_weight_policy_sha256': study.POLICY_SHA256}
    memory.auxiliary = metadata
    assert memory.cache.auxiliary['risk_replay'] == refs
    assert all(memory.auxiliary[k] == v for k, v in metadata.items())
    restored = adapter.Memory.from_bytes(memory.to_bytes())
    assert type(restored) is adapter.Memory
    assert restored.to_bytes() == memory.to_bytes()
    assert restored.summary() == memory.summary()
    size = len(memory.to_bytes())
    assert size < 1048576
    probe_results = []
    for mode in (True, False):
        model.train(mode)
        before = snapshot(model, optimizer, memory)
        diagnostic = adapter.mode_probe(model, memory, c, lambda: None)
        after = snapshot(model, optimizer, memory)
        assert before == after
        assert diagnostic['eval_self'] == [0., 0., 0.]
        assert len(diagnostic['train_against_same_model_eval']) == 4
        probe_results.append({'mode': mode, 'unchanged': True, 'diagnostic': diagnostic})
    # An exception after changing a train seed must restore state as well.
    model.eval(); before = snapshot(model, optimizer, memory)
    original_logits = risk.base.logits
    call_count = 0
    def fail_on_third_call(*args, **kwargs):
        nonlocal call_count
        call_count += 1
        if call_count == 3:
            raise RuntimeError('HANDWRITTEN_MODE_PROBE_FAILURE_AFTER_SEED_CHANGE')
        return original_logits(*args, **kwargs)
    try:
        with mock.patch.object(risk.base, 'logits', side_effect=fail_on_third_call):
            adapter.mode_probe(model, memory, c, lambda: None)
    except RuntimeError as error:
        assert str(error) == 'HANDWRITTEN_MODE_PROBE_FAILURE_AFTER_SEED_CHANGE'
    else:
        raise AssertionError('The deliberate exception was not reached')
    assert snapshot(model, optimizer, memory) == before
    (OUT / 'converted_memory.json').write_bytes(memory.to_bytes())
    write_json(OUT / 'mode_probe_diagnostics.json', probe_results)
    write_json(OUT / 'conversion_inputs.json', {'config': c, 'original_er_payload': json.loads(old_payload),
                'metadata': metadata, 'counter_fixture': 'one warm update followed by explicit Adam counter 1->288'})
    emit('er_conversion_and_mode_probe', {'passed': True, 'only_surviving_groups_scored': scored[0],
        'max_per_uid_reference_error': max_reference_error, 'metadata_keeps_risk_references': True,
        'roundtrip_preserves_adapter_type': True, 'serialized_bytes': size,
        'torch_python_numpy_rng_model_adam_gradients_memory_unchanged': True,
        'train_and_eval_modes_restored': True, 'exception_after_seed_change_restored': True})


def test_observe_invariance():
    initial, optimizer, c, first, current, parent, active_ref = new_fixture()
    memory = adapter.Memory.from_er(parent.to_bytes(), initial, optimizer, c, lambda: None)
    # Force a nonzero preservation gradient in an explicit diagnostic-only fixture.
    # Labels and texts remain handmade; reference shortening is not a stage result.
    for entry in memory.cache.auxiliary['risk_replay']['groups'].values():
        entry['values'] = {degree: (np.asarray(values) * np.array([.76, .67, .55])).tolist()
                           for degree, values in entry['values'].items()}
    payload = memory.to_bytes()
    initial_model, initial_optimizer = copy.deepcopy(initial.state_dict()), copy.deepcopy(optimizer.state_dict())
    torch.manual_seed(61353); random.seed(62262); np.random.seed(63463)
    initial_rng = full_rng()
    branches = []
    expanded = []
    for observe in (False, True):
        model = copy.deepcopy(initial); model.load_state_dict(initial_model)
        opt = risk.core.make_optimizer(model, c); opt.load_state_dict(copy.deepcopy(initial_optimizer))
        branch_memory = adapter.Memory.from_bytes(payload)
        restore_full_rng(initial_rng)
        branch_memory.begin_stage(2)
        h1, r1 = branch_memory.draw()
        expanded.append({'observe': observe, 'current': current[0].payload(), 'history': h1.payload(), 'reference': r1})
        first_row = risk.update(model, opt, current[0], h1, r1, c, 2, 1, 65553, 67773,
                                history_weight=.1, retention_weight=.5, observe=observe)
        after_first = snapshot(model, opt, branch_memory)
        h2, r2 = branch_memory.draw()
        second_row = risk.update(model, opt, current[1], h2, r2, c, 2, 2, 68883, 69993,
                                 history_weight=.1, retention_weight=.5, observe=False)
        after_second = snapshot(model, opt, branch_memory)
        common_first = {k: v for k, v in first_row.items() if k not in ('head_gradient_diagnostics', 'modules')}
        branches.append({'observe': observe, 'first': first_row, 'common_first': common_first,
                         'after_first': after_first, 'second': second_row, 'after_second': after_second})
    assert branches[0]['common_first'] == branches[1]['common_first']
    assert branches[0]['after_first'] == branches[1]['after_first']
    assert branches[0]['second'] == branches[1]['second']
    assert branches[0]['after_second'] == branches[1]['after_second']
    assert branches[0]['first']['modules'] == {}
    assert set(branches[1]['first']['modules']) == {'encoder', 'head'}
    diagnostics = branches[1]['first']['head_gradient_diagnostics']
    assert set(diagnostics) == {'weighted_history', 'rank', 'positive', 'negative'}
    write_json(OUT / 'observe_invariance_branches.json', branches)
    write_json(OUT / 'observe_invariance_inputs.json', {'config': c, 'rng': initial_rng, 'branches': expanded,
                'counter_fixture': 'one actual warm update then Adam counter 1->288',
                'reference_fixture': 'per-channel factors [.76,.67,.55], explicit activation probe only'})
    emit('observe_invariance', {'passed': True, 'first_update_identical': True, 'next_update_identical': True,
          'model_adam_gradients_rng_mode_memory_bit_exact': True, 'actual_branch_risk_updates': 4,
          'observe_true_diagnostics': diagnostics})


class Budget:
    def check(self, *args):
        return None
    def state(self):
        return {'scope': 'handwritten independent CPU fixture'}


def test_shared_runner():
    model, optimizer, c, first, current, parent, _ = new_fixture()
    p = study.contract()
    memory = adapter.Memory.from_er(parent.to_bytes(), model, optimizer, c, lambda: None)
    first_references = copy.deepcopy(memory.cache.auxiliary['risk_replay']['groups'])
    baseline = risk.parent.Memory.from_bytes(parent.to_bytes()); baseline.begin_stage(2)
    sequence, stream = risk.parent.schedule(current, risk.parent.contract(), 'ABC', 2)
    ids = [baseline.draw()[0].uid for _ in range(288)]
    expected_log = {'current_ids': [g.uid for g in sequence], 'history_ids': ids,
                    'memory_after_training': baseline.summary()}
    (OUT / 'runner').mkdir(); (OUT / 'runner' / 'updates').mkdir()
    write_json(OUT / 'runner_fixture_inputs.json', {'config': c, 'policy': p, 'expected_log': expected_log,
               'first': [g.payload() for g in first], 'current': [g.payload() for g in current],
               'counter_fixture': 'one actual warm update then explicit Adam counter 1->288; actual runner performs 288 updates'})
    original_update = adapter.risk.update
    original_clip = torch.nn.utils.clip_grad_norm_
    observed = []
    oracle_comparisons = {}
    selected = {1, 29, 30, 288}
    before_rng = full_rng()
    def checked_update(m, opt, cur, hist, reference, config, stage, step, cs, hs, **kwargs):
        assert kwargs['history_weight'] == .1
        assert kwargs['retention_weight'] == .5
        assert kwargs['observe'] == (step in selected)
        assert reference == first_references[hist.uid]['values']
        assert hist.uid == ids[step-1] and cur.uid == sequence[step-1].uid
        assert cs == risk.data.seed_for(stream, step-1, 'dropout')
        assert hs == risk.data.seed_for(risk.parent.contract()['memory_seed'], 'ABC', 2, step-1, 'history_dropout')
        captured = {}
        if step in selected:
            rng = full_rng()
            gradients, details = oracle.independent_parameter_gradient(m, cur, hist, config, reference, .1, .5, cs, hs)
            targets, state_targets, norm, scale = oracle.manual_adam(m, opt, gradients, config, step)
            restore_full_rng(rng)
        def capture(parameters, *args, **kw):
            parameters = list(parameters)
            captured.update({n: par.grad.detach().numpy().copy() for n, par in m.named_parameters()})
            return original_clip(parameters, *args, **kw)
        if step in selected:
            with mock.patch.object(torch.nn.utils, 'clip_grad_norm_', side_effect=capture):
                result = original_update(m, opt, cur, hist, reference, config, stage, step, cs, hs, **kwargs)
            errors = {}
            for name, par in m.named_parameters():
                oracle.assert_allclose(captured[name], gradients[name], atol=2e-6, rtol=2e-5,
                                       label=f'formal runner step {step} {name} independent preclip gradient')
                oracle.assert_allclose(par.detach().numpy(), targets[name], atol=2e-7,
                                       label=f'formal runner step {step} {name} independent AdamW')
                for key in ('exp_avg', 'exp_avg_sq'):
                    oracle.assert_allclose(opt.state[par][key].numpy(), state_targets[name][key], atol=2e-8, rtol=2e-5,
                                           label=f'formal runner step {step} {name} {key}')
                errors[name] = {'gradient_max_error': float(np.max(abs(captured[name]-gradients[name]))),
                               'parameter_max_error': float(np.max(abs(par.detach().numpy()-targets[name])))}
            oracle.assert_allclose(result['total'], details['total'], atol=3e-6,
                                   label='runner actual objective at step '+str(step))
            oracle_comparisons[str(step)] = {'errors': errors, 'norm': norm, 'clip_scale': scale,
                                            'expected_objective': details, 'actual_total': result['total']}
        else:
            result = original_update(m, opt, cur, hist, reference, config, stage, step, cs, hs, **kwargs)
        observed.append({'step': step, 'current': cur.uid, 'history': hist.uid, 'current_seed': cs,
                         'history_seed': hs, 'lambda': kwargs['history_weight'], 'gamma': kwargs['retention_weight'],
                         'observe': kwargs['observe'], 'retention': result['retention'], 'total': result['total']})
        return result
    with mock.patch.object(adapter.risk, 'update', new=checked_update):
        result = runner.train_stage(model, optimizer, current, memory, c, 'ABC', 2, 'risk',
                                    OUT/'runner', expected_log, Budget(), p)
    assert len(observed) == 288 and risk.parent.adam_step(optimizer) == 576
    assert set(result['observations']) == {'1', '29', '30', '288'}
    assert 'first_update_head_gradient_norms' in result['risk_diagnostics']
    values = np.load(OUT/'runner'/result['update_file']['path'])
    col = {k: values[:, i] for i, k in enumerate(result['update_columns'])}
    assert np.array_equal(col['total'], col['current_total'] + .1*col['history_total'] + .5*col['retention'])
    assert np.array_equal(col['retention_weight'], np.full(288, .5))
    before_refs = copy.deepcopy(memory.cache.auxiliary['risk_replay']['groups'])
    # Same metadata assignment and live-memory retain sequence as formal train().
    memory.auxiliary = {'checkpoint_metadata': {'stage': 2, 'rng': runner.rng_state()},
                        'stage_map': {'a': 1., 'b': 0.}, 'history_weight': .1}
    assert memory.cache.auxiliary['risk_replay']['groups'] == before_refs
    score_rows = []
    original_score = risk.parent.ranking.score
    def observe_score(m, groups, *args):
        score_rows.extend(g.uid for g in groups)
        return original_score(m, groups, *args)
    with mock.patch.object(risk.parent.ranking, 'score', side_effect=observe_score):
        memory.retain(current, 2, model, optimizer, c, lambda: None)
    now_refs = memory.cache.auxiliary['risk_replay']['groups']
    newcomers = set(now_refs) - set(before_refs)
    assert set(score_rows) == newcomers
    for uid in set(now_refs) & set(before_refs):
        assert now_refs[uid] == before_refs[uid]
    for g in memory.cache.reservoir.groups:
        if g.uid in newcomers:
            score = original_score(model, [g], c)[0]
            rs, counts = oracle.scalar_risks(score)
            ref = oracle.reference_from_risks(rs, counts)
            for degree in ('1', '2'):
                oracle.assert_allclose(now_refs[g.uid]['values'][degree], ref[degree], atol=1e-6,
                                       label='newcomer reference after real runner')
    assert memory.auxiliary['checkpoint_metadata']['stage'] == 2
    payload = memory.to_bytes(); restored = adapter.Memory.from_bytes(payload)
    assert restored.to_bytes() == payload and len(payload) < 1048576
    (OUT / 'runner_memory_after2.json').write_bytes(payload)
    # Check a real next-stage update from a restored adapter and full saved state.
    saved_model, saved_optimizer = copy.deepcopy(model.state_dict()), copy.deepcopy(optimizer.state_dict())
    rng = full_rng(); next_runs = []
    for mem in (memory, restored):
        model.load_state_dict(saved_model); optimizer.load_state_dict(copy.deepcopy(saved_optimizer)); restore_full_rng(rng)
        mem.begin_stage(3); history, reference = mem.draw()
        row = risk.update(model, optimizer, oracle.group('pilot_c_next', 301), history, reference, c, 3, 1,
                          61181, 63381, history_weight=.1, retention_weight=.5, observe=True)
        next_runs.append({'row': row, 'snapshot': snapshot(model, optimizer, mem)})
    assert next_runs[0] == next_runs[1]
    write_json(OUT / 'runner_observed_calls.json', observed)
    write_json(OUT / 'runner_independent_update_comparisons.json', oracle_comparisons)
    write_json(OUT / 'runner_next_stage_restore.json', next_runs)
    emit('shared_runner_actual_stage', {'passed': True, 'physical_stage_updates': 288,
         'lambda': .1, 'gamma': .5, 'adam_end_of_stage': 576,
         'selected_independent_gradient_adam_steps': sorted(selected),
         'all_actual_reference_uid_seed_and_coefficients_checked': True,
         'observation_steps': list(result['observations']), 'serialized_bytes_with_metadata': len(payload),
         'newcomer_only_references': sorted(newcomers), 'old_survivors_not_refreshed': True,
         'next_stage_update_full_state_restore_identical': True,
         'max_gradient_error': max(v['gradient_max_error'] for item in oracle_comparisons.values() for v in item['errors'].values()),
         'max_parameter_error': max(v['parameter_max_error'] for item in oracle_comparisons.values() for v in item['errors'].values())})


def main():
    global OUT
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--tests', default='conversion,observe,runner')
    args = parser.parse_args()
    OUT = args.output.resolve(); OUT.mkdir(parents=True, exist_ok=False)
    torch.set_num_threads(1); torch.use_deterministic_algorithms(True)
    assert os.environ.get('CUDA_VISIBLE_DEVICES') == '' and not torch.cuda.is_available()
    print(json.dumps({'scope': 'handwritten Tiny CPU incremental audit only', 'input': str(ROOT),
                      'python': sys.version, 'torch': torch.__version__, 'numpy': np.__version__,
                      'formal_data': False, 'native_bge': False}, indent=2), flush=True)
    started = time.monotonic()
    cases = {'conversion': test_conversion_and_modes, 'observe': test_observe_invariance, 'runner': test_shared_runner}
    try:
        with (mock.patch.object(risk.base.public, 'public_inputs', side_effect=AssertionError('NO_FORMAL_INPUTS')),
              mock.patch.object(risk.base.public, 'attach_labels', side_effect=AssertionError('NO_FORMAL_LABELS')),
              mock.patch.object(risk.data, 'Archive', side_effect=AssertionError('NO_FORMAL_ARCHIVE')),
              mock.patch.object(risk.base, 'load_model', side_effect=AssertionError('NO_NATIVE_BGE'))):
            for name in args.tests.split(','):
                cases[name]()
    finally:
        write_json(OUT / 'results.json', {'results': RESULTS, 'seconds': time.monotonic()-started})
    print('INDEPENDENT INCREMENTAL CHECKS PASSED', flush=True)


if __name__ == '__main__':
    main()
