# 正式 risk 接入的独立 CPU 增量核验

## 裁决与范围

本目录支持的结论是：**本轮风险更新、共享 runner 阶段调用、存活参考、模式诊断与 observe 观测范围内，没有发现当前生产阻断；前轮 R1/R2 两个测试盲点已实际关闭。** 整个正式作业能否启动仍须结合总报告对对照绑定、盲门、授权和监听的裁决。Tiny 核验不提供科学效果或创新结论。

机器汇总在 `result.json`。本次没有正式数据、标签、服务器、BGE 模型或 CUDA 访问，没有下载模型，没有重复前轮完整数学测试和 8 个变异。`source_delta.json` 及两个 `*_delta.diff` 保存前后来源差异；query_risks、make_reference、distribution_penalty、RiskMemory、train_stage 的源段完全不变，生产 update 只新增观测。

## 实际执行

1. 当前修补生命周期用例通过，完整命令/输出在 `repaired_lifecycle_original_run/`。同一当前测试分别对 stage γ=0 和参考行逆序两个明确单缺陷副本运行；各出现一个正确断言失败，零运行错误，退出码 1。副本及完整输出在 `mutants/`。
2. `incremental_v1/original_run/` 中，ER 六存活群转换、逐 UID 参考、metadata 保留、模式诊断和 observe 不变性均通过。逐 UID 最大风险差 3.4732597820e-7，含元数据的原阶段缓存为 95,256 字节。模式诊断在 train/eval 两种初始模式，以及 train seed 已改变后人为抛异常的情形下，最终 Python/NumPy/Torch RNG、模型、Adam、参数梯度、训练模式与记忆均与调用前相同。生产 `finally` 显式恢复 Torch CPU／可见 CUDA RNG 和训练模式；Python/NumPy RNG 未被诊断消耗，模型、Adam、已有梯度和记忆也未被诊断修改。
3. observe=False 和 observe=True 的首次真实更新及后续真实更新完全相同，比较包括模型、Adam、参数梯度、RNG、模式和缓存。四个头上诊断范数实际计算且不为零；该诊断只测隐藏头权重，不称全 encoder 诊断。
4. `incremental_v2/runner_run/` 退出码为 0，共享正式 `step28_er_weight_run.train_stage` 实际执行 288 次风险更新，λ=.1、γ=.5。每次核对当前/历史 UID、参考、两个 dropout seed、系数与 observe 标志。步骤 1/29/30/288 对照前轮已独立核验的标量 logit 梯度和 NumPy AdamW 公式，最大梯度差 7.4505805969e-8，最大参数差 2.7129950642e-7；Adam 矩也通过。
5. 同一实际阶段结束后按正式路径替换 auxiliary，再 retain。risk references 没有被 checkpoint 元数据覆盖；仅两个新存活群生成参考，四个旧存活参考不刷新。完整缓存 95,422 字节，恢复后下一次实际 stage3 更新完全相同。没有执行 stage3 完整 288 步或六正式端点。
6. `saved_reference_gate_run/` 用上述实际内存和训练日志直接调用 adapter.verify_references，stage2 分支通过；恢复内存一次 draw 后的 stage3 参考检查分支也通过。摘要与 payload 错配被拒绝；修改旧参考、同步重写 payload 和全部摘要后，stage2/stage3 均由“Old risk reference refreshed”拒绝。这里没有新增训练，也没有把此 helper 检查称为完整 stage3 盲门。

## 本方失败与精度门修正

v1 共享 runner 在步骤 30 的独立参数对照中退出 1，原源码、输入、stdout、stderr、退出码完整保留。此前通过的转换、模式和 observe 项没有在 v2 重复运行。

问题是本方把 NumPy float64 闭式 AdamW 预期值与 Torch float32 多次舍入结果，统一限定为固定 2e-7 绝对误差。在 encoder.emb.weight[62,4]，实际值 -3.11403226852417，闭式预期 -3.1140325398236763；相对误差 8.7121602920e-8；局部 float32 ULP 为 2.3841857910e-7，误差为 1.1379 ULP，距最接近的 float32 参考值正好一个 ULP。原固定绝对界比该幅度的一个 ULP 还小。

v2 事先明确使用 `atol=2e-7`、`rtol=2*float32_eps`，逐分量误差界为 `atol + rtol * abs(reference)`，只用于参数比较。独立数学、梯度、Adam 矩公式与断言不变。完整原始数组、分量和精度计算源码在 `incremental_v2/runner_data/runner_step_30_raw.npz`、`precision_analysis.json`、`analyze_precision.py`。这属于审查方参考精度门修正，**不是当前生产算法失败**。

## 人工夹具披露

本轮 Tiny 使用一次实际 warm update 后把 Adam counter 明确从 1 改为 288 的来源状态夹具；随后共享 runner 实际完成 288 步。observe 配对检查的历史参考乘 [.76,.67,.55] 只用于激活非零保持梯度；共享 runner 采用未缩放的真实同一 Tiny 模型 eval 参考。独立配置 clip_norm=.08 只用于观察主动裁剪，没有改原附件合同。

## 自包含复跑

目录默认关系：同一审查根目录下有 `input/`（新附件解压内容）及本 `independent_reference/`。若另放输入，可设置 `RISK_PILOT_INPUT` 指向包含 scripts/schema 的解压根目录。全部数学 helper 已包含在 `reused_v4/oracle.py`，是前轮已执行源码的精确副本，来源 SHA 在 `reuse_identity.json`；运行时不依赖前轮目录。

本次环境 Python 3.12.14、NumPy 2.3.5、官方 CPU Torch 2.7.1+cpu，Torch 单线程、禁用 CUDA。可使用已装这些依赖的 Python，或创建独立环境：

```bash
python3.12 -m venv .venv
.venv/bin/python -m pip install numpy==2.3.5
.venv/bin/python -m pip install --index-url https://download.pytorch.org/whl/cpu torch==2.7.1+cpu sympy==1.13.3
```

从审查根目录，使用尚不存在的新结果目录运行最终推荐入口：

```bash
.venv/bin/python independent_reference/run_recorded.py independent_reference/my_run .venv/bin/python independent_reference/incremental_v2/check.py --output independent_reference/my_data
```

记录器保存完整命令、环境、stdout、stderr、退出码，强制 CUDA_VISIBLE_DEVICES 为空并设置线程为 1。若 Torch 用 pip --target 安装，设置 `RISK_AUDIT_TORCH_PATH` 指向那个目录即可；普通虚拟环境无需设置。

修补生命周期的原版与一个反例的运行方法：

```bash
.venv/bin/python independent_reference/run_recorded.py independent_reference/my_lifecycle_run .venv/bin/python independent_reference/run_repaired_lifecycle.py
.venv/bin/python independent_reference/run_recorded.py independent_reference/my_gamma0_run .venv/bin/python independent_reference/run_repaired_lifecycle.py --module independent_reference/mutants/stage_gamma_zero/step28_risk_replay.py
```

原版预期退出 0；声明的变异预期退出 1。不要覆盖已提交的成功/失败结果目录。已保存数据的参考检查源码和全部输入在 `check_saved_references.py`、`saved_reference_gate_data/`；它使用已执行的真实 Tiny 文件，不需要加载模型。
