"""Independent handwritten evaluation/collection checks. No model or formal data.

Numerical markers are synthetic metric matrices, not research outcomes. Saved-file
finalize checks explicitly mock only comparator resolution and prior identity
binding; the actual read_points/finalize/evaluate/save code remains live. Resolver
identity and resource/training entry are outside this independent test.
"""
from __future__ import annotations

import copy
import itertools
import json
from pathlib import Path
import sys
from types import SimpleNamespace
from unittest import mock

import numpy as np

HERE = Path(__file__).resolve().parent
INPUT = HERE.parent / "input"
sys.path.insert(0, str(INPUT / "scripts"))
import step28_er_weight as method
import step28_er_weight_evaluate as actual
import step28_er_weight_run as runner
import step28_risk_study as study


def dump(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n")


def record(path, root):
    return method.data.record(path, root)


def main():
    out = HERE / "run"
    out.mkdir()  # Evidence is not overwritten.
    p = study.contract()
    orders = ["ABC", "BCA", "CAB"]
    roles = ["raw", "stage-cal", "first-cal"]
    arms = ["seq", "tenth", "logit_quarter", "logit_tenth", "risk"]
    domains = ["ABC"[i % 3] for i in range(60)]
    ids = [f"handwritten_evaluation_{i:02d}" for i in range(60)]
    columns = list(method.metrics.COLUMNS)
    assert len(columns) == 22
    ranks = [columns.index(k) for k in (*method.metrics.CURVE_KEYS, *method.metrics.RETRIEVAL_KEYS)]
    errors = [columns.index(k) for k in ("brier", "log_loss")]
    positive = np.ones(22); positive[errors] = -1

    new, old = {}, {}
    for oi, order in enumerate(orders):
        for arm in ["shared", *arms]:
            for stage in ([1] if arm == "shared" else [2, 3]):
                point = f"{order}_shared" if arm == "shared" else f"{order}_{arm}_stage{stage}"
                am = 0 if arm == "shared" else arms.index(arm) + 1
                base = .24 + np.arange(60)[:, None] * .0001 + np.arange(22)[None, :] * .00003
                base = base + positive[None, :] * (am * .012 + stage * .003 + oi * .0007)
                views = {}
                for ri, role in enumerate(roles):
                    mat = base.copy()
                    if ri:
                        delta = .002 * ri * positive
                        delta[ranks] = 0
                        mat += delta
                    views[role] = mat
                (new if arm == "risk" else old)[point] = views
    np.savez(out / "synthetic_metric_matrices.npz", **{
        f"{point}__{role}": matrix for source in (old, new)
        for point, views in source.items() for role, matrix in views.items()})
    dump(out / "synthetic_input_identity.json", {
        "scope": "Handwritten marker metrics, not model measurements", "domains": domains,
        "group_ids": ids, "columns": columns, "orders": orders, "roles": roles})

    terms = {
        "O": [(3, 1, .5), (3, 2, .5)],
        "N": [(2, 2, .5), (3, 3, .5)], "Z": [(3, 3, 1.)],
        "F_first": [(1, 1, 1.), (3, 1, -1.)],
        "F": [(1, 1, .5), (3, 1, -.5), (2, 2, .5), (3, 2, -.5)],
        "G": [(2, 2, .5), (1, 2, -.5), (3, 3, .5), (2, 3, -.5)],
        "final_all": [(3, 1, 1/3), (3, 2, 1/3), (3, 3, 1/3)],
    }
    draws = np.random.Generator(np.random.PCG64(20260930)).integers(0, 20, size=(5000, 3, 20))
    freq = [np.asarray([np.bincount(row, minlength=20) for row in draws[:, d]]) for d in range(3)]
    rows = [[i for i, d in enumerate(domains) if d == label] for label in "ABC"]

    def field(arm, role, endpoint):
        target = np.zeros((3, 3, 20, 22))
        for oi, order in enumerate(orders):
            for stage, arrival, weight in terms[endpoint]:
                key = f"{order}_shared" if stage == 1 else f"{order}_{arm}_stage{stage}"
                views = new[key] if arm == "risk" and stage > 1 else old[key]
                if role == "primary":
                    values = views["stage-cal"].copy()
                    values[:, ranks] = views["raw"][:, ranks]
                else:
                    values = views[role]
                di = "ABC".index(order[arrival - 1])
                target[oi, di] += weight * values[rows[di]]
        if endpoint in ("F_first", "F", "G"):
            target[..., errors] *= -1
        return target

    def summarize(values):
        by_order = values.sum(axis=1).mean(axis=1)
        expected_mean = by_order.mean(axis=0)
        averaged = values.mean(axis=0)
        boot = sum(freq[d] @ averaged[d] / 20 for d in range(3))
        ordered = np.sort(boot, axis=0)
        bounds = []
        for q in (.025, .975):
            at = q * 4999
            lo = int(np.floor(at)); weight = at - lo
            bounds.append(ordered[lo] * (1 - weight) + ordered[min(lo+1, 4999)] * weight)
        return expected_mean, by_order, np.asarray(bounds)

    actual_results = actual.evaluate_matrices(new, old, domains, p)
    max_error = 0.
    checked = 0
    fields = {}

    def compare_summary(got, v):
        nonlocal max_error, checked
        mean, by_order, bounds = summarize(v)
        for ci, name in enumerate(columns):
            expected = [mean[ci], *by_order[:, ci], *bounds[:, ci]]
            observed = [got[name]["mean"], *[got[name]["per_order"][o] for o in orders],
                        *got[name]["conditional_95pct_interval"]]
            error = float(np.max(np.abs(np.asarray(expected) - observed)))
            max_error = max(max_error, error); checked += len(expected)
            np.testing.assert_allclose(observed, expected, atol=5e-15, rtol=0)

    for arm in arms:
        fields[arm] = {}
        for role in [*roles, "primary"]:
            fields[arm][role] = {}
            for endpoint in terms:
                f = field(arm, role, endpoint)
                fields[arm][role][endpoint] = f
                compare_summary(actual_results["endpoints"][arm][role][endpoint], f)

    expected_pairs = {f"risk_minus_{a}" for a in ["logit_tenth", "tenth", "seq", "logit_quarter"]}
    assert set(actual_results["comparisons"]) == expected_pairs
    assert "selection" not in actual_results
    assert set(actual_results["method_checks"]) == {"logit_tenth", "tenth", "seq", "logit_quarter"}
    for reference in ["logit_tenth", "tenth", "seq", "logit_quarter"]:
        result = actual_results["comparisons"]["risk_minus_" + reference]
        for endpoint in terms:
            compare_summary(result["primary"][endpoint], fields["risk"]["primary"][endpoint]
                            - fields[reference]["primary"][endpoint])
        for endpoint in ("O", "N"):
            compare_summary(result["against_raw_reference"][endpoint], fields["risk"]["primary"][endpoint]
                            - fields[reference]["raw"][endpoint])
        assert len(result["interpretation"]["checks"]) == 23

    dump(out / "evaluation_arithmetic.json", {"passed": True, "checked_scalars": checked,
        "max_absolute_error": max_error, "comparisons": sorted(expected_pairs),
        "endpoint_names": list(terms), "methods": arms, "roles": [*roles, "primary"],
        "bootstrap": "independent actual-domain frequency matrices and hand linear order-statistic interpolation"})
    print(json.dumps({"event": "independent_evaluation_arithmetic", "passed": True,
                      "checked_scalars": checked, "max_absolute_error": max_error}))

    # Actual collection over 60 handwritten labels/score rows. No tokenizer/model.
    cliques = [i for i, count in enumerate([3] * 4 + [2] * 8) for _ in range(count)]
    labels = tuple(int(cliques[i] == cliques[j]) for i, j in itertools.combinations(range(28), 2))
    labelled = [SimpleNamespace(uid=uid, labels=labels) for uid in ids]
    partition = {"development": [{"group_uid": uid, "domain": domain} for uid, domain in zip(ids, domains)]}
    score_inputs = {}
    rng = np.random.default_rng(76103)
    for pi, point in enumerate(method.expected_points(p)):
        z = (rng.normal(-1, 1, (60, 378)) + np.asarray(labels)[None, :] * 1.2 + pi * .02).astype(np.float32)
        score_inputs[point] = {"raw": z, "stage-cal": .8*z.astype(np.float64)-.1,
                               "first-cal": 1.1*z.astype(np.float64)+.2}
    np.savez(out / "handwritten_collection_scores.npz", **{
        point + "__" + role: values for point, role_values in score_inputs.items() for role, values in role_values.items()})
    dump(out / "handwritten_collection_labels.json", {"group_ids": ids, "labels": labels,
        "scope": "Labels constructed from twelve handwritten cliques, no formal data"})
    source_files = method.sources(p)
    collected = runner.collect(out / "actual_collection", score_inputs, labelled, partition, source_files, p)
    assert collected["status"] == "ALL_18_RISK_REPLAY_MATRICES_SAVED_BEFORE_COMPARISONS"
    assert len(collected["points"]) == 6
    arrays, counts = actual.read_points(out / "actual_collection", collected, method.expected_points(p))
    assert sum(len(views) for views in arrays.values()) == 18
    for views in arrays.values():
        for matrix in views.values():
            assert matrix.shape == (60, 22) and matrix.dtype == np.float64
    for views in counts.values():
        for group_counts in views.values():
            assert len(group_counts) == 60
            assert all(g["tp"]+g["fn"] == 20 and g["fp"]+g["tn"] == 358 for g in group_counts)
    dump(out / "collection_check.json", {"passed": True, "points": 6, "metric_count_sets": 18,
        "matrix_shape": [60,22], "total_matrix_count_payloads": 36,
        "scope": "actual collect/read_points on handwritten scores/labels; zero training/checkpoint endpoints"})
    print(json.dumps({"event": "actual_handwritten_collection", "passed": True, "points": 6, "sets": 18}))

    # A file-pipeline check after comparator resolution. The comparator identity
    # resolver and baseline are intentionally mocked, never claimed as audited by this test.
    def write_marker_collection(root, source):
        root.mkdir(parents=True)
        collection = {"group_ids": ids, "domains": domains, "metric_columns": columns, "points": {}}
        c = [{"tp": 10, "fn": 10, "fp": 20, "tn": 338} for _ in ids]
        for point, views in source.items():
            collection["points"][point] = {}
            for role, matrix in views.items():
                arr_path = root / (point + "_" + role + ".npy")
                np.save(arr_path, matrix)
                count_path = root / (point + "_" + role + "_counts.json")
                dump(count_path, c)
                collection["points"][point][role] = {"matrix": record(arr_path, root), "counts": record(count_path, root)}
        dump(root / "collected.json", collection)
        return collection

    baseline_dir = out / "marker_baseline" / "evaluation"
    baseline_collection = write_marker_collection(baseline_dir, {
        k: v for k,v in old.items() if "_shared" in k or "_seq_" in k})
    references = {}
    resolved = copy.deepcopy(p)
    resolved.pop("pending_logit_reference")
    for arm in ["tenth", "logit_quarter", "logit_tenth"]:
        directory = out / ("marker_" + arm) / "evaluation"
        collection = write_marker_collection(directory, {k:v for k,v in old.items() if "_"+arm+"_" in k})
        references[arm] = {"job": directory.parent, "collected": collection}
        resolved.setdefault("continuation_references", {}).setdefault(arm, {})["records"] = {
            "evaluation/collected.json": record(directory/"collected.json",directory)}
    binding = {"collected": baseline_collection, "continuation_references": references}
    with mock.patch.object(study, "resolve_comparator", return_value=resolved), \
            mock.patch.object(method, "baseline", return_value=binding), \
            mock.patch.object(method.base.public, "attach_labels", side_effect=AssertionError("No label re-read in finalize")), \
            mock.patch.object(method.base, "load_model", side_effect=AssertionError("No model in finalize")):
        final = actual.finalize(out/"actual_collection", baseline_dir, p)
    assert final["status"] == "COMPLETE_RISK_REPLAY_DEVELOPMENT_COMPARISON"
    assert final["new_metric_count_sets"] == 18
    assert final["reused_metric_count_sets"] == 81
    assert set(final["comparisons"]) == expected_pairs
    assert len(list((out/"actual_collection/reference").glob("*.npy"))) == 81
    assert len(list((out/"actual_collection/reference").glob("*_counts.json"))) == 81
    assert len((out/"actual_collection/stage_metrics.csv").read_text().splitlines()) == 8911
    dump(out / "finalize_pipeline_check.json", {"passed": True, "new_sets": 18, "reused_sets": 81,
        "stage_table_data_rows": 8910, "comparisons": sorted(expected_pairs),
        "mocked": ["pending comparator resolver", "prior source/state identity baseline binding"],
        "real": ["collection", "saved matrix/count read", "reference copy", "evaluation arithmetic", "stage CSV/output JSON"],
        "formal_label_reads": 0, "model_loads": 0, "training_updates": 0,
        "warning": "Not a real prior result binding or formal six-endpoint test"})
    print(json.dumps({"event": "saved_file_finalize_pipeline", "passed": True,
                      "new_sets": 18, "reused_sets": 81, "mocked_binding": True}))
    print("ALL INDEPENDENT EVALUATION/COLLECTION CHECKS PASSED")


if __name__ == "__main__":
    main()
