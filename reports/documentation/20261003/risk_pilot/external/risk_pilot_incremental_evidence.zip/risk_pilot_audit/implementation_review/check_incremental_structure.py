"""Independent source-delta and old/new raw native-evidence comparison.
Read-only attachment inspection. No formal data/model loaders or training calls.
"""
import ast
import hashlib
import json
from pathlib import Path

OLD=Path('/workspace/scratch/ae1bf546d06e/risk_audit/input')
NEW=Path('/workspace/scratch/ae1bf546d06e/risk_pilot_audit/input')
OUT=Path(__file__).resolve().parent

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def defs(path):
    root=ast.parse(path.read_text(encoding='utf-8'))
    return {node.name:ast.dump(node,include_attributes=False) for node in root.body
            if isinstance(node,(ast.FunctionDef,ast.ClassDef))}

before=defs(OLD/'scripts/step28_risk_replay.py')
after=defs(NEW/'scripts/step28_risk_replay.py')
unchanged=['query_risks','validate_reference','make_reference','distribution_penalty','RiskMemory','train_stage']
checks={f'unmodified_math_or_lifecycle:{name}':before[name]==after[name] for name in unchanged}
checks['update_has_a_source_change']=before['update']!=after['update']
for name in ('step28_bge_continual.py','step28_chinese_base.py','step28_alias_ranking.py',
             'step28_continual_population.py','step28_continual_population_data.py'):
    checks['unmodified_dependency:'+name]=digest(OLD/'scripts'/name)==digest(NEW/'scripts'/name)

old_native=json.loads((OLD/'reports/documentation/20261003/risk_replay/evidence/native.json').read_text())['native']
new_native=json.loads((NEW/'reports/documentation/20261003/risk_pilot/cpu/native.json').read_text())
for key in ('actual_native_updates','counter_fixture','independent_scalar_retention','parameter_digests',
            'reference_fixture','retention_gradient_decomposition'):
    checks['native_preserved_raw_evidence:'+key]=old_native[key]==new_native[key]
for arm in ('zero','risk'):
    for key,value in old_native['updates'][arm].items():
        checks[f'native_old_scalar_unchanged:{arm}:{key}']=new_native['updates'][arm][key]==value
    checks['native_observation_present:'+arm]=bool(new_native['updates'][arm]['modules'])
    checks['native_head_diagnostic_present:'+arm]='head_gradient_diagnostics' in new_native['updates'][arm]

mutants=json.loads((NEW/'reports/documentation/20261003/risk_pilot/cpu/mutants/result.json').read_text())
for name in ('stage_gamma_zero','reference_rows_reversed'):
    row=mutants[name]
    checks['submitted_mutant_expected_assertion:'+name]=(row['run'],row['failures'],row['errors'],row['detected'])==(1,1,0,True)

result={'scope':'read_only_attachment_AST_and_raw_evidence; not a new native execution',
        'checks':checks,'all_pass':all(checks.values()),
        'old_risk_source_sha256':digest(OLD/'scripts/step28_risk_replay.py'),
        'new_risk_source_sha256':digest(NEW/'scripts/step28_risk_replay.py'),
        'old_native_actual_updates':old_native['actual_native_updates'],
        'new_native_actual_updates':new_native['actual_native_updates']}
(OUT/'structure_check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
raise SystemExit(0 if result['all_pass'] else 1)
