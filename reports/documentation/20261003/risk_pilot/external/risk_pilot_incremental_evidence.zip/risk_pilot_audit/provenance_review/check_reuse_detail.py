"""Read-only supplemental AST and evidence-value checks, Python standard library only."""
from pathlib import Path
import ast
import copy
import hashlib
import json

BASE = Path(__file__).resolve().parents[1]
ROOT = BASE / "input"
OLD = BASE.parent / "risk_audit/input"
R = ROOT / "reports/documentation/20261003/risk_pilot"
OUT = Path(__file__).resolve().parent
result = {}

def emit(k, v):
    result[k] = v
    print(k + "=" + json.dumps(v, ensure_ascii=False, sort_keys=True))

def defs(p):
    return {n.name: ast.dump(n, include_attributes=False) for n in ast.parse(p.read_text()).body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}

old_defs = defs(OLD / "scripts/step28_risk_replay.py")
new_defs = defs(ROOT / "scripts/step28_risk_replay.py")
emit("risk_code_ast_delta", {"unchanged": sorted(k for k in old_defs.keys() & new_defs.keys() if old_defs[k] == new_defs[k]), "changed": sorted(k for k in old_defs.keys() & new_defs.keys() if old_defs[k] != new_defs[k]), "added": sorted(new_defs.keys()-old_defs.keys()), "removed": sorted(old_defs.keys()-new_defs.keys())})
emit("native_probe_entire_file_unchanged_from_prior_review", (OLD / "scripts/step28_risk_replay_check.py").read_bytes() == (ROOT / "scripts/step28_risk_replay_check.py").read_bytes())
old_native = json.loads((OLD / "reports/documentation/20261003/risk_replay/evidence/native.json").read_text())["native"]
new_native = json.loads((R / "cpu/native.json").read_text())
without_observations = copy.deepcopy(new_native)
added_keys = {}
for mode, row in without_observations["updates"].items():
    added_keys[mode] = sorted(row.keys() - old_native["updates"][mode].keys())
    for k in added_keys[mode]:
        del row[k]
emit("native_observation_only_new_keys", added_keys)
emit("native_previous_all_values_exact_after_removing_only_new_observations", without_observations == old_native)

# Execute the exact supplied record() and sha256() functions with independent
# temporary path arguments. The relative/absolute mismatch fails before I/O.
tree = ast.parse((ROOT / "scripts/step28_continual_population_data.py").read_text())
selected = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in ("record", "sha256")]
ns = {"Path": Path, "hashlib": hashlib}
exec(compile(ast.Module(body=selected, type_ignores=[]), "<supplied-record-and-sha256>", "exec"), ns)
relative = Path("reports/documentation/20261003/risk_pilot/cpu_attempt1/evidence/audit.json")
try:
    ns["record"](relative, ROOT)
except ValueError as e:
    emit("reproduced_relative_absolute_receipt_failure", str(e))
else:
    raise AssertionError("The recorded failure was not reproduced")
fixed = ns["record"](ROOT / relative, ROOT)
emit("corrected_absolute_receipt", fixed)
parent = json.loads((R / "cpu/audit.json").read_text())["source_registry_rebinding"]["native_reused_from"]
emit("corrected_receipt_same_audit_bytes_and_digest", all(fixed[k] == parent[k] for k in ("bytes", "sha256")))
emit("limitations", ["No new Torch/BGE execution; this verifies supplied origin identity and compatibility only", "Original shell/stdin programs for rebinding and mutant subprocess harness are not included; failure/source alignment is checked, not backend authenticity", "No scientific inference from file digests"])
(OUT / "reuse_detail.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print("REUSE_DETAIL_COMPLETED")
