"""Independent, stdlib-only read-only provenance checks; no model or formal input loading."""
from pathlib import Path
import ast
import copy
import difflib
import hashlib
import io
import json
import re
import sys
import types
import zipfile

BASE = Path(__file__).resolve().parents[1]
ROOT = BASE / "input"
REPORT = ROOT / "reports/documentation/20261003/risk_pilot"
OUT = Path(__file__).resolve().parent
OLD = BASE.parent / "risk_audit"
findings = {}

def digest(b):
    return hashlib.sha256(b).hexdigest()

def record(p, root=ROOT):
    b = p.read_bytes()
    return {"path": p.relative_to(root).as_posix(), "bytes": len(b), "sha256": digest(b)}

def read(p):
    return json.loads(p.read_text())

def verify(p, r):
    b = p.read_bytes()
    if len(b) != r["bytes"] or digest(b) != r["sha256"]:
        raise ValueError("File identity mismatch: " + str(p))
    return p

def manifest_check(rows, get):
    bad = []
    for r in rows:
        try:
            b = get(r["path"])
            if len(b) != r["bytes"] or digest(b) != r["sha256"]:
                bad.append({"path": r["path"], "actual_bytes": len(b), "actual_sha256": digest(b), "expected": r})
        except Exception as e:
            bad.append({"path": r["path"], "error": repr(e)})
    return {"count": len(rows), "mismatches": bad}

def emit(k, v):
    findings[k] = v
    print(k + "=" + json.dumps(v, ensure_ascii=False, sort_keys=True))

review = read(REPORT / "review_inventory.json")
emit("review_inventory", manifest_check(review, lambda n: (ROOT / n).read_bytes()))
actual_review_files = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob("*") if p.is_file()}
emit("review_unlisted_files", sorted(actual_review_files - {r["path"] for r in review}))
deploy_rows = read(REPORT / "deploy_inventory.json")
deploy_blob = (REPORT / "deploy.zip").read_bytes()
with zipfile.ZipFile(io.BytesIO(deploy_blob)) as z:
    deploy = {n: z.read(n) for n in z.namelist() if not n.endswith("/")}
emit("deploy_zip", {"bytes": len(deploy_blob), "sha256": digest(deploy_blob), "members": len(deploy), "zip_crc_test": z.testzip() if False else "CRC checked while reading all members"})
emit("deploy_inventory_vs_zip", manifest_check(deploy_rows, deploy.__getitem__))
emit("deploy_inventory_vs_outer", manifest_check(deploy_rows, lambda n: (ROOT / n).read_bytes()))
emit("deploy_manifest_members", {"unlisted": sorted(set(deploy) - {r["path"] for r in deploy_rows}), "missing": sorted({r["path"] for r in deploy_rows} - set(deploy))})
different = []
for name, old in deploy.items():
    new = (ROOT / name).read_bytes()
    if old != new:
        different.append(name)
        patch = ''.join(difflib.unified_diff(old.decode().splitlines(keepends=True), new.decode().splitlines(keepends=True), fromfile="deploy.zip/" + name, tofile="outer/" + name))
        (OUT / (Path(name).name + ".deploy_to_outer.diff")).write_text(patch)
emit("deploy_vs_outer_different_paths", different)

attempt_rows = read(REPORT / "cpu_attempt1_inventory.json")
emit("cpu_attempt1_inventory", manifest_check(attempt_rows, lambda n: (REPORT / "cpu_attempt1" / n).read_bytes()))
prior = read(REPORT / "cpu_attempt1/evidence/audit.json")
current = read(REPORT / "cpu/audit.json")
emit("native_exact_reuse", (REPORT / "cpu/native.json").read_bytes() == (REPORT / "cpu_attempt1/evidence/native.json").read_bytes())
emit("current_native_binding", manifest_check(list(current["native"].values()), lambda n: (REPORT / "cpu" / n).read_bytes()))
emit("attempt_source_vs_deploy", manifest_check(prior["source_files"], deploy.__getitem__))
emit("final_source_vs_outer", manifest_check(current["source_files"], lambda n: (ROOT / n).read_bytes()))
prior_map = {r["path"]: r for r in prior["source_files"]}
current_map = {r["path"]: r for r in current["source_files"]}
emit("source_registry_delta", {"removed": sorted(prior_map.keys() - current_map.keys()), "added": sorted(current_map.keys() - prior_map.keys()), "changed": sorted(n for n in prior_map.keys() & current_map.keys() if prior_map[n] != current_map[n])})
expected_native_reuse = current["source_registry_rebinding"]["native_reused_from"]
emit("native_reuse_parent_binding", {"matches_attempt_audit": (expected_native_reuse["bytes"] == (REPORT / "cpu_attempt1/evidence/audit.json").stat().st_size and expected_native_reuse["sha256"] == digest((REPORT / "cpu_attempt1/evidence/audit.json").read_bytes())), "path_is_origin_workspace_relative": expected_native_reuse["path"]})

# Execute only the supplied sources() and verify_audit() ASTs using independent
# stdlib file adapters. No project import, NumPy, Torch, model, or data is loaded.
data = types.SimpleNamespace(ROOT=ROOT, record=record, read_json=read, verify=verify)
def load_functions(text, names, namespace):
    tree = ast.parse(text)
    chosen = [n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name in names]
    assert {n.name for n in chosen} == set(names)
    exec(compile(ast.Module(body=chosen, type_ignores=[]), "<source-extracted-functions>", "exec"), namespace)
    return namespace
base_ns = load_functions((ROOT / "scripts/step28_bge_continual_run.py").read_text(), ["sources"], {"data": data})
paired = types.SimpleNamespace(prior=types.SimpleNamespace(sources=base_ns["sources"]))
new_ns = load_functions((ROOT / "scripts/step28_risk_study.py").read_text(), ["sources", "verify_audit"], {"data": data, "paired": paired})
actual_sources = new_ns["sources"]()
emit("actual_sources_function_matches_final_audit", actual_sources == current["source_files"])
new_ns["verify_audit"](current, REPORT / "cpu/audit.json", actual_sources)
emit("final_audit_gate_on_outer_sources", "PASS")

def deploy_record(p, root=ROOT):
    n = p.relative_to(root).as_posix()
    b = deploy[n]
    return {"path": n, "bytes": len(b), "sha256": digest(b)}
deploy_data = types.SimpleNamespace(ROOT=ROOT, record=deploy_record)
dep_base_ns = load_functions(deploy["scripts/step28_bge_continual_run.py"].decode(), ["sources"], {"data": deploy_data})
dep_paired = types.SimpleNamespace(prior=types.SimpleNamespace(sources=dep_base_ns["sources"]))
dep_ns = load_functions(deploy["scripts/step28_risk_study.py"].decode(), ["sources"], {"data": deploy_data, "paired": dep_paired})
deploy_sources = dep_ns["sources"]()
emit("actual_deploy_sources_match_attempt_audit", deploy_sources == prior["source_files"])
try:
    new_ns["verify_audit"](current, REPORT / "cpu/audit.json", deploy_sources)
except ValueError as e:
    emit("final_audit_gate_on_deploy_sources", {"status": "REJECTED", "exception": str(e)})
else:
    raise AssertionError("Expected final audit/deploy mismatch was not rejected")

native = read(REPORT / "cpu/native.json")
emit("native_scope", {k: native[k] for k in ["actual_native_updates", "counter_fixture", "reference_fixture", "retention_gradient_decomposition"]})
for mutant in ["stage_gamma_zero", "reference_rows_reversed"]:
    name = mutant + ".py"
    a = (ROOT / "scripts/step28_risk_replay.py").read_text()
    b = (REPORT / "cpu/mutants" / name).read_text()
    d = ''.join(difflib.unified_diff(a.splitlines(keepends=True), b.splitlines(keepends=True), fromfile="current/step28_risk_replay.py", tofile="mutant/" + name))
    (OUT / (name + ".diff")).write_text(d)
    stderr = (REPORT / "cpu/mutants" / (mutant + ".stderr")).read_text()
    emit("mutant_" + mutant, {"diff": d, "one_test_failed_no_errors": "Ran 1 test" in stderr and "FAILED (failures=1)" in stderr and "ERROR:" not in stderr})

test_names = []
for name in ["test_step28_risk_replay.py", "test_step28_risk_execution.py"]:
    t = ast.parse((ROOT / "tests" / name).read_text())
    test_names.extend(name + "::" + n.name for n in ast.walk(t) if isinstance(n, ast.FunctionDef) and n.name.startswith("test_"))
emit("ten_distinct_test_methods", test_names)
initial_err = (REPORT / "cpu_attempt1/stderr.txt").read_text()
rebind_err = (REPORT / "cpu/rebinding.stderr").read_text()
emit("cpu_receipts", {"initial_tests": re.search(r"Ran \d+ tests in [\d.]+s", initial_err).group(), "initial_exit": (REPORT / "cpu_attempt1/exit.txt").read_text().strip(), "rebinding_tests": re.search(r"Ran \d+ tests in [\d.]+s", rebind_err).group(), "rebinding_exit": (REPORT / "cpu/rebinding.exit").read_text().strip(), "rebinding_failed_after_tests_ok": rebind_err.index("\nOK\n") < rebind_err.index("Traceback"), "binding_fixed_exit": (REPORT / "cpu/binding_fixed.exit").read_text().strip(), "binding_fixed_stderr_bytes": (REPORT / "cpu/binding_fixed.stderr").stat().st_size})
resource = (REPORT / "cpu_attempt1/resource.log").read_text()
rss_kib = int(re.search(r"Maximum resident set size \(kbytes\): (\d+)", resource).group(1))
emit("cpu_budget", {"reported_program_seconds": prior["seconds"], "rss_bytes": rss_kib * 1024, "rss_less_than_32GiB": rss_kib * 1024 < 32 * 1024**3, "elapsed": re.search(r"Elapsed .*?: (.+)", resource).group(1), "timeout_45m_present": "45m taskset -c 46" in resource, "all_supplied_cpu_evidence_bytes": sum(p.stat().st_size for d in [REPORT / "cpu", REPORT / "cpu_attempt1"] for p in d.rglob("*") if p.is_file()), "affinity": prior["cpu_affinity"], "gpu_used": "not independently measurable retrospectively; entry rejects torch.cuda.is_available()"})

embedded_report = ROOT / "reports/documentation/20261003/risk_replay/external/risk_audit/deliverables/report.zh.txt"
embedded_zip = ROOT / "reports/documentation/20261003/risk_replay/external/risk_replay_independent_review_evidence.zip"
emit("prior_review_report_byte_identical", embedded_report.read_bytes() == (OLD / "deliverables/report.zh.txt").read_bytes())
emit("prior_review_zip_byte_identical", embedded_zip.read_bytes() == (OLD / "deliverables/risk_replay_independent_review_evidence.zip").read_bytes())
common_changed, common_same = [], []
for p in ROOT.rglob("*"):
    if not p.is_file() or p.suffix not in (".py", ".sh", ".json", ".md"):
        continue
    rel = p.relative_to(ROOT)
    old = OLD / "input" / rel
    if old.is_file():
        (common_same if old.read_bytes() == p.read_bytes() else common_changed).append(rel.as_posix())
        if old.read_bytes() != p.read_bytes() and p.suffix in (".py", ".sh"):
            d = ''.join(difflib.unified_diff(old.read_text().splitlines(keepends=True), p.read_text().splitlines(keepends=True), fromfile="prior_review/" + str(rel), tofile="pilot/" + str(rel)))
            (OUT / (p.name + ".prior_to_pilot.diff")).write_text(d)
emit("prior_input_common_files", {"unchanged": sorted(common_same), "changed": sorted(common_changed)})
git_diff = (REPORT / "implementation.diff").read_text()
emit("implementation_diff_listed_paths", re.findall(r"^diff --git a/(\S+) b/\S+$", git_diff, re.M))
emit("scope", {"stdlib_only": True, "input_modified": False, "model_loaded": False, "formal_data_accessed": False, "training_started": False, "hashes_used_only_for_identity": True})
(OUT / "findings.json").write_text(json.dumps(findings, ensure_ascii=False, indent=2) + "\n")
print("PROVENANCE_CHECK_COMPLETED: findings include a reproduced deployment-source mismatch; exit 0 means checker completed, not scientific approval.")
