#!/usr/bin/env python3
"""Package retained audit artifacts, preserving input bytes. No scientific execution."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parent
INPUT_ZIP = WORK / 'upload/review(4).zip'
OUT = ROOT / 'deliverables/risk_pilot_incremental_evidence.zip'
RECEIPT = ROOT / 'deliverables/risk_pilot_evidence_receipt.json'
EXPECTED = '654265a64f8a12b0450ad3003d0df1d986f6b88e22921a8ee2cf8be14800f623'

def sha(payload):
    return hashlib.sha256(payload).hexdigest()

if OUT.exists() or RECEIPT.exists():
    raise FileExistsError('Preserve the existing evidence archive/receipt before rebuilding')

input_bytes = INPUT_ZIP.read_bytes()
assert len(input_bytes) == 1575125 and sha(input_bytes) == EXPECTED
payloads = {}

def add(path, archive_name):
    if archive_name in payloads:
        raise ValueError('Duplicate member: ' + archive_name)
    if '..' in Path(archive_name).parts or Path(archive_name).is_absolute() or path.is_symlink():
        raise ValueError('Unsafe member: ' + archive_name)
    payloads[archive_name] = path

add(INPUT_ZIP, 'risk_pilot_audit/original_upload/review(4).zip')
with zipfile.ZipFile(INPUT_ZIP) as original:
    assert len(original.infolist()) == 83
    assert original.testzip() is None
    for member in original.infolist():
        assert not member.is_dir()
        actual = ROOT / 'input' / member.filename
        assert original.read(member) == actual.read_bytes(), member.filename
        add(actual, 'risk_pilot_audit/input/' + member.filename)

for name in ['README.zh.txt', 'input_identity.json', 'build_verdict.py', 'build_evidence_pack.py']:
    add(ROOT / name, 'risk_pilot_audit/' + name)

folders = ['independent_reference', 'implementation_review', 'evaluation_review',
           'pending_binding_review', 'listener_review', 'provenance_review',
           'root_startup_review', 'report_builder', 'deliverables']
for folder in folders:
    for path in sorted((ROOT / folder).rglob('*')):
        if not path.is_file():
            continue
        rel = path.relative_to(ROOT)
        if any(part == '__pycache__' or part.startswith('.') for part in rel.parts):
            continue
        if path.suffix == '.pyc' or path == OUT or path == RECEIPT:
            continue
        if folder == 'report_builder' and ('fonts' in rel.parts or path.suffix.lower() in {'.png', '.jpg', '.jpeg'}):
            continue
        add(path, 'risk_pilot_audit/' + rel.as_posix())

# These are exactly the already-reviewed materials needed by cross-turn source
# comparison programs. No prior Torch runtime or other large cache is included.
for path in sorted((WORK / 'risk_audit/input').rglob('*')):
    if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc':
        add(path, 'risk_audit/input/' + path.relative_to(WORK/'risk_audit/input').as_posix())
for name in ['report.zh.txt', 'risk_replay_independent_review_evidence.zip']:
    add(WORK / 'risk_audit/deliverables' / name, 'risk_audit/deliverables/' + name)

rows = []
for name, path in sorted(payloads.items()):
    body = path.read_bytes()
    rows.append({'path': name, 'bytes': len(body), 'sha256': sha(body)})
manifest = {
    'schema': 'independent_risk_pilot_audit_payload_manifest_v1',
    'scope': 'Download integrity only; not scientific correctness evidence',
    'manifest_excludes_itself': True,
    'payload_count': len(rows),
    'payload_uncompressed_bytes': sum(row['bytes'] for row in rows),
    'original_input_sha256': EXPECTED,
    'files': rows,
}
manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2)+'\n').encode()

def entry(name):
    info = zipfile.ZipInfo(name, date_time=(2026, 10, 3, 0, 0, 0))
    info.compress_type = zipfile.ZIP_DEFLATED
    info.create_system = 3
    info.external_attr = (0o100644 << 16)
    return info

with zipfile.ZipFile(OUT, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, path in sorted(payloads.items()):
        archive.writestr(entry(name), path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    archive.writestr(entry('MANIFEST.json'), manifest_bytes, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)

with zipfile.ZipFile(OUT) as archive:
    assert archive.testzip() is None
    assert len(archive.infolist()) == len(rows)+1
    assert len(set(archive.namelist())) == len(archive.namelist())
    for row in rows:
        body = archive.read(row['path'])
        assert len(body) == row['bytes'] and sha(body) == row['sha256'], row['path']
    assert archive.read('risk_pilot_audit/original_upload/review(4).zip') == input_bytes

final_bytes = OUT.read_bytes()
receipt = {
    'file': OUT.name, 'bytes': len(final_bytes), 'members': len(rows)+1,
    'sha256': sha(final_bytes),
    'payload_uncompressed_bytes': manifest['payload_uncompressed_bytes'],
    'all_payload_manifest_entries_verified': True,
    'crc_bad_member': None,
    'original_zip_and_all_83_original_members_unchanged': True,
    'original_zip_sha256': EXPECTED,
    'contents': '8-page PDF and text report, machine verdict, original inputs, independent executed sources/fixtures/full stdout/stderr/exit codes, failed versions, proposed listener and minimal patch',
    'formal_execution_performed': False,
}
RECEIPT.write_text(json.dumps(receipt, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps(receipt, ensure_ascii=False, indent=2))
