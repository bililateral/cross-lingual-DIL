"""Record this isolated handwritten review without overwriting existing outputs."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

root=Path(__file__).resolve().parent
out=root/'run'
out.mkdir(exist_ok=False)
env=dict(os.environ)
env.update(CUDA_VISIBLE_DEVICES='',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',
           MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
command=[sys.executable,str(root/'startup_reference.py')]
(out/'command.json').write_text(json.dumps({'command':command,'cwd':str(root),
    'environment':{k:env.get(k) for k in ('PYTHONPATH','CUDA_VISIBLE_DEVICES','PYTHONDONTWRITEBYTECODE','OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS')}},indent=2))
start=time.monotonic()
with (out/'stdout.txt').open('wb') as stdout,(out/'stderr.txt').open('wb') as stderr:
    process=subprocess.run(command,env=env,cwd=root,stdout=stdout,stderr=stderr)
(out/'exit_code.txt').write_text(str(process.returncode)+'\n')
(out/'execution.json').write_text(json.dumps({'exit_code':process.returncode,'seconds':time.monotonic()-start,
    **{k+'_sha256':hashlib.sha256((out/(k+'.txt')).read_bytes()).hexdigest() for k in ('stdout','stderr')}},indent=2))
print((out/'stdout.txt').read_text())
print((out/'stderr.txt').read_text(),file=sys.stderr)
raise SystemExit(process.returncode)
