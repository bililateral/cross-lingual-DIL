"""Handwritten startup-order check; no GPU, formal input, training or authorization.

All authorization-shaped JSON below is an explicitly synthetic test fixture in
an isolated scratch root. It cannot authorize the real job. Production sources,
the submitted handmade CPU receipt, and its native summary are read only.
"""
from pathlib import Path
import copy
import hashlib
import json
import os
import sys
from unittest import mock

HERE = Path(__file__).resolve().parent
AUDIT = HERE.parent
INPUT = Path(os.environ.get('RISK_PILOT_INPUT', AUDIT/'input')).resolve()
sys.path.insert(0, str(INPUT/'scripts'))
import step28_er_weight as method
import step28_er_weight_run as runner
import step28_risk_study as study
import torch

torch.set_num_threads(1)
p = study.contract()
sources = study.sources()
receipt_path = INPUT/'reports/documentation/20261003/risk_pilot/cpu/audit.json'
receipt = method.data.read_json(receipt_path)
assert receipt['source_files'] == sources
study.verify_audit(receipt, receipt_path, sources)
print('SUBMITTED_FINAL_CPU_SOURCE_BINDING_PASS', len(sources))

fixtures = HERE/'fixtures'
fixtures.mkdir(exist_ok=False)
results = []
for name in ('review_false', 'wrong_source', 'bad_cpu_receipt', 'valid_prerequisites_no_gpu'):
    root = fixtures/name
    root.mkdir()
    job = root/'reports/handwritten_job'
    auth = {
        'status': 'AUTHORIZED_RISK_REPLAY_AFTER_REVIEW',
        'policy_sha256': method.policy_sha256(p),
        'source_files': copy.deepcopy(sources),
        'job': 'reports/handwritten_job',
        'runtime': copy.deepcopy(p['runtime']),
        'supervision': copy.deepcopy(p['supervision']),
        'review_and_primary_passed': True,
        'HANDWRITTEN_FIXTURE_ONLY': 'Never a real formal-job authorization',
    }
    local_receipt = copy.deepcopy(receipt)
    if name == 'review_false':
        auth['review_and_primary_passed'] = False
    elif name == 'wrong_source':
        auth['source_files'][0]['sha256'] = '0'*64
    elif name == 'bad_cpu_receipt':
        local_receipt['status'] = 'NOT_VERIFIED_HANDWRITTEN_FIXTURE'
    auth_path = root/'handwritten_authorization.json'
    cpu_path = root/'handwritten_cpu_audit.json'
    method.data.write_json(auth_path, auth)
    method.data.write_json(cpu_path, local_receipt)
    for rec in local_receipt['native'].values():
        (root/rec['path']).write_bytes((receipt_path.parent/rec['path']).read_bytes())
    events = []
    def no_gpu():
        events.append('gpu_resource_check')
        return False
    def cpu_verify(*args, **kwargs):
        events.append('cpu_audit_verify')
        return original_verify(*args, **kwargs)
    def forbidden(*args, **kwargs):
        events.append('FORBIDDEN_FORMAL_OPERATION')
        raise AssertionError('No formal loader, train, or label parser may be called')
    original_verify = study.verify_audit
    with mock.patch.object(method.data, 'ROOT', root), \
         mock.patch.object(method, 'sources', return_value=sources), \
         mock.patch.object(study, 'verify_audit', side_effect=cpu_verify), \
         mock.patch.object(torch.cuda, 'is_available', side_effect=no_gpu), \
         mock.patch.object(runner, 'train', side_effect=forbidden), \
         mock.patch.object(runner.prior, 'parse_once', side_effect=forbidden), \
         mock.patch.object(method.base.public, 'public_inputs', side_effect=forbidden):
        try:
            runner.execute(job, cpu_path, auth_path, 'risk')
        except (ValueError, RuntimeError) as error:
            actual = type(error).__name__+': '+str(error)
        else:
            raise AssertionError('Synthetic no-GPU case unexpectedly started execution')
    expected_events = {
        'review_false': [],
        'wrong_source': [],
        'bad_cpu_receipt': ['cpu_audit_verify'],
        'valid_prerequisites_no_gpu': ['cpu_audit_verify', 'gpu_resource_check'],
    }[name]
    assert events == expected_events, (name, events)
    assert not job.exists(), name
    row = {'case': name, 'events': events, 'exception': actual,
           'formal_loader_calls': 0, 'train_calls': 0, 'job_created': False,
           'access_record_created': False, 'passed': True}
    results.append(row)
    print(json.dumps(row, ensure_ascii=False))
out = {'source': str(INPUT), 'torch': torch.__version__, 'python': sys.version,
       'scope': 'Synthetic startup prerequisites and call order only; no real approval or GPU availability claim',
       'final_cpu_sources': len(sources), 'checks': results, 'all_passed': True}
(HERE/'results.json').write_text(json.dumps(out, ensure_ascii=False, indent=2)+'\n')
print('PASS_FOUR_STARTUP_ORDER_CHECKS')
