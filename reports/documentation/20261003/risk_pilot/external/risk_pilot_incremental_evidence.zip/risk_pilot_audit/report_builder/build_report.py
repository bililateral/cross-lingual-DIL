#!/usr/bin/env python3
"""Build the final Chinese risk-replay review PDF from report.zh.txt.

This file only generates a PDF when run. The authoring marker required by the
PDF skill must be run once by the caller immediately before that first run.
No network, source attachment mutation, or scientific experiment is performed.

Usage:
    python build_report.py
    python build_report.py --input /absolute/report.zh.txt --output /absolute/report.pdf

Input format: first non-empty line is the title; ## and ### are headings;
blank lines delimit paragraphs; code fences and literal list lines are supported.
Long paths, hashes and URLs are allowed to wrap. Local TrueType CJK fonts are
preferred, with MuPDF's bundled Droid Sans Fallback as the embedded-font fallback.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from html import escape
import json
import os
from pathlib import Path
import re
import sys

from reportlab import rl_config
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    BaseDocTemplate, Frame, HRFlowable, PageTemplate, Paragraph, Spacer,
)

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_INPUT = ROOT / "deliverables/report.zh.txt"
DEFAULT_OUTPUT = ROOT / "deliverables/risk_replay_review.zh.pdf"
FONT_DIR = Path(__file__).resolve().parent / "fonts"
INK = colors.HexColor("#182631")
NAVY = colors.HexColor("#193F56")
MUTED = colors.HexColor("#52636F")
RULE = colors.HexColor("#B9CBD4")
PAPER_NOTE = colors.HexColor("#F3F6F8")
MATH_DASHES = str.maketrans({"\u2010": "-", "\u2011": "-", "\u2012": "-",
                           "\u2013": "-", "\u2014": "-", "\u2212": "-"})
URL = re.compile(r"https?://[^\s<>]+")
BULLET = re.compile(r"^(?:[-*]\s+|\d+[.)、]\s*|[（(]\d+[)）]\s*)")


@dataclass
class Fonts:
    cjk_name: str
    cjk_path: Path
    cjk_map: set[int]
    latin_name: str
    latin_path: Path
    latin_map: set[int]


def character_map(path: Path) -> set[int]:
    from fontTools.ttLib import TTFont as FontToolsTTFont
    font = FontToolsTTFont(str(path), lazy=True)
    try:
        return set(font.getBestCmap() or {})
    finally:
        font.close()


def select_cjk_font() -> Path:
    explicit = os.environ.get("RISK_REVIEW_CJK_FONT")
    candidates = ([Path(explicit)] if explicit else []) + [
        Path("/usr/share/fonts/truetype/noto/NotoSansSC-Regular.ttf"),
        Path("/usr/share/fonts/truetype/noto/NotoSansCJKsc-Regular.ttf"),
        Path("/usr/share/fonts/truetype/wqy/wqy-zenhei.ttf"),
        Path("/usr/share/fonts/truetype/arphic/uming.ttf"),
        FONT_DIR / "DroidSansFallback.ttf",
    ]
    for candidate in candidates:
        if candidate.is_file() and {ord("中"), ord("文"), ord("审")} <= character_map(candidate):
            return candidate
    # PyMuPDF ships a complete, reusable CJK font in its native resources even
    # when fontconfig has no CJK fonts. Extracting that resource is fully local.
    import fitz
    bundled = fitz.Font(fontname="cjk")
    if not all(bundled.has_glyph(ord(ch)) for ch in "中文审查风险卖家"):
        raise RuntimeError("Bundled CJK font does not cover required Chinese text")
    FONT_DIR.mkdir(parents=True, exist_ok=True)
    target = FONT_DIR / "DroidSansFallback.ttf"
    target.write_bytes(bundled.buffer)
    return target


def register_fonts() -> Fonts:
    cjk_path = select_cjk_font()
    latin_path = Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf")
    if not latin_path.is_file():
        runtime = Path(os.environ.get("CODEX_PRIMARY_RUNTIME_ROOT", "/opt/codex/runtimes/codex-primary-runtime"))
        latin_path = runtime / "dependencies/native/poppler/poppler/fonts/DejaVuSans.ttf"
    if not latin_path.is_file():
        raise FileNotFoundError("A local DejaVuSans TTF is required for mathematical symbols")
    pdfmetrics.registerFont(TTFont("ReviewCJK", str(cjk_path)))
    pdfmetrics.registerFont(TTFont("ReviewLatin", str(latin_path)))
    # Chinese emphasis uses size/color and hierarchy. Mapping bold to the same
    # genuine CJK face avoids silently switching Chinese text to a Latin font.
    pdfmetrics.registerFontFamily("ReviewCJK", normal="ReviewCJK", bold="ReviewCJK",
                                  italic="ReviewCJK", boldItalic="ReviewCJK")
    pdfmetrics.registerFontFamily("ReviewLatin", normal="ReviewLatin", bold="ReviewLatin",
                                  italic="ReviewLatin", boldItalic="ReviewLatin")
    return Fonts("ReviewCJK", cjk_path, character_map(cjk_path),
                 "ReviewLatin", latin_path, character_map(latin_path))


def normalize_source(text: str) -> str:
    return text.replace("\r\n", "\n").replace("\r", "\n").translate(MATH_DASHES)


def font_markup(text: str, fonts: Fonts) -> str:
    parts: list[str] = []
    current_font: str | None = None
    run: list[str] = []
    def flush() -> None:
        if run:
            parts.append(f'<font name="{current_font}">{escape("".join(run))}</font>')
            run.clear()
    for character in text:
        cp = ord(character)
        if character == "\t":
            character, cp = " ", 32
        if cp < 128 or cp in fonts.cjk_map:
            selected = fonts.cjk_name
        elif cp in fonts.latin_map:
            selected = fonts.latin_name
        else:
            raise ValueError(f"No embedded font covers U+{cp:04X} {character!r}; edit font coverage, not content")
        if selected != current_font:
            flush()
            current_font = selected
        run.append(character)
    flush()
    return "".join(parts)


def inline_markup(text: str, fonts: Fonts) -> str:
    result: list[str] = []
    index = 0
    for match in URL.finditer(text):
        result.append(font_markup(text[index:match.start()], fonts))
        token = match.group(0)
        address = token.rstrip("。，；、）)]}")
        suffix = token[len(address):]
        # Escaped link targets retain the exact URL; wordWrap=CJK makes the
        # displayed characters splittable without inserting literal spaces.
        result.append(f'<link href="{escape(address, quote=True)}" color="#245E7B">'
                      f'{font_markup(address, fonts)}</link>')
        result.append(font_markup(suffix, fonts))
        index = match.end()
    result.append(font_markup(text[index:], fonts))
    return "".join(result)


def paragraph_markup(lines: list[str], fonts: Fonts, preserve_indent: bool = False) -> str:
    output: list[str] = []
    for line in lines:
        if preserve_indent:
            count = len(line) - len(line.lstrip(" "))
            output.append("&nbsp;" * count + inline_markup(line[count:], fonts))
        else:
            output.append(inline_markup(line.strip(), fonts))
    return "<br/>".join(output)


def make_styles(fonts: Fonts) -> dict[str, ParagraphStyle]:
    common = dict(fontName=fonts.cjk_name, textColor=INK, wordWrap="CJK",
                  alignment=TA_LEFT, allowWidows=0, allowOrphans=0,
                  splitLongWords=1, hyphenationLang=None)
    body = ParagraphStyle("Body", fontSize=10.2, leading=16.6, spaceAfter=7.2, **common)
    return {
        "title": ParagraphStyle("Title", fontSize=22, leading=31, spaceBefore=3,
                                spaceAfter=18, keepWithNext=1, **{**common, "textColor": NAVY}),
        "h2": ParagraphStyle("Heading2", fontSize=14.5, leading=21.5, spaceBefore=16,
                             spaceAfter=9, keepWithNext=1, **{**common, "textColor": NAVY}),
        "h3": ParagraphStyle("Heading3", fontSize=11.7, leading=18.5, spaceBefore=10,
                             spaceAfter=6, keepWithNext=1, **{**common, "textColor": NAVY}),
        "body": body,
        "list": ParagraphStyle("List", parent=body, leftIndent=8, firstLineIndent=0,
                               spaceAfter=6),
        "code": ParagraphStyle("Code", fontSize=8.6, leading=13.5, spaceBefore=4,
                               spaceAfter=7, leftIndent=7, rightIndent=7,
                               backColor=PAPER_NOTE, borderPadding=6, **common),
    }


class ReviewDocument(BaseDocTemplate):
    def __init__(self, filename: str, *, title: str, fonts: Fonts):
        width, height = A4
        self.review_title = title
        self.review_fonts = fonts
        self.current_section = "固定开发点接入增量外审"
        self.heading_count = 0
        self.last_outline_level = 0
        self.seen_sections: list[dict] = []
        super().__init__(filename, pagesize=A4,
                         leftMargin=19 * mm, rightMargin=18 * mm,
                         topMargin=23 * mm, bottomMargin=21 * mm,
                         title=title, author="Independent scientific review",
                         subject="群体风险分布保持重放：固定开发点接入增量审查",
                         creator="ReportLab / local build_report.py",
                         pageCompression=1, allowSplitting=1)
        frame = Frame(self.leftMargin, self.bottomMargin, self.width, self.height,
                      leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0,
                      id="body")
        self.addPageTemplates([PageTemplate(id="review", frames=[frame], onPage=self.page_decoration)])

    def page_decoration(self, canvas, doc) -> None:
        width, height = A4
        canvas.saveState()
        canvas.setStrokeColor(RULE)
        canvas.setLineWidth(.55)
        canvas.line(self.leftMargin, height - 16.9 * mm, width - self.rightMargin, height - 16.9 * mm)
        canvas.line(self.leftMargin, 15.7 * mm, width - self.rightMargin, 15.7 * mm)
        canvas.setFillColor(MUTED)
        canvas.setFont(self.review_fonts.cjk_name, 8)
        canvas.drawString(self.leftMargin, height - 13.7 * mm, "群体风险分布保持重放 / 正式接入增量外审")
        canvas.setFont(self.review_fonts.latin_name, 7.4)
        canvas.drawRightString(width - self.rightMargin, height - 13.7 * mm, "2026-10-03")
        canvas.setFont(self.review_fonts.cjk_name, 7.7)
        canvas.drawString(self.leftMargin, 10.7 * mm, "正式接入 · 独立核验 · 证据边界")
        canvas.drawRightString(width - self.rightMargin, 10.7 * mm, f"第 {doc.page} 页")
        canvas.restoreState()

    def afterFlowable(self, flowable) -> None:
        if not hasattr(flowable, "_outline_label"):
            return
        label = flowable._outline_label
        requested = flowable._outline_level
        level = min(requested, self.last_outline_level + 1)
        self.heading_count += 1
        key = f"section_{self.heading_count:03d}"
        self.canv.bookmarkPage(key)
        self.canv.addOutlineEntry(label, key, level=level, closed=False)
        self.last_outline_level = level
        self.current_section = label
        self.seen_sections.append({"title": label, "page": self.page, "level": level})


def story_from_text(source: str, fonts: Fonts) -> tuple[str, list]:
    lines = source.splitlines()
    first = next((index for index, value in enumerate(lines) if value.strip()), None)
    if first is None:
        raise ValueError("The final review source is empty")
    title = re.sub(r"^#+\s*", "", lines[first].strip())
    styles = make_styles(fonts)
    title_paragraph = Paragraph(inline_markup(title, fonts), styles["title"])
    title_paragraph._outline_label, title_paragraph._outline_level = title, 0
    story: list = [title_paragraph,
                   HRFlowable(width="100%", thickness=1.5, color=NAVY,
                              spaceAfter=13), Spacer(1, 3)]
    buffer: list[str] = []
    code = False
    def flush() -> None:
        if buffer:
            story.append(Paragraph(paragraph_markup(buffer, fonts, preserve_indent=code),
                                   styles["code" if code else "body"]))
            buffer.clear()
    for raw in lines[first + 1:]:
        line = raw.rstrip()
        if line.lstrip().startswith("```"):
            flush()
            code = not code
            continue
        if not line.strip():
            flush()
            continue
        if code:
            buffer.append(line)
            continue
        matched = re.match(r"^(#{2,})\s*(.+?)\s*$", line)
        if matched:
            flush()
            label = matched.group(2)
            top_level = len(matched.group(1)) == 2
            heading = Paragraph(inline_markup(label, fonts), styles["h2" if top_level else "h3"])
            heading._outline_label, heading._outline_level = label, 1 if top_level else 2
            story.append(heading)
            continue
        if BULLET.match(line):
            flush()
            story.append(Paragraph(inline_markup(line, fonts), styles["list"]))
            continue
        buffer.append(line)
    flush()
    if code:
        raise ValueError("Unclosed code fence in the review source")
    return title, story


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    source_path = args.input.resolve()
    output_path = args.output.resolve()
    if not source_path.is_file():
        raise FileNotFoundError(source_path)
    if output_path.exists():
        raise FileExistsError(f"Preserve the prior PDF before rebuilding: {output_path}")
    source = normalize_source(source_path.read_text(encoding="utf-8"))
    fonts = register_fonts()
    title, story = story_from_text(source, fonts)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    doc = ReviewDocument(str(output_path), title=title, fonts=fonts)
    rl_config.warnOnMissingFontGlyphs = 1
    doc.build(story)
    from pypdf import PdfReader
    reader = PdfReader(str(output_path))
    extracted = "\n".join(page.extract_text() or "" for page in reader.pages)
    if len(reader.pages) < 1 or not extracted.strip():
        raise RuntimeError("Generated PDF is empty or has no extractable text")
    manifest = {
        "input": str(source_path), "output": str(output_path),
        "pages": len(reader.pages), "bytes": output_path.stat().st_size,
        "source_characters": len(source), "extracted_characters": len(extracted),
        "embedded_cjk_font": str(fonts.cjk_path),
        "embedded_symbol_font": str(fonts.latin_path),
        "bookmarks": doc.seen_sections,
        "visual_verification": "REQUIRED: render with pdftoppm and inspect before delivery",
    }
    metadata = output_path.with_suffix(".build.json")
    metadata.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
