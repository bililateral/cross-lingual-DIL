#!/usr/bin/env python3
"""Assemble the incremental audit decision from retained evidence; no experiments."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'deliverables'

def read(path):
    return json.loads((ROOT / path).read_text(encoding='utf-8'))

def identity(path):
    payload = (ROOT / path).read_bytes()
    return {'path': path, 'bytes': len(payload), 'sha256': hashlib.sha256(payload).hexdigest()}

independent = read('independent_reference/result.json')
listener = read('listener_review/verdict.json')
pending = read('pending_binding_review/reference_v1_results.json')
evaluation = read('evaluation_review/run/finalize_pipeline_check.json')
startup = read('root_startup_review/results.json')

result = {
    'schema_version': 'risk_pilot_incremental_review_v1',
    'review_date': '2026-10-03',
    'input': read('input_identity.json'),
    'identity_statement': {
        'session_configuration_label': 'GPT-6 Astra Pro',
        'user_requested_label': 'Web GPT 6 Pro',
        'authenticated_backend_model_id_available': False,
        'requested_backend_identity_certified': False,
    },
    'decision': {
        'as_submitted': 'HOLD_FOR_LISTENER_ONLY_FIX',
        'as_submitted_one_shot_listener_may_start': False,
        'scientific_python_incremental_review': 'PASS_WITH_SCOPED_HANDWRITTEN_EVIDENCE',
        'proposed_listener_control_flow': 'PASS_FOUR_SYNTHETIC_CASES_AND_BASH_SYNTAX',
        'after_exact_minimal_listener_fix': 'MAY_START_FIXED_POINT_WHEN_EXISTING_PRIMARY_REVIEW_SOURCE_AUTHORIZATION_AND_RESOURCE_GATES_PASS',
        'requires_new_user_choice_or_additional_experiment_permission': False,
        'requires_full_bge_rerun_for_listener_only_fix': False,
        'proposal_applied_to_attachment_or_server': False,
        'formal_execution_performed': False,
        'actual_listener_launched': False,
        'current_server_resources_or_files_verified': False,
        'real_formal_authorization_created': False,
    },
    'fixed_point': {
        'arm': 'risk', 'history_weight': 0.1, 'retention_weight': 0.5,
        'seed': 's0', 'orders': ['ABC', 'BCA', 'CAB'],
        'new_training_stages_per_order': [2, 3],
        'updates_per_stage': 288, 'total_new_updates': 1728,
        'group_gradient_presentations': 3456, 'endpoints': 6,
        'roles': ['raw', 'stage-cal', 'first-cal'],
        'new_metric_count_sets': 18, 'matrix_shape': [60, 22],
        'primary_comparison': 'risk_minus_logit_tenth',
        'comparisons': ['risk_minus_logit_tenth', 'risk_minus_tenth', 'risk_minus_seq', 'risk_minus_logit_quarter'],
        'new_candidates_seeds_data_or_budgets_added': False,
        'policy': identity('input/schema/step28_risk_policy.json'),
    },
    'current_scientific_blockers': [],
    'current_required_repairs': listener['reproducibility_defects'],
    'repair': {
        'scope': 'One listener file only; final 32 scientific source files unchanged',
        'original': identity('input/scripts/run_step28_risk_linux_20261003.sh'),
        'proposed': identity('deliverables/run_step28_risk_linux_20261003.sh'),
        'patch': identity('deliverables/listener_minimal_fix.patch'),
        'required_before_one_shot_listener_launch': True,
        'verification': listener['evidence'],
        'original_fragment_exit_does_not_imply_semantic_success': True,
        'existing_primary_reviewer_should_check_final_source_audit_and_patched_listener_identity': True,
    },
    'seven_requested_paths': [
        {'id': 1, 'path': 'risk objective -> gradient -> clip -> AdamW -> actual stage call',
         'status': 'PASS_SCOPED', 'evidence': 'independent_reference/result.json',
         'closed_previous_blind_spots': ['R1 nondefault stage weights/reference passing', 'R2 per-UID different-text reference binding']},
        {'id': 2, 'path': 'shared start -> six surviving ER groups -> immutable old refs -> bounded auxiliary -> restore',
         'status': 'PASS_SCOPED', 'evidence': 'independent_reference/result.json',
         'native_first_stage_and_six_endpoints_executed_here': False},
        {'id': 3, 'path': 'complete blind gate -> calibration -> three roles -> 22 metrics',
         'status': 'PASS_SOURCE_AND_LAYERED_HANDWRITTEN_EVIDENCE',
         'evidence': ['evaluation_review/run/collection_check.json', 'independent_reference/saved_reference_gate_data'],
         'submitted_gate_fixture_mocks_reference_validation': True,
         'real_tiny_saved_reference_helper_independently_checked': True},
        {'id': 4, 'path': 'preselected pending LOGIT0.1 -> complete-result identity -> saved-matrix finalize',
         'status': 'PASS_REAL_FUNCTIONS_ON_SYNTHETIC_FILES',
         'evidence': 'pending_binding_review/reference_v1_results.json',
         'model_loader_train_or_label_parser_calls': 0},
        {'id': 5, 'path': 'mode and head-gradient diagnostics -> unchanged state and next update',
         'status': 'PASS_SCOPED', 'evidence': 'independent_reference/result.json',
         'finally_explicitly_restores': ['Torch CPU RNG', 'visible CUDA RNG', 'model mode'],
         'python_numpy_rng': 'not consumed; unchanged in independent checks, not explicitly restored by finally',
         'head_gradient_scale_probe_covers_full_encoder': False},
        {'id': 6, 'path': 'input inventory -> first deployment evidence -> final 32-source audit',
         'status': 'PASS_CURRENT_CHAIN_WITH_NONBLOCKING_HISTORICAL_COMMAND_GAPS',
         'evidence': ['provenance_review/findings.json', 'implementation_review/structure_check.json', 'root_startup_review/results.json']},
        {'id': 7, 'path': 'review before resource gate -> unique one-shot execution -> self deletion',
         'status': 'REPAIR_TWO_LOCAL_LISTENER_DEFECTS',
         'evidence': ['listener_review/results.json', 'root_startup_review/results.json'],
         'deleted_logit_quarter_terminal_weights_required': False},
    ],
    'independent_executions': {
        'risk_runner_memory_and_observation': independent,
        'pending_binding_and_finalize': pending,
        'evaluation_arithmetic': {
            'checked_scalars': 23232, 'max_absolute_error': 1.6653345369377348e-16,
            'views': ['raw', 'stage-cal', 'first-cal', 'primary'],
            'primary_is_statistical_combination_not_fourth_collected_role': True,
            'pipeline': evaluation,
        },
        'startup_prerequisite_order': startup,
        'listener': listener,
    },
    'provenance': {
        'review_inventory_payload_count': 82, 'review_inventory_mismatches': 0,
        'initial_deploy_members': 48, 'deploy_inventory_mismatches': 0,
        'first_cpu_inventory_count': 10, 'first_cpu_inventory_mismatches': 0,
        'initial_cpu_scientific_source_count': 33,
        'final_cpu_scientific_source_count': 32,
        'final_current_sources_match_final_audit': True,
        'current_sources_and_verify_audit_actually_invoked': True,
        'initial_deploy_with_final_audit_is_rejected': True,
        'historical_deploy_difference_is_current_launch_blocker': False,
        'final_registry_change': 'listener excluded; scientific computation unchanged',
        'final_native_reuses_first_attempt_bytes': True,
        'new_native_updates_during_source_rebinding': 0,
        'prior_report_and_evidence_zip_embedded_exactly': True,
        'original_zip_and_all_original_member_bytes_preserved': True,
    },
    'nonblocking_closeout_or_material_gaps': [
        {'id': 'N-FINALIZE-RECEIPT',
         'finding': 'Manual saved-matrix finalize produces full evaluation but does not issue job/completion.json and preserves original failure.json.',
         'action': 'Document the completed statistics separately at closeout; preserve original failure; do not retrain or reparse.'},
        {'id': 'N-DEPLOY-LABEL',
         'finding': 'Nested deploy.zip is the documented initial deployment; final outer code has the final 32-source binding.',
         'action': 'Label historical deployment and use final outer sources; no new BGE run required.'},
        {'id': 'N-HISTORICAL-COMMANDS',
         'finding': '8-versus-10 payload wording, original transport archive absent, original rebinding stdin and exact historical mutant argv absent.',
         'action': 'Correct wording and retain original commands if available; current independent checks remain valid.'},
    ],
    'scientific_interpretation': {
        'algorithm_reasonableness': 'Prior conditional empirical-cache regularizer judgment retained',
        'innovation': 'Prior insufficient-novelty judgment retained; task renaming not credited',
        'proxy_risk_improvement': 'Does not establish unseen-identity MAP/FPR or joint-risk preservation',
        'formal_effectiveness': 'NOT_EVALUATED_NO_FORMAL_RESULTS',
        'development_point_is_independent_confirmation': False,
        'old_unseen_identity_and_new_group_tradeoffs_must_remain_separate': True,
    },
    'explicit_non_actions': [
        'No formal text, labels, caches, weights, credentials, test or owners accessed',
        'No GPU training, remote Linux execution, listener launch or actual resource verification',
        'No source attachment edits or patch deployment',
        'No extra candidate, method, seed, data, criterion or budget',
        'No repeat of unchanged literature review, whole historical mutant suite or native BGE execution',
    ],
    'complete_report': 'deliverables/risk_pilot_review.zh.txt',
    'evidence_pack_readme': 'README.zh.txt',
}

assert result['input']['sha256'] == '654265a64f8a12b0450ad3003d0df1d986f6b88e22921a8ee2cf8be14800f623'
assert result['fixed_point']['policy']['sha256'] == '5706629736dfe9c598f1d59cc61f04bb65e9fd83b4275e391dfc3d2ebf2e5548'
assert result['repair']['original']['sha256'] == listener['listener_source_sha256']
assert (OUT/'run_step28_risk_linux_20261003.sh').read_bytes() == (ROOT/'listener_review/proposed_listener.sh').read_bytes()
assert len(result['current_required_repairs']) == 2
assert all(row['passed'] for row in startup['checks'])
target = OUT / 'risk_pilot_verdict.json'
if target.exists():
    raise FileExistsError(target)
target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'output': str(target), 'decision': result['decision'], 'repair': result['repair']['proposed']}, ensure_ascii=False, indent=2))
