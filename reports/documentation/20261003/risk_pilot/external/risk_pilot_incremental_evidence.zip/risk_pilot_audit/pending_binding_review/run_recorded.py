"""Record unabridged stdout/stderr and exact exit code for an independent probe."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys
import time

parser = argparse.ArgumentParser()
parser.add_argument("source")
parser.add_argument("--out", required=True)
args = parser.parse_args()
source = Path(args.source).resolve()
out = Path(args.out).resolve()
out.mkdir(parents=True, exist_ok=False)
command = [sys.executable, str(source)]
metadata = {"command": command, "cwd": str(source.parent),
            "started_utc": datetime.now(timezone.utc).isoformat()}
(out / "command.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + "\n")
started = time.monotonic()
with (out / "stdout.txt").open("wb") as stdout, (out / "stderr.txt").open("wb") as stderr:
    completed = subprocess.run(command, cwd=source.parent, stdout=stdout, stderr=stderr, check=False)
(out / "exit_code.txt").write_text(str(completed.returncode) + "\n")
metadata.update(exit_code=completed.returncode, elapsed_seconds=time.monotonic() - started,
                finished_utc=datetime.now(timezone.utc).isoformat())
(out / "execution.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + "\n")
print(json.dumps(metadata, ensure_ascii=False, indent=2), flush=True)
print((out / "stdout.txt").read_text(), end="", flush=True)
print((out / "stderr.txt").read_text(), end="", file=sys.stderr, flush=True)
sys.exit(completed.returncode)
