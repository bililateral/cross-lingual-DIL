本目录包含延后绑定LOGIT0.1与finalize的独立最小集成核验。

入口：reference_v1.py
记录器：run_recorded.py
实际完整日志：run_v1/stdout.txt、stderr.txt、exit_code.txt、command.json、execution.json
机器结果：reference_v1_results.json
手写输入和真实生成的统计输出：fixture_v1/
解释与源码定位：REPORT.zh.txt

复跑要求：Python >=3.10、NumPy；不需要Torch/BGE权重/GPU/正式数据。
在复制目录中删除或改名已输出的fixture_v1后执行：
  python run_recorded.py reference_v1.py --out run_fresh
原脚本拒绝覆盖已存在fixture_v1，因此不要在唯一证据副本上删记录复跑。
输入源码默认位于本目录上一级input/scripts，即risk_pilot_audit/input/scripts。

这是手写矩阵与文件身份夹具：真实生产resolver、baseline、一整套finalize和
5000次bootstrap被实际调用；不冒称原生六端点。任何训练、标签解析或模型
加载入口被调用都会抛错。全部指定trap调用数为0。

各语义错误变更在reference_v1.py中逐字明确；期望的ValueError/FileNotFoundError
为负测试通过，完整异常消息保存在stdout。未出现失败的独立参考版本；原
附件的失败/修正材料由主审证据包另行完整保留。
