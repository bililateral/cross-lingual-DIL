"""Actual pending/finalize integration on explicitly handwritten small files.

No original input bytes are changed. No formal texts/labels/cache/model weights.
Only source-root/identity bindings are replaced by local fixture identities. The
production resolver, baseline validator, matrix reader and full 5000-bootstrap
finalizer execute unmodified. All mocked model/parser functions raise if called.
"""
from __future__ import annotations

import copy
from contextlib import ExitStack
import hashlib
import json
from pathlib import Path
import sys
from unittest import mock

import numpy as np

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / "input"
sys.path.insert(0, str(SOURCE / "scripts"))
import step28_er_weight as method
import step28_er_weight_evaluate as evaluation
import step28_er_weight_run as runner
import step28_risk_study as study

data = method.data
WORK = HERE / "fixture_v1"
if WORK.exists():
    raise FileExistsError("Refuse to overwrite actual earlier fixture run")
WORK.mkdir()
RESULTS = []


def emit(case, **values):
    row = {"case": case, **values}
    RESULTS.append(row)
    print(json.dumps(row, ensure_ascii=False, sort_keys=True), flush=True)


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    data.write_json(path, value)


def identities(job):
    return {name: data.record(job / name, job) for name in (
        "execution.json", "run/manifest.json", "run/partition.json",
        "evaluation/collected.json", "evaluation/evaluation.json")}


def must_reject(case, function, expected=(ValueError, FileNotFoundError)):
    try:
        function()
    except expected as error:
        emit(case, detected=True, exception=type(error).__name__, message=str(error))
        return
    raise AssertionError("Fault was accepted: " + case)


def hashes(root):
    return {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(root.rglob("*")) if p.is_file()}


p = study.contract()
risk_sources = method.sources(p)
old_sources = method.prior.sources()
env = {"fixture": "handwritten identity metadata, no native training"}
p["baseline"]["environment"] = env
base_job = WORK / "base_job"
risk_job = WORK / "risk_job"
risk_root = risk_job / "evaluation"
reference_jobs = {arm: WORK / (arm + "_job") for arm in
                  ("tenth", "logit_quarter", "logit_tenth")}
domains = [d for d in "ABC" for _ in range(20)]
ids = [f"handwritten_{d}_{i:02}" for d in "ABC" for i in range(20)]
partition = {"development": [{"group_uid": uid, "domain": domain}
                             for uid, domain in zip(ids, domains, strict=True)]}
confusion = {"tp": 12, "fp": 8, "fn": 8, "tn": 350}
cm = method.metrics.confusion_metrics(**confusion)


def collection(job, names, status, sources, digest, gain):
    out = job / "evaluation"
    out.mkdir(parents=True, exist_ok=True)
    collected = {"status": status, "source_files": sources,
                 "policy_sha256": digest, "metric_columns": list(method.metrics.COLUMNS),
                 "group_ids": ids, "domains": domains, "points": {}}
    for name in names:
        # Deliberately simple finite matrices; these are not model performance.
        values = np.full((60, 22), .3 + gain, dtype=np.float64)
        for metric in ("brier", "log_loss"):
            values[:, method.metrics.COLUMNS.index(metric)] = .3 - gain
        for metric, value in cm.items():
            values[:, method.metrics.COLUMNS.index(metric)] = value
        rows = {}
        for role in method.ROLES:
            matrix = out / f"{name}_{role}.npy"
            np.save(matrix, values, allow_pickle=False)
            counts = out / f"{name}_{role}_counts.json"
            write(counts, [confusion.copy() for _ in range(60)])
            rows[role] = {"matrix": data.record(matrix, out), "counts": data.record(counts, out)}
        collected["points"][name] = rows
    write(out / "collected.json", collected)
    return collected


base_names = [name for order in method.ORDERS for name in
              [order + "_shared", *(f"{order}_seq_stage{s}" for s in (2, 3))]]
base_collected = collection(base_job, base_names,
    "ALL_PILOT_MATRICES_SAVED_BEFORE_COMPARISONS", old_sources,
    method.parent.POLICY_SHA256, 0.)
base_manifest = {"status": method.prior.COMPLETE, "source_files": old_sources,
                 "points": {}, "memories": {}}
shared_states = {}
for order in method.ORDERS:
    shared = {
        "full_checkpoint": {"path": "NO_NATIVE_WEIGHTS_PRESENT.pt", "bytes": 0, "sha256": "fixture"},
        "model_state_sha256": "handwritten_shared_identity_" + order,
        "first_map_parameters": {"a": 1., "b": 0.},
    }
    shared_states[order] = shared
    path = base_job / "run/points" / (order + "_shared.json")
    write(path, shared)
    base_manifest["points"][order + "_shared"] = data.record(path, base_job / "run")
    for arm in ("er", "logit"):
        base_manifest["memories"][f"{order}_{arm}_after1"] = {
            "file": {"path": f"NO_REAL_CACHE_{order}_{arm}.json", "bytes": 0, "sha256": "fixture"}}
write(base_job / "execution.json", {**env, "source_files": old_sources})
write(base_job / "run/manifest.json", base_manifest)
write(base_job / "run/partition.json", partition)
write(base_job / "evaluation/evaluation.json", {"status": "COMPLETE_BGE_CONTINUAL_DIAGNOSTIC"})
p["baseline"]["linux_job"] = base_job.relative_to(WORK).as_posix()
p["baseline"]["records"] = identities(base_job)

for arm, gain in (("tenth", .01), ("logit_quarter", .02), ("logit_tenth", .04)):
    job = reference_jobs[arm]
    tag = "ER_WEIGHT" if arm == "tenth" else "LOGIT_WEIGHT"
    digest = (p["pending_logit_reference"]["policy_sha256"] if arm == "logit_tenth"
              else p["continuation_references"][arm]["policy_sha256"])
    marker = job / "handwritten_source.txt"
    marker.parent.mkdir(parents=True, exist_ok=True)
    marker.write_text("HANDWRITTEN MATRIX FILE FIXTURE: " + arm + "\n", encoding="utf-8")
    sources = [data.record(marker, job)]
    names = [f"{order}_{arm}_stage{s}" for order in method.ORDERS for s in (2, 3)]
    collection(job, names, f"ALL_18_{tag}_MATRICES_SAVED_BEFORE_COMPARISONS", sources, digest, gain)
    manifest = {"status": f"COMPLETE_1728_{tag}_UPDATES_VALID_BLIND",
                "policy_sha256": digest, "physical_updates": 1728,
                "gradient_group_presentations": 3456, "points": {name: {} for name in names},
                "baseline_records": p["baseline"]["records"], "source_files": sources,
                "restored_starts": {}}
    for order, shared in shared_states.items():
        manifest["restored_starts"][order + "_" + arm] = {
            "full_checkpoint": shared["full_checkpoint"],
            "model_state_sha256": shared["model_state_sha256"],
            "first_map": shared["first_map_parameters"],
            "memory_source": base_manifest["memories"][f"{order}_{'er' if arm == 'tenth' else 'logit'}_after1"]["file"],
            "adam_step": 288, "first_scores_replayed_exactly": True}
    write(job / "execution.json", {**env, "source_files": sources})
    write(job / "run/manifest.json", manifest)
    write(job / "run/partition.json", partition)
    write(job / "evaluation/evaluation.json", {
        "status": f"COMPLETE_{tag}_DEVELOPMENT_COMPARISON", "policy_sha256": digest,
        "source_files": sources, "fixture_not_training": True})
    if arm == "logit_tenth":
        p["pending_logit_reference"].update(
            linux_job=job.relative_to(WORK).as_posix(),
            execution=data.record(job / "execution.json", job))
    else:
        p["continuation_references"][arm].update(
            linux_job=job.relative_to(WORK).as_posix(), records=identities(job))

collection(risk_job, method.expected_points(p),
    "ALL_18_RISK_REPLAY_MATRICES_SAVED_BEFORE_COMPARISONS", risk_sources,
    study.POLICY_SHA256, .08)
write(risk_job / "access.json", {"train": 1, "valid": 1, "heldout": 0, "owners": 0,
                                "fixture_not_actual_access": True})
write(WORK / "fixture_policy.json", p)
write(WORK / "fixture_scope.json", {
    "source": str(SOURCE), "production_changed": False,
    "formal_data": False, "native_weights_or_cache": False,
    "matrices": "handwritten 60x22 arrays, not observed performance",
    "identity_metadata": "local self-consistent identities replacing original job paths and pins",
    "bootstrap": "production full 5000 replicates, no statistical function patched",
    "patches": ["data.ROOT=fixture root", "method.sources returns actual original risk source list",
                "prior.sources returns actual original parent source list",
                "training/parser/model-loading entrypoints raise on access"]})
input_before = hashes(WORK)

with ExitStack() as patches:
    patches.enter_context(mock.patch.object(data, "ROOT", WORK))
    patches.enter_context(mock.patch.object(method, "sources", return_value=risk_sources))
    patches.enter_context(mock.patch.object(method.prior, "sources", return_value=old_sources))
    forbidden = []
    for owner, name in ((runner, "train"), (runner, "collect"),
                        (method.prior, "parse_once"), (method.base, "load_model"),
                        (method.core, "load_model"), (method, "update")):
        forbidden.append(patches.enter_context(mock.patch.object(owner, name,
            side_effect=AssertionError("Forbidden training/formal-data entry called: " + name))))
    # Training preparation uses only already-complete controls; pending LOGIT.1
    # completion is intentionally absent and does not gate training baselines.
    first = method.baseline(p)
    assert set(first["continuation_references"]) == {"tenth", "logit_quarter"}
    emit("baseline_before_pending_completion", passed=True,
         loaded_refs=sorted(first["continuation_references"]))
    pending = reference_jobs["logit_tenth"]
    must_reject("missing_pending_completion", lambda: evaluation.finalize(risk_root, base_job / "evaluation", p))
    assert not (risk_root / "logit_reference_binding.json").exists()
    assert not (risk_root / "evaluation.json").exists()
    assert input_before == hashes(WORK)
    emit("missing_control_preserved_all_candidate_matrices", passed=True)
    # Reproduce the execute exception state without pretending to call GPU execute.
    write(risk_job / "failure.json", {"status": "FAILED_NO_AUTOMATIC_RETRY",
          "error": "HANDWRITTEN execute-shaped state: pending completion absent",
          "label_parses": data.read_json(risk_job / "access.json")})
    failed_hash = data.sha256(risk_job / "failure.json")
    write(pending / "completion.json", {"status": "COMPLETE_RISK_REPLAY_DEVELOPMENT_COMPARISON"})
    must_reject("wrong_pending_completion_status", lambda: study.resolve_comparator(p, risk_root))
    write(pending / "completion.json", {"status": "COMPLETE_LOGIT_WEIGHT_DEVELOPMENT_COMPARISON"})
    # A changed execution file must fail before any result binding is persisted.
    original_execution = (pending / "execution.json").read_bytes()
    write(pending / "execution.json", {"modified_execution": True})
    must_reject("changed_preselected_execution", lambda: study.resolve_comparator(p, risk_root))
    (pending / "execution.json").write_bytes(original_execution)
    resolved = study.resolve_comparator(p, risk_root)
    assert "pending_logit_reference" in p and "pending_logit_reference" not in resolved
    assert set(resolved["continuation_references"]) == {"tenth", "logit_quarter", "logit_tenth"}
    assert resolved["study"] == "seller_alias_risk_replay"
    refs = method.baseline(resolved)
    assert set(refs["continuation_references"]) == {"tenth", "logit_quarter", "logit_tenth"}
    emit("resolved_policy_scope_and_baseline", passed=True,
         candidate_evidence_tag=method.evidence_tag(resolved),
         logit_evidence_tag=resolved["continuation_references"]["logit_tenth"]["evidence_tag"])
    # Actual full saved-matrix finalize, with real readers, validators, 5000
    # bootstrap and write-once results. No comparator checkpoint exists at all.
    result = evaluation.finalize(risk_root, base_job / "evaluation", p)
    assert result["status"] == "COMPLETE_RISK_REPLAY_DEVELOPMENT_COMPARISON"
    assert result["new_metric_count_sets"] == 18
    assert result["reused_metric_count_sets"] == 81
    assert set(result["method_checks"]) == {"logit_tenth", "tenth", "seq", "logit_quarter"}
    for arm, expected in (("logit_tenth", .04), ("tenth", .07), ("seq", .08), ("logit_quarter", .06)):
        actual = result["comparisons"]["risk_minus_" + arm]["primary"]["O"]["map"]["mean"]
        assert abs(actual - expected) < 1e-14, (arm, actual)
        assert len(result["method_checks"][arm]["checks"]) == 23
    assert "selection" not in result
    emit("actual_full_finalize", passed=True, status=result["status"],
         new_sets=result["new_metric_count_sets"], reused_sets=result["reused_metric_count_sets"],
         comparisons=sorted(result["comparisons"]), bootstrap_shape=[5000, 3, 20],
         formal_training_or_parser_calls=sum(item.call_count for item in forbidden))
    assert all(item.call_count == 0 for item in forbidden)
    before_repeat = hashes(risk_root)
    repeated = evaluation.finalize(risk_root, base_job / "evaluation", p)
    assert repeated == result
    assert hashes(risk_root) == before_repeat
    emit("repeat_finalize_identical_bytes", passed=True, files=len(before_repeat))
    # Once fixed, even a valid-format changed result cannot silently replace the
    # saved exact comparator. Restore fixture file after the mutation test.
    eval_path = pending / "evaluation/evaluation.json"
    eval_before = eval_path.read_bytes()
    changed = data.read_json(eval_path); changed["fixture_mutation"] = "after binding"
    write(eval_path, changed)
    must_reject("comparator_changed_after_binding", lambda: study.resolve_comparator(p, risk_root))
    eval_path.write_bytes(eval_before)
    # Validator fault probes rewrite only independent fixture files and refresh
    # their local records. Thus failures are semantic, not mere stale hashes.
    for case, filename, mutate in (
        ("wrong_ref_policy", "run/manifest.json", lambda x: x.update(policy_sha256="wrong")),
        ("missing_ref_endpoint", "evaluation/collected.json", lambda x: x["points"].pop(next(iter(x["points"])))),
        ("wrong_shared_model", "run/manifest.json", lambda x: x["restored_starts"]["ABC_logit_tenth"].update(model_state_sha256="wrong")),
        ("wrong_memory_arm", "run/manifest.json", lambda x: x["restored_starts"]["ABC_logit_tenth"].update(memory_source={"wrong": "er"})),
        ("misaligned_group_ids", "evaluation/collected.json", lambda x: x["group_ids"].reverse()),
        ("different_execution_sources", "execution.json", lambda x: x.update(source_files=[])),
    ):
        target = pending / filename; original = target.read_bytes()
        content = data.read_json(target); mutate(content); write(target, content)
        q = copy.deepcopy(resolved)
        q["continuation_references"]["logit_tenth"]["records"] = identities(pending)
        must_reject(case, lambda q=q: method.baseline(q))
        target.write_bytes(original)
    assert data.sha256(risk_job / "failure.json") == failed_hash
    assert not (risk_job / "completion.json").exists()
    emit("job_lifecycle_after_saved_matrix_finalize", observation=True,
         evaluation_status=data.read_json(risk_root / "evaluation.json")["status"],
         original_failure_preserved=True, job_completion_file_exists=False,
         interpretation="Statistics complete; generic CLI finalize does not issue job completion receipt")

write(HERE / "reference_v1_results.json", {
    "status": "PASS_HANDWRITTEN_PENDING_BINDING_AND_FULL_FINALIZE",
    "no_formal_data_or_models": True, "cases": RESULTS,
    "nonblocking_lifecycle_observation": "saved-matrix finalize preserves failure.json and does not write job/completion.json"})
print("ALL HANDWRITTEN PENDING/FINALIZE CHECKS PASSED", flush=True)
