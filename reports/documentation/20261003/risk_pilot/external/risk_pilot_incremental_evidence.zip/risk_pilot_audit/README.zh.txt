正式固定开发点接入增量外审——交付说明
2026-10-03

先读 deliverables/risk_pilot_review.zh.pdf 或同名 .txt，再读
deliverables/risk_pilot_verdict.json。两项当前修复都在一个监听文件；科学Python
路径在本轮增量范围通过。原件裁决为 HOLD_FOR_LISTENER_ONLY_FIX。
所附修正脚本与补丁尚未部署，未改原附件。合入精确局部修正并满足既定主审、
来源绑定授权和资源门后，可启动已经授权的固定单点；不要求完整BGE重跑。

一、原附件和复用材料

original_upload/review(4).zip 是用户上传的同一原件：1,575,125字节，83成员，
SHA-256 654265a64f8a12b0450ad3003d0df1d986f6b88e22921a8ee2cf8be14800f623。
input/ 保留83个原成员的原字节，生产修改/变异没有写回此处。
input/reports/documentation/20261003/risk_pilot/deploy.zip 是历史首次部署原件；
最终外层32项科学来源及最终CPU audit是当前接入对象，不要混用版本。
与本目录并列的 risk_audit/ 只保留前轮 input 和两份已交付文件，供前后来源
比较复跑；不是本轮重复执行历史核验。前轮完整方法裁决也已经嵌在原附件。

二、各独立切片与实际退出结果

independent_reference/
  result.json / README.zh.md 是风险、缓存、runner及观测切片的完整说明。
  repaired_lifecycle_original_run：本轮修补用例原版退出0。
  mutants/stage_gamma_zero 与 reference_rows_reversed：各预期断言失败退出1；
  不是运行环境报错，单缺陷源码和完整输出均在各目录中。
  incremental_v1/original_run：转换、模式与observe先通过，然后step30在本方
  固定绝对精度门失败，退出1，全部原件保留。
  incremental_v2/runner_run：只复跑runner，真实288更新退出0；1/29/30/288
  保存实际/独立预期的梯度、Adam矩与参数数组。参考精度修正没有改数学公式。
  saved_reference_gate_run：对真实Tiny内存和日志直接调用生产参考核查，退出0；
  stage3仅一个draw后的helper分支和恢复后下一更新，不是完整第三阶段。
  reused_v4/oracle.py 是前轮独立数学helper精确副本，没有旧运行目录依赖。

evaluation_review/
  command.json、stdout.txt、stderr.txt、exit_code.txt、execution.json保留实际运行。
  23,232标量独立算术、实际collect/read_points和统计写出，退出0。
  此处finalize显式mock来源绑定，不能单独当作来源核验；见下一个切片。

pending_binding_review/
  reference_v1.py、fixture_v1/、run_v1/及reference_v1_results.json。
  实际未改resolver/baseline/finalize，在完整手写文件上做5000次bootstrap，退出0。
  缺对照及所有错身份/错语义案例属于预期拒绝；训练、模型与标签解析调用为0。
  不依赖任何原生模型、原缓存或已删除的LOGIT0.25末端权重。

listener_review/
  check_listener.py / run_check.py、cases/ 和完整命令/输出。
  原控制片段在“更新后已退出”与“rm失败”两例的语义检查退出1；两片段自身
  可能退出0正是缺陷的一部分。主套件退出0表示正确检出原问题并验证修正。
  修正控制流四例通过，完整修正版bash -n退出0。
  proposed_listener.sh 与 deliverables/run_step28_risk_linux_20261003.sh 字节相同。
  listener_minimal_fix.patch 只修改该监听文件。没有实际启动服务器监听。

root_startup_review/
  startup_reference.py、fixtures/、run/和results.json，退出0。
  四个手写启动门拒绝案例检查真实execute调用先后。JSON明确为人工夹具，不是
  本方创建的真实正式授权，不得拿这些夹具去启动正式作业。

provenance_review/ 与 implementation_review/
  标准库来源、AST和提交native数字对照；完整命令/输出/退出0。
  源哈希用于身份，不作为计算正确性的替代证据。
  所附相对路径重绑定失败与修正原件在input中；本方record函数复现亦保留。
  没有本方重新加载BGE，最终native复用首次CPU探针不是又做3次新更新。

空stdout/stderr是实际空文件。每个科学运行的对应record目录记录精确命令及
退出码。expected rejection、原程序失败、本方参考失败分别标注，勿合并成
“全部PASS”或将手写差值称为正式收益。源代码定位以input中原文件行为准。

三、人工夹具与依赖边界

本方Python3.12.14 / NumPy2.3.5 / Torch2.7.1+cpu，CUDA禁用、Torch单线程。
所附Linux py310/Torch2.9.1+cu130原生CPU证据另列，不能把两环境混写。
Tiny首状态为一次真实warm后显式改Adam计数1→288；observe配对使用参考乘
[.76,.67,.55]；独立Tiny clip_norm=.08用于激活裁剪。这些都是手写探针。
共享runner的真实288步使用未缩放eval参考；正式policy没有修改。
本轮没有正式文本、标签、缓存、权重、凭据、test或owners，没有GPU/远程运行，
没有完整六端点训练或新的正式效果数据。

四、复跑说明

先复制整包到新的审查工作目录，保留原证据副本；不要覆写已有运行目录。
推荐核心入口及环境安装命令见independent_reference/README.zh.md。
使用已有CPU Torch环境即可；证据包不重复装入庞大运行时或模型文件。

从risk_pilot_audit目录，在安装依赖的Python中运行：
  python independent_reference/run_recorded.py independent_reference/new_run python independent_reference/incremental_v2/check.py --output independent_reference/new_data
此入口可用RISK_PILOT_INPUT显式指定含scripts/schema的输入根。

延后绑定切片只需Python及NumPy。在复制目录中，将已保存fixture_v1改名后按其
README运行记录器；原入口拒绝覆盖既有fixture。评价与listener脚本也会写相邻
结果目录，务必在工作副本中执行。不要删除唯一证据副本来腾出路径。

provenance两个入口用相对目录寻找并列的risk_audit；本包已提供所需旧材料。
implementation_review/check_incremental_structure.py保留了实际执行时的绝对
路径；异地复跑需在工作副本中将顶部OLD/NEW改成对应的risk_audit/input和
risk_pilot_audit/input，并把路径改动记录到新命令说明。原源码没有为美化可移植
性而追改。历史command.json中运行时绝对路径按事实保留。

单独解析保存矩阵的正式恢复入口是原脚本的：
  python scripts/step28_er_weight_run.py finalize --study risk --out reports/job/evaluation
此为被审查的既有接口说明，不能对本手写夹具假装执行正式收尾。manual finalize
不会补写job/completion.json，需在收尾另记统计完成，并保留原failure.json。

五、包校验与报告构建

MANIFEST.json列出除自身以外所有ZIP载荷的路径、字节数、SHA-256；其作用是
确认下载完整性。build_evidence_pack.py、build_verdict.py仅整理证据，没有训练。
PDF为8页，全部页实际渲染并检查中文字体、文字、页边及源码路径换行；构建源码
及stdout/stderr/退出码在report_builder。渲染图片和运行时依赖不装入小证据包。
包外risk_pilot_evidence_receipt.json列出最终证据ZIP字节数、成员数和SHA-256。

最终裁决以本轮总报告及risk_pilot_verdict.json为准。各分工切片不能独自给整个
作业签发启动结论。修正监听不改变前轮算法、创新或效果判断。
