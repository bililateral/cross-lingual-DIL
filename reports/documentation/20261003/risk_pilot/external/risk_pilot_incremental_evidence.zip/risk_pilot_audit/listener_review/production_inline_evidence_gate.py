import json, sys
from pathlib import Path
audit, auth = [json.loads(Path(p).read_text()) for p in sys.argv[1:]]
assert audit['status'] == 'PASS_RISK_REPLAY_HANDMADE_CPU'
assert audit['contracts']['failed'] == 0 and audit['contracts']['skipped'] == 0
assert audit['native_risk_gradient_increment_verified']
assert audit['source_files'] == auth['source_files']
assert auth['review_and_primary_passed']
