set -euo pipefail
set +e
self="$1"; out="$2"; queue="$3"; child=424242
alive="$4"; delete_ok="$5"
delete_status=0
kill() { [[ "$alive" == 1 ]]; }
sleep() { printf 'UNEXPECTED_SLEEP\n' >&2; exit 97; }
date() { printf 'FIXTURE-TIME\n'; }
rm() {
  if [[ "$delete_ok" == 1 ]]; then command rm "$@";
  else printf 'FIXTURE_RM_FAILURE\n' >&2; return 1; fi
}
while kill -0 "$child" 2>/dev/null; do
  if grep -q '"event":"updates"' "$out/train.log"; then
    break
  fi
  sleep 15
done
delete_status=0
if grep -q '"event":"updates"' "$out/train.log"; then
  if rm -- "$self"; then
    date --iso-8601=seconds > "$queue/script_deleted_after_updates.txt"
  else
    delete_status=$?
    printf '%s\n' "$delete_status" > "$queue/script_delete_failed.txt"
  fi
fi

training_status=0
printf '%s\n' "$training_status" > "$out/exit_status.txt"
if ((training_status == 0 && delete_status != 0)); then exit "$delete_status"; fi
exit "$training_status"
