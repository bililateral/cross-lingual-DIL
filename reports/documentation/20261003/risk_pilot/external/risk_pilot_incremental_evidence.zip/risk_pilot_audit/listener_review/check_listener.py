"""Review the listener with isolated command stubs, never execute the listener.

All subprocess shell code is restricted to the extracted self-delete fragment,
with kill/sleep/rm/date replaced by explicit fixture functions. Formal paths,
SSH, CUDA, real resource probes and the training command are never executed.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
INPUT = ROOT / "input"
SCRIPT = INPUT / "scripts/run_step28_risk_linux_20261003.sh"
text = SCRIPT.read_text()
original = text[text.index('while kill -0 "$child"'):text.index('wait "$child"')]
(OUT / "production_self_delete_fragment.sh").write_text(original)

# Proposed local change only: the log predicate is checked after the liveness
# loop as well, and a success receipt is conditional on successful deletion.
# There is no retry and no new resource or experiment policy.
fixed = '''while kill -0 "$child" 2>/dev/null; do
  if grep -q '\"event\":\"updates\"' "$out/train.log"; then
    break
  fi
  sleep 15
done
delete_status=0
if grep -q '\"event\":\"updates\"' "$out/train.log"; then
  if rm -- "$self"; then
    date --iso-8601=seconds > "$queue/script_deleted_after_updates.txt"
  else
    delete_status=$?
    printf '%s\\n' "$delete_status" > "$queue/script_delete_failed.txt"
  fi
fi
'''
(OUT / "proposed_self_delete_fragment.sh").write_text(fixed)

FIXTURE = '''set -euo pipefail
set +e
self="$1"; out="$2"; queue="$3"; child=424242
alive="$4"; delete_ok="$5"
delete_status=0
kill() { [[ "$alive" == 1 ]]; }
sleep() { printf 'UNEXPECTED_SLEEP\\n' >&2; exit 97; }
date() { printf 'FIXTURE-TIME\\n'; }
rm() {
  if [[ "$delete_ok" == 1 ]]; then command rm "$@";
  else printf 'FIXTURE_RM_FAILURE\\n' >&2; return 1; fi
}
'''

def run_child(directory, name, argv, *, data=None, env=None):
    directory.mkdir(parents=True, exist_ok=True)
    (directory / (name + ".command.json")).write_text(json.dumps({"argv": argv}, ensure_ascii=False, indent=2) + "\n")
    with (directory / (name + ".stdout.txt")).open("w") as stdout, (directory / (name + ".stderr.txt")).open("w") as stderr:
        proc = subprocess.run(argv, input=data, stdout=stdout, stderr=stderr, env=env, check=False)
    (directory / (name + ".exit_code.txt")).write_text(str(proc.returncode) + "\n")
    return proc.returncode


def run_case(version, case, alive, delete_ok, has_event):
    case_dir = OUT / "cases" / (version + "_" + case)
    case_dir.mkdir(parents=True, exist_ok=False)
    out, queue = case_dir / "job", case_dir / "listener"
    out.mkdir(); queue.mkdir()
    self = case_dir / "listener_fixture.sh"
    self.write_text("A disposable fixture, never the actual reviewed listener.\n")
    (out / "train.log").write_text('{"event":"updates","stage_updates":24,"logical_updates":312}\n' if has_event else "")
    body = original if version == "production" else fixed
    # Training exit handling is a stub too. Its status is saved separately;
    # cleanup failure only changes the listener exit, not the training result.
    suffix = '''
training_status=0
printf '%s\\n' "$training_status" > "$out/exit_status.txt"
if ((training_status == 0 && delete_status != 0)); then exit "$delete_status"; fi
exit "$training_status"
'''
    snippet = case_dir / "fixture.sh"
    snippet.write_text(FIXTURE + body + suffix)
    rc = run_child(case_dir, "shell", ["bash", str(snippet), str(self), str(out), str(queue), str(alive), str(delete_ok)])
    result = {"version": version, "case": case, "simulated_alive_at_poll": bool(alive),
              "simulated_rm_success": bool(delete_ok), "updates_event_already_written": bool(has_event),
              "shell_exit_code": rc, "self_still_exists": self.exists(),
              "success_receipt_exists": (queue / "script_deleted_after_updates.txt").exists(),
              "failure_receipt_exists": (queue / "script_delete_failed.txt").exists(),
              "training_exit_code": int((out / "exit_status.txt").read_text())}
    (case_dir / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    verifier = '''import json,sys
r=json.load(open(sys.argv[1]))
if not r['updates_event_already_written']:
    assert r['self_still_exists'] and not r['success_receipt_exists']
elif r['simulated_rm_success']:
    assert not r['self_still_exists'], 'Updates existed before process exit, but listener was not deleted'
    assert r['success_receipt_exists']
else:
    assert not r['success_receipt_exists'], 'Deletion failed but success receipt was written'
    assert r['self_still_exists'] and r['failure_receipt_exists']
    assert r['shell_exit_code'] != 0 and r['training_exit_code'] == 0
print('SEMANTIC_CONTRACT_CHECK_PASS')
'''
    verifier_path = case_dir / "verify_contract.py"
    verifier_path.write_text(verifier)
    check_rc = run_child(case_dir, "semantic_check", [sys.executable, str(verifier_path), str(case_dir / "result.json")])
    result["semantic_check_exit_code"] = check_rc
    print("SELF_DELETE_CASE " + json.dumps(result))
    return result


def source_exclusion_check():
    sys.path.insert(0, str(INPUT / "scripts"))
    import step28_er_weight as method
    p = method.contract("risk")
    actual = method.sources(p)
    audit = json.loads((INPUT / "reports/documentation/20261003/risk_pilot/cpu/audit.json").read_text())
    assert actual == audit["source_files"]
    target_name = "scripts/run_step28_risk_linux_20261003.sh"
    assert target_name not in [row["path"] for row in actual]
    # Build a tiny isolated copy containing only the 32 scientific source files
    # and one copied listener. The production sources() is evaluated before and
    # after deleting this COPY, with data.ROOT temporarily bound to the fixture.
    copy_root = OUT / "source_copy_fixture"
    copy_root.mkdir(exist_ok=False)
    for rec in actual:
        src = INPUT / rec["path"]
        dest = copy_root / rec["path"]
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, dest)
    listener_copy = copy_root / target_name
    shutil.copyfile(SCRIPT, listener_copy)
    original_root = method.data.ROOT
    try:
        method.data.ROOT = copy_root
        before = method.sources(p)
        listener_copy.unlink()
        after = method.sources(p)
    finally:
        method.data.ROOT = original_root
    assert before == after == actual
    # The copy is reproducible evidence, but full source bytes are already in
    # the submitted archive. Retain only its manifest rather than duplicates.
    (OUT / "source_exclusion_manifest.json").write_text(json.dumps({"source_count": len(actual),
        "sources_unchanged_after_copy_deletion": before == after,
        "matches_current_audit": actual == audit["source_files"],
        "deleted_only_fixture_copy": str(listener_copy), "source_files": actual}, indent=2) + "\n")
    print("SOURCE_EXCLUSION " + json.dumps({"source_count": len(actual), "current_audit_matches": True,
          "sources_unchanged_after_listener_copy_deletion": True}))


def inline_gate_check():
    checker = text.split("<<'PY'\n", 1)[1].split("\nPY", 1)[0]
    checker_path = OUT / "production_inline_evidence_gate.py"
    checker_path.write_text(checker + "\n")
    for allowed in (False, True):
        name = "rejected" if not allowed else "accepted"
        directory = OUT / "inline_gate" / name
        directory.mkdir(parents=True, exist_ok=True)
        audit = {"status": "PASS_RISK_REPLAY_HANDMADE_CPU", "contracts": {"failed": 0, "skipped": 0},
                 "native_risk_gradient_increment_verified": True, "source_files": ["FIXTURE-SOURCE"]}
        auth = {"source_files": ["FIXTURE-SOURCE"], "review_and_primary_passed": allowed}
        audit_path, auth_path = directory / "audit.json", directory / "authorization.json"
        audit_path.write_text(json.dumps(audit)); auth_path.write_text(json.dumps(auth))
        rc = run_child(directory, "inline_check", [sys.executable, str(checker_path), str(audit_path), str(auth_path)])
        assert (rc == 0) == allowed
        print("INLINE_GATE " + json.dumps({"review_flag": allowed, "exit_code": rc,
              "scope": "exact checker only, no resource probes or actual authorization"}))


print(json.dumps({"python": sys.version, "listener_sha256": hashlib.sha256(SCRIPT.read_bytes()).hexdigest(),
                  "scope": "static source and isolated command stubs; no actual listener/SSH/GPU/formal input"}))
syntax_rc = run_child(OUT, "bash_syntax", ["bash", "-n", str(SCRIPT)])
assert syntax_rc == 0
inline_gate_check()
source_exclusion_check()
cases = []
for version in ("production", "proposed"):
    cases += [run_case(version, "normal_alive_updates", 1, 1, True),
              run_case(version, "exited_after_updates", 0, 1, True),
              run_case(version, "rm_failed", 1, 0, True),
              run_case(version, "exited_before_updates", 0, 1, False)]
assert [x["semantic_check_exit_code"] for x in cases] == [0, 1, 1, 0, 0, 0, 0, 0]
(OUT / "results.json").write_text(json.dumps(cases, indent=2) + "\n")
print("EXPECTED_PRODUCTION_DEFECTS_REPRODUCED; LOCAL_CORRECTION_PASSED_ALL_FOUR_CASES")
