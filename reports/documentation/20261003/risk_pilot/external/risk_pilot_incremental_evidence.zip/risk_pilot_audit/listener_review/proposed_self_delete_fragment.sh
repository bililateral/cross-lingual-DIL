while kill -0 "$child" 2>/dev/null; do
  if grep -q '"event":"updates"' "$out/train.log"; then
    break
  fi
  sleep 15
done
delete_status=0
if grep -q '"event":"updates"' "$out/train.log"; then
  if rm -- "$self"; then
    date --iso-8601=seconds > "$queue/script_deleted_after_updates.txt"
  else
    delete_status=$?
    printf '%s\n' "$delete_status" > "$queue/script_delete_failed.txt"
  fi
fi
