A disposable fixture, never the actual reviewed listener.
