while kill -0 "$child" 2>/dev/null; do
  if grep -q '"event":"updates"' "$out/train.log"; then
    # Delete only this listener after actual new updates, preserving launch records.
    rm -- "$self"
    date --iso-8601=seconds > "$queue/script_deleted_after_updates.txt"
    break
  fi
  sleep 15
done
