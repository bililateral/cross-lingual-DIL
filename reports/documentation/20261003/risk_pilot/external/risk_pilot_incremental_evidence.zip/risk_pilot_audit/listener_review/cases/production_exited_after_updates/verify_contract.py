import json,sys
r=json.load(open(sys.argv[1]))
if not r['updates_event_already_written']:
    assert r['self_still_exists'] and not r['success_receipt_exists']
elif r['simulated_rm_success']:
    assert not r['self_still_exists'], 'Updates existed before process exit, but listener was not deleted'
    assert r['success_receipt_exists']
else:
    assert not r['success_receipt_exists'], 'Deletion failed but success receipt was written'
    assert r['self_still_exists'] and r['failure_receipt_exists']
    assert r['shell_exit_code'] != 0 and r['training_exit_code'] == 0
print('SEMANTIC_CONTRACT_CHECK_PASS')
