"""Produce, syntax-check, and retain a proposed patch; never apply or launch it."""
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

out = Path(__file__).resolve().parent
source = out.parent / "input/scripts/run_step28_risk_linux_20261003.sh"
original = source.read_text()
old_fragment = (out / "production_self_delete_fragment.sh").read_text()
new_fragment = (out / "proposed_self_delete_fragment.sh").read_text()
assert original.count(old_fragment) == 1
proposed = original.replace(old_fragment, new_fragment)
proposed = proposed.replace(
    'printf \'%s exit=%s; no automatic retry\\n\' "$(date --iso-8601=seconds)" "$status"\nexit "$status"\n',
    'printf \'%s training_exit=%s cleanup_exit=%s; no automatic retry\\n\' "$(date --iso-8601=seconds)" "$status" "$delete_status"\n'
    'if ((status == 0 && delete_status != 0)); then\n  exit "$delete_status"\nfi\nexit "$status"\n')
assert proposed != original
path = out / "proposed_listener.sh"
path.write_text(proposed)
diff = ''.join(difflib.unified_diff(original.splitlines(True), proposed.splitlines(True),
    fromfile="a/scripts/run_step28_risk_linux_20261003.sh",
    tofile="b/scripts/run_step28_risk_linux_20261003.sh"))
(out / "listener_minimal_fix.patch").write_text(diff)
argv = ["bash", "-n", str(path)]
(out / "proposed_syntax.command.json").write_text(json.dumps({"argv": argv}, indent=2) + "\n")
with (out / "proposed_syntax.stdout.txt").open("w") as stdout, (out / "proposed_syntax.stderr.txt").open("w") as stderr:
    result = subprocess.run(argv, stdout=stdout, stderr=stderr, check=False)
(out / "proposed_syntax.exit_code.txt").write_text(str(result.returncode) + "\n")
assert result.returncode == 0
assert source.read_text() == original
print(json.dumps({"source_unchanged": True, "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
                  "proposed_syntax_exit_code": result.returncode, "applied": False, "launched": False}))
