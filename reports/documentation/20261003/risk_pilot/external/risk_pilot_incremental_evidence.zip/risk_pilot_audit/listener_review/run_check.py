"""Preserve complete listener-review stdout, stderr and process return code."""
import json
import os
from pathlib import Path
import subprocess
import sys

out = Path(__file__).resolve().parent
env = os.environ.copy()
env["CUDA_VISIBLE_DEVICES"] = ""
env["PYTHONDONTWRITEBYTECODE"] = "1"
command = [sys.executable, str(out / "check_listener.py")]
(out / "command.json").write_text(json.dumps({"argv": command, "CUDA_VISIBLE_DEVICES": "", "PYTHONDONTWRITEBYTECODE": "1"}, indent=2) + "\n")
with (out / "stdout.txt").open("w") as stdout, (out / "stderr.txt").open("w") as stderr:
    completed = subprocess.run(command, stdout=stdout, stderr=stderr, env=env, check=False)
(out / "exit_code.txt").write_text(str(completed.returncode) + "\n")
print(json.dumps({"exit_code": completed.returncode, "stdout": str(out / "stdout.txt"), "stderr": str(out / "stderr.txt")}))
sys.exit(completed.returncode)
