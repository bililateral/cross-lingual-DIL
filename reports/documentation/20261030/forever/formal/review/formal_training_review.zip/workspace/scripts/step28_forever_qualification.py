"""Bounded handwritten qualification supervisor. No formal data or train action."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import psutil

GIB = 2**30
EXIT_GRACE = 2.
EXIT_KILL_ALLOWANCE = 2.


def write(path: Path, value) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')


def log_update(path: Path, row: dict) -> None:
    with path.open('a') as stream:
        stream.write(json.dumps(dict(wall_time_epoch=time.time(), **row))+'\n')


def verify(root: Path, permit: dict) -> None:
    if (permit['status'] != 'APPROVED_MINIMAL_IMPLEMENTATION_CPU_GPU_ONLY'
            or permit['cpu_seconds'] != 600 or permit['gpu_seconds'] != 3600
            or permit['optimizer_calls'] is not None or permit['formal_training'] is not False
            or permit['formal_data'] is not False):
        raise ValueError('Qualification scope differs')
    for row in permit['sources']:
        raw = (root/row['path']).read_bytes()
        if len(raw) != row['bytes'] or hashlib.sha256(raw).hexdigest() != row['sha256']:
            raise ValueError(f'Deployed source differs: {row["path"]}')


def resources() -> dict:
    import shutil
    values = subprocess.check_output(['nvidia-smi', '--id=0', '--query-gpu=memory.free,memory.total',
                                      '--format=csv,noheader,nounits'], text=True, timeout=2)
    free, total = [int(v)*2**20 for v in values.strip().split(',')]
    return dict(epoch=time.time(), free_gpu_bytes=free, total_gpu_bytes=total,
                ram_available_bytes=psutil.virtual_memory().available,
                disk_free_bytes=shutil.disk_usage(Path.cwd()).free)


def elapsed_workers(children: list[dict]) -> float:
    now = time.monotonic()
    for row in children:
        if row['process'].poll() is not None and row['ended'] is None:
            row['ended'] = now
    return sum((row['ended'] or now)-row['started'] for row in children)


def budget_delay(cap: float, elapsed: float, active: int) -> float:
    # All workers receive TERM together, then KILL together; rounding is reserved once.
    reserve = active*(EXIT_GRACE+EXIT_KILL_ALLOWANCE)+1
    if active < 1 or cap-elapsed <= reserve:
        raise TimeoutError('Insufficient cumulative budget including concurrent exit tail')
    return (cap-elapsed-reserve)/active


def stop_children(children: list[dict]) -> None:
    for sig, duration in ((signal.SIGTERM, EXIT_GRACE), (signal.SIGKILL, EXIT_KILL_ALLOWANCE)):
        for row in children:
            if row['process'].poll() is None:
                try:
                    os.killpg(row['process'].pid, sig)
                except ProcessLookupError:
                    pass
        deadline = time.monotonic()+duration
        while any(row['process'].poll() is None for row in children) and time.monotonic() < deadline:
            elapsed_workers(children)
            time.sleep(.01)
        elapsed_workers(children)
    if any(row['process'].poll() is None for row in children):
        raise RuntimeError('Worker not reaped after KILL; retain actual elapsed and stop')


def auxiliary_admission(snapshot: dict, main_gpu: int, main_rss: int, disk_used: int) -> dict:
    required = dict(free_gpu_bytes=20*GIB+max(0, 10*GIB-main_gpu),
                    ram_available_bytes=128*GIB+max(0, 64*GIB-main_rss),
                    disk_free_bytes=64*GIB+max(0, 96*GIB-disk_used))
    return dict(required=required, observed=snapshot,
                ready=all(snapshot[key] >= value for key, value in required.items()))


def compute_overlap(intervals: list[list[dict]]) -> float:
    # Intersect actual single-update intervals. Checkpoint I/O and idle residency are absent.
    return sum(max(0., min(a['ended'], b['ended'], c['ended'])-
                   max(a['started'], b['started'], c['started']))
               for a in intervals[0] for b in intervals[1] for c in intervals[2])


def predecessor_ready(root: Path, live_commands: list[str], g1_only_accepted: bool = False) -> bool:
    """Use the user's accepted VendorLink scope; never manufacture G2 success."""
    paths = [root/'ledger.json', root/'g1/result.json']
    if not g1_only_accepted:
        paths.extend(root/f'g2_{i}/result.json' for i in range(3))
    if not all(p.is_file() for p in paths):
        return False
    ledger, first, *workers = [json.loads(p.read_text()) for p in paths]
    accepted_status = ('SINGLE_SLOT_QUALIFIED_G2_NOT_QUALIFIED' if g1_only_accepted
                       else 'NATIVE_QUALIFIED_NOT_FORMAL_TRAINING')
    return (ledger.get('status') == accepted_status
            and first.get('status') == 'G1_PASSED'
            and all(r.get('status') == 'G2_WORKER_PASSED' for r in workers)
            and not any('vendorlink' in cmd and ('native' in cmd or 'step29_linux_20261029' in cmd)
                        for cmd in live_commands))


def supervise(args) -> None:
    root = Path(__file__).resolve().parents[1]
    permit = json.loads(args.permit.read_text())
    verify(root, permit)
    slots = permit.get('gpu_slots', 3)
    if slots not in (1, 3):
        raise ValueError('Qualification supports the approved single or three slots only')
    if args.job.exists():
        raise FileExistsError('Never overwrite/restart an existing qualification attempt')
    args.job.mkdir(parents=True)
    # The ledger is external to recoverable learner checkpoints and never rolls back.
    ledger_path = args.permit.parent/'qualification_accounting.json'
    ledger = json.loads(ledger_path.read_text()) if ledger_path.exists() else dict(cpu_seconds=0, gpu_seconds=0, optimizer_calls=0, attempts=[])
    if args.mode == 'gpu':
        live = []
        for p in psutil.process_iter(['cmdline']):
            try:
                live.append(' '.join(p.info['cmdline'] or []))
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
        if not predecessor_ready(Path(permit['vendorlink_predecessor']), live,
                                 permit.get('vendorlink_g1_only_accepted', False)):
            write(args.job/'status.json', dict(status='WAITING_VENDORLINK_NO_WORKER_STARTED',
                  reason='Accepted VendorLink qualification scope must succeed and related workers must exit'))
            return
        if not permit.get('implementation_review_closed'):
            write(args.job/'status.json', dict(status='WAITING_IMPLEMENTATION_REVIEW_NO_WORKER_STARTED'))
            return
        resource = resources()
        write(args.job/'admission.json', resource)
        if (resource['free_gpu_bytes'] < 10*slots*GIB or resource['ram_available_bytes'] < 64*slots*GIB
                or resource['disk_free_bytes'] < 160*GIB):
            write(args.job/'status.json', dict(status='WAITING_RESOURCES_NO_WORKER_STARTED',
                  reason=f'{slots} slot(s) reserve 10 GiB GPU and 64 GiB RSS each, and 96+64 GiB disk',
                  formal_training=False))
            return
    bucket = 'cpu_seconds' if args.mode == 'cpu' else 'gpu_seconds'
    cap = permit[bucket]-ledger[bucket]
    if cap <= 0:
        raise RuntimeError('Qualification bucket exhausted')
    env = dict(os.environ, OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
               TOKENIZERS_PARALLELISM='false', PYTHONDONTWRITEBYTECODE='1', CUBLAS_WORKSPACE_CONFIG=':4096:8')
    children, logs, started = [], [], time.monotonic()
    if args.mode == 'cpu':
        env.update(CUDA_VISIBLE_DEVICES='', FOREVER_TEST_TMP=str(args.job.resolve()),
                   FOREVER_TEST_REPORT=str((args.job/'evidence.json').resolve()))
        commands = [[sys.executable, '-B', str(root/'tests/test_step28_forever.py')]]
    else:
        env['CUDA_VISIBLE_DEVICES'] = '0'
        commands = [[sys.executable, '-B', str(Path(__file__).resolve()), '--mode', 'worker',
                     '--job', str(args.job), '--slot', str(i), '--deadline', str(time.monotonic()+cap),
                     '--permit', str(args.permit)] for i in range(slots)]
        write(args.job/'gpu_dispatch.json', dict(controller_pid=os.getpid(),
              permit_sha256=hashlib.sha256(args.permit.read_bytes()).hexdigest(),
              prior_optimizer_calls=ledger['optimizer_calls'], slots=slots))
    peaks = dict(rss_bytes=0, disk_bytes=0)
    last_sample = 0.
    stopped = None
    def timeout(signum, frame):
        raise TimeoutError('Cumulative qualification deadline including exit reserve')
    old_handler = signal.signal(signal.SIGALRM, timeout)
    def arm(additional=0):
        elapsed = elapsed_workers(children)
        active = sum(r['process'].poll() is None for r in children)+additional
        if active:
            signal.setitimer(signal.ITIMER_REAL, budget_delay(cap, elapsed, active))
    try:
        def launch(index):
            command = commands[index]
            stream = (args.job/f'console{index}.txt').open('w')
            logs.append(stream)
            begin = time.monotonic()
            child = subprocess.Popen(command, cwd=root, env=env, stdout=stream, stderr=subprocess.STDOUT,
                                     start_new_session=True)
            children.append(dict(process=child, started=begin, ended=None, slot=index))
        arm(1)
        launch(0)
        while any(row['process'].poll() is None for row in children):
            arm()
            if args.mode == 'gpu' and slots == 3 and len(children) == 1 and (args.job/'main_ready.json').exists():
                main = children[0]['process']
                process = psutil.Process(main.pid)
                used = subprocess.check_output(['nvidia-smi', '--id=0',
                    '--query-compute-apps=pid,used_memory', '--format=csv,noheader,nounits'], text=True, timeout=2)
                main_gpu = sum(int(parts[1])*2**20 for line in used.splitlines()
                               if len(parts := line.split(',')) == 2 and int(parts[0]) == main.pid)
                main_rss = sum(p.memory_info().rss for p in [process, *process.children(recursive=True)])
                disk_used = sum(p.stat().st_size for p in args.job.rglob('*') if p.is_file())
                admission = auxiliary_admission(resources(), main_gpu, main_rss, disk_used)
                write(args.job/'aux_admission.json', admission)
                if main.poll() is not None or not admission['ready']:
                    stopped = 'AUXILIARY_RESOURCE_CHANGED'
                    break
                arm(2)  # Reserve both pending slots once, before either Popen.
                launch(1)
                launch(2)
            elapsed, rss = 0., 0
            for row in children:
                p = row['process']
                if p.poll() is not None and row['ended'] is None:
                    row['ended'] = time.monotonic()
                elapsed += (row['ended'] or time.monotonic())-row['started']
                if p.poll() is None:
                    try:
                        process = psutil.Process(p.pid)
                        resident = sum(v.memory_info().rss for v in [process, *process.children(recursive=True)])
                        rss += resident
                        if resident > (4 if args.mode == 'cpu' else 64)*GIB:
                            stopped = 'RSS_CAP'
                    except psutil.NoSuchProcess:
                        pass
                elif p.returncode != 0:
                    stopped = 'CHILD_FAILURE'
            files = [p for p in args.job.rglob('*') if p.is_file()]
            disk = sum(p.stat().st_size for p in files)
            peaks['rss_bytes'], peaks['disk_bytes'] = max(peaks['rss_bytes'], rss), max(peaks['disk_bytes'], disk)
            calls = sum(len(p.read_text().splitlines()) for p in args.job.glob('slot*/calls.jsonl'))
            if disk > (64*2**20 if args.mode == 'cpu' else 96*GIB):
                stopped = 'DISK_CAP'
            if args.mode == 'gpu' and time.monotonic()-last_sample > 2:
                last_sample = time.monotonic()
                snapshot = resources()
                with (args.job/'resource_samples.jsonl').open('a') as stream:
                    stream.write(json.dumps(snapshot)+'\n')
                if snapshot['disk_free_bytes'] < 64*GIB or rss > 64*slots*GIB:
                    stopped = 'SHARED_RESOURCE_CAP'
            if stopped:
                break
            time.sleep(.2)
    except Exception as error:
        stopped = f'{type(error).__name__}: {error}'
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, old_handler)
        try:
            stop_children(children)
        except RuntimeError as error:
            stopped = str(error)
        for row in children:
            row['ended'] = row['ended'] or time.monotonic()
        for stream in logs:
            stream.close()
        charged = math.ceil(sum(row['ended']-row['started'] for row in children))
        calls = sum(len(p.read_text().splitlines()) for p in args.job.glob('slot*/calls.jsonl'))
        ledger[bucket] += charged
        ledger['optimizer_calls'] += calls
        if charged > cap:
            stopped = 'ACTUAL_TIME_CAP_EXCEEDED'  # Never clamp or discard actual tail consumption.
        receipt = dict(mode=args.mode, job=str(args.job), charged_seconds=charged, optimizer_calls=calls,
                       children=[dict(slot=r['slot'], pid=r['process'].pid, exit_code=r['process'].returncode,
                                      elapsed_seconds=r['ended']-r['started']) for r in children],
                       status='PASS' if stopped is None and children and all(r['process'].returncode == 0 for r in children) else 'STOP',
                       reason=stopped, peaks=peaks, wall_seconds=time.monotonic()-started,
                       formal_data_reads=0, formal_training=False)
        if args.mode == 'gpu' and receipt['status'] == 'PASS':
            try:
                results = [json.loads((args.job/f'slot{i}/result.json').read_text()) for i in range(slots)]
                overlap = compute_overlap([r['update_intervals'] for r in results]) if slots == 3 else None
                receipt.update(qualified_slots=slots, three_worker_compute_overlap_seconds=overlap)
                if (calls != 39+3*(slots-1) or (slots == 3 and overlap <= 0)
                        or any(r['status'] != 'PASS_BOUNDED_NATIVE_SLOT' for r in results)):
                    receipt.update(status='STOP', reason='NATIVE_EVIDENCE_INCOMPLETE')
            except (OSError, ValueError, KeyError) as error:
                receipt.update(status='STOP', reason='NATIVE_EVIDENCE_MISSING', detail=repr(error))
        ledger['attempts'].append(receipt)
        write(ledger_path, ledger)
        write(args.job/'receipt.json', receipt)
    if receipt['status'] != 'PASS':
        raise RuntimeError('Bounded qualification stopped; failures remain charged')


def worker(args) -> None:
    # Imported only inside explicitly authorized Linux GPU workers.
    import torch
    import step28_forever as m
    import step28_forever_run as run
    from step28_comparison_native import group
    from test_step28_forever import dispatcher
    permit = json.loads(args.permit.read_text())
    dispatch = json.loads((args.job/'gpu_dispatch.json').read_text())
    if (not permit.get('implementation_review_closed') or not psutil.pid_exists(dispatch['controller_pid'])
            or dispatch['permit_sha256'] != hashlib.sha256(args.permit.read_bytes()).hexdigest()):
        raise ValueError('GPU worker requires the reviewed active qualification dispatch')
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    m.parent.configure_numerics()
    torch.cuda.set_per_process_memory_fraction(8.5*GIB/torch.cuda.get_device_properties(0).total_memory)
    job = args.job/f'slot{args.slot}'
    job.mkdir()
    allowed_calls = 39 if args.slot == 0 else 3
    calls, rows = [], []
    def check(reserve=0):
        if time.monotonic() >= args.deadline-5:
            raise TimeoutError('Qualification deadline')
        if psutil.Process().memory_info().rss > 64*GIB:
            raise RuntimeError('Worker RSS cap')
    def physical():
        if len(calls) >= allowed_calls:
            raise RuntimeError('Fixed per-slot physical update allocation exhausted')
        calls.append(dict(attempt=len(calls)+1, epoch=time.time()))
        with (job/'calls.jsonl').open('a') as stream:
            stream.write(json.dumps(calls[-1])+'\n')
    def log(row):
        rows.append(row)
        log_update(job/'updates.jsonl', row)
    def timed(label, fn):
        check()
        torch.cuda.synchronize()
        begin = time.monotonic()
        write(job/'phase.json', dict(phase=label, epoch=time.time()))
        value = fn()
        torch.cuda.synchronize()
        timings[label] = time.monotonic()-begin
        intervals[label] = dict(started=begin, ended=time.monotonic())
        return value
    timings, intervals = {}, {}
    spec = m.Spec('ABC', 4)
    c = m.config(spec)
    # Pretrained identity is checked before loading; only the existing archive is used.
    archive = m.core.model_files(m.record.base.model_config(c, 'split_rank'))
    if any(archive[k] != c['models']['split_rank'][k] for k in ('file_count', 'total_size_bytes', 'content_sha256')):
        raise ValueError('Pinned BGE archive differs')
    model, optimizer = timed('load', lambda: m.fresh(spec, c))
    if not torch.cuda.is_bf16_supported() or not model.encoder[0].auto_model.is_gradient_checkpointing:
        raise ValueError('Native BF16 and existing encoder checkpointing required')
    learner = m.Learner(spec, model, optimizer, c)
    current = group('forever_current', 0)
    old = [group(f'forever_old_{i}', 48+i) for i in range(6)]
    for g in [current, *old]:
        ids = model.encoder.tokenizer(m.record.base.record_texts(g, 'separate_moments'),
                                     padding=False, truncation=False)['input_ids']
        if len(ids) != 448 or set(map(len, ids)) != {256}:
            raise ValueError('Actual maximum 224-record/two-channel/256-token shape absent')
    timed('fixture', lambda: log(learner.update(old[0], 'fixture', check=check, before_step=physical)))
    learner.anchor = m.snapshot(model)
    learner.old.add_stage(old)
    learner.old.seen = 48  # Explicit qualification-only stage-2 reservoir fixture, no invented Adam steps.
    learner.stage = 2
    supply = dispatcher(spec)  # Handwritten tiny dispatcher only, never the formal archive.
    supply.supply.next_stage[spec.run_id] = 2
    supply.current(2)
    identity = dict(spec=spec.identity(), config=c, qualification_only=True,
                    sources=json.loads(args.permit.read_text())['sources'])
    store = run.Store(job/'state', identity, check)
    if args.slot == 0:
        for i in range(23):
            timed(f'current{i+1}', lambda: learner.advance(current, check, physical, log))
        write(args.job/'main_ready.json', dict(epoch=time.time()))
        while dispatch['slots'] == 3 and not all((args.job/f'aux_ready{i}.json').exists() for i in (1, 2)):
            check()
            time.sleep(.1)
        write(args.job/'compute_start.json', dict(epoch=time.time()))
        # One real event checkpoint, timed independently; no duplicate full save at the same state.
        timed('current24_and_replay', lambda: learner.advance(current, check, physical, log,
                    lambda: timed('full_commit', lambda: store.commit(learner, supply))))
        if learner.clock.next_threshold != 1 or learner.counts != dict(current=24, replay=12, fixture=1):
            raise ValueError('Full production calibration and first two replay epochs missing')
        timed('uninterrupted_next', lambda: log(learner.update(current, 'current', check=check, before_step=physical)))
        expected = m.core.state_digest(dict(model=model.state_dict(), optimizer=optimizer.state_dict(),
                                           state=learner.small(), rng=m.diag.rng_state()))
        # Restore in place, without a second GPU model or fabricated optimizer counter.
        supply = dispatcher(spec)
        timed('full_restore', lambda: store.restore(learner, supply))
        timed('restored_next', lambda: log(learner.update(current, 'current', check=check, before_step=physical)))
        actual = m.core.state_digest(dict(model=model.state_dict(), optimizer=optimizer.state_dict(),
                                         state=learner.small(), rng=m.diag.rng_state()))
        if actual != expected:
            raise ValueError('Actual next BGE model/Adam/clock/cursor/RNG differ after restoration')
        write(args.job/'main_done.json', dict(epoch=time.time()))
    else:
        write(args.job/f'aux_ready{args.slot}.json', dict(epoch=time.time()))
        while not (args.job/'compute_start.json').exists():
            check()
            time.sleep(.1)
        timed('overlap_current', lambda: log(learner.update(current, 'current', check=check, before_step=physical)))
        # Auxiliary replay tests the same production kernel at fixed beta; no calibrated-clock claim.
        timed('overlap_replay', lambda: log(learner.update(old[0], 'replay', ('aux',), .001, check, physical)))
        while not (args.job/'main_done.json').exists():
            check()
            time.sleep(.1)  # Deliberate residency through main save/restore; this wall time is charged.
    if not all(any(r.get('displacement') and r['displacement'][role] > 0 for r in rows) for role in ('encoder', 'head')):
        raise ValueError('Native current encoder/head displacement not demonstrated')
    if not any(r.get('regularizer') and r['regularizer']['penalty'] > 0 for r in rows):
        raise ValueError('Native nonzero anchor regularization not demonstrated')
    write(job/'result.json', dict(status='PASS_BOUNDED_NATIVE_SLOT', slot=args.slot, qualification_only=True,
          fixture_predecessor_updates=1, physical_calls=len(calls), logical_counts=learner.counts,
          actual_adam_step=m.parent.adam_step(optimizer), timings=timings, intervals=intervals,
          update_intervals=[r['compute_interval'] for r in rows if r['role'] in ('current', 'replay')],
          parameters=m.mapping(model, optimizer),
          anchor_bytes=sum(t.numel()*t.element_size() for t in learner.anchor.values()),
          history_bytes=learner.historical_bytes(), maximum_group=dict(records=224, channels=2, tokens=256),
          peak_allocated_bytes=torch.cuda.max_memory_allocated(), peak_reserved_bytes=torch.cuda.max_memory_reserved(),
          formal_data_reads=0, untested='Remaining production events, full stages, formal data and end calibration'))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=('cpu', 'gpu', 'worker'), required=True)
    parser.add_argument('--job', type=Path, required=True)
    parser.add_argument('--permit', type=Path, required=True)
    parser.add_argument('--slot', type=int, choices=(0, 1, 2))
    parser.add_argument('--deadline', type=float)
    args = parser.parse_args()
    if args.mode == 'worker':
        sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'tests'))
        verify(Path(__file__).resolve().parents[1], json.loads(args.permit.read_text()))
        worker(args)
    else:
        supervise(args)
