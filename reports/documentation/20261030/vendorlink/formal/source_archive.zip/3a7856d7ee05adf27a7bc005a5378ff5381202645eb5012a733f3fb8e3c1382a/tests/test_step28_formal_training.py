"""Linux-only handwritten evidence for the two new formal training entries."""
import copy
import json
import os
from pathlib import Path
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'scripts'))
import step28_formal_queue as queue
import step28_forever_formal as forever
import step29_vendorlink_run as vendor_run
import step29_vendorlink_formal as vendor
from test_step28_forever import fixture as forever_fixture, dispatcher
from test_step29_vendorlink import fixture as vendor_fixture, model_for

EVIDENCE = {}


class FormalTrainingTests(unittest.TestCase):
    def test_compact_vendor_endpoints_preserve_actual_trajectory_and_scores(self):
        for name in ('VendorLink_SEQ', 'H_full'):
            with tempfile.TemporaryDirectory() as temp:
                root = Path(temp)
                initial = model_for(name, root)
                scores, states, updates = [], [], []
                for compact in (False, True):
                    model = copy.deepcopy(initial)
                    job = root/str(compact)
                    vendor_run.execute(model, lambda domain: [vendor_fixture(domain)], job, order='ABC', seed=4, epochs=2,
                        identity={'handwritten': True}, inference_endpoints=compact)
                    scores.append(vendor_run.evaluate(model, [vendor_fixture('C', 'heldout').blind()]))
                    updates.append((job/'updates.jsonl').read_bytes())
                    states.append([torch.load(job/f'stage{i}.pt', map_location='cpu', weights_only=False)
                                   for i in (1, 2, 3)])
                self.assertEqual(updates[0], updates[1])
                self.assertEqual(scores[0], scores[1])
                for old, compact in zip(states[0], states[1], strict=True):
                    self.assertNotIn('optimizer', compact)
                    self.assertNotIn('memory', compact)
                    self.assertEqual(old['model'].keys(), compact['model'].keys())
                    for key in old['model']:
                        torch.testing.assert_close(old['model'][key], compact['model'][key], rtol=0, atol=0)
                EVIDENCE[name] = dict(three_actual_stages=True, compact_vs_full_models_equal=True,
                                     real_update_logs_and_blind_scores_equal=True)

    def test_calibration_failure_preserves_actual_fit_before_raising(self):
        learner = forever_fixture()
        learner.phase = 'endpoint'
        supplied = dispatcher(learner.spec)
        _, calibration = supplied.current(1)
        with tempfile.TemporaryDirectory() as temp:
            store = forever.run.Store(Path(temp), {'handwritten': True})
            detail = dict(status='HANDWRITTEN_FIT_FAILURE', reason='known injected fit failure', a=2, b=3)
            with patch.object(forever.m.parent.calibration, 'fit', return_value=detail):
                with self.assertRaisesRegex(ValueError, 'Current calibration failed'):
                    forever.run.endpoint(learner, calibration, store)
            saved = list((Path(temp)/'maps').glob('*.json'))
            self.assertEqual(len(saved), 1)
            self.assertEqual(json.loads(saved[0].read_text()), detail)
            self.assertFalse(list((Path(temp)/'models').glob('*.pt')))
            EVIDENCE['calibration_failure'] = dict(real_score_path=True, failure_detail_saved=True,
                                                   no_success_endpoint=True)

    def test_single_queue_failure_charged_and_next_child_not_launched(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            allowed = dict(campaign=str(root/'batch'), workspace=str(root), prior_used_seconds=dict(training=7., control=0.),
                           budget_seconds=dict(training=200., control=30.))
            rows = [dict(id='fail', seconds=90), dict(id='must_not_run', seconds=90)]
            def command(row, job, deadline):
                return [sys.executable, '-c', 'import sys;sys.exit(2)']
            with patch.object(queue, 'resources', return_value={'ready': True}):
                with self.assertRaisesRegex(RuntimeError, 'Worker failed'):
                    queue.dispatch(allowed, rows, command, lambda row, job: self.fail('Failed child cannot validate'))
            saved = json.loads((root/'batch/failure.json').read_text())
            self.assertEqual(len(saved['completed']), 1)
            self.assertFalse(saved['completed'][0]['success'])
            self.assertGreater(saved['used']['training'], 7)
            self.assertFalse((root/'batch/must_not_run').exists())
            EVIDENCE['serial_failure'] = dict(real_process_exit=2, next_not_dispatched=True,
                                             inherited_seconds=7, actual_seconds=saved['used']['training'])

    def test_forever_real_formal_three_stage_flow_on_handwritten_tiny_model(self):
        learner = forever_fixture()
        spec = learner.spec
        supplied = dispatcher(spec)
        partition = supplied.supply.partition
        archive = dict(file_count=1, total_size_bytes=1, content_sha256='handwritten')
        c = dict(learner.c, models={'split_rank': archive})
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            job = root/spec.run_id
            job.mkdir()
            allowed = dict(campaign=str(root), sources=[dict(handwritten=True)], limits=dict(
                rss_bytes=4 * 2**30, disk_bytes=64 * 2**20, small_bytes=32 * 2**20,
                free_reserve_bytes=1, allocator_bytes=1))
            with patch.object(forever.m, 'config', return_value=c), \
                 patch.object(forever.m.five.base, 'model_config', return_value={}), \
                 patch.object(forever.m.core, 'model_files', return_value=archive), \
                 patch.object(forever.run, 'training_inputs', return_value=(supplied.supply, partition, {'handwritten': True})), \
                 patch.object(forever.m, 'fresh', return_value=(learner.model, learner.optimizer)), \
                 patch.object(torch.cuda, 'set_per_process_memory_fraction'), \
                 patch.object(torch.cuda, 'get_device_properties', return_value=type('P', (), {'total_memory': 1})()), \
                 patch.object(torch, 'set_num_interop_threads'):
                result = forever.execute(job, spec, time.monotonic() + 450, allowed)
            self.assertEqual(result['counts']['current'], 864)
            self.assertEqual(result['counts']['fixture'], 0)
            self.assertGreater(result['counts']['replay'], 0)
            self.assertEqual(set(result['points']), {'1', '2', '3'})
            self.assertFalse((job/'run/latest.json').exists())
            self.assertFalse(list((job/'run/work').glob('*.pt')))
            self.assertFalse(list((job/'run/anchors').glob('*.pt')))
            self.assertEqual(len(list((job/'run/models').glob('*.pt'))), 3)
            rows = [json.loads(line) for line in (job/'run/updates.jsonl').read_text().splitlines()]
            self.assertEqual(sum(r['role'] == 'current' for r in rows), 864)
            self.assertTrue(any(r['role'] == 'replay' and r['regularizer']['penalty'] > 0 for r in rows))
            # A missing actual endpoint must invalidate the batch even with the old success JSON.
            next((job/'run/models').glob('*.pt')).unlink()
            with self.assertRaises((FileNotFoundError, ValueError)):
                forever.validate_completion(spec, job/'run', allowed)
            EVIDENCE['forever_formal'] = dict(real_current_updates=864, counts=result['counts'],
                real_three_stage_calibration_and_restore=True, successful_cleanup=True,
                missing_endpoint_rejected=True, not_native_or_formal_data=True)


if __name__ == '__main__':
    if sys.platform != 'linux':
        raise SystemExit('Research tests run only in Linux py310')
    torch.set_num_threads(1)
    suite = (unittest.defaultTestLoader.loadTestsFromNames(sys.argv[1:], sys.modules[__name__])
             if len(sys.argv) > 1 else unittest.defaultTestLoader.loadTestsFromTestCase(FormalTrainingTests))
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    if os.environ.get('FORMAL_TEST_EVIDENCE'):
        queue.write(Path(os.environ['FORMAL_TEST_EVIDENCE']), dict(evidence=EVIDENCE,
            tests_run=result.testsRun, failures=len(result.failures), errors=len(result.errors)))
    raise SystemExit(not result.wasSuccessful())
